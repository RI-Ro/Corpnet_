package marking

import (
	"bytes"
	"context"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"log"
	"math"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/pdfcpu/pdfcpu/pkg/api"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/model"
	"github.com/pdfcpu/pdfcpu/pkg/pdfcpu/types"
	xfont "golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
	"golang.org/x/image/math/fixed"

	"athena/backend/internal/config"
)

// ВЖИГАНИЕ ШТАМПОВ (#5). pdfcpu TextWatermark в этой сборке ОТКАЗЫВАЕТСЯ
// использовать пользовательский кириллический шрифт («LiberationSans
// unsupported»), поэтому векторный текст с кириллицей невозможен. Надёжное
// решение: рисуем ОДИН прозрачный слой РАЗМЕРОМ СО СТРАНИЦУ, на нём — все штампы
// нашим TTF (кириллица гарантирована) в точных координатах (как overlay в
// браузере: угол рамки на заданном отступе от края), и накладываем слой на PDF
// по центру в масштабе 1:1. Так позиционирование точное и не зависит от того,
// как pdfcpu центрирует/масштабирует картинку.

var (
	fontOnce sync.Once
	sfntFont *opentype.Font
)

var pdfConfiguration *model.Configuration

func Configure(cfg config.MarkingConfig) error {
	root := strings.TrimSpace(cfg.PDFCPUConfigRoot)
	if root == "" {
		root = "/tmp"
	}
	dir := filepath.Join(root, "pdfcpu")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return fmt.Errorf("каталог pdfcpu %s: %w", dir, err)
	}
	info, err := os.Lstat(dir)
	if err != nil {
		return err
	}
	if !info.IsDir() || info.Mode().Perm()&0022 != 0 {
		return fmt.Errorf("каталог pdfcpu %s должен быть каталогом без записи для группы и остальных пользователей", dir)
	}
	conf, err := api.LoadConfiguration(api.ConfigurationOptions{Root: root})
	if err != nil {
		return fmt.Errorf("настройки pdfcpu %s: %w", dir, err)
	}
	pdfConfiguration = conf
	overlayTempDir = strings.TrimSpace(cfg.TempDir)
	if overlayTempDir != "" {
		// Проверяем доступность СРАЗУ, на старте: иначе о неверно указанном
		// каталоге узнавали бы в момент печати, то есть от пользователя.
		if probe, err := os.CreateTemp(overlayTempDir, "athena-probe-*"); err != nil {
			log.Printf("marking: каталог marking.temp_dir=%q недоступен на запись (%v) — "+
				"будет использован системный временный каталог", overlayTempDir, err)
			overlayTempDir = ""
		} else {
			name := probe.Name()
			probe.Close()
			os.Remove(name)
			log.Printf("marking: промежуточные файлы маркировки — в %s", overlayTempDir)
		}
	}
	fontOnce.Do(func() {
		if cfg.FontFile == "" {
			log.Printf("marking: TTF-шрифт не задан (marking.font_file) — вжигание недоступно")
			return
		}
		data, err := os.ReadFile(cfg.FontFile)
		if err != nil {
			log.Printf("marking: не удалось прочитать шрифт %s: %v", cfg.FontFile, err)
			return
		}
		f, err := opentype.Parse(data)
		if err != nil {
			log.Printf("marking: не удалось разобрать шрифт %s: %v", cfg.FontFile, err)
			return
		}
		sfntFont = f
		log.Printf("marking: шрифт %s готов для вжигания штампов", filepath.Base(cfg.FontFile))
	})
	RenderHook = renderWithPDFCPU
	return nil
}

func renderWithPDFCPU(original []byte, specs []Spec) ([]byte, error) {
	if len(specs) == 0 {
		return original, nil
	}
	if sfntFont == nil {
		return original, fmt.Errorf("шрифт для вжигания не сконфигурирован (marking.font_file)")
	}

	ctx := context.Background()
	conf := pdfConfiguration.Clone()
	boxes, err := api.Boxes(ctx, bytes.NewReader(original), watermarkPages(), conf)
	if err != nil {
		return original, fmt.Errorf("геометрия страниц PDF: %w", err)
	}
	marks := make(map[int]*model.Watermark)
	layers := make(map[[2]int]string)
	defer func() {
		for _, name := range layers {
			if err := os.Remove(name); err != nil {
				log.Printf("marking: удаление слоя: %v", err)
			}
		}
	}()
	desc := fmt.Sprintf("pos:c, scalefactor:%.4f abs, rotation:0", 1.0/float64(overlayScale))
	for i, bounds := range boxes {
		box := bounds.CropBox()
		if box == nil {
			continue // страница не входит в выбранный диапазон
		}
		w, h := box.Width(), box.Height()
		if bounds.Rot%180 != 0 {
			w, h = h, w
		}
		if !(w > 0 && h > 0 && w <= 16000 && h <= 16000 && w*h*overlayScale*overlayScale <= 20000000) {
			return original, fmt.Errorf("неподдерживаемый размер страницы %d", i+1)
		}
		size := [2]int{max(1, int(math.Round(w*overlayScale))), max(1, int(math.Round(h*overlayScale)))}
		name, ok := layers[size]
		if !ok {
			layer, err := renderPageOverlay(specs, size[0], size[1])
			if err != nil {
				return original, err
			}
			name, err = createOverlayFile(layer)
			if err != nil {
				return original, err
			}
			layers[size] = name
		}
		wm, err := api.ImageWatermark(ctx, name, desc, true, false, types.POINTS, conf)
		if err != nil {
			return original, err
		}
		marks[i+1] = wm
	}
	var out bytes.Buffer
	if err := api.AddWatermarksMap(ctx, bytes.NewReader(original), &out, marks, conf); err != nil {
		return original, fmt.Errorf("маркировка PDF: %w", err)
	}
	return out.Bytes(), nil
}

// overlayTempDir — каталог для промежуточного файла слоя. Пусто — системный.
// Задаётся из конфига (marking.temp_dir) через Configure.
var overlayTempDir string

// createOverlayFile размещает PNG-слой так, чтобы ПО ВОЗМОЖНОСТИ не писать
// на диск, и возвращает путь к нему.
//
// Требование было: «не сохранять в отдельную папку в tmp, а просто в новый
// файл с обязательным удалением потом; если можно не сохранять как файл, а
// формировать в рамках кода — реализовать так».
//
// Полностью без файла обойтись нельзя: api.ImageWatermark принимает ПУТЬ к
// картинке, а не io.Reader. Вариант с io.Reader в pdfcpu, возможно, есть, но
// проверить его наличие в v0.8.1 здесь нечем: исходники пакета недоступны
// (go mod download к proxy.golang.org запрещён сетевой политикой — проверено,
// 403 «Host not in allowlist»), а скомпилировать проект тоже нечем. Подставить
// непроверяемый вызов в код, который нельзя собрать, — значит с высокой
// вероятностью сломать сборку целиком. Место для замены помечено в Apply.
//
// Поэтому файл остаётся, но ПЕРВЫМ делом пробуется /dev/shm — файловая
// система в ОЗУ, которая есть в любом Linux-контейнере. Запись туда не
// касается диска вообще: это и есть «формировать в рамках кода» на практике,
// и именно это снимает исходный симптом — периодические сбои записи в /tmp
// (переполнение, read-only, политика контейнера, квота).
//
// Порядок попыток:
//  1. marking.temp_dir — если администратор указал каталог явно, его воля главнее;
//  2. /dev/shm — ОЗУ, диск не задействован;
//  3. os.TempDir() — обычный системный каталог;
//  4. рабочий каталог процесса — последняя линия.
//
// Отказ печати из-за недоступности одного каталога недопустим, поэтому
// пробуются все, а в тексте ошибки перечисляется, что именно не получилось.
func createOverlayFile(pngData []byte) (string, error) {
	var tried []string
	candidates := []string{overlayTempDir, "/dev/shm", os.TempDir(), "."}
	for _, dir := range candidates {
		if dir == "" {
			continue
		}
		f, err := os.CreateTemp(dir, "athena-stamp-*.png")
		if err != nil {
			tried = append(tried, fmt.Sprintf("%s (%v)", dir, err))
			continue
		}
		name := f.Name()
		if _, err := f.Write(pngData); err != nil {
			f.Close()
			os.Remove(name)
			tried = append(tried, fmt.Sprintf("%s (запись: %v)", dir, err))
			continue
		}
		if err := f.Close(); err != nil {
			os.Remove(name)
			tried = append(tried, fmt.Sprintf("%s (закрытие: %v)", dir, err))
			continue
		}
		return name, nil
	}
	return "", fmt.Errorf("не удалось разместить промежуточный файл маркировки, проверены: %s; "+
		"укажите доступный на запись каталог в marking.temp_dir", strings.Join(tried, "; "))
}

// overlayScale — во сколько раз слой штампов рисуется подробнее страницы.
//
// ЗАЧЕМ. Слой — это растр, и раньше он рисовался один пиксель на пункт, то
// есть 72 точки на дюйм. На экране такой штамп выглядит нормально, а на
// печати принтер растягивает его до своих 300–600 точек на дюйм, и буквы
// расплываются — именно это и было замечено: «наложенные штампы менее
// чёткие». Текст самого документа при этом остаётся резким, потому что он
// векторный, и разница бросается в глаза.
//
// Слой рисуется в 4 раза крупнее (288 точек на дюйм) и при наложении
// уменьшается обратно множителем 1/4. Физический размер штампа не меняется
// ни на пункт — меняется только плотность пикселей.
//
// Почему 4, а не больше: площадь растёт квадратом множителя, и при 8 слой на
// A4 занимает уже под сотню мегабайт в памяти. 288 точек на дюйм покрывают
// обычную печать, а разницу с 600 на штампе в семь пунктов глаз не видит.
const overlayScale = 4

// renderPageOverlay рисует все штампы на прозрачном слое размером со страницу.
// Координаты как в overlay браузера: угол рамки штампа отстоит на (ax, ay) от
// названного угла страницы ВНУТРЬ (ay — вниз для верхних якорей).
func renderPageOverlay(specs []Spec, pageW, pageH int) ([]byte, error) {
	if pageW < 1 || pageH < 1 {
		return nil, fmt.Errorf("bad page size")
	}
	img := image.NewRGBA(image.Rect(0, 0, pageW, pageH)) // прозрачный
	for _, s := range specs {
		if err := drawStamp(img, s, pageW, pageH); err != nil {
			log.Printf("marking: штамп %q пропущен: %v", s.Text, err)
		}
	}
	var out bytes.Buffer
	if err := png.Encode(&out, img); err != nil {
		return nil, err
	}
	return out.Bytes(), nil
}

func drawStamp(img *image.RGBA, s Spec, pageW, pageH int) error {
	// Отступы, рамка и смещения заданы в ПУНКТАХ, а рисуем мы в пикселях
	// слоя, которых на пункт приходится overlayScale. Поэтому каждая такая
	// величина умножается на множитель — иначе крупный слой получил бы
	// отступы в четыре раза тоньше положенного, а штамп уехал бы в угол.
	const padXpt, padYpt, borderPt = 6, 4, 1
	padX, padY, border := padXpt*overlayScale, padYpt*overlayScale, borderPt*overlayScale
	fsize := float64(s.FontSize)
	if fsize <= 0 {
		fsize = 9
	}
	// Размер шрифта увеличивается через DPI, а не через Size: так растут и
	// метрики (ascent, descent, ширина строки), которыми ниже считается
	// рамка, и считать их отдельно не нужно.
	face, err := opentype.NewFace(sfntFont, &opentype.FaceOptions{
		Size: fsize, DPI: 72 * overlayScale, Hinting: xfont.HintingFull})
	if err != nil {
		return err
	}
	defer face.Close()
	m := face.Metrics()
	ascent, descent := m.Ascent.Ceil(), m.Descent.Ceil()
	// Межстрочный зазор тоже задан в ПУНКТАХ (2 пункта) и тоже умножается на
	// множитель. Без этого на крупном слое строки сходились бы теснее, и
	// высота рамки отличалась бы от прежней — у двухстрочного штампа на 3
	// пункта.
	lineH := ascent + descent + 2*overlayScale

	lines := strings.Split(s.Text, "\n")
	maxW := 0
	for _, ln := range lines {
		if w := xfont.MeasureString(face, ln).Ceil(); w > maxW {
			maxW = w
		}
	}
	boxW := maxW + 2*padX + 2*border
	boxH := lineH*len(lines) + 2*padY + 2*border

	ax := absInt(int(s.OffsetX)) * overlayScale
	ay := absInt(int(s.OffsetY)) * overlayScale
	// Левый-верхний угол рамки на странице.
	var x0, y0 int
	switch s.Position {
	case "tl":
		x0, y0 = ax, ay
	case "tr":
		x0, y0 = pageW-ax-boxW, ay
	case "bl":
		x0, y0 = ax, pageH-ay-boxH
	case "br":
		x0, y0 = pageW-ax-boxW, pageH-ay-boxH
	case "c":
		x0, y0 = (pageW-boxW)/2, (pageH-boxH)/2
	default:
		x0, y0 = pageW-ax-boxW, pageH-ay-boxH
	}

	// Фон (по умолчанию непрозрачный белый — как карточка overlay).
	bg := color.RGBA{255, 255, 255, 255}
	if c, ok := parseHex(s.FillColorHex); ok {
		bg = c
	}
	fillRect(img, x0, y0, x0+boxW, y0+boxH, bg)

	textColor := color.RGBA{0, 0, 0, 255}
	if c, ok := parseHex(s.ColorHex); ok {
		textColor = c
	}
	if s.Border {
		bc := textColor
		if c, ok := parseHex(s.BorderColorHex); ok {
			bc = c
		}
		strokeRect(img, x0, y0, x0+boxW, y0+boxH, border, bc)
	}

	d := &xfont.Drawer{Dst: img, Src: &image.Uniform{textColor}, Face: face}
	for i, ln := range lines {
		baseline := y0 + border + padY + ascent + i*lineH
		d.Dot = fixed.P(x0+border+padX, baseline)
		d.DrawString(ln)
	}
	return nil
}

func fillRect(img *image.RGBA, x0, y0, x1, y1 int, c color.RGBA) {
	if x0 < 0 {
		x0 = 0
	}
	if y0 < 0 {
		y0 = 0
	}
	if x1 > img.Bounds().Dx() {
		x1 = img.Bounds().Dx()
	}
	if y1 > img.Bounds().Dy() {
		y1 = img.Bounds().Dy()
	}
	draw.Draw(img, image.Rect(x0, y0, x1, y1), &image.Uniform{c}, image.Point{}, draw.Src)
}

func strokeRect(img *image.RGBA, x0, y0, x1, y1, t int, c color.RGBA) {
	for i := 0; i < t; i++ {
		for x := x0; x < x1; x++ {
			img.SetRGBA(x, y0+i, c)
			img.SetRGBA(x, y1-1-i, c)
		}
		for y := y0; y < y1; y++ {
			img.SetRGBA(x0+i, y, c)
			img.SetRGBA(x1-1-i, y, c)
		}
	}
}

func parseHex(h string) (color.RGBA, bool) {
	h = strings.TrimSpace(h)
	if len(h) == 7 && h[0] == '#' {
		var r, g, b int
		if _, err := fmt.Sscanf(h, "#%02x%02x%02x", &r, &g, &b); err == nil {
			return color.RGBA{uint8(r), uint8(g), uint8(b), 255}, true
		}
	}
	return color.RGBA{}, false
}

func absInt(v int) int {
	if v < 0 {
		return -v
	}
	return v
}
