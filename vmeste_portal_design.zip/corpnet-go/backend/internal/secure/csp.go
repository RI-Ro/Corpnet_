package secure

import "strings"

// CSPOptions — настройка политики. Нулевое значение даёт строгую политику для SPA, обслуживаемой с того же origin.
type CSPOptions struct {
	// Extra — дополнительные директивы целиком, через «;» (например, "img-src 'self' https://cdn.example.com"):
	// директива с тем же именем заменяет стандартную.
	Extra string
}

// CSP собирает Content-Security-Policy для приложения:
//   - скрипты только свои (без inline/eval; 'wasm-unsafe-eval' нужен pdf.js для декодеров изображений);
//   - стили свои + inline (React style=…);
//   - картинки: свои, data:/blob: и https: (внешние обложки/аватары по ссылке);
//   - соединения: свои + WebSocket; воркеры: свои + blob:;
//   - запрещены <object>/<embed>, смена <base>, отправка форм на чужие адреса, встраивание в чужие фреймы.
func CSP(o CSPOptions) string {
	d := map[string]string{
		"default-src":     "'self'",
		"script-src":      "'self' 'wasm-unsafe-eval'",
		"style-src":       "'self' 'unsafe-inline'",
		"img-src":         "'self' data: blob: https:",
		"media-src":       "'self' blob: https:",
		"font-src":        "'self' data:",
		"connect-src":     "'self' ws: wss:",
		"worker-src":      "'self' blob:",
		"frame-src":       "'self'",
		"object-src":      "'none'",
		"base-uri":        "'self'",
		"form-action":     "'self'",
		"frame-ancestors": "'self'",
	}
	order := []string{"default-src", "script-src", "style-src", "img-src", "media-src", "font-src", "connect-src", "worker-src", "frame-src", "object-src", "base-uri", "form-action", "frame-ancestors"}
	for _, part := range strings.Split(o.Extra, ";") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		name := strings.ToLower(strings.Fields(part)[0])
		if _, known := d[name]; !known {
			order = append(order, name)
		}
		d[name] = strings.TrimSpace(strings.TrimPrefix(part, strings.Fields(part)[0]))
	}
	var b strings.Builder
	for i, n := range order {
		if i > 0 {
			b.WriteString("; ")
		}
		b.WriteString(n)
		if d[n] != "" {
			b.WriteString(" " + d[n])
		}
	}
	return b.String()
}

// Headers — набор защитных заголовков ответа. https — запрос пришёл по TLS (включает HSTS).
func Headers(https bool) map[string]string {
	h := map[string]string{
		"X-Content-Type-Options":            "nosniff",
		"X-Frame-Options":                   "SAMEORIGIN",
		"Referrer-Policy":                   "strict-origin-when-cross-origin",
		"Permissions-Policy":                "camera=(self), microphone=(self), display-capture=(self), geolocation=(), payment=(), usb=(), interest-cohort=()",
		"Cross-Origin-Opener-Policy":        "same-origin",
		"Cross-Origin-Resource-Policy":      "same-origin",
		"X-Permitted-Cross-Domain-Policies": "none",
	}
	if https {
		h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
	}
	return h
}
