// Раздел «База знаний» верхнего уровня: каталог баз, поиск по страницам, создание; /wiki/:space[/:page] — экраны базы.
import React, { useState } from 'react';
import * as I from '../../lib/icons';
import { api } from '../../lib/api';
import { useQuery } from '../../lib/query';
import { Link, matchPath, useLocation } from '../../lib/router';
import { useStore } from '../../lib/store';
import { cx, useDebounced } from '../../lib/util';
import { useTitle } from '../../lib/router';
import { Btn, Empty, ErrorBox, Input, Loading } from '../../ui';
import { SpaceModal } from './dialogs';
import { W, WSpace, pagePath, spacePath } from './lib';
import { WikiSnippet } from './render';
import { wikiRoute } from './index';

function WikiHome() {
  useTitle('База знаний');
  const me = useStore((s) => s.me)!;
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 250);
  const [create, setCreate] = useState(false);
  const spaces = useQuery<WSpace[]>('wiki:spaces', () => api.get(`${W}/spaces`), { stale: 15000 });
  const found = useQuery<any[]>('wiki:q:' + dq, () => (dq.length >= 2 ? api.get(`${W}/search?q=${encodeURIComponent(dq)}`) : Promise.resolve([])), { stale: 15000 });
  if (spaces.error && !spaces.data) return <ErrorBox error={spaces.error} retry={spaces.refetch} />;
  if (!spaces.data) return <Loading />;
  const canCreate = me.role !== 'user';
  return (
    <div className="stack" style={{ maxWidth: 1100 }}>
      <div className="pageH"><h1>База знаний</h1><span className="sub">инструкции, регламенты, справочники</span><span className="sp" />
        {canCreate && <Btn kind="pri" onClick={() => setCreate(true)}><I.Plus size={16} /> Новая база</Btn>}
      </div>
      <div className="fSearch"><Input placeholder="Поиск по всем страницам баз знаний…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {dq.length >= 2 ? (
        <div className="card">
          {!found.data ? <Loading /> : found.data.length === 0 ? <Empty icon={I.Search} title="Ничего не найдено">Попробуйте другие слова.</Empty> :
            found.data.map((r) => (
              <Link key={r.id} to={pagePath(r.space_id, r.id, r.title)} className="fileRow">
                <span style={{ fontSize: 22 }}>{r.icon || '📄'}</span>
                <div style={{ minWidth: 0 }}><div className="bold clip">{r.title}</div>
                  <div className="small muted clamp2"><WikiSnippet text={r.snippet} /></div>
                  <div className="tiny faint">{r.space_icon} {r.space_title}</div></div>
              </Link>
            ))}
        </div>
      ) : spaces.data.length === 0 ? (
        <div className="card"><Empty icon={I.Book} title="Баз знаний пока нет">{canCreate ? 'Создайте первую базу — для регламентов, инструкций или справочника отдела.' : 'Когда редакторы создадут базы знаний, они появятся здесь.'}</Empty></div>
      ) : (
        <div className="wkGrid">
          {spaces.data.map((s) => (
            <Link key={s.id} to={spacePath(s.id)} className="card wkSpaceCard">
              <span className={cx('wkSpaceIc', /^c\d$/.test(s.cover) ? s.cover : 'c1')}>{s.icon || '📘'}</span>
              <span className="sp" style={{ minWidth: 0 }}>
                <span className="bold" style={{ display: 'flex', gap: 6, alignItems: 'center' }}><span className="clip">{s.title}</span>{s.visibility === 'restricted' && <I.Lock size={13} className="faint" />}</span>
                <span className="small muted clamp3" style={{ display: 'block', marginTop: 4 }}>{s.description || 'База знаний'}</span>
              </span>
            </Link>
          ))}
        </div>
      )}
      {create && <SpaceModal folder={null} onClose={() => setCreate(false)} />}
    </div>
  );
}

/** Маршрутизатор раздела: /wiki → каталог, /wiki/:space[/:page] → экран базы. */
export function WikiPage() {
  const { path } = useLocation();
  return <>{path === '/wiki' || path === '/wiki/' ? <WikiHome /> : wikiRoute(path) || <WikiHome />}</>;
}
