package middleware

import (
	"errors"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// FreshUser актуализирует признак администратора и активность учётной записи
// ПО БАЗЕ, а не по токену.
//
// Проблема: is_admin зашит в JWT при входе и действует до истечения токена
// (и продлевается вместе с ним), поэтому смена роли применялась только после
// перелогина. Здесь признак перечитывается из user_roles с коротким кэшем
// (freshTTL): нагрузка на БД — один запрос на пользователя в несколько
// секунд, а изменение роли вступает в силу почти сразу (а на этом же
// экземпляре — мгновенно, см. InvalidateUser).
//
// Заблокированный пользователь (is_active=false) получает 401: токен у него
// ещё действителен, но работать он уже не должен.
const freshTTL = 5 * time.Second

type freshEntry struct {
	isAdmin bool
	active  bool
	at      time.Time
}

var fresh = struct {
	mu sync.Mutex
	m  map[int64]freshEntry
}{m: make(map[int64]freshEntry)}

// InvalidateUser сбрасывает кэш пользователя (вызывается при смене ролей).
func InvalidateUser(id int64) {
	fresh.mu.Lock()
	delete(fresh.m, id)
	fresh.mu.Unlock()
}

// InvalidateAllUsers сбрасывает весь кэш.
func InvalidateAllUsers() {
	fresh.mu.Lock()
	fresh.m = make(map[int64]freshEntry)
	fresh.mu.Unlock()
}

func FreshUser(pool *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		uid, _ := c.Locals(CtxUserID).(int64)
		if uid == 0 {
			return c.Next()
		}
		fresh.mu.Lock()
		e, ok := fresh.m[uid]
		fresh.mu.Unlock()
		if !ok || time.Since(e.at) > freshTTL {
			var isAdmin, active bool
			err := pool.QueryRow(c.Context(), `
				SELECT u.is_active,
				       EXISTS(SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id AND ur.role = 'admin')
				  FROM users u WHERE u.id = $1`, uid).Scan(&active, &isAdmin)
			if errors.Is(err, pgx.ErrNoRows) {
				return fiber.NewError(fiber.StatusUnauthorized, "учётная запись не найдена")
			}
			if err != nil {
				// Не удалось проверить, действует ли учётная запись, —
				// пропускать запрос нельзя.
				return fiber.NewError(fiber.StatusServiceUnavailable, "сервис временно недоступен, повторите попытку")
			}
			e = freshEntry{isAdmin: isAdmin, active: active, at: time.Now()}
			fresh.mu.Lock()
			if len(fresh.m) > 20000 {
				fresh.m = make(map[int64]freshEntry)
			}
			fresh.m[uid] = e
			fresh.mu.Unlock()
		}
		if !e.active {
			return fiber.NewError(fiber.StatusUnauthorized, "учётная запись заблокирована")
		}
		c.Locals(CtxIsAdmin, e.isAdmin)
		return c.Next()
	}
}
