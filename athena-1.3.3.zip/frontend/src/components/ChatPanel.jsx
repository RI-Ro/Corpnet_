import React, { useEffect, useRef, useState, useCallback } from 'react'
import Icon from '../components/Icon'
import { api } from '../api/client'
import { playEventSound } from '../lib/sound'
import { fmtDateTime } from '../utils/format'

// Обсуждение документа. Сообщения ПЕРСИСТЯТСЯ в БД (chat_messages); при открытии
// карточки история подгружается через REST, живые сообщения приходят по WS.
// Показываем автора и дату; поддерживаются вложения (files[]).
// fmt — дата-время с защитой от некорректного значения.
//
// Объявлена на уровне МОДУЛЯ, а не внутри ChatPanel: ею пользуются и
// ReadReceipt, и сам ChatPanel. Внутри компонента она была бы не видна
// соседним компонентам — обращение к ней дало бы ReferenceError в рантайме,
// который ни сборка, ни линтер не покажут.
function fmt(ts) {
  try {
    return fmtDateTime(ts)
  } catch (_) {
    return ts
  }
}

// ReadReceipt — галочки прочтения и раскрывающийся список «кто прочитал».
//
// Данные приходят вместе с историей обсуждения (read_by, recipient_count),
// отдельных запросов на сообщение нет: в длинном обсуждении это была бы
// сотня запросов на открытие вкладки.
function ReadReceipt({ message }) {
  const [open, setOpen] = useState(false)
  // Положение списка в координатах ОКНА (position: fixed) — см. ниже.
  const [pos, setPos] = useState(null)
  const ref = useRef(null)
  const btnRef = useRef(null)
  const readBy = message.read_by || []
  const total = message.recipient_count || 0
  // Прочитали все, кому документ доступен.
  const allRead = total > 0 && readBy.length >= total

  // Закрытие по клику вне списка.
  useEffect(() => {
    if (!open) return undefined
    function onDown(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [open])

  //, п. 2 — список «кто прочитал» у ПЕРВОГО сообщения был
  // нечитаем.
  //
  // Было: absolutely-позиционированный блок с «bottom-full» — он всегда
  // раскрывался ВВЕРХ и лежал внутри прокручиваемого списка сообщений. У
  // первого сообщения места сверху нет, и список уходил за границу
  // контейнера: прокрутка его обрезала (overflow-y:auto), а шапка вкладки
  // перекрывала остаток, т.к. z-index внутри прокручиваемого блока не
  // поднимает его над соседними слоями — у них свой контекст наложения.
  //
  // Стало: position: fixed в координатах окна. Такой блок не обрезается
  // никаким overflow родителя, лежит выше прочих слоёв, а направление
  // выбирается по фактически доступному месту: вверх, если сверху помещается,
  // иначе вниз. Высота оценивается по числу строк, а не берётся константой,
  // иначе короткий список у верхнего края всё равно считался бы «не
  // помещающимся».
  const PANEL_W = 240
  const openPanel = () => {
    if (readBy.length === 0) return
    if (open) {
      setOpen(false)
      return
    }
    const r = btnRef.current?.getBoundingClientRect()
    if (!r) {
      setOpen(true)
      return
    }
    // 44 — заголовок и подвал списка, 18 — строка на человека, 180 — предел
    // (дальше внутри списка своя прокрутка, max-h-40).
    const est = Math.min(180, 44 + readBy.length * 18)
    const spaceAbove = r.top
    const up = spaceAbove >= est + 8
    // Выравниваем по правому краю галочек, но не вылезаем за экран.
    const left = Math.max(8, Math.min(r.right - PANEL_W, window.innerWidth - PANEL_W - 8))
    setPos({ left, top: up ? Math.max(8, r.top - est - 6) : r.bottom + 6 })
    setOpen(true)
  }

  // Блок привязан к координатам окна, поэтому при прокрутке списка сообщений
  // он «отстал» бы от своей галочки — закрываем.
  useEffect(() => {
    if (!open) return undefined
    const close = () => setOpen(false)
    window.addEventListener('scroll', close, true)
    window.addEventListener('resize', close)
    return () => {
      window.removeEventListener('scroll', close, true)
      window.removeEventListener('resize', close)
    }
  }, [open])

  const title = readBy.length === 0
    ? 'Ещё не прочитано'
    : allRead
      ? `Прочитали все (${readBy.length})`
      : `Прочитали ${readBy.length} из ${total}`

  return (
    <span className="relative inline-flex items-center" ref={ref}>
      <button
        type="button"
        ref={btnRef}
        onClick={openPanel}
        title={title}
        aria-label={title}
        aria-expanded={open}
        className={`inline-flex items-center ${allRead ? 'text-accent' : 'text-text-secondary'} ${
          readBy.length > 0 ? 'hover:opacity-80' : 'cursor-default'
        }`}
      >
        <Ticks double={allRead} />
      </button>

      {open && readBy.length > 0 && (
        <div
          className="z-50 surface-2 border border-border p-2 shadow-xl"
          style={{
            position: 'fixed',
            left: pos?.left ?? 8,
            top: pos?.top ?? 8,
            width: PANEL_W,
          }}
        >
          <div className="label mb-1">{title}</div>
          <ul className="max-h-40 overflow-auto space-y-0.5">
            {readBy.map((r) => (
              <li key={r.user_id} className="flex items-baseline justify-between gap-2">
                <span className="text-[11px] truncate">{r.full_name}</span>
                <span className="text-[10px] text-text-secondary whitespace-nowrap nums">
                  {fmt(r.read_at)}
                </span>
              </li>
            ))}
          </ul>
          {!allRead && total > readBy.length && (
            <div className="text-[10px] text-text-secondary mt-1 pt-1 border-t border-border">
              Ещё не прочитали: {total - readBy.length}
            </div>
          )}
        </div>
      )}
    </span>
  )
}

// Ticks — одна или две галочки. Рисуются SVG, а не символами «✓✓»: юникодные
// галочки в разных шрифтах выглядят по-разному, а на части машин отсутствуют
// (та же причина, по которой весь интерфейс перешёл на SVG-иконки).
function Ticks({ double }) {
  return (
    <svg width="16" height="11" viewBox="0 0 16 11" fill="none" aria-hidden="true">
      <path d="M1 6.2L4.2 9.4L10.2 1.6" stroke="currentColor" strokeWidth="1.6"
            strokeLinecap="round" strokeLinejoin="round" />
      {double && (
        <path d="M6.2 9.4L12.2 1.6" stroke="currentColor" strokeWidth="1.6"
              strokeLinecap="round" strokeLinejoin="round" />
      )}
    </svg>
  )
}

export default function ChatPanel({ documentId, currentUserId, readOnly = false }) {
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const [files, setFiles] = useState([])
  const [connected, setConnected] = useState(false)
  const [sending, setSending] = useState(false)
  const wsRef = useRef(null)
  const listRef = useRef(null)
  const fileRef = useRef(null)

  // Слить сообщение по id без дублей (WS может продублировать REST-ответ).
  const mergeMessage = useCallback((m) => {
    setMessages((prev) => {
      if (m.id && prev.some((x) => x.id === m.id)) return prev
      return [...prev, m]
    })
  }, [])

  // История из БД при открытии.
  useEffect(() => {
    let cancelled = false
    api.getChatHistory(documentId)
      .then((r) => { if (!cancelled) setMessages(r.items || []) })
      .catch(() => {})
    return () => { cancelled = true }
  }, [documentId])

  // WS с авто-переподключением.
  useEffect(() => {
    let closedByUs = false
    let retry = 0
    let timer = null

    function connect() {
      let ws
      try { ws = new WebSocket(api.wsURL(documentId)) } catch (_) { schedule(); return }
      wsRef.current = ws
      ws.onopen = () => { retry = 0; setConnected(true) }
      ws.onclose = () => { setConnected(false); if (!closedByUs) schedule() }
      ws.onerror = () => { try { ws.close() } catch (_) { /* noop */ } }
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data)
          if (msg.type === 'chat_message') {
            mergeMessage(msg)
            if (msg.author_id && msg.author_id !== currentUserId) playEventSound('chat_message')
          } else if (msg.type === 'chat_updated') {
            api.getChatHistory(documentId).then((r) => setMessages(r.items || [])).catch(() => {})
          }
        } catch (_) { /* игнорируем */ }
      }
    }
    function schedule() {
      retry += 1
      timer = setTimeout(connect, Math.min(15000, 1000 * 2 ** Math.min(retry, 4)))
    }
    connect()
    return () => {
      closedByUs = true
      clearTimeout(timer)
      try { wsRef.current && wsRef.current.close() } catch (_) { /* noop */ }
    }
  }, [documentId, currentUserId, mergeMessage])

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight })
  }, [messages])

  const send = useCallback(async () => {
    if ((!text.trim() && files.length === 0) || sending) return
    setSending(true)
    try {
      if (files.length > 0) {
        // С вложениями — только через REST (WS не носит бинарные файлы).
        await api.postChatMessage(documentId, text.trim(), files)
        setFiles([])
        if (fileRef.current) fileRef.current.value = ''
        setText('')
        // Всегда перечитываем историю: WS-эхо не содержит вложений, поэтому
        // полагаться на него нельзя (иначе появлялось «пустое» сообщение).
        setMessages((await api.getChatHistory(documentId)).items || [])
      } else if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({ type: 'chat_message', text: text.trim() }))
        setText('')
      } else {
        // WS закрыт — отправляем через REST, чтобы сообщение не потерялось.
        await api.postChatMessage(documentId, text.trim(), [])
        setText('')
        setMessages((await api.getChatHistory(documentId)).items || [])
      }
    } catch (e) {
      alert(e.message || 'Не удалось отправить сообщение')
    } finally {
      setSending(false)
    }
  }, [text, files, sending, connected, documentId])

  return (
    <div className="surface-1 flex flex-col h-full min-h-0">
      <div className="px-3 py-2 border-b border-border flex items-center justify-between">
        <h2 className="font-medium text-sm">Обсуждение</h2>
        <span className={`text-[10px] ${connected ? 'text-success' : 'text-text-secondary'}`}>
          {connected ? '● на связи' : '○ не в сети'}
        </span>
      </div>

      <div ref={listRef} className="flex-1 min-h-0 overflow-auto p-3 space-y-2">
        {messages.length === 0 && <div className="text-text-secondary text-xs">Сообщений пока нет</div>}
        {messages.map((m, i) => {
          const mine = m.author_id === currentUserId
          return (
            <div key={m.id || i} className={`flex flex-col ${mine ? 'items-end' : 'items-start'}`}>
              <div className={`max-w-[85%] rounded-lg px-2.5 py-1.5 text-sm ${mine ? 'bg-accent/15 border border-accent/30' : 'bg-surface-alt border border-border'}`}>
                {!mine && <div className="text-[11px] text-text-secondary mb-0.5">{m.author_name || `Пользователь #${m.author_id}`}</div>}
                {m.deleted ? (
                  <div className="italic text-text-secondary">сообщение удалено</div>
                ) : (
                  <>
                    {m.text && <div className="whitespace-pre-wrap break-words">{m.text}</div>}
                    {(m.attachments || []).map((a) => (
                      <button
                        key={a.id}
                        onClick={() => api.downloadChatAttachment(a.id, a.file_name).catch((e) => alert(e.message))}
                        className="mt-1 flex items-center gap-1 text-xs text-accent hover:underline"
                      >
                        <Icon name="paperclip" size={13} /> {a.file_name} <span className="text-text-secondary">({(a.size_bytes || 0).toLocaleString('ru-RU')} байт)</span>
                      </button>
                    ))}
                  </>
                )}
              </div>
              <div className="text-[10px] text-text-secondary mt-0.5 flex items-center gap-1.5">
                <span>{fmt(m.created_at)}</span>
                {/* Отметка прочтения — только у СВОИХ сообщений: автору важно,
                    прочитали ли его. Одна галочка — доставлено, но прочитали
                    не все; две — прочитали все, кому документ доступен.
                    Список «кто и когда» раскрывается по нажатию, а не висит
                    постоянно: в обсуждении на двадцать сообщений постоянные
                    списки читать невозможно. */}
                {mine && !m.deleted && <ReadReceipt message={m} />}
                {m.edited_at && !m.deleted && <span>· изменено {fmt(m.edited_at)}</span>}
                {mine && !m.deleted && (
                  <>
                    <button
                      className="text-accent hover:underline"
                      onClick={() => {
                        const nt = prompt('Изменить сообщение:', m.text || '')
                        if (nt && nt.trim() && nt.trim() !== m.text) {
                          api.editChatMessage(m.id, nt.trim())
                            .then(() => api.getChatHistory(documentId).then((r) => setMessages(r.items || [])))
                            .catch((e) => alert(e.message))
                        }
                      }}
                    >править</button>
                    <button
                      className="text-danger hover:underline"
                      onClick={() => {
                        if (confirm('Удалить сообщение?')) {
                          api.deleteChatMessage(m.id)
                            .then(() => api.getChatHistory(documentId).then((r) => setMessages(r.items || [])))
                            .catch((e) => alert(e.message))
                        }
                      }}
                    >удалить</button>
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>

      {readOnly ? (
        <div className="border-t border-border p-3 text-xs text-text-secondary">
          Документ в архиве — новые сообщения недоступны.
        </div>
      ) : (
      <div className="border-t border-border p-2">
        {files.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-1">
            {files.map((f, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 bg-surface-alt border border-border rounded px-1.5 py-0.5 text-[11px]">
                {f.name}
                <button className="text-danger" onClick={() => setFiles(files.filter((_, i) => i !== idx))}>×</button>
              </span>
            ))}
          </div>
        )}
        <div className="flex items-end gap-1.5">
          <button
            onClick={() => fileRef.current?.click()}
            className="px-2 py-1.5 rounded-md border border-border text-sm"
            title="Прикрепить файл"
          ><Icon name="paperclip" /></button>
          <input
            ref={fileRef}
            type="file"
            multiple
            className="hidden"
            onChange={(e) => setFiles([...files, ...Array.from(e.target.files || [])])}
          />
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            // Enter — новая строка (как в обычном тексте), Ctrl+Enter (⌘+Enter
            // на Mac) — отправка: длинные сообщения больше не уходят
            // недописанными от случайного Enter.
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send() }
            }}
            rows={2}
            placeholder="Сообщение… (Ctrl+Enter — отправить)"
            className="field flex-1 resize-none"
          />
          <button
            onClick={send}
            disabled={sending || (!text.trim() && files.length === 0)}
            className="btn btn-primary disabled:opacity-60"
            title="Отправить (Ctrl+Enter)"
            aria-label="Отправить сообщение (Ctrl+Enter)"
          >→</button>
        </div>
      </div>
      )}
    </div>
  )
}
