// Реестр пунктов бокового меню. Видимость: модуль включён администратором, у пользователя достаточно прав, пользователь не скрыл пункт.
// Порядок: внутри каждой группы по пользовательскому списку menuOrder (новые пункты — в конец, неизвестные id игнорируются).
import * as I from './icons';
import * as X from './social-icons';
import { ReqIcon } from '../pages/requests/icons';
import { canWrite, isAdmin, isEditor, type Me } from './store';

export type MenuGroup = 'main' | 'people' | 'materials' | 'manage';
export interface MenuItem {
  id: string; to: string; label: string; icon: any; group: MenuGroup;
  module?: string; badge?: 'chats' | 'req'; locked?: boolean;
  match?: (p: string) => boolean; show?: (me: Me) => boolean;
}
export const GROUPS: { id: MenuGroup; label: string }[] = [
  { id: 'main', label: 'Главное' }, { id: 'people', label: 'Люди' }, { id: 'materials', label: 'Материалы' }, { id: 'manage', label: 'Управление' },
];

export const MENU: MenuItem[] = [
  { id: 'news', to: '/', label: 'Новости', icon: I.Newspaper, group: 'main', module: 'news', locked: true, match: (p) => p === '/' || p.startsWith('/news') },
  { id: 'directions', to: '/directions', label: 'Направления деятельности', icon: I.Layers, group: 'main', module: 'people' },
  { id: 'messages', to: '/messages', label: 'Сообщения', icon: I.Message, group: 'main', module: 'messenger', badge: 'chats' },
  { id: 'calendar', to: '/calendar', label: 'Календарь', icon: I.Calendar, group: 'main', module: 'calendar' },
  { id: 'groups', to: '/groups', label: 'Группы', icon: I.Users, group: 'main', module: 'groups' },
  { id: 'ideas', to: '/ideas', label: 'Есть идея', icon: I.Lightbulb, group: 'main', module: 'ideas' },
  { id: 'ask', to: '/ask', label: 'Спросите директора', icon: I.Message, group: 'main', module: 'ask' },
  { id: 'bookmarks', to: '/bookmarks', label: 'Закладки', icon: X.Bookmark, group: 'main', module: 'bookmarks' },
  { id: 'people', to: '/people', label: 'Сотрудники', icon: I.UserCheck, group: 'people', module: 'people' },
  { id: 'departments', to: '/departments', label: 'Подразделения', icon: I.Building, group: 'people', module: 'people' },
  { id: 'vacations', to: '/vacations', label: 'График отпусков', icon: I.Clock, group: 'people', module: 'vacations' },
  { id: 'onboarding', to: '/onboarding', label: 'Адаптация', icon: I.UserPlus, group: 'people', module: 'onboarding' },
  { id: 'learning', to: '/learning', label: 'Обучение', icon: I.GradCap, group: 'people', module: 'learning' },
  { id: 'rewards', to: '/rewards', label: 'Достижения', icon: I.Star, group: 'people', module: 'rewards' },
  { id: 'surveys', to: '/surveys', label: 'Опросы', icon: I.Chart, group: 'people', module: 'surveys' },
  { id: 'requests', to: '/requests', label: 'Заявки', icon: ReqIcon, group: 'people', module: 'requests', badge: 'req' },
  { id: 'documents', to: '/documents', label: 'Документы', icon: I.FileText, group: 'materials', module: 'files' },
  { id: 'photos', to: '/photos', label: 'Фотогалерея', icon: I.Image, group: 'materials', module: 'files' },
  { id: 'videos', to: '/videos', label: 'Видео', icon: I.Video, group: 'materials', module: 'files' },
  { id: 'wiki', to: '/wiki', label: 'База знаний', icon: I.Book, group: 'materials', module: 'wiki', match: (p) => p.startsWith('/wiki') },
  { id: 'resources', to: '/resources', label: 'Ресурсы', icon: I.Link, group: 'materials' },
  { id: 'company', to: '/company', label: 'О компании', icon: I.Briefcase, group: 'materials' },
  { id: 'feedback', to: '/feedback', label: 'Обращения', icon: I.Shield, group: 'materials', module: 'feedback' },
  { id: 'editorial', to: '/editorial', label: 'Редакция', icon: I.Edit, group: 'materials', module: 'news', show: (me) => canWrite(me) },
  { id: 'admin', to: '/admin', label: 'Админ-панель', icon: I.Dashboard, group: 'manage', locked: true, show: (me) => isEditor(me) },
];

/** Пункты, доступные пользователю до учёта его личных настроек (для окна настройки меню). */
export function availableItems(me: Me, modulesOff: string[]): MenuItem[] {
  return MENU.filter((m) => (isAdmin(me) || !m.module || !modulesOff.includes(m.module)) && (!m.show || m.show(me)))
    .map((m) => (m.id === 'admin' && !isAdmin(me) ? { ...m, label: 'Редактор' } : m));
}

function orderWithin(items: MenuItem[], order: string[]): MenuItem[] {
  const idx = (id: string) => { const i = order.indexOf(id); return i < 0 ? 1e6 : i; };
  return items.map((m, k) => ({ m, k })).sort((a, b) => idx(a.m.id) - idx(b.m.id) || a.k - b.k).map((x) => x.m);
}

/** Итоговое меню: по группам, с порядком и скрытием пользователя. Модуль, выключенный администратором, скрыт у всех (администратор видит пункт в настройках, но не в меню). */
export function buildMenu(me: Me, modulesOff: string[], order: string[], hidden: string[]): { group: MenuGroup; label: string; items: MenuItem[] }[] {
  const avail = availableItems(me, modulesOff).filter((m) => !(m.module && modulesOff.includes(m.module)));
  return GROUPS.map((g) => ({
    group: g.id, label: g.label,
    items: orderWithin(avail.filter((m) => m.group === g.id), order).filter((m) => m.locked || !hidden.includes(m.id)),
  })).filter((g) => g.items.length);
}
export { orderWithin };
