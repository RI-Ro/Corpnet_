"""Минимальный HTTP-клиент для сквозных проверок (только стандартная библиотека)."""
import json, os, ssl, urllib.request, urllib.error

BASE = os.environ.get("ATHENA_URL", "https://localhost:8443")
CTX = ssl._create_unverified_context()  # стенд с самоподписанным сертификатом

PDF = (b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
       b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n")


class Session:
    """Сеанс как у браузера: cookie, выданные сервером, и CSRF-заголовок."""

    def __init__(self, cookies=None):
        self.cookies = dict(cookies or {})
        self.set_cookie_headers = []

    def copy(self):
        return Session(self.cookies)

    @property
    def csrf(self):
        return self.cookies.get("athena_csrf", "")

    @property
    def session_value(self):
        return self.cookies.get("__Host-athena_session") or self.cookies.get("athena_session", "")

    def absorb(self, headers):
        for raw in headers.get_all("Set-Cookie") or []:
            self.set_cookie_headers.append(raw)
            name, _, rest = raw.partition("=")
            value = rest.split(";", 1)[0]
            low = raw.lower()
            if not value or "max-age=0" in low or "max-age=-1" in low or "1970" in low:
                self.cookies.pop(name.strip(), None)
            else:
                self.cookies[name.strip()] = value


UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}


def call(method, path, token=None, body=None, headers=None, raw=False, csrf=True):
    """token — объект Session (имя параметра оставлено прежним)."""
    h = {"Content-Type": "application/json"}
    if isinstance(token, Session):
        if token.cookies:
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in token.cookies.items())
        if csrf and method in UNSAFE and token.csrf:
            h["X-CSRF-Token"] = token.csrf
    if headers:
        h.update(headers)
    data = body if isinstance(body, (bytes, type(None))) else json.dumps(body).encode()
    req = urllib.request.Request(BASE + path, data=data, method=method, headers=h)
    try:
        r = urllib.request.urlopen(req, context=CTX)
        code, b, hd = r.status, r.read(), r.headers
    except urllib.error.HTTPError as e:
        code, b, hd = e.code, e.read(), e.headers
    if isinstance(token, Session):
        token.absorb(hd)
    if raw:
        return code, b, hd
    try:
        return code, json.loads(b)
    except Exception:
        return code, b[:200]


def login(user, password="password123", raw=False):
    s = Session()
    c, r = call("POST", "/api/auth/login", s, body={"login": user, "password": password})
    if c != 200:
        raise SystemExit(f"вход {user}: {c} {r}")
    return (s, r) if raw else s


def multipart(fields, file=None, fname="doc.pdf"):
    bnd = "xxATHENAxx"
    out = b""
    for k, v in fields.items():
        out += f'--{bnd}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n'.encode() + (v if isinstance(v, bytes) else str(v).encode()) + b"\r\n"
    if file is not None:
        out += f'--{bnd}\r\nContent-Disposition: form-data; name="file"; filename="{fname}"\r\nContent-Type: application/pdf\r\n\r\n'.encode() + file + b"\r\n"
    out += f"--{bnd}--\r\n".encode()
    return out, {"Content-Type": f"multipart/form-data; boundary={bnd}"}


def create_doc(token, title, approvers, signers, recipients=None, file=None, extra=None):
    """approvers: [{"stage_type","approver_id","step"}]"""
    f = {"title": title, "category_id": 1, "route": json.dumps({"approvers": approvers, "signer_ids": signers})}
    if recipients:
        f["recipients"] = json.dumps(recipients)
    if extra:
        f.update(extra)
    body, h = multipart(f, file if file is not None else PDF + f"% {title}\n".encode())
    return call("POST", "/api/documents", token, body, headers=h)
