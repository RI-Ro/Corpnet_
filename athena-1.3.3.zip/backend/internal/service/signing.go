package service

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"athena/backend/internal/mailer"
)

type SigningService struct {
	numbering *NumberingService
	secret    []byte
}

// NewSigningService. secret — серверный секрет простой электронной подписи
// (signing.secret в файле конфигурации). Подпись — это HMAC-SHA256 от
// подписанной строки на этом секрете: без секрета её нельзя ни подделать,
// ни «поправить» в базе данных незаметно.
func NewSigningService(numbering *NumberingService, secret string) *SigningService {
	return &SigningService{numbering: numbering, secret: []byte(secret)}
}

// SignatureKeyID — короткий отпечаток секрета. Хранится рядом с подписью,
// чтобы после смены секрета было видно, каким ключом подпись выполнена.
func (s *SigningService) SignatureKeyID() string {
	sum := sha256.Sum256(append([]byte("athena/pes-key-id:"), s.secret...))
	return hex.EncodeToString(sum[:4])
}

// ComputeSignature — HMAC-SHA256(секрет, подписанная строка), hex.
func (s *SigningService) ComputeSignature(payload string) string {
	m := hmac.New(sha256.New, s.secret)
	m.Write([]byte(payload))
	return hex.EncodeToString(m.Sum(nil))
}

// VerifySignature проверяет подпись по сохранённой подписанной строке.
// keyMatch=false означает, что подпись выполнена другим секретом (секрет
// меняли) и проверить её текущим ключом нельзя.
func (s *SigningService) VerifySignature(payload, signature, keyID string) (valid, keyMatch bool) {
	if keyID != s.SignatureKeyID() {
		return false, false
	}
	return hmac.Equal([]byte(s.ComputeSignature(payload)), []byte(signature)), true
}

// Sign выполняется, когда согласующий этапа stage_type='signing' подтверждает
// решение (см. handlers.ApprovalHandler.Decide) — это и есть момент
// подписания. Присваивает исходящий номер атомарно (см. NumberingService),
// пишет маркировку в document_signatures и переводит статус в 'signed'.
// Номер выдаётся ЗДЕСЬ, а не при создании документа — иначе удалённые/
// отклонённые черновики оставляли бы дыры в нумерации.
// SignMeta — метаданные факта подписания для юридической значимости (63-ФЗ):
// фактический IP клиента (с учётом прокси/NAT) и user-agent. Логин, снимок
// ФИО/должности и хэш содержимого документа сервис вычисляет сам.
type SignMeta struct {
	IP        string
	UserAgent string
}

// onBehalfOf — тот, чей этап подписи решён. Совпадает с signerID, когда
// человек подписывает от себя; при замещении это замещаемый (п. 19).
// Подписывающим во всех случаях остаётся signerID: подписывать чужим именем
// нельзя, замещение фиксируется ПОМЕТКОЙ в самой подписи.
func (s *SigningService) Sign(ctx context.Context, tx pgx.Tx, documentID, signerID, onBehalfOf int64, signatureType string, meta SignMeta) (string, []int64, error) {
	var authorDepartmentID int64
	var authorNumberingDeptID *int64
	err := tx.QueryRow(ctx, `
		SELECT d.author_department_id, au.numbering_department_id
		FROM documents d
		JOIN users au ON au.id = d.author_id
		WHERE d.id = $1`, documentID).Scan(&authorDepartmentID, &authorNumberingDeptID)
	if err != nil {
		return "", nil, fmt.Errorf("lookup document/author: %w", err)
	}
	// Номер регистрируется по подразделению АВТОРА документа (по ТЗ), а не
	// подписанта. Берём numbering_department_id автора, если задан, иначе —
	// основное подразделение автора.
	deptForNumbering := authorDepartmentID
	if authorNumberingDeptID != nil && *authorNumberingDeptID != 0 {
		deptForNumbering = *authorNumberingDeptID
	}

	// Присвоение номера обёрнуто в SAVEPOINT с ретраем на UNIQUE-конфликт.
	// В норме NextOutgoing гарантирует уникальность (department_id, year,
	// seq_type — атомарный счётчик + pathPrefix уникален на подразделение).
	// Но numbering_prefix теперь редактируется вручную через консоль
	// администрирования и НЕ имеет UNIQUE-ограничения в БД — если админ по
	// ошибке присвоит одинаковый numbering_prefix двум подразделениям, номера
	// могут совпасть. Вместо падения всей подписи — перевыпускаем номер
	// (счётчик уже продвинут, следующий вызов даст новое значение) и пробуем
	// снова, до 5 попыток.
	const maxAttempts = 5
	var outgoingNumber string
	for attempt := 1; ; attempt++ {
		if _, err = tx.Exec(ctx, `SAVEPOINT sp_outgoing_number`); err != nil {
			return "", nil, fmt.Errorf("savepoint: %w", err)
		}
		outgoingNumber, err = s.numbering.NextOutgoing(ctx, tx, deptForNumbering)
		if err == nil {
			_, err = tx.Exec(ctx, `UPDATE documents SET status = 'signed', outgoing_number = $1 WHERE id = $2`, outgoingNumber, documentID)
		}
		if err == nil {
			if _, relErr := tx.Exec(ctx, `RELEASE SAVEPOINT sp_outgoing_number`); relErr != nil {
				return "", nil, fmt.Errorf("release savepoint: %w", relErr)
			}
			break
		}
		if !isUniqueViolation(err) || attempt >= maxAttempts {
			return "", nil, fmt.Errorf("assign outgoing number (attempt %d): %w", attempt, err)
		}
		if _, rbErr := tx.Exec(ctx, `ROLLBACK TO SAVEPOINT sp_outgoing_number`); rbErr != nil {
			return "", nil, fmt.Errorf("rollback savepoint: %w", rbErr)
		}
		// коллизия номера — повторяем с новым значением счётчика
	}

	// #8 (63-ФЗ) — Снимок ФИО, должности и ЛОГИНА подписанта на момент подписи.
	var signerFIO, signerPos, signerLogin string
	if err := tx.QueryRow(ctx, `SELECT coalesce(full_name,''), coalesce(position,''), coalesce(login,'') FROM users WHERE id=$1`, signerID).Scan(&signerFIO, &signerPos, &signerLogin); err != nil {
		return "", nil, fmt.Errorf("lookup signer snapshot: %w", err)
	}

	// #8 — Хэш СОДЕРЖИМОГО документа на момент подписи: привязывает подпись к
	// конкретному файлу (любое последующее изменение файла станет заметным при
	// сверке хэша). Берём уже вычисленный sha256 файла. Если файла нет — пусто.
	var documentHash string
	_ = tx.QueryRow(ctx, `SELECT coalesce(sha256,'') FROM document_files WHERE document_id=$1`, documentID).Scan(&documentHash)

	// Отпечаток факта подписания (ПЭП): включает содержимое документа, личность
	// подписанта (id+login), исходящий номер, время и фактический IP — это
	// «данные, позволяющие определить лицо, подписавшее документ» (63-ФЗ).
	// Для УНЭП/УКЭП здесь место интеграции с крипто-провайдером/УЦ.
	// Подписанная строка: что именно подписано. Хэш файла связывает подпись
	// с содержимым документа, остальное — с подписантом, номером и временем.
	signedAt := time.Now().UTC().Format(time.RFC3339)
	payload := fmt.Sprintf("v1|sha256=%s|doc=%d|signer=%d|login=%s|number=%s|at=%s",
		documentHash, documentID, signerID, signerLogin, outgoingNumber, signedAt)
	signatureHash := s.ComputeSignature(payload)

	storageResource := fmt.Sprintf("ИР «Афина» / Архив %d / %s", time.Now().Year(), outgoingNumber)

	// Факт подписания заместителем фиксируется В САМОЙ ПОДПИСИ, а не только в
	// истории: подпись — юридически значимая запись, и по ней должно быть
	// видно, что человек действовал за другого в период замещения.
	// Подписывающим при этом остаётся сам заместитель (signer_id, ФИО,
	// должность — его): подписывать чужим именем нельзя.
	//
	// п. 19 — пометка называет КОНКРЕТНОГО замещаемого (чей этап подписи
	// решён), а не весь список замещаемых: иначе по подписи нельзя понять, за
	// кого она поставлена, когда у заместителя несколько замещений.

	_, err = tx.Exec(ctx, `
		INSERT INTO document_signatures
		    (document_id, signer_id, signature_type, signature_hash, storage_resource,
		     signer_fio, signer_position, signer_login, signed_ip, user_agent, document_hash,
		     signed_payload, key_id)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
		documentID, signerID, signatureType, signatureHash, storageResource,
		signerFIO, signerPos, signerLogin, meta.IP, meta.UserAgent, documentHash,
		payload, s.SignatureKeyID())
	if err != nil {
		return "", nil, fmt.Errorf("insert signature: %w", err)
	}

	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, to_status, comment)
		VALUES ($1, $2, 'signed', 'signed', $3)`, documentID, signerID,
		(outgoingNumber))
	if err != nil {
		return "", nil, fmt.Errorf("insert history: %w", err)
	}

	// Примечание: отдельное уведомление автору о подписании здесь НЕ создаём —
	// единое уведомление всем заинтересованным (включая автора) с kind
	// 'document_signed' рассылает обработчик Decide через NotifyDocumentEvent.
	// Иначе автор получал бы ДВА уведомления о подписи.

	// #3/#2 — Мультиподпись: достаточно ОДНОЙ подписи. Сначала СНИМАЕМ
	// видимость у прочих выбранных подписантов (пока их signing-этапы ещё
	// существуют), затем полностью УДАЛЯЕМ их этапы подписи — чтобы в истории и
	// в маршруте не оставалось никаких записей вида «подпись не требуется».
	//
	// После подписи видимость остаётся ТОЛЬКО у подписавшего: у прочих
	// подписантов забираем доступ, выданный как участникам подписи
	// (access_reason='approval_stage'), но лишь если у них НЕТ иной
	// роли-участника в этом документе (напр. они ещё и согласующий).
	//
	// «Подписавший» здесь — ВЛАДЕЛЕЦ решённого этапа (onBehalfOf), а не тот,
	// кто нажал кнопку. При замещении это разные люди, и если считать по
	// нажавшему, замещаемый лишился бы доступа к собственному документу, а
	// его этап подписи попал бы в удаление как «чужой непройденный»
	// (п. 19).
	if _, err := tx.Exec(ctx, `
		DELETE FROM document_access da
		WHERE da.document_id=$1
		  AND da.access_reason='approval_stage'
		  AND da.user_id <> $2
		  AND da.user_id IN (
		    SELECT approver_id FROM approval_stages
		    WHERE document_id=$1 AND stage_type='signing' AND approver_id <> $2
		  )
		  AND NOT EXISTS (
		    SELECT 1 FROM approval_stages s2
		    WHERE s2.document_id=$1 AND s2.approver_id=da.user_id
		      AND s2.stage_type <> 'signing'
		  )`, documentID, onBehalfOf); err != nil {
		return "", nil, fmt.Errorf("revoke other signers visibility: %w", err)
	}
	// Удаляем зависимости и сами НЕ ПРОЙДЕННЫЕ этапы подписи прочих
	// подписантов (status <> 'approved'). Этапы подписи, помеченные approved
	// (переадресация подписи как согласование, #1), сохраняем — они отражают
	// факт согласования в маршруте.
	if _, err := tx.Exec(ctx, `
		DELETE FROM approval_stage_dependencies
		WHERE stage_id IN (
		    SELECT id FROM approval_stages
		    WHERE document_id=$1 AND stage_type='signing' AND approver_id <> $2
		      AND status <> 'approved')`, documentID, onBehalfOf); err != nil {
		return "", nil, fmt.Errorf("delete other signing deps: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		DELETE FROM approval_stages
		WHERE document_id=$1 AND stage_type='signing' AND approver_id <> $2
		  AND status <> 'approved'`, documentID, onBehalfOf); err != nil {
		return "", nil, fmt.Errorf("delete other signing stages: %w", err)
	}
	// Контролёры, назначенные до подписания, получают доступ и уведомление
	// только сейчас: до подписи документ был промежуточным вариантом.
	if _, err := tx.Exec(ctx, `
		WITH c AS (
		  SELECT dc.user_id FROM document_controllers dc
		    JOIN documents d ON d.id = dc.document_id AND d.on_control
		   WHERE dc.document_id = $1
		     AND NOT EXISTS (SELECT 1 FROM document_access da
		                      WHERE da.document_id = $1 AND da.user_id = dc.user_id
		                        AND da.access_reason = 'controller')
		), g AS (
		  INSERT INTO document_access (document_id, user_id, access_reason)
		  SELECT $1, user_id, 'controller' FROM c ON CONFLICT DO NOTHING
		)
		INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, requires_ack)
		SELECT user_id, $1, 'control_assigned', '{}', $2, $3 FROM c`,
		documentID, signerID, RequiresAck("control_assigned")); err != nil {
		return "", nil, fmt.Errorf("open to controllers: %w", err)
	}
	// Активируем плановых получателей (выбранных при создании): выдаём им
	// доступ к документу и уведомляем. До подписания они не видели документ.
	planned, err := tx.Query(ctx, `
		SELECT recipient_user_id FROM document_recipients
		WHERE document_id = $1 AND is_planned = true`, documentID)
	if err != nil {
		return "", nil, fmt.Errorf("load planned recipients: %w", err)
	}
	var plannedIDs []int64
	for planned.Next() {
		var uid int64
		if err := planned.Scan(&uid); err != nil {
			planned.Close()
			return "", nil, err
		}
		plannedIDs = append(plannedIDs, uid)
	}
	planned.Close()
	var notifiedIDs []int64
	for _, uid := range plannedIDs {
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_access (document_id, user_id, access_reason)
			VALUES ($1, $2, 'recipient') ON CONFLICT DO NOTHING`, documentID, uid); err != nil {
			return "", nil, err
		}
		// Номер экземпляра получателю здесь НЕ выдаём — он присваивается только
		// когда получатель РЕАЛЬНО откроет документ (присвоение при первом
		// просмотре в Get). Иначе номер «зависал» бы за исключённым из рассылки.
		// #7 — актор = подписавший (именно он своей подписью направил документ
		// плановым получателям). #2 — 'document_sent' входит в будильники.
		members, err := deliveryMembers(ctx, tx, uid)
		if err != nil {
			return "", nil, err
		}
		for _, memberID := range members {
			if _, err := tx.Exec(ctx, `
			INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, requires_ack)
			VALUES ($1, $2, 'document_sent', '{}', $3, $4)`,
				memberID, documentID, signerID, RequiresAck("document_sent")); err != nil {
				return "", nil, err
			}
			notifiedIDs = append(notifiedIDs, memberID)
		}
	}
	// Снимаем флаг планового — теперь они обычные активные получатели.
	if _, err := tx.Exec(ctx, `
		UPDATE document_recipients SET is_planned = false
		WHERE document_id = $1 AND is_planned = true`, documentID); err != nil {
		return "", nil, err
	}

	// СЕМАНТИКА signed/sent: если при создании была задана плановая рассылка,
	// то подпись = автоматическое направление. Переводим в 'sent' и пишем
	// событие истории — иначе документ «завис» бы в 'signed', хотя адресаты
	// уже уведомлены. Если плановых не было — остаёмся в 'signed' (ждём ручного
	// «Направить» с выбором адресатов).
	// Письма плановым адресатам — в очередь (не влияет на подпись).
	mailer.EnqueueNewDocument(ctx, tx, documentID, notifiedIDs)
	if len(plannedIDs) > 0 {
		if _, err := tx.Exec(ctx, `UPDATE documents SET status = 'sent' WHERE id = $1`, documentID); err != nil {
			return "", nil, fmt.Errorf("auto-send after sign: %w", err)
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'sent', 'signed', 'sent', 'автоматически направлен плановым адресатам')`, documentID, signerID); err != nil {
			return "", nil, fmt.Errorf("insert sent history: %w", err)
		}
	}

	return outgoingNumber, notifiedIDs, nil
}
