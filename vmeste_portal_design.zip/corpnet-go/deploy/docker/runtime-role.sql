-- Выполняется владельцем миграций после установки схемы.
\getenv runtime_password APP_DB_PASSWORD
SELECT 'CREATE ROLE portal_runtime LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS'
WHERE NOT EXISTS (SELECT FROM pg_roles WHERE rolname='portal_runtime') \gexec
ALTER ROLE portal_runtime WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS PASSWORD :'runtime_password';
GRANT corpnet_app TO portal_runtime;
