// Слой «живости» интерфейса: motion (появление, индикатор навигации).
// Ничего не знает о страницах: работает через делегирование и MutationObserver, поэтому страницы не правятся.
// Уважает prefers-reduced-motion. Принципы: ease-out, 150–400 мс, анимируем только transform/opacity.
import { animate, stagger } from 'motion';

export const EASE_OUT = [0.23, 1, 0.32, 1] as const;
const reduce = () => matchMedia('(prefers-reduced-motion: reduce)').matches || document.documentElement.dataset.perf === 'lite';

/** Элементы, которые «въезжают» при появлении в DOM (списки новостей, карточки людей, правая колонка…). */
const ENTER = '.ncard, .person, .railC, .stack > .card, .grid3 > *, .newsGrid > *, .hero > *, .heroSide > *';

let queue: HTMLElement[] = [];
let scheduled = false;
function flush() {
  scheduled = false;
  const els = queue.filter((e) => e.isConnected && !e.dataset.fx);
  queue = [];
  if (!els.length || reduce()) return;
  // только то, что реально на экране (+небольшой запас): остальное анимировать незачем
  const vis = els.filter((e) => { const r = e.getBoundingClientRect(); return r.bottom > -40 && r.top < innerHeight + 120; }).slice(0, 24);
  vis.forEach((e) => (e.dataset.fx = '1'));
  if (!vis.length) return;
  animate(vis, { opacity: [0, 1], transform: ['translateY(14px) scale(.985)', 'translateY(0px) scale(1)'] }, { duration: 0.45, delay: stagger(0.045, { startDelay: 0.02 }), ease: EASE_OUT })
    .finished.then(() => vis.forEach((e) => { e.style.removeProperty('opacity'); e.style.removeProperty('transform'); }), () => {});
}
function enqueue(e: HTMLElement) { queue.push(e); if (!scheduled) { scheduled = true; requestAnimationFrame(flush); } }

export function initFx() {
  // 1) появление новых карточек
  new MutationObserver((muts) => {
    for (const m of muts) for (const n of m.addedNodes) {
      if (!(n instanceof HTMLElement)) continue;
      if (n.matches(ENTER)) enqueue(n);
      n.querySelectorAll?.<HTMLElement>(ENTER).forEach(enqueue);
    }
  }).observe(document.body, { childList: true, subtree: true });

}

/** Скользящий индикатор активного пункта навигации (аналог layoutId). Вызывать при смене маршрута. */
export function movePill(nav: HTMLElement | null) {
  if (!nav) return;
  const pill = nav.querySelector<HTMLElement>('.navPill');
  const on = nav.querySelector<HTMLElement>('.navA.on');
  if (!pill) return;
  if (!on) { pill.style.opacity = '0'; return; }
  const y = on.offsetTop, h = on.offsetHeight;
  if (pill.dataset.ready !== '1' || reduce()) {
    pill.style.transform = `translateY(${y}px)`; pill.style.height = h + 'px'; pill.style.opacity = '1'; pill.dataset.ready = '1';
    return;
  }
  pill.style.opacity = '1';
  animate(pill, { transform: `translateY(${y}px)`, height: h + 'px' }, { type: 'spring', stiffness: 520, damping: 38 });
}
