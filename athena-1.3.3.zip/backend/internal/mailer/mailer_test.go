package mailer

import (
	"strings"
	"testing"

	"athena/backend/internal/config"
)

func TestRender(t *testing.T) {
	var cfg config.EmailConfig
	cfg.Enabled = true
	cfg.NewDocument.Subject = "Новое указание:\n{{.Title}} ({{.Number}})"
	cfg.NewDocument.Body = "{{.RecipientName}}, вам направлено «{{.Title}}». {{.URL}} id={{.ID}}"
	Configure(cfg, "Афина")
	if !Enabled() {
		t.Fatal("почта должна быть включена")
	}
	s, b, err := Render(NewDocumentData{ID: 7, Title: "О предоставлении сведений", Number: "ИСХ-1-5/2026",
		URL: "https://x/document/7", RecipientName: "Иванов И.И."})
	if err != nil {
		t.Fatal(err)
	}
	if strings.ContainsAny(s, "\r\n") || s != "Новое указание: О предоставлении сведений (ИСХ-1-5/2026)" {
		t.Errorf("тема: %q", s)
	}
	if !strings.Contains(b, "https://x/document/7") || !strings.Contains(b, "id=7") || !strings.Contains(b, "Иванов") {
		t.Errorf("текст: %q", b)
	}
	// Ошибка в шаблоне выключает почту, а не роняет приложение.
	cfg.NewDocument.Body = "{{.Title"
	Configure(cfg, "Афина")
	if Enabled() {
		t.Fatal("при ошибке шаблона почта должна быть выключена")
	}
	Configure(config.EmailConfig{}, "Афина")
}
