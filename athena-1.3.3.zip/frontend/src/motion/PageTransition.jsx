import React, { useEffect } from 'react'
import { motion, useAnimationControls } from 'motion/react'
import { useLocation } from 'react-router-dom'
import { EASE_OUT } from './presets'

// PageTransition — мягкое появление страницы при смене маршрута.
//
// Намеренно БЕЗ key={pathname}: перемонтирование сбросило бы состояние
// страницы (фильтры, прокрутку, открытые панели) при каждом переходе между
// разделами, у которых один и тот же компонент (/documents/:category).
// Вместо этого анимация запускается императивно на тот же узел.
export default function PageTransition({ children }) {
  const { pathname } = useLocation()
  const controls = useAnimationControls()

  useEffect(() => {
    controls.start({
      opacity: [0, 1],
      y: [8, 0],
      transition: { duration: 0.24, ease: EASE_OUT },
    })
  }, [pathname, controls])

  return (
    <motion.div animate={controls} initial={false}>
      {children}
    </motion.div>
  )
}
