import React, { useState, useRef, useEffect } from 'react'
import { useTheme, THEMES } from '../context/ThemeContext'
import Icon from './Icon'

const SWATCH = {
  balun: ['#0c0f0b', '#b6ff3c'],
  midnight: ['#0a0d16', '#5b7fff'],
  carbon: ['#0a0a0a', '#35e6d6'],
  'graphite-neon': ['#0e0c14', '#b479ff'],
  ember: ['#120d0a', '#ff8a3c'],
  light: ['#f5f6fb', '#4a5cff'],
  paper: ['#f7f1e6', '#b4780f'],
  mint: ['#f2faf4', '#1f9e5c'],
  frost: ['#f0f6fb', '#1c8fd1'],
  rose: ['#fbf3f6', '#c23b7a'],
}

// «названия тем убрать».
//
// Названия («Balun», «Midnight», «Carbon») ничего человеку не говорили: по
// слову нельзя понять, как будет выглядеть экран, и выбирали всё равно по
// образцу цвета. Вместо подписей оставлены сами образцы — два цвета темы,
// фоновый и акцентный, и пометка «тёмная»/«светлая»: это единственное, что
// при выборе оформления действительно нужно знать.
//
// Темы разделены на две группы с заголовками, чтобы без подписей не
// получилась безликая решётка из десяти кружков.
const darkThemes = THEMES.filter((t) => t.dark)
const lightThemes = THEMES.filter((t) => !t.dark)

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  const current = THEMES.find((t) => t.id === theme) || THEMES[0]

  // Группа образцов. Образец — кнопка без текста, поэтому у неё обязателен
  // title и aria-label: без них выбор оформления недоступен ни с клавиатуры,
  // ни экранному диктору. Внутри названия темы нет — есть номер в группе,
  // по которому человек может сослаться на свой выбор.
  const swatches = (list, kindLabel) => (
    <div className="flex flex-wrap gap-1.5 px-1 pb-1.5">
      {list.map((t, i) => (
        <button
          key={t.id}
          onClick={() => {
            setTheme(t.id)
            setOpen(false)
          }}
          title={`${kindLabel} ${i + 1}`}
          aria-label={`${kindLabel} ${i + 1}`}
          aria-pressed={t.id === theme}
          className={`w-8 h-8 rounded-md overflow-hidden border-2 ${
            t.id === theme ? 'border-accent' : 'border-border hover:border-text-secondary'
          }`}
        >
          <span className="flex w-full h-full">
            <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[t.id]?.[0] }} />
            <span className="w-1/2 h-full" style={{ backgroundColor: SWATCH[t.id]?.[1] }} />
          </span>
        </button>
      ))}
    </div>
  )

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        title={`Оформление: ${current.dark ? 'тёмное' : 'светлое'}`}
        aria-label="Сменить оформление"
        className="flex items-center justify-center w-9 h-9 rounded-md border border-border bg-surface-alt text-text-primary hover:text-accent"
      >
        <Icon name="palette" size={20} />
      </button>

      {open && (
        <div className="absolute right-0 mt-1 w-56 bg-surface border border-border rounded-md shadow-lg z-20 p-1.5">
          <div className="kicker px-2 py-1">// тёмные</div>
          {swatches(darkThemes, 'Тёмное оформление')}
          <div className="kicker px-2 py-1">// светлые</div>
          {swatches(lightThemes, 'Светлое оформление')}
        </div>
      )}
    </div>
  )
}
