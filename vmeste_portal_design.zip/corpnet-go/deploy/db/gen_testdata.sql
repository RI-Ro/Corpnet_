-- Генератор тестовых данных (для нагрузочных стендов): подразделения разной вложенности, сотрудники, новости,
-- фотоальбомы с вложенными папками, группы (чаты групп создаёт триггер БД).
-- Запуск (после migrate.sh --seed …):  ./gen-testdata.sh [подразделений] [сотрудников] [новостей] [альбомов]
--   по умолчанию: 220 / 3200 / 5200 / 220.  Повторный запуск ничего не добавляет (метка — логины gen.*).
-- Пароль всех сгенерированных сотрудников: corpnet123. Данные воспроизводимы (setseed).
\if :{?depts}
\else
\set depts 220
\endif
\if :{?users}
\else
\set users 3200
\endif
\if :{?news}
\else
\set news 5200
\endif
\if :{?albums}
\else
\set albums 220
\endif
SELECT set_config('gen.depts', :'depts', false), set_config('gen.users', :'users', false),
       set_config('gen.news', :'news', false), set_config('gen.albums', :'albums', false) \g /dev/null

DO $gen$
DECLARE
  nd int := current_setting('gen.depts')::int;  nu int := current_setting('gen.users')::int;
  nn int := current_setting('gen.news')::int;   na int := current_setting('gen.albums')::int;
  fn_m text[] := ARRAY['Александр','Дмитрий','Максим','Сергей','Андрей','Алексей','Артём','Илья','Кирилл','Михаил','Никита','Матвей','Роман','Егор','Арсений','Иван','Денис','Евгений','Даниил','Тимофей'];
  fn_f text[] := ARRAY['Анна','Мария','Елена','Дарья','Анастасия','Ольга','Наталья','Екатерина','Татьяна','Ирина','Светлана','Юлия','Полина','Виктория','Ксения','Алиса','Вера','Марина','Софья','Яна'];
  ln_b text[] := ARRAY['Иванов','Смирнов','Кузнецов','Попов','Васильев','Петров','Соколов','Михайлов','Новиков','Фёдоров','Морозов','Волков','Алексеев','Лебедев','Семёнов','Егоров','Павлов','Козлов','Степанов','Николаев','Орлов','Андреев','Макаров','Никитин','Захаров','Зайцев','Соловьёв','Борисов','Яковлев','Григорьев'];
  patr_m text[] := ARRAY['Александрович','Дмитриевич','Сергеевич','Андреевич','Алексеевич','Иванович','Михайлович','Николаевич','Павлович','Игоревич'];
  patr_f text[] := ARRAY['Александровна','Дмитриевна','Сергеевна','Андреевна','Алексеевна','Ивановна','Михайловна','Николаевна','Павловна','Игоревна'];
  jobs text[] := ARRAY['Специалист','Ведущий специалист','Старший специалист','Менеджер','Аналитик','Инженер','Руководитель группы','Консультант','Координатор','Эксперт','Разработчик','Бухгалтер','Юрист','Дизайнер','Тестировщик'];
  dn text[] := ARRAY['Производство','Логистика','Закупки','Качество','Маркетинг','Продажи','Поддержка','Разработка','Аналитика','Финансы','Юридический','Безопасность','Обучение','Сервис','Проекты','Планирование','Склад','Эксплуатация','Клиентский','Операционный'];
  topics text[] := ARRAY['Итоги квартала','Новый регламент','Корпоративное мероприятие','Обновление системы','Охрана труда','День открытых дверей','Запуск проекта','Благодарность команде','Изменения в графике','Новые сотрудники','Обучение и развитие','Спортивный турнир','Благотворительная акция','Режим работы в праздники','Встреча с руководством','Итоги конкурса','Реорганизация процессов','ИТ-инфраструктура','Партнёрство','Награждение лучших'];
  cats int[]; i int; p bigint; d int; gender boolean; mx bigint;
BEGIN
  PERFORM setseed(0.42);
  IF EXISTS (SELECT 1 FROM users WHERE login LIKE 'gen.%') THEN RAISE NOTICE 'тестовые данные уже созданы — пропуск'; RETURN; END IF;
  SELECT array_agg(id) INTO cats FROM categories;
  IF cats IS NULL THEN INSERT INTO categories (name, color, sort) VALUES ('Компания', '#286b9e', 1), ('События', '#b5541c', 2) RETURNING id INTO i; SELECT array_agg(id) INTO cats FROM categories; END IF;

  -- ---- подразделения: 8 корней, дальше случайный родитель глубиной до 7 уровней
  CREATE TEMP TABLE gd (id bigint, depth int) ON COMMIT DROP;
  FOR i IN 1..nd LOOP
    IF i <= 8 THEN
      INSERT INTO departments (name, sort) VALUES (dn[1 + (i * 3) % 20] || ' · дивизион ' || i, i * 10) RETURNING id INTO p;
      INSERT INTO gd VALUES (p, 1);
    ELSE
      SELECT id, depth INTO p, d FROM gd WHERE depth < 7 ORDER BY random() LIMIT 1;
      INSERT INTO departments (name, parent_id, sort) VALUES (dn[1 + (i * 7) % 20] || ' ' || i, p, i) RETURNING id INTO mx;
      INSERT INTO gd VALUES (mx, d + 1);
    END IF;
  END LOOP;

  -- ---- сотрудники
  INSERT INTO users (login, email, password_hash, first_name, last_name, middle_name, job_title, department_id, role, phone1, birthday, hire_date, avatar)
  SELECT 'gen.u' || g, 'gen.u' || g || '@corpnet.local', '$2a$10$dwG1/93z2gJGJoP04WoQXecuzuEOD3QjI0nJ5R/.a0ratgXKaGJKu',
         CASE WHEN g % 2 = 0 THEN fn_m[1 + (g * 7) % 20] ELSE fn_f[1 + (g * 11) % 20] END,
         ln_b[1 + (g * 13) % 30] || CASE WHEN g % 2 = 0 THEN '' ELSE 'а' END,
         CASE WHEN g % 2 = 0 THEN patr_m[1 + (g * 3) % 10] ELSE patr_f[1 + (g * 3) % 10] END,
         jobs[1 + (g * 5) % 15], (SELECT id FROM gd OFFSET (g * 37) % nd LIMIT 1),
         CASE WHEN g % 50 = 0 THEN 'editor' ELSE 'user' END,
         '+7 9' || lpad(((g * 7919) % 100)::text, 2, '0') || ' ' || lpad(((g * 104729) % 1000)::text, 3, '0') || '-' || lpad((g % 100)::text, 2, '0') || '-' || lpad(((g * 31) % 100)::text, 2, '0'),
         make_date(1965 + (g * 7) % 40, 1 + (g * 3) % 12, 1 + (g * 5) % 28), current_date - ((g * 17) % 3650),
         CASE WHEN g % 5 <> 0 THEN '/demo/avatars/' || (g % 34 + 1) || '.jpg' ELSE '' END
  FROM generate_series(1, nu) g;
  -- руководители: по одному на подразделение
  UPDATE departments d SET head_id = h.uid FROM (SELECT DISTINCT ON (department_id) id AS uid, department_id FROM users WHERE login LIKE 'gen.%' ORDER BY department_id, id) h WHERE h.department_id = d.id;
  UPDATE users u SET is_head = true WHERE u.id IN (SELECT head_id FROM departments WHERE head_id IS NOT NULL) AND u.login LIKE 'gen.%';

  -- ---- новости (часть адресная: target_depts; полоса публикации — последние 2 года)
  INSERT INTO news (title, summary, body, category_id, author_id, cover, important, pinned, status, department_id, published_at, views_count, target_depts)
  SELECT topics[1 + (g * 7) % 20] || ' №' || g, 'Краткое содержание публикации №' || g || ': ' || lower(topics[1 + (g * 3) % 20]) || '.',
         E'## ' || topics[1 + (g * 7) % 20] || E'\n\nТестовая публикация №' || g || E'. Здесь описаны детали события, сроки и ответственные.\n\n- Пункт первый\n- Пункт второй\n- Пункт третий\n\nПодробности — у руководителя подразделения.',
         cats[1 + g % array_length(cats, 1)], a.id, CASE WHEN g % 5 < 3 THEN '/demo/covers/' || (g % 12 + 1) || '.jpg' ELSE '' END,
         g % 40 = 0, false, CASE WHEN g % 25 = 0 THEN 'draft' ELSE 'published' END, a.department_id,
         now() - (g * interval '2 hours' * 730 * 24 / nn / 2), 10 + (g * 37) % 900,
         CASE WHEN g % 12 = 0 THEN ARRAY[(SELECT id FROM gd OFFSET (g * 13) % nd LIMIT 1), (SELECT id FROM gd OFFSET (g * 29) % nd LIMIT 1)] ELSE '{}' END
  FROM generate_series(1, nn) g
  CROSS JOIN LATERAL (SELECT id, department_id FROM users WHERE role IN ('editor', 'admin') AND (login LIKE 'gen.%' OR role = 'admin') OFFSET (g * 7) % (SELECT count(*) FROM users WHERE role IN ('editor', 'admin') AND (login LIKE 'gen.%' OR role = 'admin')) LIMIT 1) a;
  INSERT INTO news_revisions (news_id, version, title, summary, body, cover, category_id, department_id, status, published_at, change_note, author_id)
  SELECT n.id, 1, n.title, n.summary, n.body, n.cover, n.category_id, n.department_id, n.status, n.published_at, 'Первая публикация', n.author_id FROM news n WHERE n.title ~ ' №\d+$' AND n.author_id IN (SELECT id FROM users WHERE login LIKE 'gen.%' OR role = 'admin');

  -- ---- фотоальбомы: 12 корневых, дальше вложенные до 5 уровней; в каждом по 3 снимка
  CREATE TEMP TABLE gf (id bigint, depth int) ON COMMIT DROP;
  FOR i IN 1..na LOOP
    IF i <= 12 THEN
      INSERT INTO folders (kind, name, description, visibility, owner_id) VALUES ('photos', 'Фотоархив: ' || topics[1 + (i * 3) % 20] || ' ' || (2015 + i), 'Корневой альбом №' || i, 'company', (SELECT id FROM users WHERE login = 'admin')) RETURNING id INTO p;
      INSERT INTO gf VALUES (p, 1);
    ELSE
      SELECT id, depth INTO p, d FROM gf WHERE depth < 5 ORDER BY random() LIMIT 1;
      INSERT INTO folders (kind, parent_id, name, description, visibility, owner_id) VALUES ('photos', p, 'Альбом ' || i || ': ' || lower(topics[1 + (i * 7) % 20]), 'Вложенный альбом, уровень ' || (d + 1), 'company', (SELECT id FROM users WHERE login = 'admin')) RETURNING id INTO mx;
      INSERT INTO gf VALUES (mx, d + 1);
    END IF;
  END LOOP;
  INSERT INTO files (folder_id, owner_id, name, mime, size, storage, thumb, external_url, width, height, context)
  SELECT gf.id, (SELECT id FROM users WHERE login = 'admin'), 'foto-' || gf.id || '-' || k || '.jpg', 'image/jpeg', 120000 + k * 1000, '',
         '/demo/covers/' || ((gf.id + k) % 12 + 1) || '.jpg', '/demo/covers/' || ((gf.id + k) % 12 + 1) || '.jpg', 1200, 800, 'folder'
  FROM gf CROSS JOIN generate_series(1, 3) k;

  -- ---- группы (чат группы и участников ведут триггеры БД)
  INSERT INTO user_groups (name, description, visibility, owner_id)
  SELECT 'Группа по интересам №' || g, 'Тестовая группа', 'public', (SELECT id FROM users WHERE login LIKE 'gen.%' ORDER BY id OFFSET g * 17 LIMIT 1) FROM generate_series(1, 40) g;
  INSERT INTO group_members (group_id, user_id, role)
  SELECT ug.id, ug.owner_id, 'owner' FROM user_groups ug WHERE ug.name LIKE 'Группа по интересам №%' ON CONFLICT DO NOTHING;
  INSERT INTO group_members (group_id, user_id, role)
  SELECT ug.id, u.id, 'member' FROM user_groups ug JOIN users u ON u.login LIKE 'gen.%' AND (u.id * 31 + ug.id * 17) % 40 = 0
  WHERE ug.name LIKE 'Группа по интересам №%' ON CONFLICT DO NOTHING;
  RAISE NOTICE 'создано: подразделений %, сотрудников %, новостей %, альбомов %', nd, nu, nn, na;
END $gen$;
ANALYZE;
