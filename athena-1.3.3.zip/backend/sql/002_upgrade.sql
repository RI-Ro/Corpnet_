\set ON_ERROR_STOP on
BEGIN;
LOCK TABLE schema_version IN EXCLUSIVE MODE;
SELECT NOT EXISTS (SELECT 1 FROM schema_version WHERE version=2) AS needs_upgrade \gset
\if :needs_upgrade
\ir migrations/002_workflow.sql
\endif
COMMIT;
