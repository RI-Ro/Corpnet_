package handlers

import (
	"runtime"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/indexer"
	"athena/backend/internal/metrics"
)

// AdminDashboardHandler — ТЕХНИЧЕСКИЙ дашборд состояния системы (#10).
//
// Зачем он отдельно от /api/dashboard/stats. Обычный дашборд намеренно
// персональный: все его счётчики считаются под RLS текущего пользователя и
// отвечают на вопрос «что требует МОЕГО действия». Администратору нужен
// другой вопрос — «что происходит с системой в целом»: сколько всего
// документов, растёт ли очередь индексации, не упёрся ли пул соединений,
// сколько выдач на печать не зарегистрировано в бумажном журнале. Смешивать
// это в одном эндпоинте нельзя: половина цифр имела бы разный смысл для
// разных пользователей, а вторая половина не имела бы смысла ни для кого,
// кроме администратора.
//
// ГЛАВНОЕ ОГРАНИЧЕНИЕ, определившее выбор каждого запроса ниже — RLS.
// Приложение подключается к БД ОБЫЧНОЙ ролью (не владельцем и не BYPASSRLS),
// а на documents / chat_messages / notifications включён FORCE ROW LEVEL
// SECURITY. Обхода RLS для администратора НЕТ (он был убран намеренно): в
// политике documents_select роль admin не упоминается вовсе. Поэтому
// «SELECT count(*) FROM documents» из этого хендлера вернул бы не общее
// число документов, а число документов, доступных лично этому администратору,
// — то есть тихо соврал бы. Проверено на тестовой базе (60 007 документов):
// обычная роль без app.user_id видит 0 строк, и с app.is_admin=true — тоже 0.
//
// Отсюда три класса метрик, и в JSON они разделены явно:
//
//  1. documents — считаются функцией documents_count_by_status()
//     (SECURITY DEFINER, миграция 0016_perf_v48). Она выполняется с правами
//     владельца и потому видит все строки, но отдаёт ТОЛЬКО количества по
//     статусам. Это единственный разрешённый способ узнать общее число
//     документов из приложения.
//
//  2. Всё остальное считается по таблицам БЕЗ RLS (users, departments,
//     document_access, resolutions, approval_stages, document_prints,
//     document_file_text) — такие цифры честно общесистемные.
//
//  3. rls_scoped — метрики, которые принципиально требуют самой таблицы
//     documents (просрочка по сроку, документы на контроле). Для них нет
//     SECURITY DEFINER-функции, поэтому они считаются В КОНТЕКСТЕ ТЕКУЩЕГО
//     администратора и вынесены в отдельный раздел ответа с флагом
//     rls_scoped. Фронт показывает их с явной оговоркой. Выдавать их за
//     общесистемные было бы хуже, чем не показывать вовсе.
type AdminDashboardHandler struct {
	pool *pgxpool.Pool
}

func NewAdminDashboardHandler(pool *pgxpool.Pool) *AdminDashboardHandler {
	return &AdminDashboardHandler{pool: pool}
}

// adminDashboardStartedAt — момент старта процесса для метрики аптайма.
//
// Своя переменная, а не значение из пакета metrics: там startedAt не
// экспортирован, а аптайм отдаётся только текстом в формате Prometheus на
// /metrics. Переменная пакетного уровня инициализируется при загрузке
// пакета, то есть на старте процесса, — для аптайма этого достаточно.
var adminDashboardStartedAt = time.Now()

// adminDashboardDays — глубина спарклайна «создано документов по дням».
// 30 дней: это и месячный тренд, и одновременно окно, из хвоста которого
// считается недельный итог, — второй запрос за те же данные не нужен.
const adminDashboardDays = 30

func (h *AdminDashboardHandler) requireAdmin(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return nil
}

// Metrics GET /api/admin/metrics — состояние системы одним ответом.
//
// Один ответ, а не десяток эндпоинтов: страница обновляется автоматически
// (раз в 30 секунд), и десяток параллельных запросов на каждое обновление
// занимал бы десяток соединений пула — ровно того ресурса, состояние
// которого эта же страница и показывает.
//
// Все агрегаты собираются ШЕСТЬЮ запросами в ОДНОЙ транзакции (одно
// соединение), а не запросом на каждое число: иначе на обновление уходило бы
// под тридцать round-trip'ов.
func (h *AdminDashboardHandler) Metrics(c *fiber.Ctx) error {
	if err := h.requireAdmin(c); err != nil {
		return err
	}
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	ctx := c.Context()

	// onlineUser — пользователь, активный в последний час.
	type onlineUser struct {
		ID          int64  `json:"id"`
		FullName    string `json:"full_name"`
		Position    string `json:"position"`
		Department  string `json:"department"`
		LastSeenAt  string `json:"last_seen_at"`
		IdleSeconds int64  `json:"idle_seconds"`
	}

	// monthPoint — точка исторического ряда по месяцам.
	type monthPoint struct {
		Month    string `json:"month"`
		Total    int64  `json:"total"`
		Created  int64  `json:"created"`
		Signed   int64  `json:"signed"`
		Executed int64  `json:"executed"`
		Actors   int64  `json:"actors"`
	}

	// deptRow — сводка по подразделению.
	type deptRow struct {
		ID           int64  `json:"id"`
		Name         string `json:"name"`
		City         string `json:"city"`
		IsActive     bool   `json:"is_active"`
		UsersTotal   int64  `json:"users_total"`
		UsersActive  int64  `json:"users_active"`
		UsersOnline  int64  `json:"users_online"`
		LastActivity string `json:"last_activity,omitempty"`
		DocsTotal    int64  `json:"docs_total"`
	}

	// secEvent — событие безопасности.
	type secEvent struct {
		UserName  string `json:"user_name"`
		EventType string `json:"event_type"`
		Details   string `json:"details"`
		CreatedAt string `json:"created_at"`
	}

	type dayPoint struct {
		Day   string `json:"day"`
		Count int64  `json:"count"`
	}
	type keyCount struct {
		Key   string `json:"key"`
		Count int64  `json:"count"`
	}
	type stagePoint struct {
		Status    string `json:"status"`
		StageType string `json:"stage_type"`
		Count     int64  `json:"count"`
	}

	var (
		docsTotal    int64
		docsByStatus []keyCount

		usersTotal, usersActive   int64
		deptsTotal, deptsActive   int64
		usersWithRoles            int64
		printsTotal, printsUnreg  int64
		prints7d, prints7dUnreg   int64
		prints30d, prints30dUnreg int64

		perDay               []dayPoint
		created7d            int64
		created30d           int64
		asgByStatus          []keyCount
		asgTotal, asgOverdue int64
		stages               []stagePoint
		stagesPending        int64

		rlsOverdue, rlsOnControl int64

		// Активность пользователей «прямо сейчас» и в исторической перспективе.
		online5m, online15m, online1h, online24h int64
		onlineList                               []onlineUser
		perMonth                                 []monthPoint
		deptSummary                              []deptRow
		secEvents                                []secEvent

		idx indexer.Status
	)

	txErr := db.WithUserTx(ctx, h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// --- 1. Документы по статусам (единственный путь в обход RLS) ---
		// Функция не принимает параметров и возвращает только количества —
		// по ней нельзя узнать ни об одном конкретном документе.
		rows, err := tx.Query(ctx, `SELECT status, cnt FROM documents_count_by_status()`)
		if err != nil {
			return err
		}
		for rows.Next() {
			var kc keyCount
			if err := rows.Scan(&kc.Key, &kc.Count); err != nil {
				rows.Close()
				return err
			}
			docsTotal += kc.Count
			docsByStatus = append(docsByStatus, kc)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return err
		}

		// --- 2. Все скалярные счётчики по таблицам без RLS — ОДНИМ запросом ---
		// Справочники (users/departments/user_roles) и журнал выдач на печать
		// (document_prints) под RLS не находятся, поэтому эти цифры
		// общесистемные и для администратора означают именно то, что написано.
		//
		// Печать: «не зарегистрировано» — это reg_at IS NULL. Регистрация
		// распечатанного экземпляра в бумажном журнале заполняет reg_journal,
		// reg_number и reg_at одним UPDATE (prints.go → Register), и reg_at
		// из них единственное поле, которое нельзя заполнить «пустой
		// строкой», — поэтому признак берётся по нему, а не по номеру.
		// Разрыв между выдачей и регистрацией — это и есть то, что ищет
		// администратор: распечатанный, но не учтённый экземпляр.
		if err := tx.QueryRow(ctx, `
			SELECT
			  (SELECT count(*) FROM users),
			  (SELECT count(*) FROM users WHERE is_active),
			  (SELECT count(*) FROM departments),
			  (SELECT count(*) FROM departments WHERE is_active),
			  (SELECT count(DISTINCT user_id) FROM user_roles),
			  (SELECT count(*) FROM document_prints),
			  (SELECT count(*) FROM document_prints WHERE reg_at IS NULL),
			  (SELECT count(*) FROM document_prints WHERE printed_at >= now() - interval '7 days'),
			  (SELECT count(*) FROM document_prints WHERE printed_at >= now() - interval '7 days' AND reg_at IS NULL),
			  (SELECT count(*) FROM document_prints WHERE printed_at >= now() - interval '30 days'),
			  (SELECT count(*) FROM document_prints WHERE printed_at >= now() - interval '30 days' AND reg_at IS NULL)`,
		).Scan(&usersTotal, &usersActive, &deptsTotal, &deptsActive, &usersWithRoles,
			&printsTotal, &printsUnreg, &prints7d, &prints7dUnreg, &prints30d, &prints30dUnreg); err != nil {
			return err
		}

		// --- 3. Нагрузка: создано документов по дням ---
		// Считается по document_access, а НЕ по documents.created_at, и это
		// вынужденно: documents под RLS и дал бы «мои документы по дням».
		//
		// document_access(access_reason='author') — корректная замена: строка
		// заводится ровно один раз в момент создания документа
		// (AccessService.GrantAuthorAccess, вызывается из создания документа),
		// granted_at по умолчанию now(), а первичный ключ
		// (document_id, user_id, access_reason) вместе с ON CONFLICT DO NOTHING
		// исключает дубль. Проверено на тестовой базе: 60 003 строки
		// access_reason='author' на 60 007 документов (остальные — служебные
		// документы демо-данных без автора).
		//
		// generate_series слева нужен, чтобы в ряду были и дни без документов:
		// иначе спарклайн на фронте «склеивал» бы пропущенные сутки и врал о
		// тренде.
		//
		// Запрос идёт Seq Scan'ом по document_access (на 60 тыс. строк — 19 мс
		// по замеру EXPLAIN ANALYZE): индекса по granted_at нет. На раз в
		// 30 секунд это допустимо; при дальнейшем росте таблицы стоит
		// добавить частичный индекс по granted_at — см. отчёт.
		dayRows, err := tx.Query(ctx, `
			SELECT g.d::date, coalesce(a.cnt, 0)
			FROM generate_series(current_date - ($1::int - 1), current_date, interval '1 day') AS g(d)
			LEFT JOIN (
			    SELECT granted_at::date AS d, count(*) AS cnt
			    FROM document_access
			    WHERE access_reason = 'author'
			      AND granted_at >= current_date - ($1::int - 1)
			    GROUP BY 1
			) AS a ON a.d = g.d::date
			ORDER BY 1`, adminDashboardDays)
		if err != nil {
			return err
		}
		for dayRows.Next() {
			var d time.Time
			var n int64
			if err := dayRows.Scan(&d, &n); err != nil {
				dayRows.Close()
				return err
			}
			perDay = append(perDay, dayPoint{Day: d.Format("2006-01-02"), Count: n})
		}
		dayRows.Close()
		if err := dayRows.Err(); err != nil {
			return err
		}
		// --- КТО В СИСТЕМЕ СЕЙЧАС -------------------------------------
		//
		// Считается по users.last_seen_at, которую обновляет middleware не
		// чаще раза в минуту на пользователя. Несколько порогов, а не один:
		// «за 5 минут» отвечает на вопрос «кто работает сейчас», «за сутки» —
		// «кто вообще заходил», и подменять одно другим нельзя.
		if err := tx.QueryRow(ctx, `
			SELECT count(*) FILTER (WHERE last_seen_at > now() - interval '5 minutes'),
			       count(*) FILTER (WHERE last_seen_at > now() - interval '15 minutes'),
			       count(*) FILTER (WHERE last_seen_at > now() - interval '1 hour'),
			       count(*) FILTER (WHERE last_seen_at > now() - interval '24 hours')
			FROM users`).Scan(&online5m, &online15m, &online1h, &online24h); err != nil {
			return err
		}
		onRows, err := tx.Query(ctx, `
			SELECT u.id, u.full_name, coalesce(u.position,''), coalesce(d.name,''),
			       to_char(u.last_seen_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       EXTRACT(EPOCH FROM (now() - u.last_seen_at))::bigint
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.last_seen_at > now() - interval '1 hour'
			ORDER BY u.last_seen_at DESC
			LIMIT 100`)
		if err != nil {
			return err
		}
		for onRows.Next() {
			var ou onlineUser
			if err := onRows.Scan(&ou.ID, &ou.FullName, &ou.Position, &ou.Department,
				&ou.LastSeenAt, &ou.IdleSeconds); err != nil {
				onRows.Close()
				return err
			}
			onlineList = append(onlineList, ou)
		}
		onRows.Close()
		if err := onRows.Err(); err != nil {
			return err
		}

		// --- СОБЫТИЯ В ИСТОРИЧЕСКОЙ ПЕРСПЕКТИВЕ -----------------------
		//
		// Ряд по дням ограничен 30 днями — он нужен для «что происходит
		// сейчас». Для исторической картины нужен другой масштаб: по месяцам
		// и ЗА ВСЮ историю. Считается по document_history, а не по
		// document_access: история содержит все события документооборота
		// (создание, согласование, подпись, исполнение), а не только
		// появление автора.
		monRows, err := tx.Query(ctx, `
			SELECT to_char(date_trunc('month', created_at), 'YYYY-MM') AS m,
			       count(*) AS total,
			       count(*) FILTER (WHERE event_type = 'created') AS created,
			       count(*) FILTER (WHERE event_type = 'signed') AS signed,
			       count(*) FILTER (WHERE event_type = 'executed') AS executed,
			       count(DISTINCT actor_id) AS actors
			FROM document_history
			GROUP BY 1
			ORDER BY 1`)
		if err != nil {
			return err
		}
		for monRows.Next() {
			var mp monthPoint
			if err := monRows.Scan(&mp.Month, &mp.Total, &mp.Created, &mp.Signed, &mp.Executed, &mp.Actors); err != nil {
				monRows.Close()
				return err
			}
			perMonth = append(perMonth, mp)
		}
		monRows.Close()
		if err := monRows.Err(); err != nil {
			return err
		}

		// --- СВОДКА ПО ПОДРАЗДЕЛЕНИЯМ ---------------------------------
		//
		// Одним запросом по всем подразделениям, а не по одному на каждое:
		// подразделений может быть много, и N запросов на открытие страницы
		// — это та самая нагрузка, которую дашборд должен помогать находить,
		// а не создавать.
		//
		// Счётчики документов берутся через SECURITY DEFINER-обход RLS? Нет:
		// documents под RLS, и админ после #5 её не обходит. Поэтому
		// документы считаются по author_department_id через отдельную
		// функцию-агрегат, а здесь — по данным, не закрытым RLS
		// (пользователи, роли, активность).
		deptRows, err := tx.Query(ctx, `
			SELECT d.id, d.name, coalesce(d.city,''), d.is_active,
			       count(u.id) AS users_total,
			       count(u.id) FILTER (WHERE u.is_active) AS users_active,
			       count(u.id) FILTER (WHERE u.last_seen_at > now() - interval '15 minutes') AS users_online,
			       coalesce(max(u.last_seen_at), 'epoch'::timestamptz) AS last_activity
			FROM departments d
			LEFT JOIN users u ON u.primary_department_id = d.id
			GROUP BY d.id, d.name, d.city, d.is_active
			ORDER BY d.name`)
		if err != nil {
			return err
		}
		for deptRows.Next() {
			var dr deptRow
			var last time.Time
			if err := deptRows.Scan(&dr.ID, &dr.Name, &dr.City, &dr.IsActive,
				&dr.UsersTotal, &dr.UsersActive, &dr.UsersOnline, &last); err != nil {
				deptRows.Close()
				return err
			}
			if last.Year() > 1970 {
				dr.LastActivity = last.UTC().Format("2006-01-02T15:04:05Z")
			}
			deptSummary = append(deptSummary, dr)
		}
		deptRows.Close()
		if err := deptRows.Err(); err != nil {
			return err
		}

		// --- СОБЫТИЯ БЕЗОПАСНОСТИ -------------------------------------
		secRows, err := tx.Query(ctx, `
			SELECT coalesce(u.full_name, '(удалён)'), e.event_type, coalesce(e.details,''),
			       to_char(e.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM security_events e
			LEFT JOIN users u ON u.id = e.user_id
			ORDER BY e.created_at DESC
			LIMIT 50`)
		if err != nil {
			return err
		}
		for secRows.Next() {
			var se secEvent
			if err := secRows.Scan(&se.UserName, &se.EventType, &se.Details, &se.CreatedAt); err != nil {
				secRows.Close()
				return err
			}
			secEvents = append(secEvents, se)
		}
		secRows.Close()
		if err := secRows.Err(); err != nil {
			return err
		}

		// Итоги за 7 и 30 дней считаем в Go по уже полученному ряду, а не
		// двумя дополнительными запросами: данные те же, лишний проход по
		// таблице не нужен.
		for i, p := range perDay {
			created30d += p.Count
			if i >= len(perDay)-7 {
				created7d += p.Count
			}
		}

		// --- 4. Резолюции по статусам ---
		//
		//, п. 3: поручения заменены резолюциями. Просрочка
		// берётся ЗДЕСЬ, а не из documents: у резолюции свой срок (due_date) и
		// своё закрытие (closed_at). Запрос идёт в общесистемном контексте
		// дашборда, поэтому цифра честная — в отличие от просрочки по
		// документам ниже, ограниченной видимостью.
		asgRows, err := tx.Query(ctx, `
			SELECT coalesce(status::text, ''), count(*),
			       count(*) FILTER (WHERE closed_at IS NULL
			                          AND due_date IS NOT NULL
			                          AND due_date < current_date)
			FROM resolutions GROUP BY 1 ORDER BY 2 DESC`)
		if err != nil {
			return err
		}
		for asgRows.Next() {
			var kc keyCount
			var overdue int64
			if err := asgRows.Scan(&kc.Key, &kc.Count, &overdue); err != nil {
				asgRows.Close()
				return err
			}
			asgTotal += kc.Count
			asgOverdue += overdue
			asgByStatus = append(asgByStatus, kc)
		}
		asgRows.Close()
		if err := asgRows.Err(); err != nil {
			return err
		}

		// --- 5. Этапы согласования/подписания (approval_stages без RLS) ---
		// Разрез сразу по двум осям (статус × тип этапа) одним GROUP BY:
		// администратору важно отличать «висит согласование» от «висит
		// подпись» — это разные люди и разные причины затыка.
		stageRows, err := tx.Query(ctx, `
			SELECT status::text, stage_type::text, count(*)
			FROM approval_stages GROUP BY 1, 2 ORDER BY 3 DESC`)
		if err != nil {
			return err
		}
		for stageRows.Next() {
			var sp stagePoint
			if err := stageRows.Scan(&sp.Status, &sp.StageType, &sp.Count); err != nil {
				stageRows.Close()
				return err
			}
			if sp.Status == "pending" {
				stagesPending += sp.Count
			}
			stages = append(stages, sp)
		}
		stageRows.Close()
		if err := stageRows.Err(); err != nil {
			return err
		}

		// --- 6. Метрики, требующие саму таблицу documents ---
		// ЧИТАЮТСЯ ПОД RLS ТЕКУЩЕГО АДМИНИСТРАТОРА и потому НЕ являются
		// общесистемными: администратор увидит здесь только документы, к
		// которым у него есть доступ (автор / document_access / видимость
		// подразделения). Иначе никак: SECURITY DEFINER-функции для срока и
		// контроля нет, а добавлять обход RLS ради дашборда — значит отдать
		// наружу признаки чужих документов. Фронт помечает этот блок
		// оговоркой, а не выдаёт за общую цифру.
		if err := tx.QueryRow(ctx, `
			SELECT count(*) FILTER (WHERE due_date IS NOT NULL AND due_date < current_date
			                          AND status NOT IN ('executed','archived','rejected')),
			       count(*) FILTER (WHERE on_control AND status <> 'archived')
			FROM documents`).Scan(&rlsOverdue, &rlsOnControl); err != nil {
			return err
		}

		// --- 7. Очередь индексации содержимого PDF ---
		// Готовая сводка из пакета indexer: ровно те же цифры, по которым
		// работает прелоадер поиска, — расхождения между дашбордом и поиском
		// быть не должно. Таблица document_file_text не под RLS, запрос идёт
		// в той же транзакции (pgx.Tx удовлетворяет интерфейсу QueryStatus).
		st, err := indexer.QueryStatus(ctx, tx)
		if err != nil {
			return err
		}
		idx = st
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось собрать метрики системы")
	}

	// Состояние пула соединений снимается ПОСЛЕ транзакции и напрямую у
	// pgxpool: Stat() — копия внутренних счётчиков, в базу не ходит. После
	// коммита цифры отражают пул в покое, а не искусственно занятое нашим же
	// запросом соединение.
	st := h.pool.Stat()
	var mem runtime.MemStats
	runtime.ReadMemStats(&mem)

	return c.JSON(fiber.Map{
		"generated_at": time.Now().Format(time.RFC3339),
		"documents": fiber.Map{
			"total":     docsTotal,
			"by_status": docsByStatus,
			// source объясняет на самой странице, откуда взялась цифра:
			// без этого «всего документов» выглядит как обычный count(*),
			// которого здесь как раз сделать нельзя.
			"source": "documents_count_by_status() (SECURITY DEFINER, в обход RLS)",
		},
		"people": fiber.Map{
			"users_total":        usersTotal,
			"users_active":       usersActive,
			"users_with_roles":   usersWithRoles,
			"departments_total":  deptsTotal,
			"departments_active": deptsActive,
		},
		"load": fiber.Map{
			"created_7d":  created7d,
			"created_30d": created30d,
			"per_day":     perDay,
			"source":      "document_access(access_reason='author').granted_at",
		},
		// Активность пользователей.
		"online": fiber.Map{
			"last_5m":   online5m,
			"last_15m":  online15m,
			"last_hour": online1h,
			"last_24h":  online24h,
			"users":     onlineList,
			"source":    "users.last_seen_at (обновляется не чаще раза в минуту на пользователя)",
		},
		// Историческая перспектива — по месяцам за всю историю.
		"history_by_month": perMonth,
		// Сводка по подразделениям.
		"departments": deptSummary,
		// События безопасности (смена пароля и т.п.).
		"security_events": secEvents,
		// Статистика запросов этого процесса: среднее время ответа, долгие
		// запросы, распределение по маршрутам.
		"requests": metrics.Snapshot(20),
		"indexer":  idx,
		"resolutions": fiber.Map{
			"total":     asgTotal,
			"overdue":   asgOverdue,
			"by_status": asgByStatus,
		},
		"stages": fiber.Map{
			"pending":   stagesPending,
			"by_status": stages,
		},
		"prints": fiber.Map{
			"total":            printsTotal,
			"unregistered":     printsUnreg,
			"d7":               prints7d,
			"d7_unregistered":  prints7dUnreg,
			"d30":              prints30d,
			"d30_unregistered": prints30dUnreg,
		},
		"rls_scoped": fiber.Map{
			"overdue_documents":    rlsOverdue,
			"on_control_documents": rlsOnControl,
			"note": "считается под RLS текущего администратора: видны только доступные ему документы, " +
				"а не все в системе (обхода RLS для роли admin нет)",
		},
		"runtime": fiber.Map{
			"uptime_seconds": int64(time.Since(adminDashboardStartedAt).Seconds()),
			"go_version":     runtime.Version(),
			"goroutines":     runtime.NumGoroutine(),
			"num_cpu":        runtime.NumCPU(),
			"heap_bytes":     int64(mem.HeapAlloc),
			"sys_bytes":      int64(mem.Sys),
			"gc_cycles":      int64(mem.NumGC),
		},
		"db_pool": fiber.Map{
			"total":                int64(st.TotalConns()),
			"max":                  int64(st.MaxConns()),
			"acquired":             int64(st.AcquiredConns()),
			"idle":                 int64(st.IdleConns()),
			"constructing":         int64(st.ConstructingConns()),
			"acquires":             st.AcquireCount(),
			"empty_acquires":       st.EmptyAcquireCount(),
			"canceled_acquires":    st.CanceledAcquireCount(),
			"acquire_wait_seconds": st.AcquireDuration().Seconds(),
		},
	})
}
