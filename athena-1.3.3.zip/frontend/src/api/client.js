// По умолчанию API_URL пустой -> запросы идут на относительные пути
// (/api/..., /ws/...), которые Vite dev-proxy направляет на бэкенд через
// тот же origin. Так браузер не делает cross-origin запросов и CORS не
// участвует вообще. Если нужно бить в API напрямую (напр. в проде, когда
// фронт и API на разных доменах) — задайте VITE_API_URL.
const API_URL = import.meta.env.VITE_API_URL || ''

// Сеанс хранится в cookie, недоступной скриптам страницы (HttpOnly): токена
// в интерфейсе нет вовсе. Браузер сам отправляет cookie с каждым запросом к
// этому же серверу. Рядом сервер ставит cookie athena_csrf — её значение
// интерфейс копирует в заголовок X-CSRF-Token изменяющих запросов (защита от
// подделки запросов с чужих сайтов). Наличие athena_csrf — признак того,
// что сеанс открыт; её срок совпадает со сроком сеанса.
const CSRF_COOKIE = 'athena_csrf'

function readCookie(name) {
  const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'))
  return m ? decodeURIComponent(m[1]) : ''
}

function csrfToken() {
  return readCookie(CSRF_COOKIE)
}

// Заголовки для fetch в обход request(): только CSRF, без Content-Type.
function csrfHeaders() {
  const t = csrfToken()
  return t ? { 'X-CSRF-Token': t } : {}
}

function clearSessionMarker() {
  const secure = location.protocol === 'https:' ? '; Secure' : ''
  document.cookie = `${CSRF_COOKIE}=; Max-Age=0; Path=/; SameSite=Strict${secure}`
}

// Токен прежних версий лежал в localStorage — убираем, если остался.
try { localStorage.removeItem('athena_token') } catch (_) { /* noop */ }

// wsBase возвращает абсолютный origin для WebSocket. new WebSocket() требует
// абсолютный ws://|wss:// URL — относительный путь не примет. Если API_URL
// задан (прямой режим) — берём его; иначе (режим Vite-прокси) строим из
// текущего window.location, чтобы WS шёл на тот же origin (5173) и Vite
// проксировал его на бэкенд.
function wsBase() {
  if (API_URL) return API_URL.replace(/^http/, 'ws')
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${proto}://${window.location.host}`
}

// Переход на страницу входа делается ОДИН раз на всю страницу.
//
// Без этого флага каждый из запросов, оказавшихся в полёте в момент
// истечения сессии, вызывал свой location.assign('/login'), и в консоли
// оставался ворох одинаковых ошибок. Теперь уводит первый, остальные молча
// завершаются.
let redirectingToLogin = false

function goToLogin() {
  clearSessionMarker()
  if (redirectingToLogin) return
  redirectingToLogin = true
  if (!location.pathname.startsWith('/login')) location.assign('/login')
}

// Пути, которым сеанс не нужен. Остальные защищены, и отправлять их без
// сеанса бессмысленно: сервер ответит 401.
const PUBLIC_PATHS = ['/api/auth/login', '/api/auth/info', '/api/auth/kerberos', '/api/app-config']

async function request(path, options = {}) {
  const isPublic = PUBLIC_PATHS.some((p) => path.startsWith(p))
  if (!csrfToken() && !isPublic) {
    // Не ходим на сервер заведомо без сеанса: уводим на вход сразу.
    goToLogin()
    throw new Error('Сессия истекла, войдите заново')
  }
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  }
  Object.assign(headers, csrfHeaders())

  const res = await fetch(`${API_URL}${path}`, { credentials: 'same-origin', ...options, headers })
  if (res.status === 401 && !isPublic) {
    // Сеанс истёк или завершён — уводим на вход.
    goToLogin()
    throw new Error('Сессия истекла, войдите заново')
  }
  if (!res.ok) {
    let message = `Ошибка ${res.status}`
    let reason = ''
    try {
      const body = await res.json()
      if (body.error) message = body.error
      if (body.reason) reason = body.reason
    } catch (_) {
      /* тело не JSON — оставляем дефолтное сообщение */
    }
    // Статус нужен вызывающему коду, чтобы различать 409/422 и т.п.
    const err = new Error(message)
    err.status = res.status
    err.reason = reason
    throw err
  }
  announceMutation(path, options.method)
  const contentType = res.headers.get('content-type') || ''
  if (contentType.includes('application/json')) return res.json()
  return res.blob()
}

// Онлайн-обновление для ВЛАДЕЛЬЦА действия. Сервер не шлёт ему уведомление о
// его же действии, поэтому после любого успешного изменения документа
// (отметка об исполнении, резолюция, регистрация, сообщение...) сообщаем
// интерфейсу событием 'athena:changed' — списки, счётчики и вкладки
// перечитываются сами. Событие дальше уходит в другие вкладки (lib/tabSync).
// Запросы настроек, уведомлений, сессий и входа не считаются изменением документа.
let announceTimer = null
function announceMutation(path, method) {
  const m = String(method || 'GET').toUpperCase()
  if (m === 'GET' || m === 'HEAD') return
  if (/^\/api\/(preferences|notifications|sessions|auth|me\b|audit|admin\/settings)/.test(path)) return
  clearTimeout(announceTimer)
  announceTimer = setTimeout(() => {
    try {
      const mm = path.match(/^\/api\/documents\/(\d+)/)
      window.dispatchEvent(new CustomEvent('athena:changed', { detail: { documentId: mm ? Number(mm[1]) : undefined } }))
    } catch (_) { /* noop */ }
  }, 250)
}

// Имя файла из заголовка Content-Disposition.
//
// Предпочитается filename* (RFC 6266): имена у нас кириллические, а в
// заголовке HTTP допустим только ASCII, поэтому сервер шлёт оба варианта —
// filename с заменой на подчёркивания для старых клиентов и filename* с
// кодировкой UTF-8.
function fileNameFromHeaders(res) {
  const cd = res.headers.get('content-disposition') || ''
  const star = cd.match(/filename\*=UTF-8''([^;]+)/i)
  if (star) {
    try {
      return decodeURIComponent(star[1])
    } catch (_) {
      /* повреждённая кодировка — берём запасной вариант ниже */
    }
  }
  const plain = cd.match(/filename="([^"]+)"/i)
  return plain ? plain[1] : ''
}

export const api = {
  // domain — область (realm), выбранная на странице входа; пусто — локальная
  // учётная запись либо домен указан в самом логине (ivanov@DOMAIN.LOCAL).
  login: (login, password, domain = '') =>
    request('/api/auth/login', { method: 'POST', body: JSON.stringify({ login, password, domain }) }),
  // Сведения для страницы входа: режим порта (password | kerberos), домены.
  authInfo: () => request('/api/auth/info'),
  // Вход по Kerberos: браузер сам отвечает на «401 Negotiate» билетом.
  kerberosLogin: () => request('/api/auth/kerberos'),
  // Проактивное обновление токена, чтобы активная сессия не истекала.
  refreshToken: () => request('/api/auth/refresh', { method: 'POST' }),
  getMe: () => request('/api/me'),
  getAppConfig: () => request('/api/app-config'),
  getDocumentMarking: (id) => request(`/api/documents/${id}/marking`),

  listUsers: () => request('/api/users'),

  // Серверный поиск кандидатов для шага маршрута. group: hierarchy|cross_dept|signing.
  // Возвращает пустой список, пока q пустой (защита от загрузки 300-500 человек).
  searchCandidates: ({ group, q, departmentId, limit = 20 } = {}) => {
    const params = new URLSearchParams({ group, q: q || '', limit: String(limit) })
    if (departmentId) params.set('department_id', String(departmentId))
    return request(`/api/users/candidates?${params.toString()}`)
  },

  // download — скачивание файла с авторизацией.
  //
  // Обычная ссылка <a href="/api/..."> здесь не годится: заголовок
  // Authorization она не передаёт, и сервер ответит 401. Поэтому запрос идёт
  // через fetch, а результат отдаётся браузеру как Blob.
  //
  // Один помощник на все выгрузки (версии файла, отчёты PDF и XLSX, журнал
  // аудита): раньше тот же код копировался бы в пять компонентов и в пятом
  // обязательно отстал бы от остальных.
  download: async (path, filename) => {
    const res = await fetch(`${API_URL}${path}`, {
      headers: csrfHeaders(),
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try {
        const body = await res.json()
        if (body.error) message = body.error
      } catch (_) {
        /* тело не JSON — оставляем код */
      }
      throw new Error(message)
    }
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    // Имя файла: если вызывающий его не задал, берём то, что прислал сервер.
    // Для отчёта по документу имя собирает именно сервер — только он знает
    // исходящий номер и время формирования, а дублировать эту сборку в
    // интерфейсе значило бы получить два разных имени одного файла.
    a.download = filename || fileNameFromHeaders(res) || 'file'
    document.body.appendChild(a)
    a.click()
    a.remove()
    // Освобождаем объект сразу: иначе копия файла висит в памяти вкладки до
    // её закрытия, а отчёты и PDF здесь в мегабайтах.
    URL.revokeObjectURL(url)
  },

  listDepartments: () => request('/api/departments'),
  // Сводная панель руководителя: period = 7|30|90|180|365|ytd.
  getDashboard: ({ period = '90', category = '', mark = '', department = '' } = {}) => {
    const p = new URLSearchParams({ period })
    if (category) p.set('category', category)
    if (mark) p.set('mark', mark)
    if (department) p.set('department', department)
    return request(`/api/dashboard?${p.toString()}`)
  },

  // multipart/form-data: без Content-Type — браузер сам проставит boundary.
  createDocument: async (formData) => {
    const res = await fetch(`${API_URL}/api/documents`, {
      method: 'POST',
      headers: csrfHeaders(),
      body: formData,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try {
        const body = await res.json()
        if (body.error) message = body.error
      } catch (_) {
        /* тело не JSON */
      }
      throw new Error(message)
    }
    return res.json()
  },

  listDocuments: ({ category = 'all', page = 1, pageSize, departmentId, year } = {}) => {
    const params = new URLSearchParams({ category, page: String(page) })
    if (pageSize) params.set('page_size', String(pageSize))
    if (departmentId) params.set('department_id', String(departmentId))
    if (year) params.set('year', String(year))
    return request(`/api/documents?${params.toString()}`)
  },

  // Возвращает { document, incoming_marking }; incoming_marking заполнен,
  // только если текущий пользователь — зарегистрированный получатель.
  getDocument: (id) => request(`/api/documents/${id}`),
  getCopies: (id) => request(`/api/documents/${id}/copies`),
  // Печать
  getPrints: (id) => request(`/api/documents/${id}/prints`),
  registerPrint: (id, printId, body) => request(`/api/documents/${id}/prints/${printId}/register`, { method: 'PATCH', body: JSON.stringify(body) }),
  printDownloadURL: (id) => `/api/documents/${id}/print`,
  // downloadPrint: POST на печать, получает МАРКИРОВАННЫЙ PDF (blob) и
  // инициирует скачивание файла в браузере. Возвращает Error при отказе.
  // #11 — диагностика: почему документ не выдаётся на печать.
  printDiagnostics: (id) => request(`/api/documents/${id}/print-diagnostics`),
  downloadPrint: async (id, copyId) => {
    const url = copyId ? `/api/documents/${id}/print?copy_id=${copyId}` : `/api/documents/${id}/print`
    const res = await fetch(url, {
      method: 'POST',
      headers: csrfHeaders(),
    })
    if (!res.ok) {
      let msg = 'Не удалось выдать документ на печать'
      try { const j = await res.json(); msg = j.error || j.message || msg } catch { /* ignore */ }
      throw new Error(msg)
    }
    const blob = await res.blob()
    const dlUrl = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = dlUrl
    a.download = `document-${id}-print.pdf`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(dlUrl)
  },

  // Направление рассылке. recipients: [{ user_id, department_id }].
  // Пустой массив -> бэкенд активирует плановых адресатов (выбранных при создании).
  sendDocument: (id, recipients = []) =>
    request(`/api/documents/${id}/send`, {
      method: 'POST',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({
          user_id: Number(r.user_id ?? r.id),
          department_id: Number(r.department_id),
        })),
      }),
    }),

  getStages: (id) => request(`/api/documents/${id}/stages`),

  getMyRoles: (id) => request(`/api/documents/${id}/my-roles`),

  // #26 — specialMarkId добавлен последним параметром: журнал фильтруется и
  // по особой отметке, как остальные списки.
  getRegistry: (kind, year, q, categoryId, specialMarkId, offset = 0) => {
    const p = new URLSearchParams({ offset: String(offset) })
    if (year) p.set('year', year)
    if (q) p.set('q', q)
    if (categoryId) p.set('category_id', categoryId)
    if (specialMarkId) p.set('special_mark_id', specialMarkId)
    const qs = p.toString()
    return request(`/api/registry/${kind}${qs ? `?${qs}` : ''}`)
  },
  downloadRegistryCsv: async (kind, year, q, categoryId, specialMarkId) => {
    const p = new URLSearchParams()
    if (year) p.set('year', year)
    if (q) p.set('q', q)
    if (categoryId) p.set('category_id', categoryId)
    if (specialMarkId) p.set('special_mark_id', specialMarkId)
    const qs = p.toString()
    const res = await fetch(`${API_URL}/api/registry/${kind}/export${qs ? `?${qs}` : ''}`, {
      headers: csrfHeaders(),
    })
    if (!res.ok) throw new Error(`Ошибка ${res.status}`)
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `registry_${kind}${year ? `_${year}` : ''}.xlsx`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  },
  getLinks: (id) => request(`/api/documents/${id}/links`),
  deleteLink: (id, linkId) => request(`/api/documents/${id}/links/${linkId}`, { method: 'DELETE' }),
  // Связь с системным документом (мультивыбор делается на фронте по одному вызову на документ).
  createLink: (id, targetDocumentId, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ target_document_id: Number(targetDocumentId), link_type: linkType }),
    }),
  // Связь-заметка на несистемный (бумажный/внешний) документ.
  createLinkNote: (id, textNote, linkType) =>
    request(`/api/documents/${id}/links`, {
      method: 'POST',
      body: JSON.stringify({ text_note: textNote, link_type: linkType }),
    }),
  // Поиск системных документов для связывания (частичное совпадение, ILIKE).
  // #20 — Поиск документа для связи: по НАЗВАНИЮ или по НОМЕРУ (исх./вх.) в
  // одном поле. Раньше уходил только `q`, то есть по названию и содержанию, и
  // найти документ по входящему номеру было нельзя. Параметр `any` — это одно
  // условие «ИЛИ» на сервере; отправить ту же строку в q, number и
  // incoming_number было нельзя, они объединяются через «И».
  searchSystemDocuments: (q) =>
    request(`/api/documents/search?any=${encodeURIComponent(q)}&page=1&page_size=10`),


  getNotifications: ({ onlyUnread = false, limit = 50 } = {}) =>
    request(`/api/notifications?only_unread=${onlyUnread}&limit=${limit}`),
  markNotificationRead: (id) => request(`/api/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: () => request('/api/notifications/read-all', { method: 'POST' }),
  // #2 — уведомления-будильники: требующие подтверждения и «отложить».
  getAlarmNotifications: () => request('/api/notifications/alarms'),
  // Отложить ВСЕ показанные будильники одним запросом: иначе окно не
  // закрывается с первого нажатия (их обычно несколько).
  snoozeAllNotifications: (minutes) =>
    request('/api/notifications/snooze-all', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ minutes }),
    }),
  snoozeNotification: (id, minutes) =>
    request(`/api/notifications/${id}/snooze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ minutes }),
    }),

  // Расширенный поиск/фильтр по ВСЕМ атрибутам документа. Любой параметр опционален.
  searchDocuments: (f = {}) => {
    const params = new URLSearchParams({ page: String(f.page || 1) })
    const set = (k, v) => { if (v !== undefined && v !== null && v !== '') params.set(k, String(v)) }
    set('category', f.category)
    set('q', f.q)
    set('author_id', f.authorId)
    set('signer_id', f.signerId)
    set('controller_id', f.controllerId)
    set('approver_id', f.approverId)
    set('recipient_id', f.recipientId)
    set('department_id', f.departmentId)
    set('status', f.status)
    set('on_control', f.onControl)
    set('number', f.number)
    set('incoming_number', f.incomingNumber)
    set('category_id', f.categoryId)
    // --- Группа D ---
    set('content', f.content)              // #4 — поиск по содержимому PDF
    set('special_mark_id', f.specialMarkId) // #26 — особая отметка
    set('participant_id', f.participantId)  // #28 — любое участие в документе
    set('signed_from', f.signedFrom)
    set('signed_to', f.signedTo)
    set('created_from', f.createdFrom)
    set('created_to', f.createdTo)
    set('due_from', f.dueFrom)
    set('due_to', f.dueTo)
    set('page_size', f.pageSize)
    return request(`/api/documents/search?${params.toString()}`)
  },
  getHistory: (id) => request(`/api/documents/${id}/history`),
  // #13 — getViews убран: просмотры входят в getCopies (first_view_at,
  // last_view_at, view_count).
  // #17 — счётчики для подписей вкладок.
  getDocumentCounts: (id) => request(`/api/documents/${id}/counts`),
  // #41 — количество документов по категориям бокового меню.
  getCategoryCounts: () => request('/api/documents/category-counts'),
  // #10 — метрики состояния системы для админ-дашборда.
  getAdminMetrics: () => request('/api/admin/metrics'),

  // --- Группа D: поиск и фильтры ------------------------------------------
  // #28 — люди для фильтров: без ограничения иерархией, включая уволенных.
  getFilterPeople: ({ role, q, limit = 20 } = {}) => {
    const params = new URLSearchParams({ limit: String(limit) })
    if (role) params.set('role', role)
    if (q) params.set('q', q)
    return request(`/api/users/filter-candidates?${params.toString()}`)
  },
  // #26 — справочник особых отметок.
  adminGetMarkingSettings: () => request('/api/admin/settings/marking'),
  adminSetMarkingSettings: (page_mode) =>
    request('/api/admin/settings/marking', { method: 'PUT', body: JSON.stringify({ page_mode }) }),
  getSpecialMarks: () => request('/api/special-marks'),
  createSpecialMark: (body) =>
    request('/api/admin/special-marks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  updateSpecialMark: (id, body) =>
    request(`/api/admin/special-marks/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  deleteSpecialMark: (id) => request(`/api/admin/special-marks/${id}`, { method: 'DELETE' }),
  // #4 — прогресс фоновой индексации содержимого PDF (для прелоадера).
  getSearchIndexStatus: () => request('/api/search/index-status'),
  // #3 — личные настройки интерфейса на сервере (состояние фильтров).
  getPreference: (key) => request(`/api/preferences/${encodeURIComponent(key)}`),
  savePreference: (key, value) =>
    request(`/api/preferences/${encodeURIComponent(key)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(value),
    }),
  deletePreference: (key) => request(`/api/preferences/${encodeURIComponent(key)}`, { method: 'DELETE' }),
  // Избранное (, п. 4): личный список каждого пользователя.
  // Отдельные методы вместо одного «переключить»: состояние звёздочки на
  // клиенте уже известно, а идемпотентные POST/DELETE не «перевернут» отметку
  // при повторном клике из-за задержки сети.
  addFavorite: (id) => request(`/api/documents/${id}/favorite`, { method: 'POST' }),
  removeFavorite: (id) => request(`/api/documents/${id}/favorite`, { method: 'DELETE' }),

  // ======================= =======================

  // п. 3 — резолюции руководителя (заменили поручения).
  listResolutions: (docId) => request(`/api/documents/${docId}/resolutions`),
  createResolution: (docId, body) =>
    request(`/api/documents/${docId}/resolutions`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }),
  editResolution: (id, body) =>
    request(`/api/resolutions/${id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }),
  resolutionProgress: (id) => request(`/api/resolutions/${id}/progress`, { method: 'POST' }),
  resolutionCancel: (id, reason) =>
    request(`/api/resolutions/${id}/cancel`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ reason }),
    }),
  resolutionReassign: (id, body) =>
    request(`/api/resolutions/${id}/reassign`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }),
  resolutionReport: (id, report) =>
    request(`/api/resolutions/${id}/report`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ report }),
    }),
  resolutionAccept: (id, body = {}) =>
    request(`/api/resolutions/${id}/accept`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }),
  resolutionReturn: (id, body) =>
    request(`/api/resolutions/${id}/return`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    }),
  // Методов «отменить резолюцию», «переназначить» и журнала переназначений
  // больше нет: резолюция по документу накладывается один раз, ветвления не
  // осталось, и соответствующие маршруты на сервере удалены.
  myResolutions: (status = 'open', role = '') =>
    request(`/api/my/resolutions?status=${status}${role ? `&role=${role}` : ''}`),
  getGlobalHistory: ({ limit = 100, cursor = '', documentId = '' } = {}) => {
    const p = new URLSearchParams({ limit: String(limit) })
    if (cursor) p.set('cursor', cursor)
    if (documentId) p.set('document_id', String(documentId))
    return request(`/api/history?${p.toString()}`)
  },

  // Версии карточки и файла.
  //
  // Метода скачивания версии файла здесь больше НЕТ (, п. 7 —
  // «версии файла документа нельзя скачивать!»): вместе с ним удалён и сам
  // обработчик на сервере, поэтому ссылка не работает ни из интерфейса, ни
  // напрямую.
  listVersions: (docId) => request(`/api/documents/${docId}/versions`),

  // п. 6 — предотвращение повторной регистрации.
  //
  // FormData, а не JSON: вместе с реквизитами отправляется сам файл, чтобы
  // сервер посчитал его хэш и нашёл документ с тем же содержимым. Файл при
  // этом НЕ сохраняется — только хэшируется.
  checkDuplicate: (fields, file) => {
    const fd = new FormData()
    Object.entries(fields || {}).forEach(([k, v]) => { if (v) fd.append(k, v) })
    if (file) fd.append('file', file)
    return request('/api/registration/check-duplicate', { method: 'POST', body: fd })
  },
  checkIncomingNumber: (departmentId, number) =>
    request(`/api/registration/check-incoming-number?department_id=${departmentId}&number=${encodeURIComponent(number)}`),

  // п. 5 и 7 — отчётность.
  documentReport: (docId) => request(`/api/documents/${docId}/report`),
  documentReportPdfUrl: (docId) => `/api/documents/${docId}/report.pdf`,
  // Сводной отчётности (дисциплина исполнения, область) больше нет: раздел
  // ничего не показывал, и по решению заказчика оставлен только отчёт по
  // конкретному документу. Маршруты на сервере удалены вместе с ним.

  // п. 8 — сеансы работы.
  listSessions: (activeOnly = true) => request(`/api/sessions?active=${activeOnly}`),
  revokeSession: (id) => request(`/api/sessions/${id}`, { method: 'DELETE' }),
  logout: () => request('/api/auth/logout', { method: 'POST' }),

  // Журнал аудита.
  auditList: (params) => request(`/api/audit?${new URLSearchParams(params)}`),
  auditEvents: () => request('/api/audit/events'),
  auditExportUrl: (params) => `/api/audit/export?${new URLSearchParams(params)}`,
  // п. 13 — размер журнала и удаление за период.
  auditSize: () => request('/api/audit/size'),
  auditPurge: (from, to) =>
    request(`/api/audit?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`,
      { method: 'DELETE' }),

  // Методов штатного расписания здесь больше нет.
  // Отметка об исполнении. Состояние и права
  // спрашиваются у сервера, а не вычисляются интерфейсом: именно самодельное
  // вычисление и приводило к тому, что у исполнителя, не являющегося
  // адресатом, кнопки не было.
  executionStatus: (id) => request(`/api/documents/${id}/execution`),
  markExecuted: (id, note) =>
    request(`/api/documents/${id}/complete`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    }),
  changeExecutionMark: (id, note) =>
    request(`/api/documents/${id}/complete`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    }),
  cancelExecutionMark: (id, reason) =>
    request(`/api/documents/${id}/complete`, {
      method: 'DELETE', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason }),
    }),

  getRecipients: (id) => request(`/api/documents/${id}/recipients`),
  deleteRecipient: (id, recipientId) => request(`/api/documents/${id}/recipients/${recipientId}`, { method: 'DELETE' }),
  // Пакетные счётчики адресатов для страницы списка (без N+1).
  recipientsCounts: (ids = []) =>
    ids.length ? request(`/api/recipients-counts?ids=${ids.join(',')}`) : Promise.resolve({ counts: {} }),
  // Ознакомление.
  getAcquaintances: (id) => request(`/api/documents/${id}/acquaintances`),
  acquaintCandidates: (q = '', documentId) =>
    request(`/api/acquaint-candidates?q=${encodeURIComponent(q)}${documentId ? `&document_id=${documentId}` : ''}`),
  acquaint: (id, userIds = []) =>
    request(`/api/documents/${id}/acquaint`, {
      method: 'POST',
      body: JSON.stringify({ user_ids: userIds.map(Number) }),
    }),
  // completeDocument — прежнее имя markExecuted, оставлено как синоним:
  // метод вызывается из вкладки «Исполнение», и переименовывать его заодно
  // с остальными правками значило бы смешать в одном изменении две разные
  // задачи.
  completeDocument: (id, note) => api.markExecuted(id, note),
  updateDocument: (id, patch) =>
    request(`/api/documents/${id}`, { method: 'PATCH', body: JSON.stringify(patch) }),

  // Замена PDF-оригинала до подписи (multipart). Сбрасывает согласование.
  replaceDocumentFile: async (id, file) => {
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch(`${API_URL}/api/documents/${id}/file`, {
      method: 'PATCH',
      headers: csrfHeaders(),
      body: fd,
    })
    if (!res.ok) {
      let message = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) message = b.error } catch (_) { /* noop */ }
      throw new Error(message)
    }
    return true
  },
  deleteDocument: (id) => request(`/api/documents/${id}`, { method: 'DELETE' }),
  updateRoute: (id, route) =>
    request(`/api/documents/${id}/route`, { method: 'PATCH', body: JSON.stringify(route) }),
  updateSigners: (id, signerIds) =>
    request(`/api/documents/${id}/signers`, { method: 'PUT', body: JSON.stringify({ signer_ids: signerIds }) }),
  // updatePlannedRecipients принимает ДВЕ формы записи адресата, и это не
  // небрежность, а необходимость: форма создания и изменения документа
  // работает с результатом выбора человека (там идентификатор лежит в поле
  // id), а вкладка «Рассылка» — с уже сохранённым списком рассылки (там то же
  // значение приходит с сервера в поле user_id). Приводить их к одному виду в
  // каждом вызывающем месте значило бы однажды забыть про одно из них и
  // отправить user_id: NaN — запрос при этом не падает, а молча сохраняет
  // пустую рассылку.
  updatePlannedRecipients: (id, recipients) =>
    request(`/api/documents/${id}/planned-recipients`, {
      method: 'PATCH',
      body: JSON.stringify({
        recipients: recipients.map((r) => ({
          user_id: Number(r.user_id ?? r.id),
          department_id: Number(r.department_id),
        })),
      }),
    }),
  // #4 — контролёров может быть несколько. Принимаем массив id или один id.
  setControl: (id, onControl, controllers) => {
    const arr = Array.isArray(controllers)
      ? controllers.map(Number).filter(Boolean)
      : (controllers ? [Number(controllers)] : [])
    return request(`/api/documents/${id}/control`, {
      method: 'POST',
      body: JSON.stringify({ on_control: onControl, controller_ids: arr }),
    })
  },
  getDocumentControllers: (id) => request(`/api/documents/${id}/controllers`),
  getDocumentSignatures: (id) => request(`/api/documents/${id}/signatures`),
  getDefaultControllers: () => request('/api/default-controllers'),
  archiveDocument: (id) => request(`/api/documents/${id}/archive`, { method: 'POST' }),

  // Файл отдаётся только через авторизованный запрос (Authorization header),
  // не по прямой ссылке с токеном в query — иначе токен утекает в логи
  // прокси/браузера. Компонент вьювера сам создаёт object URL из blob.
  getDocumentFileBlob: (id) => request(`/api/documents/${id}/file`),

  decideStage: (documentId, stageId, approve, comment, extra) =>
    request(`/api/documents/${documentId}/stages/${stageId}/decide`, {
      method: 'POST',
      body: JSON.stringify({ approve, comment, ...(extra || {}) }),
    }),

  // Обсуждение документа.
  getChatHistory: (id) => request(`/api/documents/${id}/chat`),
  postChatMessage: async (id, text, files = []) => {
    const fd = new FormData()
    fd.append('text', text || '')
    for (const f of files) fd.append('files', f)
    const res = await fetch(`${API_URL}/api/documents/${id}/chat`, {
      method: 'POST',
      headers: csrfHeaders(),
      body: fd,
    })
    if (!res.ok) {
      let m = `Ошибка ${res.status}`
      try { const b = await res.json(); if (b.error) m = b.error } catch (_) { /* noop */ }
      throw new Error(m)
    }
    return res.json()
  },
  downloadChatAttachment: async (aid, fileName) => {
    const res = await fetch(`${API_URL}/api/chat/attachments/${aid}`, {
      headers: csrfHeaders(),
    })
    if (!res.ok) throw new Error('Не удалось скачать вложение')
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = fileName || 'attachment'
    document.body.appendChild(a)
    a.click()
    a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  },
  editChatMessage: (mid, text) =>
    request(`/api/chat/messages/${mid}`, { method: 'PATCH', body: JSON.stringify({ text }) }),
  deleteChatMessage: (mid) => request(`/api/chat/messages/${mid}`, { method: 'DELETE' }),

  wsURL: (documentId) => {
    return `${wsBase()}/ws/documents/${documentId}/chat`
  },

  wsNotificationsURL: () => {
    return `${wsBase()}/ws/notifications`
  },

  // --- Администрирование (только для роли admin; сервер проверяет права) ---
  adminListDepartments: () => request('/api/admin/departments'),
  adminCreateDepartment: (body) => request('/api/admin/departments', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateDepartment: (id, body) => request(`/api/admin/departments/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminMoveDepartment: (id, parentId) => request(`/api/admin/departments/${id}/parent`, { method: 'PATCH', body: JSON.stringify({ parent_id: parentId }) }),
  adminDeleteDepartment: (id) => request(`/api/admin/departments/${id}`, { method: 'DELETE' }),
  adminListUsers: () => request('/api/admin/users'),
  adminCreateUser: (body) => request('/api/admin/users', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateUser: (id, body) => request(`/api/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminMoveUser: (id, departmentId) => request(`/api/admin/users/${id}/department`, { method: 'PATCH', body: JSON.stringify({ department_id: departmentId }) }),
  // Самостоятельная смена пароля. Требования отдаёт сервер — чтобы подсказка
  // в форме и настоящая проверка не разошлись.
  getPasswordRequirements: () => request('/api/password/requirements'),
  changeOwnPassword: (currentPassword, newPassword) =>
    request('/api/password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
    }),
  adminSetUserPassword: (id, password) => request(`/api/admin/users/${id}/password`, { method: 'PATCH', body: JSON.stringify({ password }) }),
  // Домены аутентификации (LDAP / Kerberos).
  adminListAuthDomains: () => request('/api/admin/auth-domains'),
  adminCreateAuthDomain: (body) => request('/api/admin/auth-domains', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateAuthDomain: (id, body) => request(`/api/admin/auth-domains/${id}`, { method: 'PUT', body: JSON.stringify(body) }),
  adminDeleteAuthDomain: (id) => request(`/api/admin/auth-domains/${id}`, { method: 'DELETE' }),
  adminTestAuthDomain: (id, login) => request(`/api/admin/auth-domains/${id}/test`, { method: 'POST', body: JSON.stringify({ login }) }),
  adminDeleteKeytab: (id) => request(`/api/admin/auth-domains/${id}/keytab`, { method: 'DELETE' }),
  adminUploadKeytab: async (id, file) => {
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch(`${API_URL}/api/admin/auth-domains/${id}/keytab`, {
      method: 'PUT', body: fd, headers: csrfHeaders(),
    })
    const body = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(body.error || `Ошибка ${res.status}`)
    return body
  },
  adminSetUserRoles: (id, departmentId, roles) => request(`/api/admin/users/${id}/roles`, { method: 'PATCH', body: JSON.stringify({ department_id: departmentId, roles }) }),
  adminSetUserDepartments: (id, sets) => request(`/api/admin/users/${id}/departments`, { method: 'PATCH', body: JSON.stringify(sets) }),

  // #4 — Группы адресатов рассылки.
  listRecipientGroups: () => request('/api/recipient-groups'),
  // #6 — категории документов
  listCategories: () => request('/api/categories'),
  adminCreateCategory: (body) => request('/api/admin/categories', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateCategory: (id, body) => request(`/api/admin/categories/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminDeleteCategory: (id) => request(`/api/admin/categories/${id}`, { method: 'DELETE' }),
  adminCreateRecipientGroup: (body) => request('/api/admin/recipient-groups', { method: 'POST', body: JSON.stringify(body) }),
  adminUpdateRecipientGroup: (id, body) => request(`/api/admin/recipient-groups/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  adminDeleteRecipientGroup: (id) => request(`/api/admin/recipient-groups/${id}`, { method: 'DELETE' }),
  adminSetRecipientGroupMembers: (id, members) => request(`/api/admin/recipient-groups/${id}/members`, { method: 'PUT', body: JSON.stringify({ members }) }),
}

// Сеанс открывает и закрывает сервер (cookie); интерфейсу остаётся только
// забыть признак сеанса при выходе.
export function clearSession() {
  clearSessionMarker()
}

export function isAuthenticated() {
  return !!csrfToken()
}
