package server

import (
	"context"
	"strconv"
	"sync"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Модуль предназначен для построчной защиты данных (RLS, миграция 007_rls.sql).
//
// Контекст пользователя передаётся через context.Context запроса (withRLS вызывается в s.h после проверки сессии).
// Каждый запрос, выполняемый с таким контекстом, уходит на сервер одной пачкой (pipeline) вместе с настройкой
//   SELECT set_config('role','corpnet_app',true), set_config('app.user_id',…,true), …
// — «local» значит «только до конца неявной транзакции пачки», поэтому настройки не протекают в соединения пула.
// Запросы без контекста (вход, фоновые задачи) — служебные: идут под ролью подключения, политики их пропускают.

type rlsUser struct {
	id   int64
	role string
	hr   bool
}
type rlsKey struct{}

func withRLS(ctx context.Context, u *User) context.Context {
	if u == nil {
		return ctx
	}
	return context.WithValue(ctx, rlsKey{}, &rlsUser{id: u.ID, role: u.Role, hr: u.HR})
}
func rlsOf(ctx context.Context) *rlsUser { v, _ := ctx.Value(rlsKey{}).(*rlsUser); return v }

// DB — пул соединений с поддержкой RLS. Методы Exec/Query/QueryRow/Begin подставляют контекст пользователя.
type DB struct {
	*pgxpool.Pool
	Off bool // RLS_DISABLE=1: аварийное отключение
}

const rlsPre = `SELECT set_config('role', 'corpnet_app', true), set_config('app.user_id', $1, true), set_config('app.role', $2, true), set_config('app.hr', $3, true)`

func (r *rlsUser) args() []any {
	hr := ""
	if r.hr {
		hr = "1"
	}
	return []any{strconv.FormatInt(r.id, 10), r.role, hr}
}

func (d *DB) rls(ctx context.Context) *rlsUser {
	if d.Off {
		return nil
	}
	return rlsOf(ctx)
}

func (d *DB) Exec(ctx context.Context, sql string, args ...any) (pgconn.CommandTag, error) {
	ru := d.rls(ctx)
	if ru == nil {
		return d.Pool.Exec(ctx, sql, args...)
	}
	conn, err := d.Pool.Acquire(ctx)
	if err != nil {
		return pgconn.CommandTag{}, err
	}
	defer conn.Release()
	b := &pgx.Batch{}
	b.Queue(rlsPre, ru.args()...)
	b.Queue(sql, args...)
	br := conn.SendBatch(ctx, b)
	if _, err := br.Exec(); err != nil {
		br.Close()
		return pgconn.CommandTag{}, err
	}
	tag, err := br.Exec()
	closeErr := br.Close()
	if err != nil {
		return pgconn.CommandTag{}, err
	}
	return tag, closeErr
}

type rlsRows struct {
	pgx.Rows
	br       pgx.BatchResults
	conn     *pgxpool.Conn
	once     sync.Once
	closeErr error
}

func (r *rlsRows) Close() {
	r.Rows.Close()
	r.once.Do(func() { r.closeErr = r.br.Close(); r.conn.Release() })
}
func (r *rlsRows) Err() error {
	if err := r.Rows.Err(); err != nil {
		return err
	}
	return r.closeErr
}
func (r *rlsRows) Next() bool {
	if r.Rows.Next() {
		return true
	}
	r.Close()
	return false
}

func (d *DB) Query(ctx context.Context, sql string, args ...any) (pgx.Rows, error) {
	ru := d.rls(ctx)
	if ru == nil {
		return d.Pool.Query(ctx, sql, args...)
	}
	conn, err := d.Pool.Acquire(ctx)
	if err != nil {
		return nil, err
	}
	b := &pgx.Batch{}
	b.Queue(rlsPre, ru.args()...)
	b.Queue(sql, args...)
	br := conn.SendBatch(ctx, b)
	if _, err := br.Exec(); err != nil {
		br.Close()
		conn.Release()
		return nil, err
	}
	rows, err := br.Query()
	if err != nil {
		br.Close()
		conn.Release()
		return nil, err
	}
	return &rlsRows{Rows: rows, br: br, conn: conn}, nil
}

type rlsRow struct {
	rows pgx.Rows
	err  error
}

func (r rlsRow) Scan(dest ...any) error {
	if r.err != nil {
		return r.err
	}
	defer r.rows.Close()
	if !r.rows.Next() {
		if err := r.rows.Err(); err != nil {
			return err
		}
		return pgx.ErrNoRows
	}
	if err := r.rows.Scan(dest...); err != nil {
		return err
	}
	r.rows.Close()
	return r.rows.Err()
}

func (d *DB) QueryRow(ctx context.Context, sql string, args ...any) pgx.Row {
	if d.rls(ctx) == nil {
		return d.Pool.QueryRow(ctx, sql, args...)
	}
	rows, err := d.Query(ctx, sql, args...)
	return rlsRow{rows: rows, err: err}
}

func (d *DB) Begin(ctx context.Context) (pgx.Tx, error) {
	tx, err := d.Pool.Begin(ctx)
	if err != nil {
		return nil, err
	}
	if ru := d.rls(ctx); ru != nil {
		if _, err := tx.Exec(ctx, rlsPre, ru.args()...); err != nil {
			tx.Rollback(ctx)
			return nil, err
		}
	}
	return tx, nil
}
