#!/usr/bin/env python3
"""Подготовка встроенного шрифта для PDF-отчётов.

ЗАЧЕМ ЭТО НУЖНО.

В проекте нет библиотеки, умеющей СОЗДАВАТЬ PDF: pdfcpu только штампует уже
готовые файлы. Отчёты по исполнительской дисциплине (замечание v51, п. 7)
нужно выдавать в PDF, причём с русским текстом и графиками.

Стандартные 14 шрифтов PDF (Helvetica и прочие) кириллицы НЕ содержат — ни в
одной кодировке. Значит шрифт надо встраивать в документ. Встраивать его целиком
(DejaVuSans.ttf — 760 КБ) в каждый отчёт накладно, а парсить TTF в рантайме,
чтобы получить номера глифов и их ширины, — лишний риск в коде, который и так
нельзя проверить сборкой.

Поэтому разделение: ЭТОТ скрипт один раз готовит
  * субсет шрифта (только нужные символы) — его встраивает Go через go:embed;
  * таблицу «символ -> номер глифа + ширина» в виде Go-файла.
Рантайм только подставляет номера глифов из готовой таблицы. Ни парсинга
шрифта, ни зависимостей.

ВАЖНО: --retain-gids. Без него субсеттер перенумеровывает глифы, и таблица,
сгенерированная по исходному шрифту, перестала бы соответствовать субсету.

Запуск (нужен fontTools: pip install fonttools):
    python3 scripts/gen_report_font.py [путь_к_DejaVuSans.ttf]

Результат:
    backend/internal/report/fonts/report-sans.ttf
    backend/internal/report/glyphs_gen.go

Лицензия шрифта: DejaVu Fonts License (Bitstream Vera + Arev) — свободная,
разрешает встраивание и распространение. Текст лицензии положен рядом со
шрифтом в fonts/LICENSE-DejaVu.txt.
"""
import os
import sys
import subprocess
import tempfile

from fontTools.ttLib import TTFont
from fontTools.subset import Subsetter, Options

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "backend", "internal", "report", "fonts")
OUT_TTF = os.path.join(OUT_DIR, "report-sans.ttf")
OUT_GO = os.path.join(ROOT, "backend", "internal", "report", "glyphs_gen.go")

# Набор символов отчёта: кириллица (оба регистра + ё/Ё), латиница, цифры,
# знаки препинания и типографика, которую реально печатаем (кавычки-ёлочки,
# тире, №, ×, стрелки, проценты, градус — встречаются в подписях графиков).
CHARS = []
CHARS += [chr(c) for c in range(0x20, 0x7F)]                 # ASCII печатаемые
CHARS += [chr(c) for c in range(0x0410, 0x0450)]             # А-я
CHARS += ["Ё", "ё", "№", "«", "»", "—", "–", "…", "•", "·",
          "“", "”", "„", "’", "‘", "×", "÷", "±", "°", "→", "←", "↑", "↓",
          "≤", "≥", "≠", "₽", " "]


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    if not os.path.exists(src):
        sys.exit(f"не найден исходный шрифт: {src}\n"
                 f"укажите путь аргументом или установите fonts-dejavu-core")

    os.makedirs(OUT_DIR, exist_ok=True)

    font = TTFont(src)
    cmap = font.getBestCmap()
    glyph_order = font.getGlyphOrder()
    gid_by_name = {n: i for i, n in enumerate(glyph_order)}
    upem = font["head"].unitsPerEm
    hmtx = font["hmtx"]

    # Таблица «символ -> (gid, ширина в 1000-й сетке)».
    # PDF ожидает ширины в тысячных долях em, поэтому пересчитываем из upem.
    table = []
    missing = []
    for ch in CHARS:
        cp = ord(ch)
        name = cmap.get(cp)
        if name is None:
            missing.append(ch)
            continue
        gid = gid_by_name[name]
        adv = hmtx[name][0]
        width = round(adv * 1000 / upem)
        table.append((cp, gid, width))
    table.sort()

    # Субсет по тем же кодовым точкам, с СОХРАНЕНИЕМ номеров глифов.
    opts = Options()
    opts.retain_gids = True
    opts.drop_tables += ["GSUB", "GPOS", "GDEF", "kern", "morx"]
    opts.notdef_outline = True
    opts.recalc_bounds = False
    sub = Subsetter(options=opts)
    sub.populate(unicodes=[cp for cp, _, _ in table])
    sub.subset(font)
    font.save(OUT_TTF)

    head = font["head"]
    os2 = font["OS/2"] if "OS/2" in font else None
    ascent = round(os2.sTypoAscender * 1000 / upem) if os2 else 800
    descent = round(os2.sTypoDescender * 1000 / upem) if os2 else -200
    # sCapHeight есть только в OS/2 версии 2+. Если его нет, берём готовое
    # значение в 1000-й сетке, а НЕ пересчитываем его: иначе 700 единиц
    # интерпретировались бы как единицы шрифта и дали бы 342 — высота
    # прописной вышла бы вдвое меньше настоящей, и просмотрщик неверно
    # подбирал бы шрифт-замену.
    cap_raw = getattr(os2, "sCapHeight", None) if os2 else None
    cap = round(cap_raw * 1000 / upem) if cap_raw else 700
    bbox = [round(v * 1000 / upem) for v in
            (head.xMin, head.yMin, head.xMax, head.yMax)]

    with open(OUT_GO, "w", encoding="utf-8") as f:
        f.write(f"""// Код сгенерирован scripts/gen_report_font.py — не править руками.
//
// Таблица «символ -> номер глифа + ширина» для встроенного шрифта отчётов
// (fonts/report-sans.ttf). Нужна PDF-генератору: в кодировке Identity-H текст
// записывается НОМЕРАМИ ГЛИФОВ, а не символами, и ширины глифов обязаны быть
// в самом документе, иначе просмотрщик не сможет расставить текст.
//
// Соответствие номеров глифов субсету обеспечено ключом --retain-gids при
// субсеттинге: без него субсеттер перенумеровал бы глифы и таблица перестала
// бы совпадать со шрифтом.
//
// Исходный шрифт: DejaVu Sans. Перегенерация:
//   python3 scripts/gen_report_font.py [путь_к_DejaVuSans.ttf]

package report

// fontUnitsPerEm — сетка исходного шрифта. Все значения ниже приведены к
// 1000-й сетке, как требует PDF, поэтому в коде она нужна только для справки.
const fontUnitsPerEm = {upem}

// Метрики дескриптора шрифта (в 1000-й сетке).
const (
\tfontAscent    = {ascent}
\tfontDescent   = {descent}
\tfontCapHeight = {cap}
)

// fontBBox — габариты шрифта для /FontBBox.
var fontBBox = [4]int{{{bbox[0]}, {bbox[1]}, {bbox[2]}, {bbox[3]}}}

// glyphInfo — номер глифа и его ширина.
type glyphInfo struct {{
\tGID   uint16
\tWidth int
}}

// glyphs — таблица по кодовой точке символа.
var glyphs = map[rune]glyphInfo{{
""")
        for cp, gid, w in table:
            ch = chr(cp)
            safe = ch if ch.isprintable() and ch not in '\\"' and cp != 0xa0 else f"U+{cp:04X}"
            f.write(f"\t{cp}: {{{gid}, {w}}}, // {safe}\n")
        f.write("}\n")

    print(f"символов в таблице: {len(table)}")
    if missing:
        print("не найдены в исходном шрифте:", "".join(missing))
    print(f"субсет: {OUT_TTF} ({os.path.getsize(OUT_TTF)} байт)")
    print(f"таблица: {OUT_GO}")


if __name__ == "__main__":
    main()
