import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { api, clearSession, isAuthenticated } from '../api/client'
import { installWindowBridge } from '../lib/tabSync'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [authed, setAuthed] = useState(isAuthenticated())
  const [login, setLoginName] = useState(localStorage.getItem('athena_login') || '')
  const [me, setMe] = useState(null) // { roles, is_admin, can_create, full_name }

  const doLogin = useCallback(async (loginValue, password, domain = '') => {
    const res = await api.login(loginValue, password, domain)
    // Сеанс сервер выдал cookie; здесь — только имя для интерфейса и
    // сигнал другим вкладкам.
    localStorage.setItem('athena_login', res.login)
    localStorage.setItem('athena_auth_event', `in:${Date.now()}`)
    setLoginName(res.login)
    setAuthed(true)
  }, [])

  // Вход по Kerberos: сеанс выдан сервером по проверенному билету.
  const doSsoLogin = useCallback((res) => {
    localStorage.setItem('athena_login', res.login)
    localStorage.setItem('athena_auth_event', `in:${Date.now()}`)
    setLoginName(res.login)
    setAuthed(true)
  }, [])

  const doLogout = useCallback(() => {
    clearSession()
    localStorage.removeItem('athena_login')
    localStorage.setItem('athena_auth_event', `out:${Date.now()}`)
    setMe(null)
    setAuthed(false)
  }, [])

  // Несколько вкладок. Cookie сеанса общая для вкладок, но событий о её
  // изменении браузер не даёт, поэтому вход и выход объявляются через
  // localStorage (событие storage приходит в ДРУГИЕ вкладки):
  //   * выход в другой вкладке → выходим и здесь;
  //   * вход другим пользователем → перезагружаем вкладку, чтобы не
  //     показывать данные прежнего пользователя;
  //   * вход в другой вкладке → считаем себя вошедшими.
  // Плюс раз в минуту сверяемся с cookie: истёкший сеанс браузер удаляет сам.
  useEffect(() => {
    installWindowBridge()
    const onStorage = (e) => {
      if (e.key === 'athena_login') {
        if (e.oldValue && e.newValue && e.oldValue !== e.newValue) window.location.reload()
        return
      }
      if (e.key !== 'athena_auth_event' || !e.newValue) return
      if (e.newValue.startsWith('out:')) {
        setMe(null)
        setAuthed(false)
      } else if (e.newValue.startsWith('in:')) {
        setLoginName(localStorage.getItem('athena_login') || '')
        setAuthed(isAuthenticated())
      }
    }
    const iv = setInterval(() => {
      if (!isAuthenticated()) { setMe(null); setAuthed(false) }
    }, 60000)
    window.addEventListener('storage', onStorage)
    return () => { window.removeEventListener('storage', onStorage); clearInterval(iv) }
  }, [])

  // Профиль с ролями — для гейтинга UI (кнопки создания и т.п.).
  useEffect(() => {
    if (!authed) { setMe(null); return }
    let stop = false
    // Роли могут меняться администратором, пока человек работает: профиль
    // перечитывается при возврате в окно и раз в 30 секунд. Объект меняем
    // только если он действительно изменился — иначе все потребители
    // контекста перерисовывались бы без причины.
    const loadMe = () => api.getMe().then((r) => {
      if (stop) return
      setMe((cur) => (cur && JSON.stringify(cur) === JSON.stringify(r) ? cur : r))
    }).catch(() => {})
    loadMe()
    const iv = setInterval(loadMe, 30000)
    window.addEventListener('focus', loadMe)
    return () => { stop = true; clearInterval(iv); window.removeEventListener('focus', loadMe) }
  }, [authed])

  // Проактивно продлеваем сеанс, пока пользователь работает: при запуске и
  // далее каждые 20 минут сервер обновляет cookie. Если сеанс уже истёк —
  // request() уводит на /login по ответу 401.
  useEffect(() => {
    if (!authed) return
    let stop = false
    const refresh = async () => {
      // Несколько вкладок не должны продлевать сеанс одновременно: если
      // его продлевала другая вкладка недавно, пропускаем.
      try {
        const last = Number(localStorage.getItem('athena_refreshed_at') || 0)
        if (Date.now() - last < 5 * 60 * 1000) return
        localStorage.setItem('athena_refreshed_at', String(Date.now()))
      } catch (_) { /* без localStorage обновляем как раньше */ }
      try {
        if (!stop) await api.refreshToken()
      } catch (_) { /* 401 обрабатывается в request() */ }
    }
    refresh()
    const iv = setInterval(refresh, 20 * 60 * 1000)
    return () => { stop = true; clearInterval(iv) }
  }, [authed])

  return (
    <AuthContext.Provider value={{
      authed, login, doLogin, doSsoLogin, doLogout,
      me,
      // Идентификатор пользователя нужен интерфейсу напрямую.
      userId: me?.user_id ?? null,
      fullName: me?.full_name || '',
      position: me?.position || '',
      roles: me?.roles || [],
      isAdmin: !!me?.is_admin,
      canCreate: !!me?.can_create,
      dashboardDepartments: me?.dashboard_departments || [],
      // п. 15 — руководитель подразделения. Нужен интерфейсу, чтобы отличать
      // «вы не руководитель» от «вы руководитель, но не по этому документу»:
      // это два разных объяснения, и общее «нельзя» человеку бесполезно.
      isChief: !!me?.is_chief,
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
