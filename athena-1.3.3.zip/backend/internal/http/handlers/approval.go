package handlers

import (
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

type ApprovalHandler struct {
	pool     *pgxpool.Pool
	approval *service.ApprovalService
	status   *service.StatusService
	signing  *service.SigningService
	hub      *ws.Hub
}

func NewApprovalHandler(pool *pgxpool.Pool, approval *service.ApprovalService, status *service.StatusService, signing *service.SigningService, hub *ws.Hub) *ApprovalHandler {
	return &ApprovalHandler{pool: pool, approval: approval, status: status, signing: signing, hub: hub}
}

var (
	errDocNotInApproval   = errors.New("документ не на согласовании")
	errRejectNeedsComment = errors.New("нужна причина отклонения")
	errCommentTooLong     = errors.New("комментарий слишком длинный")
)

type decideRequest struct {
	Approve bool   `json:"approve"`
	Comment string `json:"comment"`
	// Донаправление: если задан AddApproverID (и Approve=true) — согласовать и
	// вставить нового согласующего сразу после себя.
	AddApproverID   int64  `json:"add_approver_id,omitempty"`
	AddApproverType string `json:"add_approver_stage_type,omitempty"` // hierarchy|cross_dept
	// #4 — "before": направить на согласование ПЕРЕД собой БЕЗ отметки о
	// согласовании (Approve игнорируется). Требует AddApproverID.
	AddApproverBefore bool `json:"add_approver_before,omitempty"`
	// #1 — переадресация подписи другому подписанту (фиксируется согласование).
	// Требует, чтобы текущий этап был signing.
	ForwardSignerID int64 `json:"forward_signer_id,omitempty"`
}

type decideResponse struct {
	StageType      string  `json:"stage_type"`
	NewStatus      string  `json:"new_status,omitempty"`
	OutgoingNumber *string `json:"outgoing_number,omitempty"`
}

// Decide POST /api/documents/:id/stages/:stageId/decide
//
// Если решаемый этап имеет stage_type='signing' и решение — подтверждение,
// это одновременно и есть акт подписания: SigningService присваивает
// исходящий номер и создаёт запись в document_signatures в ЭТОЙ ЖЕ
// транзакции (атомарно с переводом статуса этапа). Push согласующим
// следующего активированного этапа отправляется ПОСЛЕ коммита.
func (h *ApprovalHandler) Decide(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор документа")
	}
	stageID, err := strconv.ParseInt(c.Params("stageId"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор этапа")
	}
	var req decideRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}

	var resp decideResponse
	var notify []int64
	var interested []int64 // все заинтересованные — для персистентных уведомлений
	var eventKind string
	var autoSentTo []int64 // плановые адресаты, авто-направленные в момент подписи

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Блокируем строку документа на всё решение: параллельные решения по
		// разным этапам одного документа (в т. ч. две подписи разом) идут
		// строго по очереди. Решать можно только пока документ действительно
		// на согласовании или подписи — не по отклонённому, подписанному или
		// архивному.
		var docStatus string
		if err := tx.QueryRow(c.Context(), `SELECT status::text FROM documents WHERE id = $1 FOR UPDATE`, docID).Scan(&docStatus); err != nil {
			if errors.Is(err, pgx.ErrNoRows) {
				return service.ErrForbiddenApprover
			}
			return err
		}
		switch docStatus {
		case "on_approval_hierarchy", "on_approval_cross_dept", "on_signing":
		default:
			return errDocNotInApproval
		}
		if len([]rune(req.Comment)) > 4000 {
			return errCommentTooLong
		}
		// Отклонение без объяснения бесполезно автору: он не знает, что править.
		if !req.Approve && req.ForwardSignerID == 0 && !(req.AddApproverBefore && req.AddApproverID != 0) &&
			strings.TrimSpace(req.Comment) == "" {
			return errRejectNeedsComment
		}
		// #4 — Ветка «направить на согласование ПЕРЕД собой» (без отметки).
		if req.AddApproverBefore && req.AddApproverID != 0 {
			newApprover, err := h.approval.SendToApproverBefore(c.Context(), tx, docID, stageID, userID, req.AddApproverID, req.AddApproverType)
			if err != nil {
				return err
			}
			resp.StageType = "hierarchy"
			resp.NewStatus, err = h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			notify = []int64{newApprover}
			eventKind = "approver_added"
			ids, err := service.NotifyDocumentEvent(c.Context(), tx, docID, eventKind, userID,
				fmt.Sprintf(`{"actor_id":%d,"added_approver_id":%d}`, userID, newApprover))
			if err != nil {
				return err
			}
			interested = ids
			return nil
		}
		// #1 — Ветка «переадресовать подпись другому подписанту» (согласование).
		if req.ForwardSignerID != 0 {
			newSigner, err := h.approval.ForwardSigner(c.Context(), tx, docID, stageID, userID, req.ForwardSignerID, req.Comment)
			if err != nil {
				return err
			}
			resp.StageType = "signing"
			resp.NewStatus, err = h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			notify = []int64{newSigner}
			eventKind = "approver_added"
			ids, err := service.NotifyDocumentEvent(c.Context(), tx, docID, eventKind, userID,
				fmt.Sprintf(`{"actor_id":%d,"forward_signer_id":%d}`, userID, newSigner))
			if err != nil {
				return err
			}
			interested = ids
			return nil
		}
		// Ветка «согласовать и направить на доп. согласование».
		if req.Approve && req.AddApproverID != 0 {
			newApprover, err := h.approval.ApproveAndAddApprover(c.Context(), tx, docID, stageID, userID, req.AddApproverID, req.AddApproverType, req.Comment)
			if err != nil {
				return err
			}
			resp.StageType = "hierarchy"
			resp.NewStatus, err = h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			notify = []int64{newApprover}
			eventKind = "approver_added"
			ids, err := service.NotifyDocumentEvent(c.Context(), tx, docID, eventKind, userID,
				fmt.Sprintf(`{"actor_id":%d,"added_approver_id":%d}`, userID, newApprover))
			if err != nil {
				return err
			}
			interested = ids
			return nil
		}

		// onBehalfOf — владелец решённого этапа. При замещении он отличается от
		// userID, и подпись обязана это зафиксировать (п. 19).
		stageType, onBehalfOf, activated, err := h.approval.Decide(c.Context(), tx, docID, stageID, userID, req.Approve, req.Comment)
		if err != nil {
			return err
		}
		resp.StageType = stageType
		notify = activated

		if !req.Approve {
			newStatus, err := h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			resp.NewStatus = newStatus
			eventKind = "stage_rejected"
		} else if stageType == "signing" {
			outgoingNumber, sentTo, err := h.signing.Sign(c.Context(), tx, docID, userID, onBehalfOf, "ПЭП",
				service.SignMeta{IP: middleware.ClientIP(c), UserAgent: c.Get("User-Agent")})
			if err != nil {
				return err
			}
			resp.OutgoingNumber = &outgoingNumber
			if len(sentTo) > 0 {
				resp.NewStatus = "sent" // плановая рассылка -> авто-направлен
				autoSentTo = sentTo
			} else {
				resp.NewStatus = "signed"
			}
			eventKind = "document_signed"
		} else {
			newStatus, err := h.status.Recompute(c.Context(), tx, docID)
			if err != nil {
				return err
			}
			resp.NewStatus = newStatus
			eventKind = "stage_approved"
		}

		// Единое уведомление всех заинтересованных о произошедшем изменении.
		payload := fmt.Sprintf(`{"actor_id":%d,"new_status":%q}`, userID, resp.NewStatus)
		ids, err := service.NotifyDocumentEvent(c.Context(), tx, docID, eventKind, userID, payload)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, service.ErrForbiddenApprover):
			return fiber.NewError(fiber.StatusForbidden,
				"решение по этому этапу принимает назначенный согласующий или тот, кто его замещает")
		case errors.Is(txErr, service.ErrStageNotPending):
			return fiber.NewError(fiber.StatusConflict, "этап уже обработан или ещё не активирован")
		case errors.Is(txErr, errDocNotInApproval):
			return fiber.NewError(fiber.StatusConflict, "документ не находится на согласовании или подписи")
		case errors.Is(txErr, errRejectNeedsComment):
			return fiber.NewError(fiber.StatusBadRequest, "укажите причину отклонения")
		case errors.Is(txErr, errCommentTooLong):
			return fiber.NewError(fiber.StatusBadRequest, "комментарий длиннее 4000 знаков")
		case errors.Is(txErr, service.ErrSelfApproval):
			return fiber.NewError(fiber.StatusBadRequest, "нельзя направить документ самому себе или автору документа")
		case errors.Is(txErr, service.ErrDuplicateApprover):
			return fiber.NewError(fiber.StatusConflict, "этот сотрудник уже участвует в маршруте документа")
		case errors.Is(txErr, service.ErrApproverWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "выбранный сотрудник не состоит в нужной группе согласования")
		case errors.Is(txErr, service.ErrSignerWrongRole):
			return fiber.NewError(fiber.StatusBadRequest, "выбранный сотрудник не имеет права подписи")
		default:
			var fe *fiber.Error
			if errors.As(txErr, &fe) {
				return txErr
			}
			log.Printf("decide stage failed: doc=%d stage=%d user=%d: %v", docID, stageID, userID, txErr)
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось обработать этап")
		}
	}

	h.hub.NotifyUsers(notify, docID, "stage_pending")
	if len(interested) > 0 {
		h.hub.NotifyUsers(interested, docID, eventKind)
	}
	if len(autoSentTo) > 0 {
		h.hub.NotifyUsers(autoSentTo, docID, "document_sent")
	}

	return c.JSON(resp)
}
