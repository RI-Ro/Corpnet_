package handlers

import (
	"errors"
	"fmt"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/report"
	"athena/backend/internal/service"
)

// ReportsHandler — отчётность.
//
//	п. 5 — отчёт по КАЖДОМУ документу: что с ним происходило, кто и в какой
//	       срок что сделал, где нарушены сроки;
//	п. 7 — СВОДНЫЙ отчёт по исполнительской дисциплине за период, в PDF и
//	       XLSX, с графиками, с выбором подразделения и видов документов.
//
// Разделение форматов по смыслу, а не «оба на всякий случай»:
//   - PDF — чтобы распечатать, подписать и подшить. Там графики, выводы
//     текстом и список нарушений;
//   - XLSX — чтобы считать дальше: сводка, разрезы и полный перечень
//     нарушений отдельными листами, без объединённых ячеек и оформления,
//     мешающего сортировке и сводным таблицам.
type ReportsHandler struct {
	pool    *pgxpool.Pool
	appName string
}

func NewReportsHandler(pool *pgxpool.Pool, appName string) *ReportsHandler {
	if appName == "" {
		appName = "ИР «Афина»"
	}
	return &ReportsHandler{pool: pool, appName: appName}
}

// ---------------------------------------------------------------------------
// п. 5 — ОТЧЁТ ПО ДОКУМЕНТУ
// ---------------------------------------------------------------------------

type docReportStage struct {
	Type      string  `json:"type"`
	Name      string  `json:"approver_name"`
	Status    string  `json:"status"`
	DecidedAt *string `json:"decided_at,omitempty"`
	Comment   *string `json:"comment,omitempty"`
	// Hours — сколько документ ждал решения этого участника: от момента,
	// когда до него дошла очередь (activated_at), до решения. Никогда не
	// отрицательно. Прежде считалось от создания строки этапа по датам, и
	// при пересоздании маршрута получалось «−1 день».
	Hours *float64 `json:"hours,omitempty"`
}

// docReportRecipient — адресат рассылки и состояние исполнения у него.
type docReportRecipient struct {
	Name       string  `json:"name"`
	Department string  `json:"department"`
	SentAt     *string `json:"sent_at,omitempty"`
	Incoming   string  `json:"incoming_number,omitempty"`
	ReceivedAt *string `json:"received_at,omitempty"`
	ViewedAt   *string `json:"viewed_at,omitempty"`
	ExecutedAt *string `json:"executed_at,omitempty"`
	ExecutedBy string  `json:"executed_by,omitempty"`
	// State — итог по адресату словами: ожидает регистрации / зарегистрирован,
	// в работе / исполнено (в срок или с опозданием) / просрочено.
	State string `json:"state"`
	Late  bool   `json:"late"`
}

type docReportResolution struct {
	ID         int64   `json:"id"`
	AuthorName string  `json:"author_name"`
	Text       string  `json:"text"`
	DueDate    *string `json:"due_date,omitempty"`
	Status     string  `json:"status"`
	Executors  string  `json:"executors"`
	ClosedAt   *string `json:"closed_at,omitempty"`
	DelayDays  *int    `json:"delay_days,omitempty"`
}

type docReport struct {
	DocumentID   int64                 `json:"document_id"`
	Title        string                `json:"title"`
	OutNumber    *string               `json:"outgoing_number,omitempty"`
	Status       string                `json:"status"`
	AuthorName   string                `json:"author_name"`
	DeptName     string                `json:"department_name"`
	CategoryName string                `json:"category_name"`
	SpecialMark  string                `json:"special_mark"`
	CreatedAt    time.Time             `json:"created_at"`
	SignedAt     *string               `json:"signed_at,omitempty"`
	DueDate      *string               `json:"due_date,omitempty"`
	ExecutedAt   *string               `json:"executed_at,omitempty"`
	OnControl    bool                  `json:"on_control"`
	Overdue      bool                  `json:"overdue"`
	LeadDays     *int                  `json:"lead_days,omitempty"`
	Stages       []docReportStage      `json:"stages"`
	Resolutions  []docReportResolution `json:"resolutions"`
	Incoming     []string              `json:"incoming"`
	Recipients   []docReportRecipient  `json:"recipients"`
	Versions     int                   `json:"card_versions"`
	FileVersions int                   `json:"file_versions"`
	Signatures   []string              `json:"signatures"`
	Violations   []string              `json:"violations"`

	// Executions — ФАКТЫ ИСПОЛНЕНИЯ с подробностями (, п. 8:
	// «в отчёте указывать исполнителей с детальным описанием факта
	// исполнения»).
	//
	// Прежде отчёт показывал только маршрут, резолюции и нарушения сроков —
	// то есть ЧТО поручали и КОМУ, но не ЧТО СДЕЛАНО. На вопрос «как именно
	// исполнен документ» отчёт не отвечал, а подшивают его ровно за этим.
	//
	// Сюда собираются два разных вида фактов, и смешивать их нельзя:
	//   * отметка об исполнении по входящему номеру подразделения — кто
	//     закрыл, когда, с каким отчётом, не по замещению ли;
	//   * отчёт исполнителя резолюции — что он написал, когда, принял ли
	//     руководитель и когда.
	Executions []docReportExecution `json:"executions"`
}

// docReportExecution — один факт исполнения в отчёте по документу (п. 8).
type docReportExecution struct {
	// Kind — вид факта: incoming (отметка по входящему номеру) либо
	// resolution (отчёт исполнителя резолюции).
	Kind  string `json:"kind"`
	Scope string `json:"scope"`
	// Executor — кто исполнил: ФИО с должностью. Снимок не делается — отчёт
	// строится в момент запроса, и актуальная должность здесь правильнее.
	Executor string `json:"executor"`
	Role     string `json:"role"`
	Status   string `json:"status"`
	// Fact — САМО ОПИСАНИЕ исполненного: текст отчёта. Это главное поле
	// пункта 8; пустым оно быть не должно, и если отчёта нет — так и
	// написано.
	Fact string `json:"fact"`
	When string `json:"when"`
	// Accepted — кто и когда принял отчёт. Для отметки по входящему номеру
	// пусто: её никто не принимает, она сама и есть закрытие.
	Accepted string `json:"accepted,omitempty"`
	// ActorNote — пометка о замещении, если исполнено заместителем. Выводится
	// отдельным полем, а не внутри Fact: при разборе важно видеть, что
	// действие совершено за другого.
	ActorNote string `json:"actor_note,omitempty"`
}

// errReportForbidden — отчёт по документу запрошен тем, кому он не положен.
var errReportForbidden = errors.New("отчёт по документу доступен автору и подписанту")

// canSeeDocReport — кому доступен отчёт по документу (, п. 8:
// «отчёт о документе показывать автору и подписанту»).
//
// Прежде отчёт мог построить любой, кто видит документ, — то есть и каждый
// адресат рассылки. Отчёт же сводит воедино сроки, задержки и фамилии тех, кто
// задержал: это документ для того, кто за прохождение отвечает, а не для
// всякого, кому бумага пришла.
//
// Право даётся:
//   - АВТОРУ — он за документ отвечает;
//   - ПОДПИСАНТУ — он его подписал, в том числе уже подписавшему (этап после
//     подписи может быть удалён, а право остаётся);
//   - КОНТРОЛЁРУ — его для контроля сроков и назначают, а отчёт ровно про
//     сроки; без этого права контроль был бы формальным;
//   - администратору.
//
// Замещение учитывается: заместитель автора или подписанта вправе построить
// отчёт на период замещения (п. 19 — замещение должно работать до конца, а не
// только на видимости документов).
func canSeeDocReport(c *fiber.Ctx, tx pgx.Tx, docID, userID int64, isAdmin bool) (bool, error) {
	if isAdmin {
		return true, nil
	}
	var ok bool
	err := tx.QueryRow(c.Context(), `
		WITH me AS (SELECT $2::bigint AS id)
		SELECT EXISTS (SELECT 1 FROM documents d
		                WHERE d.id = $1 AND d.author_id IN (SELECT id FROM me))
		    OR EXISTS (SELECT 1 FROM approval_stages st
		                WHERE st.document_id = $1 AND st.stage_type = 'signing'
		                  AND st.approver_id IN (SELECT id FROM me))
		    OR EXISTS (SELECT 1 FROM document_signatures sg
		                WHERE sg.document_id = $1
		                  AND sg.signer_id IN (SELECT id FROM me))
		    OR EXISTS (SELECT 1 FROM document_controllers dc
		                WHERE dc.document_id = $1
		                  AND dc.user_id IN (SELECT id FROM me))
		    OR EXISTS (SELECT 1 FROM documents d
		                WHERE d.id = $1 AND d.controller_id IN (SELECT id FROM me))`,
		docID, userID).Scan(&ok)
	return ok, err
}

func (h *ReportsHandler) loadDocReport(c *fiber.Ctx, docID int64) (*docReport, error) {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	r := &docReport{DocumentID: docID}

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверка права идёт ПЕРВОЙ, до выборки данных: иначе отчёт
		// собирался бы целиком и отбрасывался, а при большом документе это
		// десяток лишних запросов на каждый отказ.
		allowed, err := canSeeDocReport(c, tx, docID, userID, isAdmin)
		if err != nil {
			return err
		}
		if !allowed {
			// Документ при этом может быть человеку виден — поэтому отказ, а
			// не 404: скрывать существование документа, который он и так
			// открывает, незачем.
			return errReportForbidden
		}
		err = tx.QueryRow(c.Context(), `
			SELECT d.title, d.outgoing_number, d.status::text, coalesce(u.full_name,''),
			       coalesce(dep.name,''), coalesce(cat.name,''), coalesce(sm.name,''),
			       d.created_at,
			       to_char((SELECT max(signed_at) FROM document_signatures s WHERE s.document_id=d.id)
			               AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(d.due_date,'YYYY-MM-DD'),
			       to_char(d.executed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       d.on_control,
			       (d.due_date IS NOT NULL AND d.status NOT IN ('executed','archived')
			        AND d.due_date < current_date) AS overdue,
			       CASE WHEN d.executed_at IS NOT NULL
			            THEN (d.executed_at::date - d.created_at::date) END AS lead_days
			  FROM documents d
			  LEFT JOIN users u ON u.id = d.author_id
			  LEFT JOIN departments dep ON dep.id = d.author_department_id
			  LEFT JOIN document_categories cat ON cat.id = d.category_id
			  LEFT JOIN special_marks sm ON sm.id = d.special_mark_id
			 WHERE d.id = $1`, docID).
			Scan(&r.Title, &r.OutNumber, &r.Status, &r.AuthorName, &r.DeptName, &r.CategoryName,
				&r.SpecialMark, &r.CreatedAt,
				&r.SignedAt, &r.DueDate, &r.ExecutedAt, &r.OnControl, &r.Overdue, &r.LeadDays)
		if err != nil {
			return err
		}

		// Маршрут: сколько каждый держал документ у себя. Это и есть ответ на
		// вопрос «где документ стоял», ради которого отчёт и смотрят.
		srows, err := tx.Query(c.Context(), `
			SELECT s.stage_type::text, coalesce(u.full_name,''), s.status::text,
			       to_char(s.decided_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       s.comment,
			       CASE WHEN s.decided_at IS NOT NULL
			            THEN greatest(0, extract(epoch FROM s.decided_at - coalesce(s.activated_at, s.created_at)) / 3600)::float8 END
			  FROM approval_stages s LEFT JOIN users u ON u.id = s.approver_id
			 WHERE s.document_id = $1 ORDER BY s.step_no, s.display_order, s.id`, docID)
		if err != nil {
			return err
		}
		defer srows.Close()
		for srows.Next() {
			var st docReportStage
			if err := srows.Scan(&st.Type, &st.Name, &st.Status, &st.DecidedAt,
				&st.Comment, &st.Hours); err != nil {
				return err
			}
			r.Stages = append(r.Stages, st)
		}
		if err := srows.Err(); err != nil {
			return err
		}

		rrows, err := tx.Query(c.Context(), `
			SELECT r.id, coalesce(au.full_name,''), r.text, to_char(r.due_date,'YYYY-MM-DD'),
			       r.status::text,
			       coalesce(string_agg(coalesce(ex.full_name,'') ||
			            CASE WHEN re.is_responsible THEN ' (ответственный)' ELSE '' END,
			            ', ' ORDER BY re.is_responsible DESC), ''),
			       to_char(r.closed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       CASE WHEN r.closed_at IS NOT NULL AND r.due_date IS NOT NULL
			              AND r.closed_at::date > r.due_date
			            THEN (r.closed_at::date - r.due_date)
			            WHEN r.closed_at IS NULL AND r.due_date IS NOT NULL
			              AND r.due_date < current_date
			            THEN (current_date - r.due_date) END
			  FROM resolutions r
			  LEFT JOIN users au ON au.id = r.author_id
			  LEFT JOIN resolution_executors re ON re.resolution_id = r.id
			  LEFT JOIN users ex ON ex.id = re.user_id
			 WHERE r.document_id = $1
			 GROUP BY r.id, au.full_name ORDER BY r.created_at`, docID)
		if err != nil {
			return err
		}
		defer rrows.Close()
		for rrows.Next() {
			var x docReportResolution
			if err := rrows.Scan(&x.ID, &x.AuthorName, &x.Text, &x.DueDate, &x.Status,
				&x.Executors, &x.ClosedAt, &x.DelayDays); err != nil {
				return err
			}
			r.Resolutions = append(r.Resolutions, x)
		}
		if err := rrows.Err(); err != nil {
			return err
		}

		if err := tx.QueryRow(c.Context(), `
			SELECT coalesce(array_agg(i.incoming_number || ' (' || coalesce(dep.name,'') || ')'
			                           ORDER BY i.incoming_number), '{}')
			  FROM document_incoming_instances i
			  LEFT JOIN departments dep ON dep.id = i.receiving_department_id
			 WHERE i.document_id = $1`, docID).Scan(&r.Incoming); err != nil {
			return err
		}
		// Рассылка и исполнение по каждому адресату: когда направлено, входящий
		// номер и дата регистрации в подразделении, просмотр, отметка об
		// исполнении (кем и когда), итог словами.
		recRows, err := tx.Query(c.Context(), `
			SELECT coalesce(ru.full_name, ''), coalesce(dep.name, ''),
			       to_char(r.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce(i.incoming_number, ''),
			       to_char(i.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(i.first_viewed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(i.executed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce(eu.full_name, ''),
			       CASE
			         WHEN i.id IS NULL THEN 'ожидает регистрации'
			         WHEN i.executed_at IS NOT NULL AND d.due_date IS NOT NULL AND i.executed_at::date > d.due_date
			           THEN 'исполнено с опозданием на ' || (i.executed_at::date - d.due_date) || ' дн.'
			         WHEN i.executed_at IS NOT NULL THEN 'исполнено'
			         WHEN d.due_date IS NOT NULL AND d.due_date < current_date
			           THEN 'просрочено на ' || (current_date - d.due_date) || ' дн.'
			         ELSE 'зарегистрирован, в работе'
			       END,
			       (i.executed_at IS NOT NULL AND d.due_date IS NOT NULL AND i.executed_at::date > d.due_date)
			         OR (i.executed_at IS NULL AND d.due_date IS NOT NULL AND d.due_date < current_date)
			  FROM document_recipients r
			  JOIN documents d ON d.id = r.document_id
			  LEFT JOIN users ru ON ru.id = r.recipient_user_id
			  LEFT JOIN departments dep ON dep.id = r.recipient_department_id
			  LEFT JOIN document_incoming_instances i
			         ON i.document_id = r.document_id AND i.receiving_department_id = r.recipient_department_id
			  LEFT JOIN users eu ON eu.id = i.executed_by
			 WHERE r.document_id = $1 AND r.is_planned = false
			 ORDER BY dep.name, ru.full_name`, docID)
		if err != nil {
			return err
		}
		for recRows.Next() {
			var x docReportRecipient
			if err := recRows.Scan(&x.Name, &x.Department, &x.SentAt, &x.Incoming, &x.ReceivedAt,
				&x.ViewedAt, &x.ExecutedAt, &x.ExecutedBy, &x.State, &x.Late); err != nil {
				recRows.Close()
				return err
			}
			r.Recipients = append(r.Recipients, x)
		}
		recRows.Close()
		if err := recRows.Err(); err != nil {
			return err
		}
		if err := tx.QueryRow(c.Context(), `
			SELECT coalesce(array_agg(coalesce(s.signer_fio,'') || ', ' ||
			                 coalesce(s.signer_position,'') || ' — ' || s.signature_type ||
			                 ' от ' || to_char(s.signed_at, 'DD.MM.YYYY HH24:MI') ||
			                 coalesce(' (' || s.actor_note || ')', '')
			                 ORDER BY s.signed_at), '{}')
			  FROM document_signatures s WHERE s.document_id = $1`, docID).Scan(&r.Signatures); err != nil {
			return err
		}
		if err := tx.QueryRow(c.Context(), `
			SELECT (SELECT count(*) FROM document_versions WHERE document_id=$1),
			       (SELECT count(*) FROM document_file_versions WHERE document_id=$1)`, docID).
			Scan(&r.Versions, &r.FileVersions); err != nil {
			return err
		}

		// п. 8 — ФАКТЫ ИСПОЛНЕНИЯ. Два вида фактов собираются одним запросом
		// через UNION ALL, а не двумя: порядок в отчёте должен быть
		// хронологическим по всему документу, и склеивать два отсортированных
		// списка в коде пришлось бы вручную.
		exrows, err := tx.Query(c.Context(), `
			SELECT 'incoming' AS kind,
			       coalesce(dep.name, '') AS scope,
			       coalesce(eu.full_name, '') ||
			           CASE WHEN coalesce(eu.position,'') <> ''
			                THEN ' (' || eu.position || ')' ELSE '' END AS executor,
			       'отметка об исполнении по входящему № ' || dii.incoming_number AS role,
			       'Исполнено' AS status,
			       coalesce(NULLIF(btrim(dii.execution_note), ''),
			                'отчёт о выполнении не заполнен') AS fact,
			       to_char(dii.executed_at, 'DD.MM.YYYY HH24:MI') AS whn,
			       '' AS accepted,
			       coalesce(dii.execution_actor_note, '') AS actor_note,
			       dii.executed_at AS sort_at
			  FROM document_incoming_instances dii
			  LEFT JOIN departments dep ON dep.id = dii.receiving_department_id
			  LEFT JOIN users eu ON eu.id = dii.executed_by
			 WHERE dii.document_id = $1 AND dii.executed_at IS NOT NULL AND (app_execution_visible(dii.document_id,dii.receiving_department_id) OR dii.executed_by=app_user_id())

			UNION ALL

			SELECT 'resolution' AS kind,
			       'резолюция от ' || to_char(r.created_at, 'DD.MM.YYYY') ||
			           coalesce(', срок ' || to_char(r.due_date, 'DD.MM.YYYY'), '') AS scope,
			       coalesce(ex.full_name, '') ||
			           CASE WHEN coalesce(ex.position,'') <> ''
			                THEN ' (' || ex.position || ')' ELSE '' END AS executor,
			       CASE WHEN re.is_responsible THEN 'ответственный исполнитель'
			            ELSE 'соисполнитель' END AS role,
			       re.status::text AS status,
			       coalesce(NULLIF(btrim(re.report), ''), 'отчёт не представлен') AS fact,
			       coalesce(to_char(re.reported_at, 'DD.MM.YYYY HH24:MI'), '—') AS whn,
			       CASE WHEN re.accepted_at IS NOT NULL
			            THEN coalesce(ab.full_name,'') || ', ' ||
			                 to_char(re.accepted_at, 'DD.MM.YYYY HH24:MI')
			            ELSE '' END AS accepted,
			       '' AS actor_note,
			       coalesce(re.reported_at, re.created_at) AS sort_at
			  FROM resolution_executors re
			  JOIN resolutions r ON r.id = re.resolution_id
			  LEFT JOIN users ex ON ex.id = re.user_id
			  LEFT JOIN users ab ON ab.id = re.accepted_by
			 WHERE r.document_id = $1

			 ORDER BY sort_at`, docID)
		if err != nil {
			return err
		}
		defer exrows.Close()
		for exrows.Next() {
			var x docReportExecution
			var sortAt *time.Time
			if err := exrows.Scan(&x.Kind, &x.Scope, &x.Executor, &x.Role, &x.Status,
				&x.Fact, &x.When, &x.Accepted, &x.ActorNote, &sortAt); err != nil {
				return err
			}
			// Статусы исполнителей резолюции приходят кодами перечисления —
			// переводим здесь, одной и той же функцией, что и в интерфейсе.
			if x.Kind == "resolution" {
				x.Status = service.ResolutionExecLabel(x.Status)
			}
			r.Executions = append(r.Executions, x)
		}
		return exrows.Err()
	})
	if txErr != nil {
		return nil, txErr
	}

	// Нарушения собираются ПОСЛЕ выборки, по уже прочитанным данным: это
	// выводы отчёта, и считать их в SQL значило бы размазать логику между
	// запросом и кодом.
	if r.Overdue {
		r.Violations = append(r.Violations, "срок исполнения документа нарушен, документ не исполнен")
	}
	for _, res := range r.Resolutions {
		if res.DelayDays != nil && *res.DelayDays > 0 {
			if res.ClosedAt != nil {
				r.Violations = append(r.Violations, fmt.Sprintf(
					"резолюция «%s» исполнена с опозданием на %d дн. (исполнители: %s)",
					shorten(res.Text, 60), *res.DelayDays, res.Executors))
			} else {
				r.Violations = append(r.Violations, fmt.Sprintf(
					"резолюция «%s» не исполнена, срок нарушен на %d дн. (исполнители: %s)",
					shorten(res.Text, 60), *res.DelayDays, res.Executors))
			}
		}
	}
	if len(r.Violations) == 0 {
		r.Violations = append(r.Violations, "нарушений сроков не выявлено")
	}
	return r, nil
}

// docReportError — один перевод ошибок отчёта в коды ответа для JSON и PDF.
// Две копии этого switch однажды разошлись бы, и на один и тот же отказ
// человек получал бы разные сообщения в зависимости от формата.
func docReportError(err error) error {
	switch {
	case errors.Is(err, errReportForbidden):
		return fiber.NewError(fiber.StatusForbidden,
			"отчёт по документу доступен его автору, подписанту и контролёру")
	case errors.Is(err, pgx.ErrNoRows):
		return fiber.NewError(fiber.StatusNotFound, "документ не найден")
	}
	return fiber.NewError(fiber.StatusInternalServerError, "не удалось построить отчёт по документу")
}

// DocumentReport GET /api/documents/:id/report — отчёт по документу (JSON).
func (h *ReportsHandler) DocumentReport(c *fiber.Ctx) error {
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	r, err := h.loadDocReport(c, docID)
	if err != nil {
		return docReportError(err)
	}
	return c.JSON(r)
}

// DocumentReportPDF GET /api/documents/:id/report.pdf
func (h *ReportsHandler) DocumentReportPDF(c *fiber.Ctx) error {
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	r, err := h.loadDocReport(c, docID)
	if err != nil {
		return docReportError(err)
	}

	d := report.NewDoc("Отчёт по документу — "+h.appName,
		h.appName+" · сформировано "+time.Now().Format("02.01.2006 15:04"))
	width := report.A4Width - 2*42

	d.Paragraph(r.Title, 14, report.ColorText, width)
	num := "без исходящего номера"
	if r.OutNumber != nil && *r.OutNumber != "" {
		num = "Исходящий № " + *r.OutNumber
	}
	d.Paragraph(num+" · "+statusLabelRU(r.Status)+" · создан "+
		r.CreatedAt.Format("02.01.2006"), 9, report.ColorMuted, width)

	// Главные цифры сверху: руководителю нужен итог, а не чтение таблиц.
	d.NeedSpace(84)
	d.Space(14)
	y := d.Y() - 50
	kpi := func(i int, val, lab, hint string, col report.Color) {
		d.KPI(42+float64(i)*(width/3+4)-float64(i)*4, y, width/3-6, 50, val, lab, hint, col)
	}
	leadTxt := "—"
	if r.LeadDays != nil {
		leadTxt = strconv.Itoa(*r.LeadDays) + " дн."
	}
	viol := len(r.Violations)
	if viol == 1 && strings.HasPrefix(r.Violations[0], "нарушений") {
		viol = 0
	}
	violColor := report.ColorGood
	if viol > 0 {
		violColor = report.ColorBad
	}
	kpi(0, strconv.Itoa(len(r.Stages)), "Этапов маршрута", "согласование и подпись", report.ColorAccent)
	kpi(1, leadTxt, "Срок исполнения", "от создания до исполнения", report.ColorAccent)
	kpi(2, strconv.Itoa(viol), "Нарушений сроков", "по документу и резолюциям", violColor)
	d.Space(56)

	d.Heading("Реквизиты", 11)
	rows := [][]string{
		{"Исходящий номер", derefStr(r.OutNumber)},
		{"Автор", r.AuthorName},
		{"Подразделение", r.DeptName},
		{"Категория", r.CategoryName},
		{"Особая отметка", r.SpecialMark},
		{"Срок", orDash(r.DueDate)},
		{"Подписан", fmtISO(r.SignedAt)},
		{"Исполнен", fmtISO(r.ExecutedAt)},
		{"На контроле", yesNo(r.OnControl)},
		{"Версий карточки", strconv.Itoa(r.Versions)},
		{"Версий файла", strconv.Itoa(r.FileVersions)},
	}
	if len(r.Incoming) > 0 {
		rows = append(rows, []string{"Входящие номера", strings.Join(r.Incoming, "\n")})
	}
	d.Table(42, report.Table{
		Headers: []string{"Реквизит", "Значение"},
		Widths:  []float64{150, width - 150},
		Rows:    rows,
	})

	if len(r.Stages) > 0 {
		d.Heading("Маршрут согласования и подписи", 11)
		st := make([][]string, 0, len(r.Stages))
		for _, s := range r.Stages {
			st = append(st, []string{
				stageTypeRU(s.Type), wrapRole(s.Name), stageResultRU(s.Type, s.Status),
				fmtISO(s.DecidedAt), fmtDuration(s.Hours), derefStr(s.Comment),
			})
		}
		d.Table(42, report.Table{
			Headers: []string{"Этап", "Кто", "Результат", "Когда", "Ждал", "Комментарий"},
			Widths:  []float64{70, 110, 75, 80, 34, width - 369},
			Align:   []byte{'l', 'l', 'l', 'l', 'r', 'l'},
			Rows:    st,
		})
	}

	if len(r.Resolutions) > 0 {
		d.Heading("Резолюции", 11)
		rs := make([][]string, 0, len(r.Resolutions))
		over := map[int]bool{}
		for i, x := range r.Resolutions {
			delay := "—"
			if x.DelayDays != nil && *x.DelayDays > 0 {
				delay = "+" + strconv.Itoa(*x.DelayDays)
				over[i] = true
			}
			rs = append(rs, []string{
				x.AuthorName, x.Text, x.Executors,
				orDash(x.DueDate), service.ResolutionLabel(x.Status), delay,
			})
		}
		d.Table(42, report.Table{
			Headers: []string{"Кто наложил", "Резолюция", "Исполнители", "Срок", "Состояние", "Просрочка"},
			Widths:  []float64{90, 150, 110, 58, 76, width - 484},
			Align:   []byte{'l', 'l', 'l', 'l', 'l', 'r'},
			Rows:    rs,
			RowColor: func(i int) (report.Color, bool) {
				if over[i] {
					// Подсветка строки — вспомогательная: величина просрочки
					// напечатана числом, поэтому на ч/б печати информация
					// не теряется.
					return report.Color{R: 0.99, G: 0.93, B: 0.92}, true
				}
				return report.Color{}, false
			},
		})
	}

	// Рассылка и исполнение по адресатам.
	if len(r.Recipients) > 0 {
		d.Heading("Рассылка и исполнение", 11)
		rr := make([][]string, 0, len(r.Recipients))
		late := map[int]bool{}
		for i, x := range r.Recipients {
			inc := "—"
			if x.Incoming != "" {
				inc = x.Incoming + "\n" + fmtISO(x.ReceivedAt)
			}
			done := "—"
			if x.ExecutedAt != nil {
				done = fmtISO(x.ExecutedAt)
				if x.ExecutedBy != "" {
					done += "\n" + x.ExecutedBy
				}
			}
			late[i] = x.Late
			rr = append(rr, []string{
				wrapRole(x.Name) + "\n" + x.Department, strings.Replace(fmtISO(x.SentAt), " ", "\n", 1), inc, done, x.State,
			})
		}
		d.Table(42, report.Table{
			Headers: []string{"Адресат", "Направлено", "Входящий №", "Исполнено", "Состояние"},
			Widths:  []float64{130, 62, 95, 100, width - 387},
			Rows:    rr,
			RowColor: func(i int) (report.Color, bool) {
				if late[i] {
					return report.Color{R: 0.99, G: 0.93, B: 0.92}, true
				}
				return report.Color{}, false
			},
		})
	}

	// п. 8 — ФАКТЫ ИСПОЛНЕНИЯ. Раздел стоит ПОСЛЕ резолюций и ПЕРЕД подписями
	// намеренно: читают отчёт сверху вниз — сначала что поручали, потом что
	// сделано, и только затем формальности.
	//
	// Таблицей, а не абзацами: сопоставлять «кто — что сделал — когда — принял
	// ли руководитель» глазами по тексту неудобно, а именно это и сверяют.
	if len(r.Executions) > 0 {
		d.Heading("Факты исполнения", 11)
		d.Paragraph("Что именно сделано по документу: отметки об исполнении по входящим "+
			"номерам подразделений и отчёты исполнителей резолюций.", 8, report.ColorMuted, width)
		// АБЗАЦАМИ, А НЕ ТАБЛИЦЕЙ. Таблица здесь была первым решением и
		// оказалась неверной: столбец «что сделано» получал около 76 пунктов
		// ширины, то есть обрезался многоточием на третьем-четвёртом слове.
		// Пункт 8 требует «детальное описание факта исполнения» — именно этот
		// текст и является содержанием раздела, и урезать его ради ровных
		// столбцов значит не выполнить требование. Абзац переносится по
		// словам на всю ширину страницы.
		for _, e := range r.Executions {
			d.Space(4)
			// Первая строка — кто и на каком основании. Выделена размером,
			// чтобы при чтении подряд было видно, где начинается новый факт.
			d.Paragraph(orDashStr(e.Executor)+" — "+e.Role, 9, report.ColorText, width)
			// Вторая — служебные сведения. Состояние, время, кто принял
			// отчёт, и отдельно пометка о замещении (п. 19): при разборе
			// важно видеть, что действие совершено за другого.
			meta := e.Status
			if e.Scope != "" {
				meta += " · " + e.Scope
			}
			if e.When != "" && e.When != "—" {
				meta += " · " + e.When
			}
			if e.Accepted != "" {
				meta += " · отчёт принял: " + e.Accepted
			}
			d.Paragraph(meta, 8, report.ColorMuted, width)
			if e.ActorNote != "" {
				d.Paragraph(e.ActorNote, 8, report.ColorBad, width)
			}
			// Третья — САМО описание исполненного, целиком.
			d.Paragraph(e.Fact, 9, report.ColorText, width)
		}
	} else {
		// Пустой раздел нужен: его отсутствие читается как «забыли
		// напечатать», а прямая строка отвечает на вопрос, с которым отчёт и
		// открывают.
		d.Heading("Факты исполнения", 11)
		d.Paragraph("По документу нет ни отметок об исполнении, ни отчётов исполнителей резолюций.",
			9, report.ColorMuted, width)
	}

	if len(r.Signatures) > 0 {
		d.Heading("Подписи", 11)
		for _, s := range r.Signatures {
			d.Paragraph("• "+s, 8, report.ColorText, width)
		}
	}

	d.Heading("Выводы", 11)
	for _, v := range r.Violations {
		col := report.ColorBad
		if strings.HasPrefix(v, "нарушений") {
			col = report.ColorGood
		}
		d.Paragraph("• "+v, 9, col, width)
	}

	out, err := d.Bytes()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сформировать PDF")
	}
	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", contentDisposition(docReportFileName(r)))
	return c.Send(out)
}

// docReportFileName — имя файла отчёта по документу в виде
// «Отчет_о_документе_№_ИСХ-1/2/4-1/2026_сформирован_01.01.2026_15:30.pdf».
//
// Прежнее имя (document_12_report.pdf) ничего не говорило: в папке «Загрузки»
// десяток таких файлов отличался только числом, и чтобы понять, какой из них
// нужен, приходилось открывать каждый. Теперь в имени есть и номер документа,
// и время формирования — отчёт по одному документу собирают не один раз, и
// версии надо различать.
//
// О ЗАМЕНЕ СИМВОЛОВ. В заданном виде встречаются «/» (в исходящем номере) и
// «:» (во времени). Файл с «/» в имени создать невозможно: в файловых
// системах это разделитель каталогов, браузер всё равно заменит его сам, и на
// разных браузерах по-разному. «:» запрещён в Windows и неудобен в macOS.
// Поэтому оба заменяются на «-»: номер остаётся узнаваемым
// (ИСХ-1-2-4-1-2026), а файл сохраняется везде одинаково.
func docReportFileName(r *docReport) string {
	num := "без_номера"
	if r.OutNumber != nil && strings.TrimSpace(*r.OutNumber) != "" {
		num = strings.TrimSpace(*r.OutNumber)
	}
	name := fmt.Sprintf("Отчет_о_документе_№_%s_сформирован_%s.pdf",
		num, time.Now().Format("02.01.2006_15:04"))
	return sanitizeFileName(name)
}

// sanitizeFileName заменяет символы, недопустимые в именах файлов, на «-».
// Пробелы заменяются на «_»: имя задано со знаками подчёркивания, и пробел,
// попавший из номера документа, нарушил бы единообразие.
func sanitizeFileName(s string) string {
	var b strings.Builder
	for _, r := range s {
		switch r {
		case '/', '\\', ':', '*', '?', '"', '<', '>', '|':
			b.WriteRune('-')
		case ' ':
			b.WriteRune('_')
		default:
			if r < 0x20 {
				continue
			}
			b.WriteRune(r)
		}
	}
	return b.String()
}

// contentDisposition собирает заголовок с именем файла.
//
// Имя кириллическое, а в заголовке HTTP допустим только ASCII. Поэтому
// по RFC 6266 указываются оба варианта: filename с заменой на латиницу —
// для старых клиентов, и filename* с кодировкой UTF-8 — его понимают все
// современные браузеры и берут именно его.
func contentDisposition(name string) string {
	ascii := make([]rune, 0, len(name))
	for _, r := range name {
		if r < 0x80 {
			ascii = append(ascii, r)
		} else {
			ascii = append(ascii, '_')
		}
	}
	return fmt.Sprintf(`attachment; filename="%s"; filename*=UTF-8''%s`,
		string(ascii), url.PathEscape(name))
}

// ---------------------------------------------------------------------------
// п. 7 — СВОДНЫЙ ОТЧЁТ ПО ИСПОЛНИТЕЛЬСКОЙ ДИСЦИПЛИНЕ
// ---------------------------------------------------------------------------

func parseIDList(s string) []int64 {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	var out []int64
	for _, part := range strings.Split(s, ",") {
		if v, err := strconv.ParseInt(strings.TrimSpace(part), 10, 64); err == nil && v > 0 {
			out = append(out, v)
		}
	}
	return out
}

// disciplineVerdict — текстовый вывод по показателю.
//
// Требование «конкретные тексты»: число само по себе ничего не говорит
// читателю, который не знает, 87 % — это хорошо или плохо. Пороги выбраны
// по сложившейся практике делопроизводства и вынесены в константы, чтобы их
// можно было обсудить и поменять в одном месте.
const (
	thresholdGood = 95.0
	thresholdFair = 85.0
)

// --- мелкие помощники ------------------------------------------------------

func roundTo(v float64, digits int) float64 {
	p := 1.0
	for i := 0; i < digits; i++ {
		p *= 10
	}
	return float64(int64(v*p+0.5)) / p
}

// shorten обрезает строку по РУНАМ, а не по байтам: обрезка кириллицы по
// байтам даёт «битый» символ в конце.
// fmtDuration — длительность словами для отчёта: «< 1 ч», «5 ч», «2,5 дн.».
func fmtDuration(h *float64) string {
	if h == nil {
		return "—"
	}
	switch {
	case *h < 1:
		return "< 1 ч"
	case *h < 48:
		return strconv.Itoa(int(*h+0.5)) + " ч"
	default:
		return strings.Replace(strconv.FormatFloat(*h/24, 'f', 1, 64), ".", ",", 1) + " дн."
	}
}

func shorten(s string, max int) string {
	r := []rune(strings.TrimSpace(s))
	if len(r) <= max {
		return string(r)
	}
	return string(r[:max-1]) + "…"
}

func orDash(s *string) string {
	if s == nil || *s == "" {
		return "—"
	}
	// Дата приходит как YYYY-MM-DD; в отчёте принят русский формат.
	if t, err := time.Parse("2006-01-02", *s); err == nil {
		return t.Format("02.01.2006")
	}
	return *s
}

func fmtISO(s *string) string {
	if s == nil || *s == "" {
		return "—"
	}
	if t, err := time.Parse(time.RFC3339, *s); err == nil {
		return t.Local().Format("02.01.2006 15:04")
	}
	return *s
}

func derefStr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

func yesNo(b bool) string {
	if b {
		return "да"
	}
	return "нет"
}

func stageTypeRU(t string) string {
	switch t {
	case "hierarchy":
		return "Согласование"
	case "cross_dept":
		return "Межвед. согласование"
	case "signing":
		return "Подпись"
	}
	return t
}

func stageStatusRU(s string) string {
	switch s {
	case "waiting_deps":
		return "Ожидает"
	case "pending":
		return "На рассмотрении"
	case "approved":
		return "Согласовано"
	case "rejected":
		return "Отклонено"
	case "skipped":
		return "Пропущено"
	}
	return s
}

// orDashStr — то же, что orDash, но для обычной строки, без разбора даты.
//
// Отдельная функция, а не &s в вызове orDash: там дата разбирается и
// переформатируется, и готовая строка вида «Иванов, 14.10.2026 09:30»
// попала бы под разбор без пользы и с риском исказить её.
func orDashStr(s string) string {
	if strings.TrimSpace(s) == "" {
		return "—"
	}
	return s
}

// wrapRole переносит должность в скобках на вторую строку ячейки: «Смирнов
// А.А. (подписант)» в узкую колонку целиком не помещается, а обрезанная
// роль («(подписа…») читается хуже, чем перенос.
func wrapRole(name string) string {
	if i := strings.Index(name, " ("); i > 0 {
		return name[:i] + "\n" + name[i+1:]
	}
	return name
}

// stageResultRU — итог этапа с учётом его вида: у подписанта «согласовано»
// звучит неверно, там документ подписан.
func stageResultRU(kind, status string) string {
	if kind == "signing" && status == "approved" {
		return "Подписано"
	}
	return stageStatusRU(status)
}
