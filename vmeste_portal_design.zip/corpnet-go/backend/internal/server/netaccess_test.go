package server

import (
	"net/http/httptest"
	"testing"
)

func TestClientIPAndInternalAllowed(t *testing.T) {
	mk := func(trusted []string, remote, xff string) (*Server, string, bool) {
		s := &Server{trusted: parseCIDRs(trusted), internalNets: nil}
		r := httptest.NewRequest("GET", "/metrics", nil)
		r.RemoteAddr = remote
		if xff != "" {
			r.Header.Set("X-Forwarded-For", xff)
		}
		return s, s.clientIP(r), s.internalAllowed(r)
	}
	// без доверенных прокси X-Forwarded-For игнорируется (его может прислать кто угодно)
	if _, ip, _ := mk(nil, "203.0.113.5:1234", "10.1.1.1"); ip != "203.0.113.5" {
		t.Fatalf("spoofed XFF accepted: %s", ip)
	}
	// ...и запрос с XFF не считается внутренним, даже если TCP-адрес частный
	if _, _, ok := mk(nil, "10.0.0.9:1", "8.8.8.8"); ok {
		t.Fatal("request with XFF from unknown proxy must not be internal")
	}
	if _, _, ok := mk(nil, "10.0.0.9:1", ""); !ok {
		t.Fatal("private address without XFF must be internal")
	}
	if _, _, ok := mk(nil, "203.0.113.5:1", ""); ok {
		t.Fatal("public address must not be internal")
	}
	// доверенный балансировщик: берём первый недоверенный адрес справа (подделка слева не проходит)
	if _, ip, _ := mk([]string{"10.0.0.0/8"}, "10.0.0.2:1", "1.2.3.4, 198.51.100.7, 10.0.0.5"); ip != "198.51.100.7" {
		t.Fatalf("got %s", ip)
	}
	// клиент за балансировщиком, внешний — не внутренний
	if _, _, ok := mk([]string{"10.0.0.0/8"}, "10.0.0.2:1", "198.51.100.7"); ok {
		t.Fatal("external client behind trusted proxy must not be internal")
	}
	// INTERNAL_ALLOW заменяет «все частные»
	s := &Server{internalNets: parseCIDRs([]string{"192.168.50.0/24"})}
	r := httptest.NewRequest("GET", "/metrics", nil)
	r.RemoteAddr = "10.0.0.9:1"
	if s.internalAllowed(r) {
		t.Fatal("10.0.0.9 not in INTERNAL_ALLOW")
	}
	r.RemoteAddr = "192.168.50.3:1"
	if !s.internalAllowed(r) {
		t.Fatal("192.168.50.3 in INTERNAL_ALLOW")
	}
}

func TestPreforkN(t *testing.T) {
	for in, want := range map[string]int{"": 0, "0": 0, "off": 0, "4": 4, "-1": 0, "x": 0} {
		if got := preforkN(in); got != want {
			t.Errorf("%q → %d want %d", in, got, want)
		}
	}
	if preforkN("auto") < 1 {
		t.Error("auto")
	}
}
