import React, { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'

// DuplicateWarning — ПРЕДУПРЕЖДЕНИЕ о похожих документах при регистрации.
//
// ЧТО ЗДЕСЬ ИЗМЕНИЛОСЬ И ЧТО ПОТЕРЯНО — СКАЗАНО ПРЯМО.
//
// Этот компонент заменил CorrespondentFields, удалённый по замечанию v52,
// п. 17 («убрать корреспондент, его исходящий, дата его документа»). Вместе с
// тремя реквизитами исчез ЖЁСТКИЙ запрет повторной регистрации: он держался на
// уникальном индексе по тройке «корреспондент + его номер + его дата», и без
// реквизитов сравнивать нечего. Никакая замена этого не восполняет — именно
// эта тройка и была признаком «тот же самый документ».
//
// Что осталось:
//   * ЖЁСТКИЙ запрет по входящему номеру внутри подразделения — на уровне БД
//     (уникальный индекс uq_incoming_number_per_dept). Он был заведён как
//     второй, независимый барьер и работает по-прежнему;
//   * предупреждение здесь: совпадение контрольной суммы файла (самый
//     надёжный признак) и похожее описание.
//
// Предупреждение НЕ блокирует кнопку сохранения. Это сознательно: один и тот
// же файл законно приходит повторно — напоминанием, рассылкой нескольким
// адресатам, повторным обращением. Запрет остановил бы правильную работу, а
// решение «тот же это документ или нет» принимает человек, видя найденные.
//
// Запрос делается с задержкой и только когда есть что сравнивать: он
// отправляет файл целиком, чтобы сервер посчитал его хэш (сам файл при этом не
// сохраняется), и дёргать его на каждую нажатую букву нельзя.
const DEBOUNCE_MS = 600

//, п. 9 — «мигание» экрана при вводе описания.
//
// Причин было две, обе здесь.
//
// 1) После каждой паузы в наборе компонент на время запроса подставлял строку
//    «Проверка на повторную регистрацию…» и тут же её убирал. Высота блока
//    скакала вверх-вниз, а всё, что ниже (выбор подписантов, маршрут, предпросмотр
//    файла), прыгало вместе с ним — именно это и выглядело как перерисовка
//    экрана. Строка убрана: проверка вспомогательная, ей не нужен индикатор.
//
// 2) Каждая пауза в наборе заново отправляла на сервер ВЕСЬ выбранный файл ради
//    контрольной суммы. Файл не менялся, менялось описание, но проверялось
//    всё вместе. Теперь проверки независимы: файл уходит один раз, при выборе
//    файла, описание проверяется само по себе, а результаты объединяются тут.
//
// Предыдущий результат остаётся на экране, пока идёт новый запрос, и блок
// появляется/исчезает плавно (высота анимируется), а не рывком.
export default function DuplicateWarning({ title, file }) {
  const [fileItems, setFileItems] = useState([])
  const [titleItems, setTitleItems] = useState([])

  // Совпадение по файлу: один запрос на файл.
  useEffect(() => {
    if (!file) {
      setFileItems([])
      return undefined
    }
    let alive = true
    api
      .checkDuplicate({}, file)
      .then((res) => {
        if (alive) setFileItems(res.items || [])
      })
      .catch(() => {
        // Проверка — вспомогательная: сорвать из-за неё регистрацию нельзя.
        if (alive) setFileItems([])
      })
    return () => {
      alive = false
    }
  }, [file])

  // Совпадение по описанию: с задержкой, без файла.
  useEffect(() => {
    const ttl = (title || '').trim()
    // Описание короче четырёх знаков даёт совпадение почти с чем угодно —
    // такое предупреждение только мешает.
    if (ttl.length < 4) {
      setTitleItems([])
      return undefined
    }
    let alive = true
    const t = setTimeout(async () => {
      try {
        const res = await api.checkDuplicate({ title: ttl })
        if (alive) setTitleItems(res.items || [])
      } catch (_) {
        if (alive) setTitleItems([])
      }
    }, DEBOUNCE_MS)
    return () => {
      alive = false
      clearTimeout(t)
    }
  }, [title])

  // Один документ мог найтись обоими способами: показываем один раз, и
  // совпадение по файлу важнее — это самый надёжный признак.
  const items = useMemo(() => {
    const byId = new Map()
    for (const d of titleItems) byId.set(d.document_id, d)
    for (const d of fileItems) byId.set(d.document_id, d)
    return Array.from(byId.values())
  }, [fileItems, titleItems])
  const message = items.length > 0 ? 'Найдены похожие документы. Проверьте, не регистрируете ли вы его повторно.' : ''

  return (
    <AnimatePresence initial={false}>
      {items.length > 0 && (
        <motion.div
          key="dup"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          style={{ overflow: 'hidden' }}
        >
          <div className="border border-warning/40 bg-warning/5 rounded-md px-3 py-2">
            <div className="text-xs text-warning font-medium">{message}</div>
            <ul className="mt-1.5 space-y-1">
              {items.map((d) => (
                <li key={d.document_id} className="text-xs">
                  <Link to={`/document/${d.document_id}`} className="text-accent hover:underline">
                    {d.title || `Документ № ${d.document_id}`}
                  </Link>
                  <span className="text-text-secondary">
                    {' · '}{d.match_label}
                    {d.outgoing_number ? ` · исх. ${d.outgoing_number}` : ''}
                    {d.status_label ? ` · ${d.status_label}` : ''}
                    {d.author_name ? ` · ${d.author_name}` : ''}
                    {(d.incoming_numbers || []).length > 0
                      ? ` · вх. ${d.incoming_numbers.join(', ')}`
                      : ''}
                  </span>
                </li>
              ))}
            </ul>
            <div className="mt-1.5 text-[11px] text-text-secondary">
              Это предупреждение, а не запрет: один и тот же файл законно приходит повторно.
              Регистрацию можно продолжить.
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
