import React from 'react'
import AppearanceFields from './AppearanceFields'
import Icon from './Icon'

// Настройки пользователя: разделы меню, оформление, облегчённый режим.
// Всё хранится на сервере (настройки учётной записи) и действует после
// перезагрузки страницы и на другом компьютере.
export default function SettingsModal({ appearance, categories, hidden, onChangeHidden, animEnabled = true, onToggleAnim, perfMode = 'auto', onChangePerf, onClose }) {
  const hiddenSet = new Set(hidden)

  const toggle = (id) => {
    const next = new Set(hiddenSet)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    onChangeHidden([...next])
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="surface-1 shadow-xl w-full max-w-md max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h2 className="font-display font-semibold">Настройки</h2>
          <button onClick={onClose} className="px-2 py-1 rounded-md hover:bg-surface-alt" aria-label="Закрыть">
            <Icon name="close" size={16} />
          </button>
        </div>

        <div className="overflow-auto p-4 space-y-4">
          <AppearanceFields {...appearance} />
          <div>
            <div className="text-sm font-medium mb-1">Разделы бокового меню</div>
            <p className="text-xs text-text-secondary mb-2">
              Отметьте разделы, которые нужно показывать. Настройка сохраняется для вашей учётной записи.
            </p>
            <div className="space-y-0.5">
              {categories.map((c) => (
                <label key={c.id} className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-surface-alt cursor-pointer text-sm">
                  <input type="checkbox" checked={!hiddenSet.has(c.id)} onChange={() => toggle(c.id)} />
                  <Icon name={c.icon} size={14} className="shrink-0" style={{ color: c.color }} />
                  <span>{c.label}</span>
                </label>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <button className="btn btn-secondary" onClick={() => onChangeHidden([])}>Показать все</button>
            </div>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Оформление</div>
            <label className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-surface-alt cursor-pointer text-sm">
              <input type="checkbox" checked={animEnabled} onChange={(e) => onToggleAnim?.(e.target.checked)} />
              <span>Анимированный фон (волны)</span>
            </label>
            <p className="text-xs text-text-secondary px-2">По умолчанию выключен. Включайте только на мощном компьютере: фон постоянно нагружает процессор.</p>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Скорость работы</div>
            <label className="block text-xs text-text-secondary mb-1" htmlFor="perf-mode">Облегчённый режим (без теней и анимаций)</label>
            <select id="perf-mode" className="field w-full" value={perfMode} onChange={(e) => onChangePerf?.(e.target.value)}>
              <option value="auto">Автоматически — по мощности компьютера</option>
              <option value="lite">Всегда включён</option>
              <option value="full">Всегда выключен</option>
            </select>
          </div>

          <div>
            <div className="text-sm font-medium mb-1">Панель уведомлений</div>
            <p className="text-xs text-text-secondary mb-2">
              Размер меняется перетаскиванием левого нижнего угла панели.
            </p>
            <button className="btn btn-secondary" onClick={() => window.dispatchEvent(new CustomEvent('athena:notif_panel_reset'))}>
              Сбросить размер
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
