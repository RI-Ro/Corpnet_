import React, { Suspense, lazy } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import { loaders } from './lazy-routes'
import NotFound from './components/NotFound'
import { MotionConfig } from 'motion/react'


// Страницы грузятся по требованию (см. lazy-routes.js): на первом экране
// скачивается только нужное. Загрузчики вынесены в отдельный модуль, чтобы
// меню могло предзагружать маршрут при наведении курсора.
const Layout = lazy(loaders.layout)
const LoginPage = lazy(loaders.login)
const SsoPage = lazy(loaders.sso)
const DocumentsListPage = lazy(loaders.documents)
const DocumentDetailPage = lazy(loaders.document)
const CreateDocumentPage = lazy(loaders.create)
const RegistryPage = lazy(loaders.registry)
const ResolutionsPage = lazy(loaders.resolutions)
const HistoryPage = lazy(loaders.history)
const DashboardPage = lazy(loaders.dashboard)
const AdminPage = lazy(loaders.admin)
const AdminDashboardPage = lazy(loaders.metrics)
const AuditPage = lazy(loaders.audit)

// Лёгкий индикатор без анимаций и без тяжёлых зависимостей.
function PageFallback() {
  return <div className="p-6 text-text-secondary text-sm" role="status">Загрузка…</div>
}

function RequireAuth({ children }) {
  const { authed } = useAuth()
  if (!authed) return <Navigate to="/login" replace />
  return children
}

// Доступ к разделу администрирования — только для роли admin.
function RequireAdmin({ children }) {
  const { isAdmin, me } = useAuth()
  if (me === null) return null // профиль ещё грузится
  if (!isAdmin) return <Navigate to="/documents/all" replace />
  return children
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
    <ThemeProvider>
      <AuthProvider>
        <Suspense fallback={<PageFallback />}>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/sso" element={<SsoPage />} />
          <Route
            element={
              <RequireAuth>
                <Layout />
              </RequireAuth>
            }
          >
            <Route path="/registry/:kind" element={<RegistryPage />} />
            <Route path="/resolutions" element={<ResolutionsPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/documents/:category" element={<DocumentsListPage />} />
            <Route path="/document/new" element={<CreateDocumentPage />} />
            <Route path="/document/:id" element={<DocumentDetailPage />} />
            <Route path="/admin" element={<RequireAdmin><AdminPage /></RequireAdmin>} />
            {/* #10 — техническое состояние системы (метрики) */}
            <Route path="/admin/metrics" element={<RequireAdmin>
                  <AdminDashboardPage />
                </RequireAdmin>} />
            {/*, п. 9 — журнал аудита. RequireAdmin здесь не
                ставится: журнал читает и роль «аудитор», а она отделена от
                администратора намеренно (смысл журнала в том, чтобы действия
                администратора тоже были кому-то видны). Доступ проверяет RLS:
                у того, кому нельзя, выборка просто пуста. */}
            <Route path="/admin/audit" element={<AuditPage />} />
            {/*, п. 7 — сводная отчётность. Право проверяет
                сервер: страница сама объясняет, какой роли не хватает. */}
            <Route path="/" element={<Navigate to="/documents/all" replace />} />
            <Route path="*" element={<NotFound title="404 Oops! Страница не найдена." />} />
          </Route>
        </Routes>
        </Suspense>
      </AuthProvider>
    </ThemeProvider>
    </MotionConfig>
  )
}
