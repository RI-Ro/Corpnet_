package handlers

import (
	"context"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/http/middleware"
	"athena/backend/internal/marking"
)

// SystemSettingsHandler — системные настройки, доступные администратору.
type SystemSettingsHandler struct {
	pool *pgxpool.Pool
}

func NewSystemSettingsHandler(pool *pgxpool.Pool) *SystemSettingsHandler {
	return &SystemSettingsHandler{pool: pool}
}

// LoadMarkingPageMode читает режим страниц маркировки из БД при старте.
// Ошибка не фатальна: остаётся значение по умолчанию («first»).
func (h *SystemSettingsHandler) LoadMarkingPageMode(ctx context.Context) {
	var mode string
	err := h.pool.QueryRow(ctx,
		`SELECT value #>> '{}' FROM system_settings WHERE key='marking.page_mode'`).Scan(&mode)
	if err == nil {
		marking.SetPageMode(mode)
	}
}

// GetMarking GET /api/admin/settings/marking
func (h *SystemSettingsHandler) GetMarking(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return c.JSON(fiber.Map{"page_mode": marking.PageMode()})
}

// PutMarking PUT /api/admin/settings/marking {"page_mode":"first"|"all"}
func (h *SystemSettingsHandler) PutMarking(c *fiber.Ctx) error {
	if !c.Locals(middleware.CtxIsAdmin).(bool) {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	var req struct {
		PageMode string `json:"page_mode"`
	}
	if err := c.BodyParser(&req); err != nil || (req.PageMode != "first" && req.PageMode != "all") {
		return fiber.NewError(fiber.StatusBadRequest, "page_mode: first или all")
	}
	_, err := h.pool.Exec(c.Context(),
		`INSERT INTO system_settings (key, value, updated_at)
		 VALUES ('marking.page_mode', to_jsonb($1::text), now())
		 ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()`, req.PageMode)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сохранить настройку")
	}
	marking.SetPageMode(req.PageMode)
	return c.JSON(fiber.Map{"page_mode": marking.PageMode()})
}

// StartMarkingPageModeSync периодически перечитывает режим из БД. Нужен при
// нескольких экземплярах приложения: админ меняет настройку на одном, а
// остальные иначе продолжали бы работать со старым значением до рестарта.
func (h *SystemSettingsHandler) StartMarkingPageModeSync(ctx context.Context, every time.Duration) {
	go func() {
		t := time.NewTicker(every)
		defer t.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-t.C:
				h.LoadMarkingPageMode(ctx)
			}
		}
	}()
}
