// Команда loadtest — нагрузочный стенд портала: входит под N сгенерированными сотрудниками (gen-testdata.sh)
// и в течение заданного времени выполняет реалистичную смесь чтений (лента, уведомления, поиск, дерево
// подразделений, группы, альбомы), затем печатает RPS и p50/p95/p99 по каждому запросу.
//
//	go run ./cmd/loadtest -url http://localhost:8080 -users 200 -conc 64 -dur 30s
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"net/http/cookiejar"
	"os"
	"sort"
	"sync"
	"time"
)

type sample struct {
	name string
	d    time.Duration
	ok   bool
}

func main() {
	base := flag.String("url", "http://localhost:8080", "адрес узла")
	users := flag.Int("users", 200, "сколько сотрудников gen.uN использовать")
	conc := flag.Int("conc", 64, "параллельных пользователей")
	dur := flag.Duration("dur", 30*time.Second, "длительность")
	pass := flag.String("pass", "corpnet123", "пароль сгенерированных сотрудников")
	first := flag.Int("first", 100, "номер первого gen.uN")
	flag.Parse()

	paths := []struct{ name, path string }{
		{"news.feed", "/api/news?per=20"},
		{"news.page5", "/api/news?per=20&page=5"},
		{"notifications", "/api/notifications?per=30"},
		{"bootstrap", "/api/bootstrap"},
		{"home", "/api/home"},
		{"chats", "/api/chats"},
		{"people.search", "/api/users?per=30&q=ив"},
		{"departments", "/api/departments"},
		{"groups", "/api/groups"},
		{"albums", "/api/folders?kind=photos"},
		{"search", "/api/search?q=квартал"},
	}
	type sess struct {
		c *http.Client
	}
	var clients []*http.Client
	t0 := time.Now()
	for i := 0; i < *users; i++ {
		jar, _ := cookiejar.New(nil)
		c := &http.Client{Jar: jar, Timeout: 20 * time.Second}
		b, _ := json.Marshal(map[string]string{"login": fmt.Sprintf("gen.u%d", *first+i), "password": *pass})
		r, err := c.Post(*base+"/api/auth/login", "application/json", bytes.NewReader(b))
		if err != nil || r.StatusCode != 200 {
			continue
		}
		io.Copy(io.Discard, r.Body)
		r.Body.Close()
		clients = append(clients, c)
	}
	if len(clients) == 0 {
		fmt.Fprintln(os.Stderr, "не удалось войти ни под одним пользователем (сгенерированы ли gen.u*?)")
		os.Exit(1)
	}
	fmt.Printf("вошли: %d пользователей за %s\n", len(clients), time.Since(t0).Round(time.Millisecond))

	var mu sync.Mutex
	var all []sample
	var wg sync.WaitGroup
	stop := time.Now().Add(*dur)
	start := time.Now()
	for w := 0; w < *conc; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			rnd := rand.New(rand.NewSource(int64(w)))
			c := clients[w%len(clients)]
			var local []sample
			for time.Now().Before(stop) {
				p := paths[rnd.Intn(len(paths))]
				t := time.Now()
				r, err := c.Get(*base + p.path)
				ok := err == nil
				if err == nil {
					io.Copy(io.Discard, r.Body)
					r.Body.Close()
					ok = r.StatusCode < 400
				}
				local = append(local, sample{p.name, time.Since(t), ok})
			}
			mu.Lock()
			all = append(all, local...)
			mu.Unlock()
		}(w)
	}
	wg.Wait()
	el := time.Since(start).Seconds()

	by := map[string][]time.Duration{}
	errs := map[string]int{}
	for _, s := range all {
		by[s.name] = append(by[s.name], s.d)
		if !s.ok {
			errs[s.name]++
		}
	}
	names := make([]string, 0, len(by))
	for n := range by {
		names = append(names, n)
	}
	sort.Strings(names)
	q := func(d []time.Duration, p float64) time.Duration { return d[int(float64(len(d)-1)*p)] }
	fmt.Printf("\n%-15s %8s %9s %9s %9s %6s\n", "запрос", "число", "p50", "p95", "p99", "ошиб.")
	for _, n := range names {
		d := by[n]
		sort.Slice(d, func(i, j int) bool { return d[i] < d[j] })
		fmt.Printf("%-15s %8d %9s %9s %9s %6d\n", n, len(d), q(d, .5).Round(time.Microsecond), q(d, .95).Round(time.Microsecond), q(d, .99).Round(time.Microsecond), errs[n])
	}
	fmt.Printf("\nвсего %d запросов, %.0f запр/с, параллельно %d\n", len(all), float64(len(all))/el, *conc)
}
