package server

import (
	"context"
	"os"
	"strconv"
	"strings"
	"time"
)

// Синхронизация удалений файлов между площадками.
//
// Когда файл удаляют, removeStored стирает его (и варианты .t.jpg/.v.jpg/.v.mp4) на своей площадке и добавляет строку
// в таблицу file_tombstones основной БД. Таблица реплицируется на остальные площадки вместе с базой, поэтому каждая
// площадка читает её у себя (s.ro) и удаляет файл со своего диска (tombstoneLoop). Удаление идемпотентно, а курсор
// (время последней обработанной записи) хранится на диске и берётся с запасом tombOverlap — записи, зафиксированные
// «задним числом» из-за параллельных транзакций или отставания реплики, не теряются.
// Синхронизатор файлов (syncWanted) и подтягивание по требованию (ensureLocal) не докачивают файл, на который есть
// надгробие, — удалённый файл не «воскресает». Записи старше tombKeep чистятся; площадка, которая не выходила на связь
// дольше этого срока, должна быть перезалита как новая реплика.

const (
	tombKeep    = 90 * 24 * time.Hour
	tombOverlap = 2 * time.Minute
	tombPage    = 2000
)

var variantSuffixes = []string{".t.jpg", ".v.jpg", ".v.mp4"}

// baseName возвращает имя исходного файла для варианта (x.mp4.v.mp4 → x.mp4).
func baseName(n string) string {
	for _, suf := range variantSuffixes {
		if strings.HasSuffix(n, suf) {
			return strings.TrimSuffix(n, suf)
		}
	}
	return n
}

func (s *Server) multiSite() bool {
	return s.db != nil && len(s.filePeerURLs(context.Background())) > 0
}

// recordTombstones записывает удаление в журнал (только если площадок несколько).
func (s *Server) recordTombstones(public bool, names ...string) {
	if !s.multiSite() {
		return
	}
	kind := "prv"
	if public {
		kind = "pub"
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	for _, n := range names {
		if n == "" || strings.ContainsAny(n, "/\\") {
			continue
		}
		if _, err := s.db.Exec(ctx, `INSERT INTO file_tombstones (kind, name, dc) VALUES ($1, $2, $3)`, kind, baseName(n), s.cfg.DCID); err != nil {
			s.log.Warn("tombstone: не записано", "name", n, "err", err)
		}
	}
}

// tombstoned: есть ли надгробие на этот файл (имя варианта приводится к имени оригинала).
func (s *Server) tombstoned(ctx context.Context, kind, name string) bool {
	if s.db == nil {
		return false
	}
	var ok bool
	if err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM file_tombstones WHERE kind = $1 AND name = $2)`, kind, baseName(name)).Scan(&ok); err != nil {
		return false // нет таблицы/БД недоступна — не блокируем работу
	}
	return ok
}

func (s *Server) tombstoneLoop(ctx context.Context) {
	if !s.multiSite() {
		return
	}
	go func() {
		cp := s.cfg.DataDir + "/.tomb-cursor"
		var cursor int64 // unix-nano поля at последней обработанной записи
		if b, err := os.ReadFile(cp); err == nil {
			cursor, _ = strconv.ParseInt(strings.TrimSpace(string(b)), 10, 64)
		}
		if cursor == 0 {
			cursor = time.Now().Add(-tombKeep).UnixNano()
		}
		lastPurge := time.Time{}
		t := time.NewTicker(s.cfg.FileSyncEvery)
		defer t.Stop()
		for {
			next, n, err := s.applyTombstones(ctx, cursor)
			if err != nil {
				s.log.Warn("tombstone: сбой круга", "err", err)
			}
			if next > cursor {
				cursor = next
				_ = os.WriteFile(cp, []byte(strconv.FormatInt(cursor, 10)), 0o644)
			}
			if n > 0 {
				s.log.Info("tombstone: удалено файлов по журналу соседей", "n", n)
			}
			if time.Since(lastPurge) > time.Hour {
				lastPurge = time.Now()
				if _, err := s.db.Exec(ctx, `DELETE FROM file_tombstones WHERE at < now() - $1::interval`, strconvInterval(tombKeep)); err != nil {
					s.log.Debug("tombstone: очистка", "err", err)
				}
			}
			select {
			case <-ctx.Done():
				return
			case <-t.C:
			}
		}
	}()
}

func strconvInterval(d time.Duration) string { return strconv.Itoa(int(d.Seconds())) + " seconds" }

// applyTombstones читает записи журнала с (cursor − tombOverlap) и удаляет файлы; возвращает новый курсор и число
// записей, для которых на диске что-то было.
func (s *Server) applyTombstones(ctx context.Context, cursor int64) (int64, int, error) {
	since := time.Unix(0, cursor).Add(-tombOverlap)
	var lastID int64
	next := cursor
	removed := 0
	for ctx.Err() == nil {
		rows, err := s.ro.Query(ctx, `SELECT id, kind, name, at FROM file_tombstones WHERE at >= $1 AND id > $2 ORDER BY id LIMIT $3`, since, lastID, tombPage)
		if err != nil {
			return next, removed, err
		}
		cnt := 0
		for rows.Next() {
			var id int64
			var kind, name string
			var at time.Time
			if err := rows.Scan(&id, &kind, &name, &at); err != nil {
				rows.Close()
				return next, removed, err
			}
			cnt++
			lastID = id
			if at.UnixNano() > next {
				next = at.UnixNano()
			}
			if s.localExists(kind == "pub", name) {
				removed++
			}
			s.removeLocal(kind == "pub", name)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return next, removed, err
		}
		if cnt < tombPage {
			break
		}
	}
	return next, removed, nil
}

func (s *Server) localExists(public bool, name string) bool {
	_, err := os.Stat(s.dir(public) + "/" + name)
	return err == nil
}
