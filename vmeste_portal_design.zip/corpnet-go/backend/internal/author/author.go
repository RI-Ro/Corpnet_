// Package author хранит сведения об авторе проекта. Значение задаётся только при сборке:
//
//	go build -ldflags "-X corpnet/internal/author.name=<имя> -X corpnet/internal/author.sum=<sha256>" ./cmd/server
//
// (проще — через ../build.sh --author "<имя>"). Ни переменные окружения, ни конфигурация, ни API не могут
// изменить или убрать автора: пакет не имеет сеттеров, а процесс без корректно заданного автора не запускается.
package author

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"strings"
)

// Задаются компоновщиком (-X); переменные неэкспортируемые — из кода других пакетов недоступны для записи.
var (
	name string
	sum  string
)

// Project — название проекта, зашитое в код.
const Project = "Вместе"

// Checksum — контрольная сумма пары «проект + автор»; build.sh считает её тем же способом.
func Checksum(n string) string {
	h := sha256.Sum256([]byte("corpnet-author\x00" + n))
	return hex.EncodeToString(h[:])
}

// Name возвращает автора проекта.
func Name() string { return name }

// Verify проверяет, что автор задан при сборке и не искажён. Вызывается при старте до любой работы.
func Verify() error {
	if strings.TrimSpace(name) == "" {
		return errors.New("автор проекта не задан при сборке: используйте build.sh --author \"Имя\"")
	}
	if sum != Checksum(name) {
		return errors.New("данные об авторе проекта повреждены или изменены: пересоберите проект через build.sh --author")
	}
	return nil
}

// String — строка для логов и ответа «о программе».
func String() string { return Project + " — автор: " + name }
