import React, { useCallback, useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'motion/react'
import { api } from '../api/client'
import { useAuth } from '../context/AuthContext'
import { spring } from '../motion'

// Вход по Kerberos. Страница работает на отдельном порту (http.kerberos_addr):
// приложение само проверяет билет по keytab доменов и выдаёт JWT. Если вход
// невозможен — заглушка с контактами администраторов (config.yaml, sso.stub)
// и ссылкой на порт входа по паролю.
const REASONS = {
  not_authenticated: 'Билет Kerberos не получен. Войдите в домен и откройте систему из доверенной зоны.',
  ntlm: 'Браузер прислал NTLM вместо билета Kerberos: компьютер не в домене или адрес системы не входит в зону интрасети.',
  wrong_port: 'Вход по Kerberos выполняется на отдельном адресе.',
  not_mapped: 'Ваша доменная учётная запись не заведена в системе.',
  realm_not_allowed: 'Ваш домен не допускается к работе в системе.',
  inactive: 'Учётная запись заблокирована.',
  session_conflict: 'Под этой учётной записью уже работают с другого рабочего места.',
  disabled: 'Вход по Kerberos отключён администратором.',
}

function initials(name = '') {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?'
}

function Shield({ ok }) {
  return (
    <motion.svg
      viewBox="0 0 96 96" width="88" height="88" aria-hidden="true"
      initial={{ scale: 0.6, opacity: 0, rotate: -8 }}
      animate={{ scale: 1, opacity: 1, rotate: 0 }}
      transition={spring}
    >
      <defs>
        <linearGradient id="sg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="currentColor" stopOpacity="0.95" />
          <stop offset="1" stopColor="currentColor" stopOpacity="0.45" />
        </linearGradient>
      </defs>
      <path d="M48 6l34 12v26c0 22-14 38-34 46C28 82 14 66 14 44V18L48 6z" fill="url(#sg)" />
      {ok ? (
        <motion.path d="M32 48l12 12 22-24" fill="none" stroke="var(--color-bg)" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round"
          initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.6, delay: 0.3 }} />
      ) : (
        <>
          <motion.path d="M34 34l28 28M62 34L34 62" fill="none" stroke="var(--color-bg)" strokeWidth="7" strokeLinecap="round"
            initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.5, delay: 0.3 }} />
        </>
      )}
    </motion.svg>
  )
}

export default function SsoPage() {
  const navigate = useNavigate()
  const { doSsoLogin } = useAuth()
  const [state, setState] = useState('loading') // loading | ok | denied
  const [info, setInfo] = useState(null)
  const [reason, setReason] = useState('')
  const [message, setMessage] = useState('')

  const attempt = useCallback(async () => {
    setState('loading')
    let inf = null
    try { inf = await api.authInfo(); setInfo(inf) } catch (_) { /* заглушка покажет значения по умолчанию */ }
    // Страницу открыли на порту пароля — переходим на порт Kerberos.
    if (inf && inf.mode !== 'kerberos' && inf.kerberos_url) {
      window.location.replace(`${inf.kerberos_url}/sso`)
      return
    }
    try {
      const res = await api.kerberosLogin()
      doSsoLogin(res)
      setState('ok')
      setTimeout(() => navigate('/', { replace: true }), 700)
    } catch (e) {
      setReason(e.reason || (e.status === 401 ? 'not_authenticated' : ''))
      setMessage(e.message || '')
      setState('denied')
    }
  }, [doSsoLogin, navigate])

  useEffect(() => { attempt() }, [attempt])

  const stub = info?.stub || {}
  const accent = stub.accent || undefined
  const admins = stub.admins || []

  return (
    <div className="min-h-screen bg-bg text-accent font-body relative flex items-center justify-center">
      <div className="relative z-10 w-full max-w-3xl px-4 py-10 text-text-primary" style={accent ? { '--color-accent': accent } : undefined}>
        <AnimatePresence mode="wait">
          {state !== 'denied' ? (
            <motion.div key="wait" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
              className="surface-1 shadow-2xl mx-auto max-w-md p-8 text-center text-accent">
              <div className="flex justify-center"><Shield ok={state === 'ok'} /></div>
              <div className="mt-4 font-display text-xl font-semibold text-text-primary">
                {state === 'ok' ? 'Вход выполнен' : 'Проверяем учётную запись…'}
              </div>
              <div className="text-sm text-text-secondary mt-1">Kerberos · единый вход</div>
            </motion.div>
          ) : (
            <motion.div key="denied" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={spring}
              className="surface-1 shadow-2xl overflow-hidden">
              <div className="grid md:grid-cols-[220px_1fr]">
                <div className="flex flex-col items-center justify-center gap-3 p-8 text-accent bg-accent/10 border-b md:border-b-0 md:border-r border-border">
                  <Shield ok={false} />
                  <div className="kicker text-center text-text-secondary">Доступ ограничен</div>
                </div>
                <div className="p-6 md:p-8">
                  <h1 className="font-display text-2xl font-semibold tracking-tight">{stub.title || 'Вход по Kerberos недоступен'}</h1>
                  <p className="text-text-secondary mt-1">{stub.subtitle || 'Не удалось подтвердить вашу учётную запись в домене'}</p>

                  <div className="mt-4 text-sm leading-relaxed">{stub.message}</div>
                  {(reason || message) && (
                    <div className="mt-3 text-xs rounded-md border border-warning/40 bg-warning/10 text-warning px-3 py-2">
                      {REASONS[reason] || message}
                    </div>
                  )}
                  <div className="mt-3 text-sm text-text-secondary">{stub.hint}</div>

                  {admins.length > 0 && (
                    <div className="mt-6">
                      <div className="text-xs uppercase tracking-wide text-text-secondary mb-2">Администраторы системы</div>
                      <div className="grid sm:grid-cols-2 gap-2">
                        {admins.map((a, i) => (
                          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 + i * 0.07 }}
                            className="flex gap-3 items-start p-3 rounded-lg border border-border bg-surface-alt/60">
                            <div className="shrink-0 w-10 h-10 rounded-full bg-accent text-accent-contrast flex items-center justify-center font-semibold text-sm">
                              {initials(a.name)}
                            </div>
                            <div className="min-w-0 text-sm">
                              <div className="font-medium break-words">{a.name}</div>
                              {a.position && <div className="text-xs text-text-secondary break-words">{a.position}</div>}
                              {a.phone && <a className="block text-xs text-accent hover:underline" href={`tel:${a.phone}`}>{a.phone}</a>}
                              {a.email && <a className="block text-xs text-accent hover:underline truncate" href={`mailto:${a.email}`}>{a.email}</a>}
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}

                  {(stub.support?.email || stub.support?.phone || stub.support?.hours) && (
                    <div className="mt-4 text-xs text-text-secondary">
                      Поддержка: {[stub.support.email, stub.support.phone, stub.support.hours].filter(Boolean).join(' · ')}
                    </div>
                  )}

                  <div className="mt-6 flex flex-wrap gap-2">
                    <button className="btn btn-primary" onClick={attempt}>Повторить вход</button>
                    {info?.password_url && info.mode === 'kerberos'
                      ? <a href={`${info.password_url}/login`} className="btn btn-secondary">Войти по паролю</a>
                      : <Link to="/login" className="btn btn-secondary">Войти по паролю</Link>}
                  </div>
                  {stub.footer && <div className="mt-5 text-[11px] text-text-secondary">{stub.footer}</div>}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}
