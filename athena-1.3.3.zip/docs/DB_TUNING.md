# Рекомендации по настройке PostgreSQL для ИР «Афина»

Все данные системы, включая файлы документов (PDF), хранятся в PostgreSQL.
Поэтому от настройки сервера БД зависят и скорость работы, и сохранность данных.
Значения ниже — отправная точка для выделенного сервера БД с SSD; уточняйте
их по фактической нагрузке.

## 1. Параметры `postgresql.conf`

Кладите настройки отдельным файлом `conf.d/99-athena.conf` — так их не
затрёт обновление пакета.

| Параметр | 8 ГБ ОЗУ / 4 ядра | 16 ГБ / 8 ядер | 32 ГБ / 16 ядер | Зачем |
|---|---|---|---|---|
| `shared_buffers` | 2GB | 4GB | 8GB | ~25 % ОЗУ |
| `effective_cache_size` | 5GB | 11GB | 22GB | ~70 % ОЗУ, подсказка планировщику |
| `work_mem` | 16MB | 24MB | 32MB | сортировки списков и журналов; выделяется на операцию |
| `maintenance_work_mem` | 512MB | 1GB | 2GB | VACUUM, построение индексов |
| `max_connections` | 100 | 150 | 200 | см. раздел 2 |
| `random_page_cost` | 1.1 | 1.1 | 1.1 | SSD; на HDD оставьте 4 |
| `effective_io_concurrency` | 200 | 200 | 200 | SSD |
| `max_wal_size` | 4GB | 8GB | 8GB | реже контрольные точки при загрузке файлов |
| `min_wal_size` | 1GB | 1GB | 2GB | |
| `checkpoint_completion_target` | 0.9 | 0.9 | 0.9 | сглаживает запись |
| `wal_compression` | on | on | on | меньше объём WAL |
| `wal_buffers` | 16MB | 16MB | 16MB | |
| `jit` | off | off | off | запросы короткие, JIT только замедляет |
| `max_worker_processes` | 4 | 8 | 16 | |
| `max_parallel_workers_per_gather` | 2 | 2 | 4 | отчёты и сводки администратора |

Дополнительно:

```conf
# Зависшая транзакция держит блокировки и мешает очистке
idle_in_transaction_session_timeout = '60s'
# Страховка от «убежавшего» запроса; фоновые задачи приложения короткие
statement_timeout = '60s'
lock_timeout = '10s'

# Журнал медленных запросов — основной инструмент разбора жалоб на скорость
log_min_duration_statement = '500ms'
log_lock_waits = on
log_checkpoints = on
log_autovacuum_min_duration = '1s'

shared_preload_libraries = 'pg_stat_statements'
track_io_timing = on
```

`synchronous_commit` оставьте `on`: подпись документа и выдача номера не
должны теряться при сбое питания.

## 2. Соединения

Приложение держит пул соединений: `database.max_conns` на процесс (плюс
небольшой служебный пул фоновых задач).

* один процесс: `max_conns: 20` достаточно для сотен одновременных пользователей;
* несколько процессов (`http.prefork`): всего соединений =
  `max_conns` × число процессов. Для 8 процессов ставьте `max_conns: 8–10`.

`max_connections` сервера = суммарный пул приложения + 20 (администрирование,
резервное копирование, мониторинг). Больше не нужно: каждое соединение — это
память и переключения контекста. PgBouncer не нужен: пул есть в самом приложении. Если он всё же ставится —
только в режиме сеанса (`pool_mode = session`): служебный пул фоновых задач
задаёт параметр доступа на уровне сеанса.

## 3. Роль приложения — без исключений

Приложение работает ролью `athena_app` (её создаёт `000_init.sql`): только DML,
без `SUPERUSER`, `BYPASSRLS` и владения таблицами. Разграничение доступа к
документам и файлам выполняет сама БД (Row-Level Security); для
привилегированной роли PostgreSQL его отключает. Не выдавайте `athena_app`
дополнительных прав и не подключайте приложение владельцем базы.

В `pg_hba.conf` разрешите роли `athena_app` вход только с адреса сервера
приложения, метод `scram-sha-256`. Если БД на другом сервере — включите TLS
(`ssl = on`, в строке подключения `sslmode=verify-full`).

## 4. Файлы документов в БД

PDF хранятся в столбцах `bytea` (`document_files`, `document_file_versions`,
`chat_attachments`), физически — в TOAST-таблицах. Для них задано хранение
`EXTERNAL` (без повторного сжатия: PDF уже сжат).

* **Объём.** Планируйте диск как «суммарный размер файлов × 1,3» плюс WAL и
  место под резервные копии. Предел размера файла задаёт `uploads.max_pdf_mb`.
* **Очистка.** Удаление черновиков и замена файла оставляют «мёртвые» строки в
  TOAST. Автоочистка справляется, но для больших таблиц сделайте её чаще:

  ```sql
  ALTER TABLE document_files         SET (autovacuum_vacuum_scale_factor = 0.02, toast.autovacuum_vacuum_scale_factor = 0.02);
  ALTER TABLE document_file_versions SET (autovacuum_vacuum_scale_factor = 0.02, toast.autovacuum_vacuum_scale_factor = 0.02);
  ```
* **Резервные копии** растут вместе с файлами. При объёме базы свыше
  50–100 ГБ переходите с `pg_dump` на физические копии с архивом WAL
  (pgBackRest, WAL-G, `pg_basebackup`).

## 5. Быстро растущие таблицы

| Таблица | Что растёт | Что делать |
|---|---|---|
| `audit_log` | каждая значимая операция | чистить за период через интерфейс администратора (функция `audit_purge`); строки неизменяемы |
| `document_history`, `document_views` | действия по документам | растут пропорционально работе, чистка не предусмотрена |
| `notifications` | уведомления | прочитанные старше года удаляет фоновая задача |
| `user_sessions`, `auth_login_failures`, `kerberos_seen_tokens`, `email_outbox` | служебные | чистит фоновая задача приложения (раз в час) |

Для таблиц с частыми обновлениями полезна более частая автоочистка:

```sql
ALTER TABLE user_sessions      SET (autovacuum_vacuum_scale_factor = 0.05);
ALTER TABLE notifications      SET (autovacuum_vacuum_scale_factor = 0.05, autovacuum_analyze_scale_factor = 0.05);
ALTER TABLE approval_stages    SET (autovacuum_analyze_scale_factor = 0.05);
ALTER TABLE numbering_sequences SET (fillfactor = 70);
```

Секционирование `audit_log` по месяцам имеет смысл после ~50 млн строк; в
поставку не входит.

## 6. Сводная панель и правила доступа

Сводная панель — один запрос под правами пользователя: видимые документы,
экземпляры, этапы и резолюции отбираются один раз, дальше — агрегаты. На
5 000 документах он выполняется около 0,1 с; основное время — проверка прав
на документы построчно. Если панель заметно замедлится на ваших объёмах:

```sql
-- под ролью приложения и пользователем, для которого медленно
SET ROLE athena_app;
SELECT set_config('app.user_id', '<id пользователя>', false);
-- затем EXPLAIN (ANALYZE) запроса из журнала медленных запросов
```

Политика резолюций вычисляет «подразделения, поручения и рассылки
пользователя» один раз на запрос (функции `app_resolution_departments()`,
`app_my_resolution_ids()`). Не заменяйте её обратно вызовом
`resolution_visible()` в каждой строке — это в десятки раз медленнее.

Для сводной панели в схеме есть частичные индексы
`idx_incoming_dept_open`, `idx_incoming_executed_at`,
`idx_resolutions_open_due`, `idx_documents_executed_at`,
`idx_approval_stages_pending_since`.

## 7. Номера без пропусков

Исходящие и входящие номера выдаются из таблицы `numbering_sequences`
под блокировкой строки внутри той же транзакции, что и подпись (регистрация):
отмена транзакции возвращает номер. Следствия:

* последовательности PostgreSQL (`SEQUENCE`) для номеров не используются —
  они дают пропуски;
* выдача номеров в одном подразделении идёт строго по очереди; это доли
  миллисекунды, но длинные транзакции в БД сторонними средствами (ручные
  `BEGIN` без `COMMIT`) могут остановить регистрацию — следите за
  `idle in transaction`;
* не правьте `numbering_sequences` вручную.

## 8. Резервное копирование и восстановление

```bash
# ежедневно
pg_dump -U postgres -Fc -Z 6 -f /backup/athena_$(date +%F).dump athena
# восстановление в пустую базу
createdb -U postgres athena_restore
pg_restore -U postgres -d athena_restore --no-owner /backup/athena_2026-01-01.dump
```

* Вместе с копией базы сохраняйте `config.yaml`. **`signing.secret` храните ещё
  и отдельно** от копий базы: без него подписи не проверить, вместе с базой
  он позволяет подделать подпись.
* Роль `athena_app` в дамп базы не входит: на новом сервере создайте её
  (`CREATE ROLE athena_app LOGIN PASSWORD '…'`) до восстановления и повторите
  выдачу прав — блок «Роль приложения и права» в конце `000_init.sql`.
* Раз в квартал проверяйте восстановление на отдельном сервере: запуск
  приложения и открытие нескольких документов с проверкой подписи.

## 9. Что контролировать

```sql
-- самые тяжёлые запросы
SELECT calls, round(mean_exec_time::numeric,1) AS ms, left(query,100)
  FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 15;
-- зависшие транзакции
SELECT pid, now()-xact_start AS age, state, left(query,80)
  FROM pg_stat_activity WHERE state LIKE 'idle in transaction%' ORDER BY age DESC;
-- размер таблиц вместе с TOAST
SELECT relname, pg_size_pretty(pg_total_relation_size(oid))
  FROM pg_class WHERE relkind='r' AND relnamespace='public'::regnamespace
 ORDER BY pg_total_relation_size(oid) DESC LIMIT 10;
```

Пороговые значения: свободное место на диске БД < 20 %, соединений > 80 % от
`max_connections`, транзакция `idle in transaction` дольше минуты, запросы
дольше 500 мс в журнале. Готовые правила — в `deploy/monitoring/alerts.yml`.

## 10. Операционная система

* файловая система БД — на SSD, монтирование с `noatime`;
* `vm.swappiness = 1`, `vm.overcommit_memory = 2`;
* huge pages при `shared_buffers` ≥ 8 ГБ (`huge_pages = try`);
* часы сервера синхронизированы (chrony): время подписи берётся с сервера;
* обновления PostgreSQL в пределах основной версии ставьте регулярно.
