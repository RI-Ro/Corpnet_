#!/bin/bash
# Выполняется один раз при первом создании тома основной БД: роль для репликации, слот для B и доступ по сети.
set -euo pipefail
psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" <<'SQL'
\getenv repl_password REPL_PASSWORD
CREATE ROLE replicator WITH REPLICATION LOGIN PASSWORD :'repl_password';
SELECT pg_create_physical_replication_slot('site_b');
SQL
{
  echo "host replication replicator all scram-sha-256"
} >> "$PGDATA/pg_hba.conf"
