// Фон страницы: градиенты, бесшовные узоры (SVG в data-URI, без сети) и однотонный цвет. Рисуется поверх фона палитры полупрозрачным слоем.
const svg = (body: string, w: number, h = w) => `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}'>${body}</svg>`)}")`;
const ink = 'rgba(120,130,150,.22)';
export interface BgDef { id: string; label: string; css: string; size?: string }
export const BGS: BgDef[] = [
  { id: 'none', label: 'Без фона', css: '' },
  { id: 'aurora', label: 'Северное сияние', css: 'linear-gradient(135deg, rgba(56,189,248,.22), rgba(167,139,250,.20) 50%, rgba(52,211,153,.18))' },
  { id: 'sunset', label: 'Закат', css: 'linear-gradient(160deg, rgba(251,146,60,.22), rgba(244,114,182,.20) 55%, rgba(129,140,248,.18))' },
  { id: 'ocean', label: 'Океан', css: 'linear-gradient(180deg, rgba(14,165,233,.20), rgba(30,64,175,.16))' },
  { id: 'forest', label: 'Лес', css: 'linear-gradient(150deg, rgba(34,197,94,.20), rgba(21,128,61,.14) 60%, rgba(250,204,21,.10))' },
  { id: 'graphite', label: 'Графит', css: 'linear-gradient(180deg, rgba(100,116,139,.22), rgba(15,23,42,.18))' },
  { id: 'dots', label: 'Горошек', css: svg(`<circle cx='3' cy='3' r='1.4' fill='${ink}'/>`, 18), size: '18px 18px' },
  { id: 'grid', label: 'Клетка', css: svg(`<path d='M0 .5H24M.5 0V24' stroke='${ink}' fill='none'/>`, 24), size: '24px 24px' },
  { id: 'hex', label: 'Соты', css: svg(`<path d='M14 0l14 8v16l-14 8L0 24V8z M14 32v16 M28 24l14 8 M0 24l-14 8' stroke='${ink}' fill='none'/>`, 28, 49), size: '28px 49px' },
  { id: 'waves', label: 'Волны', css: svg(`<path d='M0 10 Q10 0 20 10 T40 10' stroke='${ink}' fill='none'/>`, 40, 20), size: '40px 20px' },
  { id: 'facets', label: 'Грани', css: svg(`<path d='M0 0L30 30L60 0M0 60L30 30L60 60' stroke='${ink}' fill='none'/>`, 60), size: '60px 60px' },
];
/** Безопасная ссылка на фото: только свой /media/… или http(s); кавычки и скобки экранируются. */
export const validPhoto = (u: any) => typeof u === 'string' && u.length < 500 && /^(\/|https?:\/\/)[^\s"'<>]*$/.test(u);
const cssUrl = (u: string) => `url("${encodeURI(u).replace(/[()'"]/g, (c) => '%' + c.charCodeAt(0).toString(16))}")`;
/** `bg` — id пресета, цвет #rrggbb или 'photo' (тогда используется photo; поверх — вуаль цвета страницы для читаемости текста) */
export function bgCss(bg: string, photo = '', dim = 55): { image: string; size: string } {
  if (bg === 'photo' && validPhoto(photo)) {
    const v = `color-mix(in srgb, var(--bg) ${Math.min(90, Math.max(0, dim))}%, transparent)`;
    return { image: `linear-gradient(${v}, ${v}), ${cssUrl(photo)}`, size: 'auto, cover' };
  }
  if (/^#[0-9a-f]{6}$/i.test(bg)) return { image: `linear-gradient(${bg}33, ${bg}33)`, size: 'auto' };
  const d = BGS.find((b) => b.id === bg);
  return { image: d?.css || '', size: d?.size || 'cover' };
}
export const validBg = (bg: any) => typeof bg === 'string' && (bg === 'photo' || BGS.some((b) => b.id === bg) || /^#[0-9a-f]{6}$/i.test(bg));
