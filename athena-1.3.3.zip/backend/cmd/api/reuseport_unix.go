//go:build unix

package main

import (
	"syscall"

	"golang.org/x/sys/unix"
)

// reusePortControl включает SO_REUSEPORT: несколько процессов слушают один
// порт, ядро распределяет соединения между ними.
func reusePortControl(_, _ string, c syscall.RawConn) error {
	var serr error
	if err := c.Control(func(fd uintptr) {
		serr = unix.SetsockoptInt(int(fd), unix.SOL_SOCKET, unix.SO_REUSEPORT, 1)
	}); err != nil {
		return err
	}
	return serr
}
