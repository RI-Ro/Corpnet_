package server

import (
	"context"
	"io"
	"log/slog"
	"os"
	"testing"

	"corpnet/internal/kv"
	"github.com/jackc/pgx/v5/pgxpool"
)

func TestReadAndWritePoolContext(t *testing.T) {
	url := os.Getenv("RLS_TEST_URL")
	if url == "" {
		t.Skip("RLS_TEST_URL requires migrated PostgreSQL")
	}
	ctx := context.Background()
	pool, err := pgxpool.New(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	srv, err := New(Config{DataDir: t.TempDir()}, pool, pool, kv.New(kv.NewMemory()), slog.New(slog.NewTextHandler(io.Discard, nil)))
	if err != nil {
		t.Fatal(err)
	}
	var owner, note int64
	if err := pool.QueryRow(ctx, "SELECT id FROM users ORDER BY id LIMIT 1").Scan(&owner); err != nil {
		t.Fatal("RLS_TEST_URL requires one seeded user:", err)
	}
	if err := pool.QueryRow(ctx, "INSERT INTO notifications(user_id,kind,title) VALUES($1,'test','RLS regression') RETURNING id", owner).Scan(&note); err != nil {
		t.Fatal(err)
	}
	defer pool.Exec(ctx, "DELETE FROM notifications WHERE id=$1", note)
	for _, db := range []*DB{srv.db, srv.ro} {
		for _, uid := range []int64{owner, owner + 1} {
			var visible bool
			err := db.QueryRow(withRLS(ctx, &User{ID: uid, Role: "user"}), "SELECT EXISTS(SELECT FROM notifications WHERE id=$1)", note).Scan(&visible)
			if err != nil || visible != (uid == owner) {
				t.Fatalf("notification uid=%d visible=%v err=%v", uid, visible, err)
			}
		}
		var role string
		var id int64
		var service bool
		err := db.QueryRow(withRLS(ctx, &User{ID: 42, Role: "user"}), "select current_user,app_uid(),app_service()").Scan(&role, &id, &service)
		if err != nil || role != "corpnet_app" || id != 42 || service {
			t.Fatalf("request context: role=%s uid=%d service=%v err=%v", role, id, service, err)
		}
		if err := db.QueryRow(ctx, "select app_service()").Scan(&service); err != nil || !service {
			t.Fatalf("service context: %v %v", service, err)
		}
	}
}

// One attachment follows its publication through draft, publication and withdrawal.
func TestNewsAttachmentVisibility(t *testing.T) {
	url := os.Getenv("RLS_TEST_URL")
	if url == "" {
		t.Skip("RLS_TEST_URL requires migrated PostgreSQL")
	}
	ctx := context.Background()
	pool, err := pgxpool.New(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	tx, err := pool.Begin(ctx)
	if err != nil {
		t.Fatal(err)
	}
	defer tx.Rollback(ctx)
	var owner, news, file int64
	if err := tx.QueryRow(ctx, "select id from users order by id limit 1").Scan(&owner); err != nil {
		t.Fatal(err)
	}
	if err := tx.QueryRow(ctx, "insert into news(title,status,author_id) values('ACL test','draft',$1) returning id", owner).Scan(&news); err != nil {
		t.Fatal(err)
	}
	if err := tx.QueryRow(ctx, "insert into files(name,context,owner_id) values('test','news',$1) returning id", owner).Scan(&file); err != nil {
		t.Fatal(err)
	}
	if _, err := tx.Exec(ctx, "insert into news_files(news_id,file_id) values ($1,$2)", news, file); err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		status  string
		hidden  bool
		allowed bool
	}{{"draft", false, false}, {"published", false, true}, {"published", true, false}} {
		if _, err := tx.Exec(ctx, "update news set status=$1,hidden=$2 where id=$3", tc.status, tc.hidden, news); err != nil {
			t.Fatal(err)
		}
		var ok bool
		if err := tx.QueryRow(ctx, "select coalesce("+fileBaseOKSQL("f")+",false) from files f where f.id=$1", file, owner+1, int64(0), false).Scan(&ok); err != nil || ok != tc.allowed {
			t.Fatalf("%s hidden=%v allowed=%v err=%v", tc.status, tc.hidden, ok, err)
		}
	}
	if _, err := tx.Exec(ctx, "update news set hidden=false,target_users=ARRAY[$1::bigint] where id=$2", owner, news); err != nil {
		t.Fatal(err)
	}
	var allowed bool
	if err := tx.QueryRow(ctx, "select "+fileBaseOKSQL("f")+" from files f where f.id=$1", file, owner+1, int64(0), false).Scan(&allowed); err != nil || allowed {
		t.Fatalf("out-of-audience attachment: allowed=%v err=%v", allowed, err)
	}

}
