import React, { useState, useCallback } from 'react'
import Icon from '../components/Icon'
import { api } from '../api/client'

const SEARCH_DEBOUNCE_MS = 250
const STAGE_LABELS = {
  hierarchy: 'По иерархии',
  cross_dept: 'Между подразделениями',
}

// RouteBuilder — конструктор маршрута согласования с настраиваемой
// очерёдностью. В отличие от жёсткого «сначала иерархия, потом межвед», здесь
// единый упорядоченный список: у каждого согласующего свой тип, а порядок
// задаёт пользователь (стрелки вверх/вниз). Иерархия может стоять после
// межведомственного согласования — как требуется.
//
// value: [{ id, full_name, department_name, stage_type }]  (порядок = очерёдность)
// onChange: (nextValue) => void
// excludeIds: id, которые нельзя выбирать (автор)
// Номера шагов согласования.
//
// У каждого согласующего — номер шага: 1, 2, 2, 3 … Согласующие с одним
// номером работают одновременно; шаг N+1 открывается, когда согласовали все
// на шаге N. Номера ВСЕГДА идут подряд от 1: после любого изменения список
// нормализуется, поэтому набрать 1-2-2-4 нельзя (сервер проверяет то же
// правило и отклонит маршрут с пропуском).
export function normalizeSteps(list) {
  const withStep = list.map((v, i) => ({ ...v, step: Number(v.step) > 0 ? Number(v.step) : i + 1, _i: i }))
  const distinct = [...new Set(withStep.map((v) => v.step))].sort((a, b) => a - b)
  const rank = new Map(distinct.map((st, i) => [st, i + 1]))
  return withStep
    .map((v) => ({ ...v, step: rank.get(v.step) }))
    .sort((a, b) => a.step - b.step || a._i - b._i)
    .map(({ _i, ...v }) => v)
}

function RouteBuilder({ value = [], onChange, excludeIds = [] }) {
  const [query, setQuery] = useState('')
  const [stageType, setStageType] = useState('hierarchy')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)

  // Список всегда показывается нормализованным (подряд от 1).
  value = normalizeSteps(value)
  const maxStep = value.reduce((m, v) => Math.max(m, v.step), 0)
  const chosenIds = new Set(value.map((v) => v.id))
  const excluded = new Set([...excludeIds, ...chosenIds])

  // Поиск кандидатов по выбранному типу этапа (роль-фильтр на сервере).
  // Список показывается СРАЗУ при открытии (пустой q = начало списка группы),
  // ввод текста лишь сужает — чтобы согласующего можно было выбрать нажатием.
  React.useEffect(() => {
    if (!open) return
    let cancelled = false
    const t = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await api.searchCandidates({ group: stageType, q: query.trim(), limit: 30 })
        if (!cancelled) setResults(res.items || [])
      } catch (_) {
        if (!cancelled) setResults([])
      } finally {
        if (!cancelled) setLoading(false)
      }
    }, query.trim() ? SEARCH_DEBOUNCE_MS : 0)
    return () => {
      cancelled = true
      clearTimeout(t)
    }
  }, [query, stageType, open])

  const add = useCallback(
    (person) => {
      onChange([
        ...value,
        {
          id: person.id,
          full_name: person.full_name,
          department_id: person.department_id,
          department_name: person.department_name,
          stage_type: stageType,
          // Новый согласующий — отдельным следующим шагом; сделать его
          // параллельным предыдущему можно кнопкой «−».
          step: maxStep + 1,
        },
      ])
      setQuery('')
      setResults([])
    },
    [value, onChange, stageType, maxStep],
  )

  const remove = useCallback((id) => onChange(value.filter((v) => v.id !== id)), [value, onChange])

  // Изменить номер шага. «−» у единственного на шаге объединяет его с
  // предыдущим шагом (параллельно), «+» у одного из нескольких выносит его
  // в отдельный следующий шаг. Половинное значение ставит человека МЕЖДУ
  // шагами; нормализация затем возвращает сплошную нумерацию.
  const setStep = useCallback(
    (id, dir) => {
      const cur = value.find((v) => v.id === id)
      if (!cur) return
      const alone = value.filter((v) => v.step === cur.step).length === 1
      const step = alone ? cur.step + dir : cur.step + dir * 0.5
      onChange(normalizeSteps(value.map((v) => (v.id === id ? { ...v, step } : v))))
    },
    [value, onChange],
  )

  const grouped = results
    .filter((r) => !excluded.has(r.id))
    .reduce((acc, r) => {
      const key = r.department_name || 'Без подразделения'
      ;(acc[key] = acc[key] || []).push(r)
      return acc
    }, {})

  return (
    <div>
      {/* Текущий маршрут — упорядоченный список */}
      {value.length > 0 && (
        <ol className="mb-3 space-y-1.5">
          {value.map((v, idx) => (
            <li
              key={v.id}
              className="flex items-center gap-2 bg-surface-alt border border-border rounded-md px-2 py-1.5 text-sm"
            >
              <div className="flex items-center gap-0.5 shrink-0" title="Номер шага: одинаковый номер — согласуют одновременно">
                <button
                  type="button"
                  onClick={() => setStep(v.id, -1)}
                  disabled={v.step <= 1 && value.filter((x) => x.step === v.step).length === 1}
                  className="w-6 h-6 rounded border border-border text-text-secondary disabled:opacity-30"
                  aria-label="Раньше"
                >
                  −
                </button>
                <span className="w-7 h-6 inline-flex items-center justify-center rounded border border-accent text-accent font-semibold nums text-sm">
                  {v.step}
                </span>
                <button
                  type="button"
                  onClick={() => setStep(v.id, 1)}
                  disabled={v.step === maxStep && value.filter((x) => x.step === v.step).length === 1}
                  className="w-6 h-6 rounded border border-border text-text-secondary disabled:opacity-30"
                  aria-label="Позже"
                >
                  +
                </button>
              </div>
              <div className="flex flex-col">
                <div className="flex flex-col leading-none">
                  <span className="flex-1">
                    {v.full_name}
                    {v.department_name && (
                      <span className="text-text-secondary"> · {v.department_name}</span>
                    )}
                  </span>
                </div>
              </div>
              <span className="ml-auto text-[10px] px-1.5 py-0.5 rounded-full border border-border text-text-secondary">
                {STAGE_LABELS[v.stage_type]}
              </span>
              <div className="flex items-center gap-0.5">
                <button type="button" onClick={() => remove(v.id)} className="px-1 text-danger" title="Убрать">
                  ×
                </button>
              </div>
            </li>
          ))}
        </ol>
      )}

      {/* Добавление нового согласующего: тип + поиск */}
      <div className="flex gap-2 relative">
        <select
          value={stageType}
          onChange={(e) => {
            setStageType(e.target.value)
            setResults([])
          }}
          className="field"
          title="Тип согласования"
        >
          <option value="hierarchy">По иерархии</option>
          <option value="cross_dept">Между подразделениями</option>
        </select>
        <div className="flex-1 relative">
          <input
            value={query}
            onFocus={() => setOpen(true)}
            onChange={(e) => {
              setQuery(e.target.value)
              setOpen(true)
            }}
            onBlur={() => setTimeout(() => setOpen(false), 150)}
            placeholder="Начните вводить имя согласующего…"
            className="field focus:outline-none focus:ring-2 focus:ring-accent"
          />
          {open && (
            <div className="absolute z-20 mt-1 w-full max-h-64 overflow-auto bg-surface border border-border rounded-md shadow-lg">
              {loading && <div className="px-3 py-2 text-xs text-text-secondary">Загрузка…</div>}
              {!loading && Object.keys(grouped).length === 0 && (
                <div className="px-3 py-2 text-xs text-text-secondary">
                  {query.trim() ? 'Ничего не найдено' : 'Нет доступных согласующих этого типа'}
                </div>
              )}
              {!loading &&
                Object.entries(grouped).map(([dept, people]) => (
                  <div key={dept}>
                    <div className="kicker px-3 pt-2 pb-1 sticky top-0 bg-surface">// {dept}</div>
                    {people.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onMouseDown={() => add(p)}
                        className="w-full text-left px-3 py-1.5 text-sm hover:bg-surface-alt"
                      >
                        {p.full_name}
                      </button>
                    ))}
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
      <p className="text-xs text-text-secondary mt-1.5">
        Номер — шаг согласования. Одинаковый номер — согласуют одновременно; следующий шаг
        открывается, когда согласовали все на предыдущем. Номера всегда идут подряд, начиная с 1.
      </p>
      {value.length > 0 && (
        <p className="text-xs text-text-secondary mt-1">
          Порядок:{' '}
          {Array.from({ length: maxStep }, (_, i) => i + 1)
            .map((st) => value.filter((v) => v.step === st).map((v) => (v.full_name || '').split(' ')[0]).join(' ‖ '))
            .join(' → ')}{' '}
          → подпись
        </p>
      )}
    </div>
  )
}

// Обёрнут в React.memo намеренно.
//
// Этот компонент стоит в формах рядом с текстовыми полями. Без memo он
// перерисовывался при вводе КАЖДОЙ буквы в соседнем поле — форма создания
// документа из-за этого заметно подтормаживала. Свойства здесь стабильные:
// value — состояние родителя, onChange — setState, excludeIds — запомненный
// массив, поэтому memo действительно отсекает лишние перерисовки.
export default React.memo(RouteBuilder)
