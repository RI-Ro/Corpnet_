import { useStore } from '../lib/store';
import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { safeNext } from '../lib/router';
import { Btn, Field, Input, Select, Spinner } from '../ui';
import './login.css';

// --- Kerberos (SPNEGO): тихая попытка входа до показа формы -------------------------------------------------------
// krb_off — в этой вкладке Kerberos не сработал или пользователь вышел: автоматически больше не пробуем (иначе после выхода
// браузер тут же залогинил бы обратно), а показываем форму и кнопку «Войти через Kerberos». krb_avail=0 — на сервере выключен.
const KRB_OFF = 'krb_off';
const KRB_AVAIL = 'krb_avail';
const ss = {
  get: (k: string) => { try { return sessionStorage.getItem(k); } catch { return null; } },
  set: (k: string, v: string) => { try { sessionStorage.setItem(k, v); } catch {} },
};

type KrbResult = { ok: boolean; enabled: boolean; msg?: string };
/** GET /api/auth/negotiate: браузер в домене сам ответит на 401 Negotiate билетом. Таймаут 3 с — форма не зависает. */
async function tryKerberos(): Promise<KrbResult> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 3000);
  try {
    const res = await fetch('/api/auth/negotiate', { credentials: 'same-origin', cache: 'no-store', signal: ctl.signal });
    if (res.ok) return { ok: true, enabled: true };
    const enabled = res.headers.get('X-Auth-Kerberos') === 'on' || /negotiate/i.test(res.headers.get('WWW-Authenticate') || '');
    let msg: string | undefined;
    if (res.status === 403 || res.status === 429) msg = (await res.json().catch(() => null))?.error; // заблокирован / не найден / лимит
    return { ok: false, enabled, msg };
  } catch {
    return { ok: false, enabled: true }; // таймаут / сеть: считаем, что Kerberos недоступен
  } finally { clearTimeout(timer); }
}

export function Login() {
  const site = useStore((s) => s.site);
  const [login, setLogin] = useState('');
  const [source, setSource] = useState(0);
  const [sources, setSources] = useState<{ id: number; name: string; sort: number; domain?: string; netbios?: string }[]>([]);
  useEffect(() => {
    api.get<{ id: number; name: string; sort: number; domain?: string; netbios?: string }[]>('/api/auth/sources').then((r) => {
      const list = (r || []).slice().sort((a, b) => a.sort - b.sort || a.id - b.id);
      setSources(list);
      if (list.length && !list.some((x) => x.id === 0)) setSource(list[0].id);
    }).catch(() => {});
  }, []);
  const domains = sources.filter((x) => x.domain);
  const domHint = domains.length ? `Если в вашей организации несколько доменов, укажите домен: ${domains.slice(0, 2).map((x) => `ivanov@${x.domain}`).join(' или ')}${domains[0].netbios ? ` или ${domains[0].netbios}\\ivanov` : ''}. Учётные записи разных доменов — разные пользователи` : undefined;
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [krbTrying, setKrbTrying] = useState(() => !ss.get(KRB_OFF));
  const [krbBusy, setKrbBusy] = useState(false);
  const goNext = () => location.replace(safeNext(new URLSearchParams(location.search).get('next')));
  async function krbAttempt(manual: boolean) {
    const r = await tryKerberos();
    if (r.ok) { ss.set(KRB_AVAIL, '1'); goNext(); return; }
    ss.set(KRB_OFF, '1');
    ss.set(KRB_AVAIL, r.enabled ? '1' : '0');
    if (r.msg) setErr(r.msg);
    else if (manual) setErr(r.enabled ? 'Kerberos недоступен: браузер не передал билет. Войдите по паролю.' : 'Вход через Kerberos не настроен. Войдите по паролю.');
    setKrbTrying(false); setKrbBusy(false);
  }
  useEffect(() => { if (krbTrying) krbAttempt(false); }, []); // eslint-disable-line
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      await api.post('/api/auth/login', { login: login.trim(), password, source });
      // полная перезагрузка: заново поднимаем сессию, тему и WebSocket; next — только внутренний путь вместе с query и #hash
      goNext();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  return (
    <div className="login">
      <div className="loginForm">
        <div className="loginIdentity">{site.logo && <img className="logoImg" src={site.logo} alt="" />}<strong>{site.name}</strong></div>
        {krbTrying ? (
          <div className="krbTry" role="status" aria-live="polite"><Spinner /><div><b>Вход через Kerberos…</b><div className="small muted">Если не получится, появится форма пароля</div></div></div>
        ) : (
        <form onSubmit={submit}>
          <div><h1>Вход</h1><p className="muted">Используйте корпоративную учётную запись</p></div>
          {sources.length > 1 && (
            <Field label="Источник авторизации">
              <Select value={source} onChange={(e) => setSource(+e.target.value)}>
                {sources.map((x) => <option key={x.id} value={x.id}>{x.name}{x.domain ? ` (${x.domain})` : ''}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Логин или email" hint={domHint}><Input type="text" autoComplete="username" autoCapitalize="none" spellCheck={false} autoFocus required value={login} onChange={(e) => setLogin(e.target.value)} placeholder={domains.length ? 'логин, логин@домен или ДОМЕН\\логин' : 'логин или name@company.ru'} /></Field>
          <Field label="Пароль"><Input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
          {err && <div className="err" role="alert">{err}</div>}
          <Btn kind="pri" size="lg" className="block" busy={busy} type="submit">Войти</Btn>
          {ss.get(KRB_AVAIL) !== '0' && (
            <Btn size="lg" className="block" type="button" busy={krbBusy} onClick={() => { setErr(''); setKrbBusy(true); krbAttempt(true); }}><I.Key size={17} /> Войти через Kerberos</Btn>
          )}
        </form>
        )}
      </div>
    </div>
  );
}
