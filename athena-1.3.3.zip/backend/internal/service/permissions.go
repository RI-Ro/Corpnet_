package service

import (
	"context"
	"strings"

	"github.com/jackc/pgx/v5"
)

// IsAuthorOrSigner возвращает true, если пользователь — автор документа ИЛИ его
// подписант (назначенный на этап stage_type='signing', либо уже подписавший).
// Используется для прав на связи и направление документа.
func IsAuthorOrSigner(ctx context.Context, tx pgx.Tx, documentID, userID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		SELECT EXISTS (
			SELECT 1 FROM documents d WHERE d.id = $1 AND d.author_id = $2
			UNION ALL
			SELECT 1 FROM approval_stages s
			  WHERE s.document_id = $1 AND s.stage_type = 'signing' AND s.approver_id = $2
			UNION ALL
			SELECT 1 FROM document_signatures sig
			  WHERE sig.document_id = $1 AND sig.signer_id = $2
		)`, documentID, userID).Scan(&ok)
	return ok, err
}

// CanAcquaint проверяет, может ли actor ознакомить targetUser.
//
// ПРАВИЛО (замечания от 15.10.2026, п. 1): право даёт РОЛЬ «может
// ознакамливать» (acquainter), а подразделения задают только ОБЛАСТЬ.
//
// Что было раньше и почему переделано. Право выводилось косвенно: его давали
// роли «руководитель» и «дежурный», а всем прочим — наличие хотя бы одной
// строки в user_acquaint_departments. Такое правило нигде не видно целиком:
// в админке отмечались подразделения, а право зависело ещё и от ролей,
// выданных в другом месте того же экрана. Человеку выбирали подразделения,
// роли при этом не было — кнопка показывалась, а список кандидатов приходил
// пустой, и понять причину было неоткуда.
//
// Область: подразделения из user_acquaint_departments и всё, что ниже них по
// иерархии. ЕСЛИ ОБЛАСТЬ НЕ ЗАДАНА — своё подразделение и ниже. Последнее
// важно: роль без области иначе не давала бы ничего, и мы вернулись бы ровно
// к той же молчаливой пустоте, из-за которой всё и переделывается.
func CanAcquaint(ctx context.Context, tx pgx.Tx, actorID, targetUserID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, acquaintScopeSQL+`
		SELECT EXISTS (
			SELECT 1 FROM users u
			WHERE u.id = $2 AND u.is_active AND u.primary_department_id IN (SELECT id FROM subtree)
		)`, actorID, targetUserID).Scan(&ok)
	return ok, err
}

// HasAcquaintRole — есть ли у пользователя роль «может ознакамливать».
// Нужна интерфейсу (показывать ли вкладку) отдельно от области: человек с
// ролью, но без подходящих кандидатов, и человек без роли — это два разных
// случая, и объяснять их надо по-разному.
func HasAcquaintRole(ctx context.Context, tx pgx.Tx, userID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, `
		SELECT EXISTS (SELECT 1 FROM user_roles
		                WHERE user_id = $1 AND role = 'acquainter')`, userID).Scan(&ok)
	return ok, err
}

// acquaintScopeSQL — область ознакомления. ОДИН запрос на проверку права и на
// подбор кандидатов: две копии неизбежно разошлись бы, и тогда человек видел
// бы в списке того, кого система потом откажется ознакомить.
//
// $1 — идентификатор пользователя.
const acquaintScopeSQL = `
	WITH subtree AS (
	    -- Ровно назначенные подразделения (1.3): подчинённые НЕ добавляются
	    -- сами — в списке на ознакомление только сотрудники отмеченных
	    -- администратором подразделений.
	    SELECT a.department_id AS id FROM user_acquaint_departments a
	     WHERE a.user_id = $1
	       AND EXISTS (SELECT 1 FROM user_roles r
	                    WHERE r.user_id = $1 AND r.role = 'acquainter')
	    UNION
	    -- Не назначено ничего — только своё подразделение.
	    SELECT u.primary_department_id FROM users u
	     WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
	       AND EXISTS (SELECT 1 FROM user_roles r
	                    WHERE r.user_id = $1 AND r.role = 'acquainter')
	       AND NOT EXISTS (SELECT 1 FROM user_acquaint_departments a WHERE a.user_id = $1)
	)
`

// AcquaintScopeSubquery — та же область как подзапрос, для выборок кандидатов.
func AcquaintScopeSubquery(placeholder string) string {
	return strings.ReplaceAll(acquaintScopeSQL, "$1", placeholder) +
		" SELECT id FROM subtree"
}

// CanAssignTo проверяет право дать поручение assignee по документу.
// Правила:
//   - автор и подписант: могут поручать ВСЕМ, кому направлен документ
//     (получателям), а также сотрудникам своего подразделения и вниз по иерархии;
//   - остальные: только сотрудникам своего подразделения и вниз по иерархии.
//
// (Плюс отдельно в хендлере — тем, кого пользователь сам ознакомил.)
func CanAssignTo(ctx context.Context, tx pgx.Tx, documentID, actorID, assigneeID int64) (bool, error) {
	// Поручить можно сотруднику СВОЕГО подразделения и ниже по иерархии.
	//
	// Отдельной области «поручения» (таблица user_assign_departments) больше
	// нет: поручения вытеснены резолюциями, настройка оставалась в админке и
	// только сбивала с толку — её заполняли, ожидая влияния на резолюции.
	// Роль «исполнитель поручений» теперь есть у всех (её выдаёт триггер при
	// создании пользователя), поэтому условие по роли ничего не отсекает и
	// оставлено лишь ради совместимости прежних данных.
	var ok bool
	err := tx.QueryRow(ctx, `
		WITH RECURSIVE roots AS (
			SELECT u.primary_department_id AS id FROM users u
			WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
		),
		subtree AS (
			SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
			UNION ALL
			SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
		)
		SELECT EXISTS (
			SELECT 1 FROM users u
			WHERE u.id = $2
			  AND u.primary_department_id IN (SELECT id FROM subtree)
			  AND EXISTS (SELECT 1 FROM user_roles ur WHERE ur.user_id = u.id AND ur.role = 'executor')
		)`, actorID, assigneeID).Scan(&ok)
	return ok, err
}
