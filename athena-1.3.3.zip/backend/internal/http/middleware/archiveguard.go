package middleware

import (
	"regexp"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
)

// ArchiveGuard — документ в архиве доступен только для чтения.
//
// Любой изменяющий запрос (POST/PUT/PATCH/DELETE) к архивному документу —
// резолюции, комментарии, отметки об исполнении, правка, маршрут, рассылка
// и т. д. — отклоняется кодом 409 с понятным текстом. Исключения: ознакомление
// (/acquaint), избранное, выдача на печать и сама команда архивации.
//
// Проверка стоит на уровне middleware, а не в каждом обработчике: набор
// действий над документом большой и растёт, и защита «по месту» неизбежно
// пропустила бы очередной обработчик.
var (
	reDocPath    = regexp.MustCompile(`^/api/documents/(\d+)(/.*)?$`)
	reResPath    = regexp.MustCompile(`^/api/resolutions/(\d+)(/.*)?$`)
	reChatMsgURL = regexp.MustCompile(`^/api/chat/messages/(\d+)$`)
)

const archivedMessage = "Документ помещён в архив: изменения невозможны. Доступно только ознакомление."

// archiveAllowedSuffixes — действия, разрешённые и для архивного документа.
var archiveAllowedSuffixes = []string{"/acquaint", "/favorite", "/print", "/archive"}

func ArchiveGuard(pool *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		switch c.Method() {
		case fiber.MethodGet, fiber.MethodHead, fiber.MethodOptions:
			return c.Next()
		}
		path := c.Path()
		var query string
		var id int64
		if m := reDocPath.FindStringSubmatch(path); m != nil {
			rest := m[2]
			for _, s := range archiveAllowedSuffixes {
				if strings.HasPrefix(rest, s) {
					return c.Next()
				}
			}
			id, _ = strconv.ParseInt(m[1], 10, 64)
			query = `SELECT status = 'archived' FROM documents WHERE id = $1`
		} else if m := reResPath.FindStringSubmatch(path); m != nil {
			id, _ = strconv.ParseInt(m[1], 10, 64)
			query = `SELECT d.status = 'archived' FROM resolutions r JOIN documents d ON d.id = r.document_id WHERE r.id = $1`
		} else if m := reChatMsgURL.FindStringSubmatch(path); m != nil {
			id, _ = strconv.ParseInt(m[1], 10, 64)
			query = `SELECT d.status = 'archived' FROM chat_messages cm JOIN documents d ON d.id = cm.document_id WHERE cm.id = $1`
		} else {
			return c.Next()
		}
		if id == 0 {
			return c.Next()
		}
		uid, _ := c.Locals(CtxUserID).(int64)
		isAdmin, _ := c.Locals(CtxIsAdmin).(bool)
		archived := false
		err := db.WithUserTx(c.Context(), pool, uid, isAdmin, func(tx pgx.Tx) error {
			// Нет строки (документ не виден) — не наше дело: пусть ответит
			// сам обработчик (404/403).
			var a bool
			if e := tx.QueryRow(c.Context(), query, id).Scan(&a); e != nil {
				return nil
			}
			archived = a
			return nil
		})
		if err == nil && archived {
			return fiber.NewError(fiber.StatusConflict, archivedMessage)
		}
		return c.Next()
	}
}
