package server

import (
	"os"
	"path/filepath"
	"testing"
)

func TestExplicitConfiguration(t *testing.T) {
	previous := fileValues
	t.Cleanup(func() { fileValues = previous })
	t.Setenv("HTTP_ADDR", ":9999")
	t.Setenv("PORTAL_TEST_KEY", "12345678901234567890123456789012")
	base := "database:\n  url: postgres://localhost/test\nauth:\n  secret_key: '${PORTAL_TEST_KEY}'\n"
	path := filepath.Join(t.TempDir(), "config.yaml")
	for _, tc := range []struct {
		suffix string
		valid  bool
	}{
		{"server:\n  addr: ':9191'\n", true},
		{"server:\n  typo: true\n", false},
		{"server:\n  internal_allow: [wrong]\n", false},
		{"server:\n  tls_cert: cert.pem\n", false},
		{"server:\n  addr: ':9191'\n  addr: ':9192'\n", false},
	} {
		if err := os.WriteFile(path, []byte(base+tc.suffix), 0600); err != nil {
			t.Fatal(err)
		}
		err := ApplyConfigFile(path)
		if (err == nil) != tc.valid {
			t.Fatalf("valid=%v: %v", tc.valid, err)
		}
		if tc.valid && LoadConfig().Addr != ":9191" {
			t.Fatal("ambient HTTP_ADDR overrode explicit configuration")
		}
	}
}
