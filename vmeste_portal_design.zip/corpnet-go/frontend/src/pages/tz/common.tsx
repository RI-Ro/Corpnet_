import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast } from '../../lib/store';
import { Badge, Btn, Field, Modal, Select, Switch, Input, Loading } from '../../ui';
import { Link } from '../../lib/router';
import { cx, fmtDate, plural } from '../../lib/util';
import * as I from '../../lib/icons';

export const errMsg = (e: any) => e?.message || 'Ошибка';
export const useAudiences = () => useQuery<any[]>('audiences', () => api.get('/api/audiences'), { stale: 60000 });

/** Иконки достижений/уровней по имени (набор ограничен общими иконками портала). */
export function GfIcon({ name, size = 24 }: { name?: string; size?: number }) {
  const m: Record<string, any> = { seedling: I.Zap, cap: I.GradCap, award: I.Star, star: I.Star, heart: I.Heart, book: I.Book, zap: I.Zap, users: I.Users, bulb: I.Lightbulb, shield: I.Shield, flame: I.Zap, message: I.Comment, rocket: I.Zap, crown: I.Star, check: I.Check };
  const C = m[name || ''] || I.Star;
  return <C size={size} />;
}

/** Плашка на странице новости: подтверждение ознакомления и (для редактора) отчёт. */
export function AckBox({ news, canManage }: { news: any; canManage: boolean }) {
  const [busy, setBusy] = useState(false);
  const [rep, setRep] = useState(false);
  if (!news?.must_read) return null;
  const done = !!news.acked;
  const overdue = news.must_read_due && new Date(news.must_read_due) < new Date(new Date().toDateString());
  async function ack() {
    setBusy(true);
    try { await api.post(`/api/news/${news.id}/ack`); news.acked = true; invalidate('home'); invalidate('news:' + news.id); toast({ title: 'Ознакомление подтверждено', kind: 'success' }, 2500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <>
      <div className={cx('card tzAck', done && 'ok')} role="status">
        {done ? <I.CheckCheck size={22} /> : <I.Alert size={22} />}
        <div className="sp" style={{ flex: 1, minWidth: 200 }}>
          <b>{done ? 'Вы ознакомились с этой публикацией' : 'Обязательно к прочтению'}</b>
          <div className="small muted">{news.must_read_due ? `Срок: до ${fmtDate(news.must_read_due)}` : 'Подтвердите, что прочитали публикацию'}{!done && overdue ? ' — срок прошёл' : ''}</div>
        </div>
        {!done && news.must_read_me !== false && <Btn kind="pri" busy={busy} onClick={ack}><I.Check size={17} /> Ознакомлен(а)</Btn>}
        {canManage && <button className="btn" onClick={() => setRep(true)}><I.Chart size={16} /> Отчёт</button>}
      </div>
      {rep && <AckReport id={news.id} onClose={() => setRep(false)} />}
    </>
  );
}

function AckReport({ id, onClose }: { id: number; onClose: () => void }) {
  const q = useQuery<any>('acks:' + id, () => api.get(`/api/news/${id}/acks`), { stale: 0 });
  const d = q.data;
  const [busy, setBusy] = useState(false);
  async function remind() {
    setBusy(true);
    try { const r = await api.post<{ sent: number }>(`/api/news/${id}/acks/remind`); toast({ title: `Напоминание отправлено: ${r.sent}`, kind: 'success' }, 3000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <Modal title="Ознакомление с публикацией" onClose={onClose} size="lg" footer={<><a className="btn" href={`/api/news/${id}/acks?csv=1`}><I.Download size={16} /> CSV</a><Btn busy={busy} onClick={remind} disabled={!d?.pending?.length}><I.Bell size={16} /> Напомнить не ознакомившимся</Btn><Btn kind="pri" onClick={onClose}>Закрыть</Btn></>}>
      {!d ? <Loading /> : (
        <div className="stack">
          <div className="row"><b>{d.acked} из {d.total}</b><span className="muted small">ознакомились</span></div>
          <div className="tzBar"><i style={{ width: `${d.total ? (d.acked * 100) / d.total : 0}%` }} /></div>
          {d.by_dept?.length > 0 && <div className="stackS">{d.by_dept.map((x: any) => <div key={x.department} className="row small"><span className="sp clip">{x.department}</span><span className="muted">{x.acked}/{x.total}</span></div>)}</div>}
          {d.pending?.length > 0 && <div><div className="small bold" style={{ marginBottom: 6 }}>Не ознакомились ({d.pending.length})</div><div className="stackS">{d.pending.map((u: any) => <Link key={u.id} to={`/people/${u.id}`} className="small">{u.name} <span className="muted">· {u.job_title}</span></Link>)}</div></div>}
        </div>
      )}
    </Modal>
  );
}

export { Badge };
