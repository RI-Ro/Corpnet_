package server

import (
	"sync"
	"time"
)

// Локальный (L1) кэш процесса: самые частые чтения на каждый запрос (сессия → пользователь → профиль) отдаются
// из памяти без обращения к Redis/БД. TTL короткий (по умолчанию 2 с), поэтому отзыв сессии или блокировка на
// другой площадке доходят максимум за это время; на своей площадке и по sys-событиям запись сбрасывается сразу.
type l1Entry struct {
	v   any
	exp int64 // unix nano
}

type l1Cache struct {
	shards [32]struct {
		mu sync.RWMutex
		m  map[string]l1Entry
	}
	max int // записей в шарде
}

func newL1(maxPerShard int) *l1Cache {
	c := &l1Cache{max: maxPerShard}
	for i := range c.shards {
		c.shards[i].m = make(map[string]l1Entry, 64)
	}
	return c
}

func (c *l1Cache) shard(k string) int {
	h := uint32(2166136261)
	for i := 0; i < len(k); i++ {
		h = (h ^ uint32(k[i])) * 16777619
	}
	return int(h % uint32(len(c.shards)))
}

func (c *l1Cache) get(k string) (any, bool) {
	if c == nil {
		return nil, false
	}
	sh := &c.shards[c.shard(k)]
	sh.mu.RLock()
	e, ok := sh.m[k]
	sh.mu.RUnlock()
	if !ok || time.Now().UnixNano() > e.exp {
		return nil, false
	}
	return e.v, true
}

func (c *l1Cache) set(k string, v any, ttl time.Duration) {
	if c == nil {
		return
	}
	sh := &c.shards[c.shard(k)]
	now := time.Now().UnixNano()
	sh.mu.Lock()
	if len(sh.m) >= c.max { // переполнение: выбрасываем просроченные, а при необходимости всё
		for kk, e := range sh.m {
			if now > e.exp {
				delete(sh.m, kk)
			}
		}
		if len(sh.m) >= c.max {
			sh.m = make(map[string]l1Entry, 64)
		}
	}
	sh.m[k] = l1Entry{v: v, exp: now + int64(ttl)}
	sh.mu.Unlock()
}

func (c *l1Cache) del(k string) {
	if c == nil {
		return
	}
	sh := &c.shards[c.shard(k)]
	sh.mu.Lock()
	delete(sh.m, k)
	sh.mu.Unlock()
}
