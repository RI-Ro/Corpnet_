package service

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5"
)

var (
	ErrNotRecipient    = errors.New("пользователь не является получателем документа")
	ErrAlreadyDone     = errors.New("отметка об исполнении уже проставлена")
	ErrDocumentNotSent = errors.New("документ ещё не направлен получателям")
)

type ExecutionService struct{}

func NewExecutionService() *ExecutionService { return &ExecutionService{} }

// AllRecipientsDone — чистая функция: все ли получатели отметили исполнение.
// Вынесена ради юнит-теста без БД. total — сколько получателей всего,
// completed — сколько с проставленным completed_at.
func AllRecipientsDone(total, completed int) bool {
	return total > 0 && total == completed
}

// ErrNoIncomingInstance — у подразделения нет входящего экземпляра, то есть
// закрывать нечего: входящий номер ещё не присвоен.
var ErrNoIncomingInstance = errors.New("по вашему подразделению входящий номер не присвоен")

// executionGroundsSQL — ОСНОВАНИЯ для работы с отметкой об исполнении по
// входящему экземпляру.
//
// ЧТО БЫЛО НЕ ТАК. Оснований было два: быть получателем рассылки по этому
// подразделению либо иметь роль execution_marker в нём. Жалоба заказчика:
// «отметка об исполнении не работает для того, кто не адресат в документе».
// Так и было: человек, которому документ дали в работу — ознакомили или
// наложили резолюцию, — адресатом не является, роли execution_marker у него
// нет, и закрыть входящий он не мог. Ему приходилось идти к дежурному, а
// дежурный не знает, что именно исполнено.
//
// ЧТО СТАЛО. Оснований четыре, и все они означают одно: «документ дали в
// работу именно этому человеку, по этому подразделению».
//
//  1. получатель рассылки по этому подразделению — как раньше, право следует
//     из самого факта получения;
//  2. роль execution_marker в этом подразделении — как раньше, назначается
//     тому, кто закрывает входящие за отдел;
//  3. ОЗНАКОМЛЕННЫЙ с документом, чьё основное подразделение — это самое
//     подразделение. Ознакомление — обычный способ передать документ
//     исполнителю внутри отдела;
//  4. ИСПОЛНИТЕЛЬ РЕЗОЛЮЦИИ по этому документу, чьё основное подразделение —
//     это самое подразделение. Резолюция руководителя и есть прямое поручение
//     исполнить.
//
// В 3 и 4 обязательна привязка к подразделению: иначе исполнитель из другого
// отдела закрывал бы чужой входящий номер, а входящий номер принадлежит
// подразделению.
//
// $1 — документ, $2 — пользователь. Условие применяется к строке dii.
const executionGroundsSQL = `
		        EXISTS (SELECT 1 FROM document_recipients r
		                 WHERE r.document_id = $1
		                   AND NOT r.is_planned AND (r.recipient_user_id = $2 OR dii.received_by = $2)
		                   AND r.recipient_department_id = dii.receiving_department_id)
		     OR EXISTS (SELECT 1 FROM user_roles ur
		                 WHERE ur.user_id = $2
		                   AND ur.role = 'execution_marker'
		                   AND ur.department_id = dii.receiving_department_id)
		     OR EXISTS (SELECT 1 FROM document_acquaintances da
		                 JOIN users au ON au.id = da.user_id
		                WHERE da.document_id = $1 AND da.user_id = $2
		                  AND au.primary_department_id = dii.receiving_department_id)
		     OR EXISTS (SELECT 1 FROM resolution_executors re
		                 JOIN resolutions r2 ON r2.id = re.resolution_id
		                 JOIN users eu ON eu.id = re.user_id
		                WHERE r2.document_id = $1 AND re.user_id = $2
		                  AND re.status <> 'cancelled'
		                  AND r2.instance_id = dii.id AND r2.status <> 'cancelled')`

// executionDepartment — подразделение, за которое человек вправе закрыть
// входящий номер этого документа.
//
// Если оснований несколько (бывает у дежурного, обслуживающего несколько
// отделов), предпочтение отдаётся экземпляру СВОЕГО основного подразделения:
// именно за него человек отвечает, и выбор «первого по порядку» мог закрыть не
// тот номер. Второй аргумент — уже закрытый экземпляр или нет; он нужен,
// чтобы для простановки искать открытый, а для изменения и отмены — закрытый.
func executionDepartment(ctx context.Context, tx pgx.Tx, documentID, userID int64, wantExecuted bool) (int64, error) {
	var status string
	if err := tx.QueryRow(ctx, `SELECT status::text FROM documents WHERE id=$1 FOR UPDATE`, documentID).Scan(&status); err != nil {
		return 0, err
	}
	if status == "archived" {
		return 0, ErrDocumentArchived
	}
	cond := "dii.executed_at IS NULL"
	if wantExecuted {
		cond = "dii.executed_at IS NOT NULL"
	}
	var deptID int64
	err := tx.QueryRow(ctx, `
		SELECT dii.receiving_department_id
		  FROM document_incoming_instances dii
		 WHERE dii.document_id = $1
		   AND `+cond+`
		   AND (`+executionGroundsSQL+`
		   )
		 ORDER BY (dii.receiving_department_id
		           = (SELECT u.primary_department_id FROM users u WHERE u.id = $2)) DESC,
		          dii.receiving_department_id
		 LIMIT 1`, documentID, userID).Scan(&deptID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// Разделяем три разные причины: «нет входящего номера вообще»,
			// «номер есть, но состояние отметки не то» и «нет права».
			// Иначе человек не понимает, идти ему за ролью или ждать
			// регистрации входящего.
			var anyInstance bool
			_ = tx.QueryRow(ctx, `
				SELECT EXISTS (SELECT 1 FROM document_incoming_instances WHERE document_id = $1)`,
				documentID).Scan(&anyInstance)
			if !anyInstance {
				return 0, ErrNoIncomingInstance
			}
			var anyGround bool
			_ = tx.QueryRow(ctx, `
				SELECT EXISTS (
				    SELECT 1 FROM document_incoming_instances dii
				     WHERE dii.document_id = $1 AND (`+executionGroundsSQL+`
				     ))`, documentID, userID).Scan(&anyGround)
			if !anyGround {
				return 0, ErrNotRecipient
			}
			if wantExecuted {
				return 0, ErrNotExecuted
			}
			return 0, ErrAlreadyDone
		}
		return 0, fmt.Errorf("поиск входящего экземпляра: %w", err)
	}
	return deptID, nil
}

// ErrNotExecuted — отметки об исполнении нет, менять или отменять нечего.
var ErrNotExecuted = errors.New("отметка об исполнении не проставлена")

// ExecutionStatus — состояние отметки об исполнении для текущего пользователя
// и перечень доступных ему действий.
//
// Отдаётся интерфейсу вместо того, чтобы он вычислял это сам. Прежде кнопка
// «Отметить исполненным» показывалась по признаку «я адресат рассылки» — и у
// исполнителя, не являющегося адресатом, кнопки не было, хотя право у него
// есть (жалоба п. 21). Теперь признак считает сервер, причём тем же условием,
// которым он потом проверяет само действие.
type ExecutionStatus struct {
	// DepartmentName — подразделение, за которое человек отмечает исполнение.
	// Показывается рядом с кнопкой: при нескольких экземплярах человек должен
	// видеть, какой именно входящий номер он закрывает.
	DepartmentName string `json:"department_name,omitempty"`
	IncomingNumber string `json:"incoming_number,omitempty"`

	// Executed — отметка уже проставлена.
	Executed   bool   `json:"executed"`
	ExecutedAt string `json:"executed_at,omitempty"`
	ExecutedBy string `json:"executed_by_name,omitempty"`
	Note       string `json:"note,omitempty"`
	ActorNote  string `json:"actor_note,omitempty"`

	// CanMark / CanChange / CanCancel — что человек вправе сделать сейчас.
	CanMark   bool `json:"can_mark"`
	CanChange bool `json:"can_change"`
	CanCancel bool `json:"can_cancel"`

	// Reason — почему ничего нельзя, человеческим языком. Заполняется, только
	// когда все три права отрицательны: пустое объяснение рядом с отсутствующей
	// кнопкой — это и есть «не работает» с точки зрения пользователя.
	Reason string `json:"reason,omitempty"`
}

// Status собирает состояние отметки об исполнении для пользователя.
func (s *ExecutionService) Status(ctx context.Context, tx pgx.Tx, documentID, userID int64) (ExecutionStatus, error) {
	var out ExecutionStatus

	var docStatus string
	if err := tx.QueryRow(ctx, `SELECT status::text FROM documents WHERE id = $1`, documentID).
		Scan(&docStatus); err != nil {
		return out, err
	}

	// Ищем экземпляр, по которому у человека есть основание — в любом
	// состоянии отметки. Предпочтение своему основному подразделению, как и в
	// executionDepartment: ответ обязан относиться к тому же экземпляру, с
	// которым потом будет работать действие.
	var deptName, incoming, execBy, note, actorNote, execAt string
	var executed bool
	err := tx.QueryRow(ctx, `
		SELECT coalesce(dep.name,''), dii.incoming_number,
		       (dii.executed_at IS NOT NULL),
		       coalesce(to_char(dii.executed_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),''),
		       coalesce(eu.full_name,''), coalesce(dii.execution_note,''),
		       coalesce(dii.execution_actor_note,'')
		  FROM document_incoming_instances dii
		  LEFT JOIN departments dep ON dep.id = dii.receiving_department_id
		  LEFT JOIN users eu ON eu.id = dii.executed_by
		 WHERE dii.document_id = $1
		   AND (`+executionGroundsSQL+`
		   )
		 ORDER BY (dii.receiving_department_id
		           = (SELECT u.primary_department_id FROM users u WHERE u.id = $2)) DESC,
		          dii.receiving_department_id
		 LIMIT 1`, documentID, userID).
		Scan(&deptName, &incoming, &executed, &execAt, &execBy, &note, &actorNote)
	if errors.Is(err, pgx.ErrNoRows) {
		// Оснований нет. Отличаем «входящих экземпляров нет вовсе» от «есть,
		// но не для вас»: это два разных ответа человеку.
		var anyInstance bool
		if e := tx.QueryRow(ctx, `
			SELECT EXISTS (SELECT 1 FROM document_incoming_instances WHERE document_id = $1)`,
			documentID).Scan(&anyInstance); e != nil {
			return out, e
		}
		if !anyInstance {
			out.Reason = "по документу ещё не присвоен входящий номер — отмечать исполнение нечего"
		} else {
			out.Reason = "отметку об исполнении ставит адресат рассылки, сотрудник с ролью " +
				"«может ставить отметки о выполнении» в этом подразделении, ознакомленный " +
				"с документом или исполнитель резолюции по нему"
		}
		return out, nil
	}
	if err != nil {
		return out, fmt.Errorf("состояние отметки об исполнении: %w", err)
	}

	out.DepartmentName = deptName
	out.IncomingNumber = incoming
	out.Executed = executed
	out.ExecutedAt = execAt
	out.ExecutedBy = execBy
	out.Note = note
	out.ActorNote = actorNote

	if docStatus == "archived" {
		out.Reason = "документ в архиве: отметку об исполнении уже не изменить"
		return out, nil
	}
	if executed {
		out.CanChange = true
		out.CanCancel = true
	} else {
		out.CanMark = true
	}
	return out, nil
}

// ErrExecutionNoteRequired — отчёт о выполнении обязателен.
var ErrExecutionNoteRequired = errors.New("укажите отчёт о выполнении")

// MarkCompleted проставляет отметку об исполнении по ВХОДЯЩЕМУ НОМЕРУ.
//
// Отметка принадлежит входящему экземпляру (= входящему номеру). Один
// экземпляр — одна отметка, и это обеспечивает структура таблицы, а не
// проверка в коде. Кто вправе её поставить — см. executionGroundsSQL.
//
// Действие заместителя фиксируется пометкой: требование — записывать, что
// выполнено заместителем на период замещения.
func (s *ExecutionService) MarkCompleted(ctx context.Context, tx pgx.Tx, documentID, userID int64, note string) (becameExecuted bool, err error) {
	if strings.TrimSpace(note) == "" {
		return false, ErrExecutionNoteRequired
	}
	deptID, err := executionDepartment(ctx, tx, documentID, userID, false)
	if err != nil {
		return false, err
	}

	actorNote := ("")
	ct, err := tx.Exec(ctx, `
		UPDATE document_incoming_instances
		   SET executed_at = now(), executed_by = $3, execution_note = NULLIF($4,''),
		       execution_actor_note = NULLIF($5,'')
		 WHERE document_id = $1 AND receiving_department_id = $2
		   AND executed_at IS NULL`, documentID, deptID, userID, note, actorNote)
	if err != nil {
		return false, fmt.Errorf("простановка отметки об исполнении: %w", err)
	}
	if ct.RowsAffected() == 0 {
		// Условие executed_at IS NULL не выполнилось — значит кто-то успел
		// закрыть этот входящий номер между проверкой и записью. Это не ошибка
		// данных, а состояние.
		return false, ErrAlreadyDone
	}

	// Отметку получателя сохраняем тоже, если человек — получатель: на ней
	// держатся существующие счётчики рассылки («исполнили N из M»).
	if _, err := tx.Exec(ctx, `
		UPDATE document_recipients
		   SET completed_at = now(), completion_note = $3
		 WHERE document_id = $1 AND recipient_department_id = $2 AND NOT is_planned AND completed_at IS NULL`,
		documentID, deptID, note); err != nil {
		return false, fmt.Errorf("отметка получателя: %w", err)
	}

	if err := writeExecutionHistory(ctx, tx, documentID, userID, deptID, "execution_marked", note, actorNote); err != nil {
		return false, err
	}
	return recomputeDocumentExecuted(ctx, tx, documentID, userID)
}

// ChangeMark изменяет уже проставленную отметку об исполнении (,
// п. 22, первая половина — «добавить возможность изменять отметку об
// исполнении»).
//
// Меняется ТОЛЬКО отчёт о выполнении. Время отметки и её автор остаются
// прежними: отметка — свидетельство о том, когда и кем работа закрыта, и
// переписывать это при исправлении текста нельзя. Исправление фиксируется
// отдельным событием истории, где виден и новый текст, и кто его внёс.
//
// Кто вправе: тот, кто отметку поставил, либо любой, у кого есть основание по
// этому экземпляру (см. executionGroundsSQL). Второе нужно потому, что
// исполнитель может уйти в отпуск или уволиться, а исправить очевидную ошибку
// в отчёте должно быть можно без администратора.
func (s *ExecutionService) ChangeMark(ctx context.Context, tx pgx.Tx, documentID, userID int64, note string) error {
	if strings.TrimSpace(note) == "" {
		return ErrExecutionNoteRequired
	}
	deptID, err := executionDepartment(ctx, tx, documentID, userID, true)
	if err != nil {
		return err
	}
	var prev string
	if err := tx.QueryRow(ctx, `
		SELECT coalesce(execution_note,'') FROM document_incoming_instances
		 WHERE document_id = $1 AND receiving_department_id = $2`, documentID, deptID).Scan(&prev); err != nil {
		return fmt.Errorf("чтение прежнего отчёта: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE document_incoming_instances SET execution_note = NULLIF($3,'')
		 WHERE document_id = $1 AND receiving_department_id = $2
		   AND executed_at IS NOT NULL`, documentID, deptID, note); err != nil {
		return fmt.Errorf("изменение отметки об исполнении: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE document_recipients SET completion_note = $3
		 WHERE document_id = $1 AND recipient_department_id = $2 AND NOT is_planned AND completed_at IS NOT NULL`,
		documentID, deptID, note); err != nil {
		return fmt.Errorf("изменение отметки получателя: %w", err)
	}
	// В истории сохраняется и прежний текст: без него непонятно, что именно
	// исправили, а отчёт об исполнении — то, по чему потом разбирают работу.
	comment := "отчёт об исполнении изменён. Было: «" + prev + "». Стало: «" + note + "»"
	return writeExecutionHistory(ctx, tx, documentID, userID, deptID, "execution_changed", comment,
		(""))
}

// CancelMark отменяет отметку об исполнении (, вторая
// половина — «или отменять её»).
//
// Что происходит: отметка снимается с экземпляра, документ перестаёт считаться
// исполненным (если он успел стать таким), и в истории остаётся событие с
// ОБЯЗАТЕЛЬНОЙ причиной. Причина обязательна не из формальности: отмена
// отметки возвращает документ в работу, и без причины через месяц невозможно
// понять, почему исполненный документ снова открыт.
//
// Чего отмена НЕ делает: не возвращает документ из архива. Архив — отдельное
// состояние и отдельное действие; молча вытаскивать документ из архива отмена
// отметки не должна, поэтому по архивному документу отмена отклоняется.
func (s *ExecutionService) CancelMark(ctx context.Context, tx pgx.Tx, documentID, userID int64, reason string) error {
	if strings.TrimSpace(reason) == "" {
		return ErrCancelReasonRequired
	}
	var status string
	if err := tx.QueryRow(ctx, `SELECT status::text FROM documents WHERE id = $1`, documentID).Scan(&status); err != nil {
		return err
	}
	if status == "archived" {
		return ErrDocumentArchived
	}
	deptID, err := executionDepartment(ctx, tx, documentID, userID, true)
	if err != nil {
		return err
	}
	if _, err := tx.Exec(ctx, `
		UPDATE document_incoming_instances
		   SET executed_at = NULL, executed_by = NULL, execution_note = NULL,
		       execution_actor_note = NULL
		 WHERE document_id = $1 AND receiving_department_id = $2`, documentID, deptID); err != nil {
		return fmt.Errorf("отмена отметки об исполнении: %w", err)
	}
	// Отметку получателя снимаем только у ТЕХ получателей этого подразделения,
	// по которым она была: счётчик «исполнили N из M» должен сойтись с
	// экземплярами, иначе рассылка покажет исполнение там, где его нет.
	if _, err := tx.Exec(ctx, `
		UPDATE document_recipients
		   SET completed_at = NULL, completion_note = NULL
		 WHERE document_id = $1 AND recipient_department_id = $2`, documentID, deptID); err != nil {
		return fmt.Errorf("снятие отметки получателя: %w", err)
	}
	if err := writeExecutionHistory(ctx, tx, documentID, userID, deptID, "execution_cancelled",
		"отметка об исполнении отменена: "+reason, ("")); err != nil {
		return err
	}
	// Документ больше не исполнен — возвращаем его в работу. Статус считается
	// пересчётом по экземплярам, а не ставится константой: часть экземпляров
	// может быть по-прежнему закрыта.
	_, err = recomputeDocumentExecuted(ctx, tx, documentID, userID)
	return err
}

// ErrCancelReasonRequired — отмена отметки без причины не принимается.
var ErrCancelReasonRequired = errors.New("укажите причину отмены отметки об исполнении")

// ErrDocumentArchived — по архивному документу действие недоступно.
var ErrDocumentArchived = errors.New("документ находится в архиве")

// writeExecutionHistory пишет событие истории с пометкой о замещении.
func writeExecutionHistory(ctx context.Context, tx pgx.Tx, documentID, userID, deptID int64, event, comment, actorNote string) error {
	if actorNote != "" {
		if strings.TrimSpace(comment) == "" {
			comment = actorNote
		} else {
			comment = comment + " — " + actorNote
		}
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment, execution_department_id)
		VALUES ($1, $2, $3, NULLIF($4,''), $5)`, documentID, userID, event, comment, deptID); err != nil {
		return fmt.Errorf("запись истории (%s): %w", event, err)
	}
	return nil
}

// recomputeDocumentExecuted приводит статус документа в соответствие с
// состоянием входящих экземпляров.
//
// Считаем по экземплярам, а не по получателям: получателей у одного
// подразделения может быть несколько, а закрывает входящий один человек — по
// получателям документ никогда бы не стал исполненным.
//
// Функция работает в обе стороны. Это важно для п. 22: после отмены отметки
// документ обязан вернуться из 'executed' в работу, и делать это отдельной
// строчкой «поставь sent» было бы неверно — часть экземпляров может остаться
// закрытой, и правильный статус зависит от всей картины, а не от последнего
// действия.
func recomputeDocumentExecuted(ctx context.Context, tx pgx.Tx, documentID, actorID int64) (bool, error) {
	var total, done int
	var status string
	if err := tx.QueryRow(ctx, `
		SELECT (SELECT count(*) FROM (SELECT recipient_department_id FROM document_recipients WHERE document_id=$1 AND NOT is_planned UNION SELECT receiving_department_id FROM document_incoming_instances WHERE document_id=$1) departments),
		       (SELECT count(executed_at) FROM document_incoming_instances WHERE document_id = $1),
		       (SELECT status::text FROM documents WHERE id = $1)`, documentID).
		Scan(&total, &done, &status); err != nil {
		return false, fmt.Errorf("подсчёт входящих экземпляров: %w", err)
	}

	if AllRecipientsDone(total, done) {
		if status == "executed" || status == "archived" {
			return false, nil
		}
		if _, err := tx.Exec(ctx, `
			UPDATE documents SET status = 'executed', executed_at = now() WHERE id = $1`, documentID); err != nil {
			return false, fmt.Errorf("перевод документа в исполненные: %w", err)
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, to_status)
			VALUES ($1, $2, 'executed', 'executed')`, documentID, actorID); err != nil {
			return false, fmt.Errorf("запись истории исполнения: %w", err)
		}
		return true, nil
	}

	// Не все экземпляры закрыты. Если документ при этом помечен исполненным —
	// значит отметку только что отменили, и его надо вернуть в работу.
	if status == "executed" {
		if _, err := tx.Exec(ctx, `
			UPDATE documents SET status = 'in_progress', executed_at = NULL WHERE id = $1`, documentID); err != nil {
			return false, fmt.Errorf("возврат документа в работу: %w", err)
		}
		if _, err := tx.Exec(ctx, `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'status_changed', 'executed', 'in_progress',
			        'документ возвращён в работу: отметка об исполнении отменена')`,
			documentID, actorID); err != nil {
			return false, fmt.Errorf("запись истории возврата в работу: %w", err)
		}
	}
	return false, nil
}

// ArchiveExecutedFromPreviousYears переводит в 'archived' все документы,
// исполненные в предыдущих годах (executed_at.year < текущий год). Идемпотентно.
// Вызывается фоновой задачей раз в сутки (см. config lifecycle.archive_check_cron).
// Выполняется в отдельной admin-транзакции (RLS обходится через app.is_admin).
// ArchiveExecutedFromPreviousYears переводит в 'archived' все исполненные
// документы, у которых с даты исполнения прошло более 14 дней. Задержка нужна
// на случай, если исполненный документ потребуется дослать (из архива дослать
// уже нельзя). Имя метода сохранено для совместимости с планировщиком.
func (s *ExecutionService) ArchiveExecutedFromPreviousYears(ctx context.Context, tx pgx.Tx) (int64, error) {
	// Архивирование и запись в историю — одним запросом: у документа,
	// ушедшего в архив автоматически, должен остаться след, кто и когда.
	tag, err := tx.Exec(ctx, `
		WITH moved AS (
			UPDATE documents
			SET status = 'archived', archived_at = now()
			WHERE status = 'executed'
			  AND executed_at IS NOT NULL
			  AND executed_at < now() - interval '14 days'
			RETURNING id
		)
		INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
		SELECT id, NULL, 'archived', 'executed', 'archived', 'помещён в архив автоматически' FROM moved`)
	if err != nil {
		return 0, fmt.Errorf("auto archive: %w", err)
	}
	return tag.RowsAffected(), nil
}
