import tailwindcss from 'tailwindcss'
import autoprefixer from 'autoprefixer'

// Масштаб текста применяется и к произвольным классам Tailwind (например text-[11px]).
// Интервалы и размеры элементов сохраняют собственную шкалу rem.
const textScale = {
  postcssPlugin: 'athena-text-size',
  OnceExit(root) {
    root.walkDecls(/^(font-size|line-height)$/, decl => {
      if (/^-?[\d.]+(?:px|rem)$/.test(decl.value)) {
        decl.value = `calc(${decl.value} * var(--ui-text, 1))`
      }
    })
  },
}
export default {plugins: [tailwindcss(), autoprefixer(), textScale]}
