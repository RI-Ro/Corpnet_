#!/usr/bin/env bash
# Сборка сервера. Автор проекта обязателен и вшивается в бинарник на этапе компиляции.
#   ./build.sh --author "Имя Фамилия" [--out corpnet]
set -euo pipefail
cd "$(dirname "$0")"
AUTHOR=""; OUT="corpnet"
while [ $# -gt 0 ]; do
  case "$1" in
    --author)  AUTHOR="${2:-}"; shift 2 ;;
    --author=*) AUTHOR="${1#*=}"; shift ;;
    --out)     OUT="${2:-}"; shift 2 ;;
    *) echo "неизвестный аргумент: $1" >&2; exit 2 ;;
  esac
done
if [ -z "${AUTHOR// /}" ]; then echo "ошибка: укажите автора проекта: --author \"Имя\"" >&2; exit 2; fi
SUM=$(printf 'corpnet-author\0%s' "$AUTHOR" | sha256sum | cut -d' ' -f1)
go build -buildvcs=false -trimpath \
  -ldflags "-s -w -X 'corpnet/internal/author.name=${AUTHOR}' -X corpnet/internal/author.sum=${SUM}" \
  -o "$OUT" ./cmd/server
echo "собрано: $OUT (автор: $AUTHOR)"
