package service

import (
	"fmt"
	"strings"
	"unicode"
)

// ============================================================================
// ТРЕБОВАНИЯ К ПАРОЛЮ.
//
// Требование: не менее 8 знаков и не менее 3 групп символов.
//
// Группы: строчные буквы, ЗАГЛАВНЫЕ буквы, цифры, прочие знаки (всё, что не
// буква и не цифра). Буквы учитываются по Unicode, а не по латинице: пароль
// «Пароль123» набран по-русски и обязан считаться состоящим из трёх групп, а
// не отвергаться как «нет заглавных».
//
// Проверка выполняется НА СЕРВЕРЕ. Фронтенд показывает те же правила и те же
// подсказки, но полагаться на проверку в браузере нельзя: запрос на смену
// пароля можно отправить и мимо формы.
// ============================================================================

const (
	// PasswordMinLength — минимальная длина, в символах (не байтах): для
	// русского пароля длина в байтах вдвое больше, и проверка len() отвергала
	// бы допустимые пароли.
	PasswordMinLength = 8
	// PasswordMinGroups — минимальное число групп символов.
	PasswordMinGroups = 3
)

// PasswordGroups возвращает названия групп, встретившихся в пароле.
// Порядок стабильный — он используется в сообщении пользователю.
func PasswordGroups(password string) []string {
	var lower, upper, digit, other bool
	for _, r := range password {
		switch {
		case unicode.IsLower(r):
			lower = true
		case unicode.IsUpper(r):
			upper = true
		case unicode.IsDigit(r):
			digit = true
		default:
			// Пробел тоже считаем знаком: он разрешён и усложняет пароль.
			other = true
		}
	}
	var out []string
	if lower {
		out = append(out, "строчные буквы")
	}
	if upper {
		out = append(out, "заглавные буквы")
	}
	if digit {
		out = append(out, "цифры")
	}
	if other {
		out = append(out, "знаки")
	}
	return out
}

// ValidatePassword проверяет пароль и возвращает ошибку с объяснением, ЧТО
// именно не так — чтобы человек не угадывал. Сообщение показывается
// пользователю как есть.
func ValidatePassword(password string) error {
	runes := []rune(password)
	groups := PasswordGroups(password)

	shortEnough := len(runes) < PasswordMinLength
	fewGroups := len(groups) < PasswordMinGroups

	switch {
	case shortEnough && fewGroups:
		return fmt.Errorf("пароль должен быть не менее %d знаков (сейчас %d) и содержать "+
			"не менее %d групп символов из четырёх: строчные буквы, заглавные буквы, цифры, знаки "+
			"(сейчас %d: %s)",
			PasswordMinLength, len(runes), PasswordMinGroups, len(groups), joinGroups(groups))
	case shortEnough:
		return fmt.Errorf("пароль должен быть не менее %d знаков (сейчас %d)",
			PasswordMinLength, len(runes))
	case fewGroups:
		return fmt.Errorf("пароль должен содержать не менее %d групп символов из четырёх: "+
			"строчные буквы, заглавные буквы, цифры, знаки (сейчас %d: %s)",
			PasswordMinGroups, len(groups), joinGroups(groups))
	}
	return nil
}

// PasswordRequirementsText — требования к паролю одной строкой. Отдаётся
// фронту, чтобы подсказка в форме и проверка на сервере не разъезжались:
// текст один и тот же.
func PasswordRequirementsText() string {
	return fmt.Sprintf("Не менее %d знаков и не менее %d групп символов из четырёх: "+
		"строчные буквы, заглавные буквы, цифры, знаки.",
		PasswordMinLength, PasswordMinGroups)
}

func joinGroups(groups []string) string {
	if len(groups) == 0 {
		return "ни одной"
	}
	return strings.Join(groups, ", ")
}
