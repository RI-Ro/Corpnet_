-- ============================================================================
--  ИР «Афина» — ТЕСТОВЫЕ ДАННЫЕ (только для стендов разработки и приёмки!)
-- ============================================================================
--  Применяется ПОСЛЕ 000_init.sql. В рабочую базу не накатывать: создаёт
--  учётные записи с общеизвестным паролем.
--
--    psql -U postgres -d athena -v ON_ERROR_STOP=1 \
--         -v signing_secret='значение signing.secret из config.yaml' \
--         -v ndocs=300 -f backend/sql/900_testdata.sql
--
--  Параметры (оба необязательны):
--    ndocs           — сколько документов сгенерировать (по умолчанию 160);
--    signing_secret  — секрет подписи из конфигурации. Если задан, тестовые
--                      подписи будут проходить проверку в карточке документа;
--                      если нет — карточка покажет «подпись выполнена другим
--                      ключом» (это ожидаемо для тестовых данных).
--
--  Что создаётся:
--    * оргструктура из 4 подразделений;
--    * 13 пользователей, пароль у всех:  password123
--        author1     автор (Отдел разработки)
--        chief1      согласующий, «может ставить резолюции», ознакомление
--        exec1       рядовой исполнитель (Отдел разработки)
--        approver2   согласующий (Департамент цифровизации)
--        crossdept1  межведомственный согласующий (Департамент финансов)
--        approver3   межведомственный согласующий (Департамент финансов)
--        finchief1   «может ставить резолюции» + канцелярия (Департамент финансов)
--        outsider1   сотрудник без ролей (Департамент финансов)
--        signer1     подписант, контролёр (Главное управление)
--        approver4   согласующий (Главное управление)
--        duty1       дежурный/канцелярия (Департамент цифровизации)
--        clerk1      канцелярия, печать (Главное управление)
--        auditor1    чтение журнала аудита
--    * документы во всех статусах с файлами, маршрутами (шаги 1 → 2 ‖ 2 → 3),
--      подписями, рассылкой, входящими экземплярами, резолюциями по
--      экземплярам, обсуждением и уведомлениями.
--
--  Повторный запуск безопасен: оргструктура и пользователи создаются только
--  если их ещё нет, ранее сгенерированные документы (заголовок «[TD] …»)
--  удаляются и создаются заново.
-- ============================================================================

\set ON_ERROR_STOP on
\if :{?ndocs}
\else
  \set ndocs 160
\endif
\if :{?signing_secret}
\else
  \set signing_secret ''
\endif

BEGIN;
SET LOCAL search_path = public;
-- Скрипт выполняет владелец/суперпользователь: RLS для него выключаем явно.
SET LOCAL row_security = off;
SELECT set_config('athena.ndocs', :'ndocs', true) IS NOT NULL AS ok \gset td_
SELECT set_config('athena.signing_secret', :'signing_secret', true) IS NOT NULL AS ok \gset td_

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

-- ---------------------------------------------------------------------------
-- 1. Оргструктура
-- ---------------------------------------------------------------------------
INSERT INTO departments (name, numbering_prefix, city, parent_id)
SELECT 'Главное управление', '1', 'Москва', NULL
 WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Главное управление');
INSERT INTO departments (name, numbering_prefix, city, parent_id)
SELECT 'Департамент цифровизации', '1/2', 'Москва', (SELECT id FROM departments WHERE name = 'Главное управление')
 WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Департамент цифровизации');
INSERT INTO departments (name, numbering_prefix, city, parent_id)
SELECT 'Департамент финансов', '1/3', 'Москва', (SELECT id FROM departments WHERE name = 'Главное управление')
 WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Департамент финансов');
INSERT INTO departments (name, numbering_prefix, city, parent_id)
SELECT 'Отдел разработки', '1/2/4', 'Москва', (SELECT id FROM departments WHERE name = 'Департамент цифровизации')
 WHERE NOT EXISTS (SELECT 1 FROM departments WHERE name = 'Отдел разработки');

-- Транзитивное замыкание дерева подразделений (пересобирается целиком).
DELETE FROM department_closure;
INSERT INTO department_closure (ancestor_id, descendant_id, depth)
WITH RECURSIVE t AS (
    SELECT id AS ancestor_id, id AS descendant_id, 0 AS depth FROM departments
    UNION ALL
    SELECT t.ancestor_id, d.id, t.depth + 1 FROM t JOIN departments d ON d.parent_id = t.descendant_id
)
SELECT ancestor_id, descendant_id, depth FROM t;

-- ---------------------------------------------------------------------------
-- 2. Пользователи (пароль password123) и роли
-- ---------------------------------------------------------------------------
CREATE TEMP TABLE td_users (login TEXT, full_name TEXT, pos TEXT, dept TEXT, roles TEXT[]) ON COMMIT DROP;
INSERT INTO td_users VALUES
 ('author1',    'Иванов И.И. (автор)',             'Специалист отдела разработки',             'Отдел разработки',         ARRAY['author']),
 ('chief1',     'Петров П.П. (нач. отдела)',       'Начальник отдела разработки',              'Отдел разработки',         ARRAY['approver_hierarchy','chief','acquainter','author']),
 ('exec1',      'Николаев Н.Н. (исполнитель)',     'Ведущий инженер отдела разработки',        'Отдел разработки',         ARRAY[]::TEXT[]),
 ('approver2',  'Белов Б.Б. (согласующий ДЦ)',     'Заместитель директора департамента цифровизации', 'Департамент цифровизации', ARRAY['approver_hierarchy']),
 ('approver3',  'Громова Г.Г. (согласование ФИН)', 'Начальник планового отдела',               'Департамент финансов',     ARRAY['approver_cross_dept']),
 ('approver4',  'Курочкин К.К. (согласующий ГУ)',  'Начальник управления делами',              'Главное управление',       ARRAY['approver_hierarchy']),
 ('crossdept1', 'Сидоров С.С. (согласование ФИН)', 'Главный специалист департамента финансов', 'Департамент финансов',     ARRAY['approver_cross_dept']),
 ('finchief1',  'Фёдорова Ф.Ф. (рук. ФИН)',        'Директор департамента финансов',           'Департамент финансов',     ARRAY['chief','clerk','acquainter']),
 ('outsider1',  'Орлов О.О. (без ролей)',          'Экономист департамента финансов',          'Департамент финансов',     ARRAY[]::TEXT[]),
 ('signer1',    'Смирнов А.А. (подписант)',        'Заместитель руководителя',                 'Главное управление',       ARRAY['signer','controller','chief']),
 ('duty1',      'Кузнецов К.К. (дежурный)',        'Дежурный по департаменту',                 'Департамент цифровизации', ARRAY['clerk','acquainter','chief']),
 ('clerk1',     'Морозова М.М. (канцелярия)',      'Делопроизводитель канцелярии',             'Главное управление',       ARRAY['clerk','acquainter','printer']),
 ('auditor1',   'Соколова С.С. (аудитор)',         'Специалист по информационной безопасности','Главное управление',       ARRAY['auditor']);

INSERT INTO users (login, password_hash, full_name, position, primary_department_id, numbering_department_id, email)
SELECT t.login, crypt('password123', gen_salt('bf', 10)), t.full_name, t.pos, d.id, d.id, t.login || '@example.local' 
  FROM td_users t JOIN departments d ON d.name = t.dept
 WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.login = t.login);

INSERT INTO user_roles (user_id, department_id, role)
SELECT u.id, u.primary_department_id, r::role_code
  FROM td_users t JOIN users u ON u.login = t.login, unnest(t.roles) AS r
ON CONFLICT DO NOTHING;

-- ---------------------------------------------------------------------------
-- 3. Документы во всех статусах
-- ---------------------------------------------------------------------------
-- Генерация идёт от имени author1; это же значение попадает в «кем изменено»
-- у версий карточки (триггер читает app.user_id).
SELECT set_config('app.user_id', (SELECT id::text FROM users WHERE login = 'author1'), true) IS NOT NULL AS ok \gset td_

-- Ранее сгенерированные документы убираем (каскадом уйдут файлы, этапы,
-- подписи, рассылка, резолюции, обсуждение, уведомления).
DELETE FROM documents WHERE title LIKE '[TD]%';

DO $gen$
DECLARE
  v_ndocs     int := current_setting('athena.ndocs')::int;
  u_author    bigint := (SELECT id FROM users WHERE login = 'author1');
  u_chief     bigint := (SELECT id FROM users WHERE login = 'chief1');
  u_exec      bigint := (SELECT id FROM users WHERE login = 'exec1');
  u_cross     bigint := (SELECT id FROM users WHERE login = 'crossdept1');
  u_appr2     bigint := (SELECT id FROM users WHERE login = 'approver2');
  u_finchief  bigint := (SELECT id FROM users WHERE login = 'finchief1');
  u_outsider  bigint := (SELECT id FROM users WHERE login = 'outsider1');
  u_signer    bigint := (SELECT id FROM users WHERE login = 'signer1');
  u_duty      bigint := (SELECT id FROM users WHERE login = 'duty1');
  d_dev       bigint := (SELECT id FROM departments WHERE name = 'Отдел разработки');
  d_dig       bigint := (SELECT id FROM departments WHERE name = 'Департамент цифровизации');
  d_fin       bigint := (SELECT id FROM departments WHERE name = 'Департамент финансов');
  v_cat       bigint[] := ARRAY(SELECT id FROM document_categories WHERE is_active ORDER BY sort_order);
  v_mark      bigint := (SELECT id FROM special_marks WHERE is_default LIMIT 1);
  -- Получатели рассылки: только канцелярия/дежурные своих подразделений
  -- (этого требует триггер check_recipient_role).
  v_recip     bigint[];
  v_rdept     bigint[];
  v_rchief    bigint[];   -- кто в подразделении-получателе накладывает резолюцию
  v_rexec     bigint[];   -- кому он поручает

  v_pdf       bytea;
  v_statuses  text[] := ARRAY['on_approval_hierarchy','on_approval_cross_dept','on_signing',
                              'signed','sent','in_progress','executed','archived','rejected'];
  -- Особые отметки: в основном без отметки, часть — «Лично» и «Срочная доставка».
  v_marks     bigint[] := ARRAY(SELECT id FROM special_marks WHERE is_active ORDER BY is_default DESC, sort_order, id);
  v_year      int := extract(year from now())::int;
  -- Номера тестовых документов помечены «Т», чтобы не пересечься с боевой
  -- нумерацией: счётчики numbering_sequences не трогаются.
  v_out_pref  text := (SELECT coalesce(NULLIF(numbering_prefix,''), 'DEP' || id) FROM departments WHERE id = d_dev);
  v_in_pref   text[];
  v_seq       int := 0;
  v_inseq     int[] := ARRAY[0,0];

  i int; r int;
  v_doc bigint; v_status text; v_created timestamptz; v_due timestamptz;
  v_outnum text; v_signed timestamptz;
  s_h bigint; s_c bigint; s_p bigint; s_s bigint; v_res bigint; v_sent boolean;
  v_inst bigint[]; v_inst_id bigint; v_payload text;
  v_secret text := current_setting('athena.signing_secret');
BEGIN
  IF v_ndocs IS NULL OR v_ndocs < 1 THEN v_ndocs := 160; END IF;
  IF u_author IS NULL OR d_dev IS NULL OR cardinality(v_cat) = 0 OR v_mark IS NULL THEN
    RAISE EXCEPTION 'нет демо-пользователей, подразделений или справочников — сначала 000_init.sql';
  END IF;
  v_recip  := ARRAY[u_duty, u_finchief];
  v_rdept  := ARRAY[d_dig, d_fin];
  v_rchief := ARRAY[u_duty, u_finchief];
  v_rexec  := ARRAY[u_exec, u_outsider];
  v_in_pref := ARRAY[
    (SELECT coalesce(NULLIF(numbering_prefix,''), 'DEP' || id) FROM departments WHERE id = d_dig),
    (SELECT coalesce(NULLIF(numbering_prefix,''), 'DEP' || id) FROM departments WHERE id = d_fin)];

  FOR i IN 1..v_ndocs LOOP
    v_status  := v_statuses[1 + (i % array_length(v_statuses, 1))];
    -- Действующие документы — последние недели, завершённые — за ~11 месяцев:
    -- так сводная панель показывает и текущую картину, и динамику.
    v_created := CASE WHEN v_status IN ('executed','archived','rejected')
                      THEN now() - make_interval(days => 8 + ((v_ndocs - i) * 330) / v_ndocs, hours => i % 9)
                      ELSE now() - make_interval(days => 1 + (i * 7) % 34, hours => i % 9) END;
    -- Срок исполнения: у четверти документов не задан, у остальных 5–11 дней
    -- от создания — часть действующих документов уже просрочена.
    v_due := CASE WHEN i % 4 = 0 THEN NULL
                  ELSE v_created + make_interval(days => 5 + i % 7, hours => 17) END;
    -- У каждого документа свой файл (минимальный корректный PDF).
    v_pdf := convert_to(
      E'%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n'
      '2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n'
      '3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\n'
      'trailer<</Root 1 0 R>>\n%%EOF\n% test document ' || i || E'\n', 'UTF8');

    v_outnum := NULL; v_signed := NULL;
    IF v_status IN ('signed','sent','in_progress','executed','archived') THEN
      v_seq := v_seq + 1;
      v_outnum := format('ИСХ-%s-Т%s/%s', v_out_pref, v_seq, v_year);
      v_signed := v_created + make_interval(days => 3 + i % 3, hours => i % 7);
    END IF;
    v_sent := v_status IN ('sent','in_progress','executed','archived');

    INSERT INTO documents (author_id, author_department_id, title, urgency, status, outgoing_number,
                           due_date, due_datetime, created_at, updated_at, category_id, special_mark_id,
                           on_control, controller_id, executed_at, archived_at)
    VALUES (u_author, d_dev,
            format('[TD] Указание №%s о проведении мероприятий (%s)', i, v_status),
            'normal'::doc_urgency, v_status::doc_status, v_outnum,
            v_due::date, v_due, v_created, v_created,
            v_cat[1 + (i % cardinality(v_cat))],
            CASE WHEN i % 5 = 1 AND cardinality(v_marks) > 1 THEN v_marks[2]
                 WHEN i % 7 = 3 AND cardinality(v_marks) > 2 THEN v_marks[3] ELSE v_mark END,
            (i % 5 = 0 AND v_signed IS NOT NULL AND v_status <> 'archived'), CASE WHEN i % 5 = 0 AND v_signed IS NOT NULL THEN u_signer END,
            CASE WHEN v_status IN ('executed','archived')
                 THEN v_signed + make_interval(days => 1 + greatest((i + 5) % 6, (i + 10) % 6), hours => 6) END,
            CASE WHEN v_status = 'archived' THEN v_signed + interval '30 days' END)
    RETURNING id INTO v_doc;

    INSERT INTO document_files (document_id, content, sha256, size_bytes, uploaded_by, uploaded_at)
    VALUES (v_doc, v_pdf, encode(sha256(v_pdf), 'hex'), length(v_pdf), u_author, v_created);

    INSERT INTO document_history (document_id, actor_id, event_type, to_status, created_at)
    VALUES (v_doc, u_author, 'created', 'on_approval_hierarchy', v_created);

    INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, u_author, 'author')
      ON CONFLICT DO NOTHING;

    -- Маршрут с номерами шагов: 1 — руководитель отдела; 2 — параллельно
    -- межведомственный согласующий и (у каждого третьего документа) ещё один
    -- согласующий; 3 — подпись.
    v_inst := ARRAY[NULL, NULL]::bigint[];
    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, step_no, decided_at, comment)
    VALUES (v_doc, 'hierarchy', u_chief,
            (CASE v_status WHEN 'on_approval_hierarchy' THEN 'pending' WHEN 'rejected' THEN 'rejected' ELSE 'approved' END)::stage_status,
            1000, 1, CASE WHEN v_status <> 'on_approval_hierarchy' THEN v_created + make_interval(hours => 2 + i % 20) END,
            CASE WHEN v_status = 'rejected' THEN 'Не указаны сроки и ответственные — доработать' END)
    RETURNING id INTO s_h;
    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, step_no, decided_at)
    VALUES (v_doc, 'cross_dept', u_cross,
            (CASE WHEN v_status IN ('on_approval_hierarchy','rejected') THEN 'waiting_deps'
                  WHEN v_status = 'on_approval_cross_dept' THEN 'pending' ELSE 'approved' END)::stage_status,
            2001, 2, CASE WHEN v_status NOT IN ('on_approval_hierarchy','rejected','on_approval_cross_dept') THEN v_created + make_interval(hours => 24 + i % 40) END)
    RETURNING id INTO s_c;
    s_p := NULL;
    IF i % 3 = 0 THEN
      INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, step_no, decided_at)
      VALUES (v_doc, 'hierarchy', u_appr2,
              (CASE WHEN v_status IN ('on_approval_hierarchy','rejected') THEN 'waiting_deps'
                    WHEN v_status = 'on_approval_cross_dept' THEN 'pending' ELSE 'approved' END)::stage_status,
              2002, 2, CASE WHEN v_status NOT IN ('on_approval_hierarchy','rejected','on_approval_cross_dept') THEN v_created + make_interval(hours => 22 + i % 6) END)
      RETURNING id INTO s_p;
      INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id) VALUES (s_p, s_h);
      IF v_status NOT IN ('on_approval_hierarchy','rejected') THEN
        INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, u_appr2, 'approval_stage') ON CONFLICT DO NOTHING;
      END IF;
    END IF;
    INSERT INTO approval_stages (document_id, stage_type, approver_id, status, display_order, step_no, decided_at)
    VALUES (v_doc, 'signing', u_signer,
            (CASE WHEN v_status = 'on_signing' THEN 'pending' WHEN v_signed IS NOT NULL THEN 'approved' ELSE 'waiting_deps' END)::stage_status,
            3000, 3, v_signed)
    RETURNING id INTO s_s;
    INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id) VALUES (s_c, s_h), (s_s, s_c);
    IF s_p IS NOT NULL THEN
      INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id) VALUES (s_s, s_p);
    END IF;

    -- Участник маршрута видит документ с момента, когда его этап стал активным.
    INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, u_chief, 'approval_stage') ON CONFLICT DO NOTHING;
    IF v_status NOT IN ('on_approval_hierarchy','rejected') THEN
      INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, u_cross, 'approval_stage') ON CONFLICT DO NOTHING;
      INSERT INTO document_history (document_id, actor_id, event_type, comment, created_at)
      VALUES (v_doc, u_chief, 'stage_approved', 'согласовано', v_created + interval '4 hours');
    END IF;
    IF v_status = 'rejected' THEN
      INSERT INTO document_history (document_id, actor_id, event_type, comment, created_at)
      VALUES (v_doc, u_chief, 'stage_rejected', 'Не указаны сроки и ответственные — доработать', v_created + interval '4 hours');
    END IF;
    IF v_status = 'on_signing' OR v_signed IS NOT NULL THEN
      INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, u_signer, 'approval_stage') ON CONFLICT DO NOTHING;
      INSERT INTO document_history (document_id, actor_id, event_type, comment, created_at)
      VALUES (v_doc, u_cross, 'stage_approved', 'замечаний нет', v_created + interval '8 hours');
    END IF;

    -- Подпись.
    IF v_signed IS NOT NULL THEN
      -- Подпись в том же виде, что делает приложение: HMAC-SHA256 на
      -- секрете signing.secret от подписанной строки.
      SELECT format('v1|sha256=%s|doc=%s|signer=%s|login=%s|number=%s|at=%s',
                    encode(sha256(v_pdf), 'hex'), v_doc, u.id, u.login, v_outnum,
                    to_char(v_signed AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
        INTO v_payload FROM users u WHERE u.id = u_signer;
      INSERT INTO document_signatures (document_id, signer_id, signed_at, signature_type, signature_hash, storage_resource,
                                       signer_fio, signer_position, signer_login, signed_ip, document_hash,
                                       signed_payload, key_id)
      SELECT v_doc, u.id, v_signed, 'ПЭП',
             encode(hmac(convert_to(v_payload, 'UTF8'), convert_to(coalesce(NULLIF(v_secret, ''), 'testdata-no-secret'), 'UTF8'), 'sha256'), 'hex'),
             format('ИР «Афина» / Архив %s / %s', v_year, v_outnum),
             u.full_name, u.position, u.login, '127.0.0.1', encode(sha256(v_pdf), 'hex'),
             v_payload,
             CASE WHEN v_secret <> '' THEN left(encode(sha256(convert_to('athena/pes-key-id:' || v_secret, 'UTF8')), 'hex'), 8)
                  ELSE 'testdata' END
        FROM users u WHERE u.id = u_signer;
      INSERT INTO document_history (document_id, actor_id, event_type, to_status, comment, created_at)
      VALUES (v_doc, u_signer, 'signed', 'signed', v_outnum, v_signed);
    END IF;

    -- Рассылка, входящие экземпляры, резолюции.
    IF v_sent THEN
      FOR r IN 1..2 LOOP
        INSERT INTO document_recipients (document_id, recipient_user_id, recipient_department_id, is_planned,
                                         completed_at, completion_note, created_at, added_by)
        VALUES (v_doc, v_recip[r], v_rdept[r], false,
                CASE WHEN v_status IN ('executed','archived') THEN v_signed + make_interval(days => 1 + (i + r * 5) % 6, hours => r * 3) END,
                CASE WHEN v_status IN ('executed','archived') THEN 'Исполнено, доложено руководителю' END,
                v_signed + interval '1 hour', u_author);
        INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, v_recip[r], 'recipient') ON CONFLICT DO NOTHING;
        -- Входящий номер появляется, когда получатель впервые открыл документ:
        -- у статуса «sent» второй получатель документ ещё не открывал.
        IF NOT (v_status = 'sent' AND r = 2) THEN
          v_inseq[r] := v_inseq[r] + 1;
          INSERT INTO document_incoming_instances (document_id, receiving_department_id, received_by, incoming_number,
                                                   instance_label, first_viewed_at, created_at, executed_at, executed_by, execution_note)
          VALUES (v_doc, v_rdept[r], v_recip[r], format('ВХ-%s-Т%s/%s', v_in_pref[r], v_inseq[r], v_year),
                  format('Экз. № %s', r + 1), v_signed + interval '3 hours', v_signed + interval '3 hours',
                  CASE WHEN v_status IN ('executed','archived') THEN v_signed + make_interval(days => 1 + (i + r * 5) % 6, hours => r * 3) END,
                  CASE WHEN v_status IN ('executed','archived') THEN v_recip[r] END,
                  CASE WHEN v_status IN ('executed','archived') THEN 'Исполнено, доложено руководителю' END)
          RETURNING id INTO v_inst_id;
          v_inst[r] := v_inst_id;
        END IF;
      END LOOP;
      INSERT INTO document_history (document_id, actor_id, event_type, to_status, created_at)
      VALUES (v_doc, u_author, 'sent', 'sent', v_signed + interval '1 hour');
      INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, is_read, created_at)
      VALUES (v_recip[1], v_doc, 'document_sent', '{}', u_author, v_status <> 'sent', v_signed + interval '1 hour');

      -- Резолюция на экземпляр одного из подразделений-получателей — у
      -- документов «в работе» и дальше.
      IF v_status IN ('in_progress','executed','archived') THEN
        r := 1 + (i % 2);
        INSERT INTO resolutions (document_id, instance_id, department_id, author_id, author_position, text, due_date, status, closed_at, closed_by, created_at)
        SELECT v_doc, v_inst[r], v_rdept[r], u.id, u.position, 'Организовать исполнение, о результатах доложить',
               (v_signed + interval '7 days')::date,
               (CASE WHEN v_status = 'in_progress' THEN (CASE WHEN i % 3 = 0 THEN 'on_report' ELSE 'in_progress' END) ELSE 'done' END)::resolution_status,
               CASE WHEN v_status <> 'in_progress' THEN v_signed + make_interval(days => 1 + i % 11, hours => 8) END,
               CASE WHEN v_status <> 'in_progress' THEN u.id END,
               v_signed + interval '5 hours'
          FROM users u WHERE u.id = v_rchief[r]
        RETURNING id INTO v_res;
        INSERT INTO resolution_executors (resolution_id, user_id, is_responsible, status, report, reported_at, accepted_at, accepted_by, created_at)
        VALUES (v_res, v_rexec[r], true,
                (CASE WHEN v_status = 'in_progress' THEN (CASE WHEN i % 3 = 0 THEN 'reported' ELSE 'in_progress' END) ELSE 'accepted' END)::resolution_exec_status,
                CASE WHEN v_status <> 'in_progress' OR i % 3 = 0 THEN 'Мероприятия проведены, материалы направлены' END,
                CASE WHEN v_status <> 'in_progress' OR i % 3 = 0 THEN v_signed + make_interval(days => 1 + i % 11, hours => 6) END,
                CASE WHEN v_status <> 'in_progress' THEN v_signed + make_interval(days => 1 + i % 11, hours => 8) END,
                CASE WHEN v_status <> 'in_progress' THEN v_rchief[r] END,
                v_signed + interval '5 hours');
        INSERT INTO document_access (document_id, user_id, access_reason) VALUES (v_doc, v_rexec[r], 'executor') ON CONFLICT DO NOTHING;
        INSERT INTO document_acquaintances (document_id, user_id, acquainted_by, created_at)
        VALUES (v_doc, v_rexec[r], v_rchief[r], v_signed + interval '5 hours')
        ON CONFLICT DO NOTHING;
        INSERT INTO document_history (resolution_id,document_id, actor_id, event_type, comment, created_at)
        VALUES (v_res,v_doc, v_rchief[r], 'resolution_issued', 'резолюция: Организовать исполнение, о результатах доложить', v_signed + interval '5 hours');
        INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, detail, is_read, created_at)
        VALUES (v_rexec[r], v_doc, 'resolution', jsonb_build_object('resolution_id',v_res), v_rchief[r], 'Организовать исполнение, о результатах доложить',
                v_status <> 'in_progress', v_signed + interval '5 hours');
      END IF;
    END IF;

    -- Обсуждение.
    INSERT INTO chat_messages (document_id, author_id, text, created_at)
    VALUES (v_doc, u_author, 'Прошу согласовать.', v_created + interval '10 minutes'),
           (v_doc, u_chief, CASE WHEN v_status = 'rejected' THEN 'Возвращаю на доработку, причина — в решении.' ELSE 'Замечаний нет.' END,
            v_created + interval '3 hours');

    -- Уведомление тому, чьего действия документ ждёт.
    IF v_status IN ('on_approval_hierarchy','on_approval_cross_dept','on_signing') THEN
      INSERT INTO notifications (user_id, document_id, kind, payload, created_at)
      VALUES (CASE v_status WHEN 'on_approval_hierarchy' THEN u_chief WHEN 'on_approval_cross_dept' THEN u_cross ELSE u_signer END,
              v_doc, 'stage_pending', '{}', v_created + interval '1 minute');
    END IF;
  END LOOP;
  -- Когда этап стал активным: первый шаг — с создания документа, следующие —
  -- с последнего решения на предыдущем шаге. (Триггер ставит now() при
  -- вставке ожидающего этапа; для истории подставляем реальные моменты.)
  UPDATE approval_stages s
     SET created_at = d.created_at,
         activated_at = coalesce(
           (SELECT max(p.decided_at) FROM approval_stages p
             WHERE p.document_id = s.document_id AND p.step_no = s.step_no - 1),
           d.created_at)
    FROM documents d
   WHERE d.id = s.document_id AND d.title LIKE '[TD]%' AND s.status <> 'waiting_deps';
  RAISE NOTICE 'Сгенерировано документов: %', v_ndocs;
END
$gen$;

COMMIT;

SELECT status, count(*) AS documents FROM documents WHERE title LIKE '[TD]%' GROUP BY status ORDER BY status;
\echo 'Тестовые данные загружены. Пароль всех тестовых пользователей: password123'
