import React, { useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery } from '../lib/query';
import { toast } from '../lib/store';
import { fmtDate } from '../lib/util';
import { Badge, Btn, Skel, Textarea } from '../ui';

export interface Version {
  id: number; version: number; title: string; status: string; change_note: string; autosave: boolean; created_at: string; author: string; comments: number;
}
export interface VersionFull extends Version {
  summary: string; body: string; cover: string; category_id: number | null; department_id: number | null; published_at: string | null;
}
interface Stats {
  views: number; uniq: number; impressions: number; clicks: number; readers: number; avg_depth: number; avg_seconds: number; finished: number; depth_buckets: number[] | null;
}

const fmtSec = (s: number) => (s < 60 ? `${s} с` : `${Math.floor(s / 60)} мин ${s % 60 ? (s % 60) + ' с' : ''}`.trim());

/** Сведения о публикации: показы, охват, глубина прочтения и время чтения. */
export function NewsStats({ id }: { id: number }) {
  const { data, error } = useQuery<Stats>('news:stats:' + id, () => api.get(`/api/news/${id}/analytics`), { stale: 30000 });
  if (error) return <div className="small muted">Аналитика недоступна</div>;
  if (!data) return <Skel h={90} />;
  const ctr = data.impressions ? Math.round((data.clicks / data.impressions) * 100) : 0;
  const b = data.depth_buckets || [0, 0, 0, 0];
  const max = Math.max(1, ...b);
  const labels = ['0–25%', '25–50%', '50–75%', '75–100%'];
  return (
    <div className="nStats">
      <div className="nsGrid">
        <div><b>{data.views}</b><span>просмотров</span></div>
        <div><b>{data.uniq}</b><span>уникальных</span></div>
        <div><b>{data.impressions}</b><span>показов в ленте</span></div>
        <div><b>{ctr}%</b><span>переходов с карточки</span></div>
        <div><b>{data.avg_depth}%</b><span>средняя глубина</span></div>
        <div><b>{data.avg_seconds ? fmtSec(data.avg_seconds) : '—'}</b><span>среднее время чтения</span></div>
      </div>
      <div className="nsBars" aria-label="Глубина прочтения">
        {b.map((v, i) => (
          <div key={i} className="nsBar"><span className="nsLbl">{labels[i]}</span><i style={{ width: (v / max) * 100 + '%' }} /><em>{v}</em></div>
        ))}
      </div>
      <div className="tiny faint">Дочитали до конца: {data.finished} из {data.readers} читателей</div>
    </div>
  );
}

function Thread({ vid }: { vid: number }) {
  const { data, refetch } = useQuery<{ items: { id: number; body: string; created_at: string; author: string }[] }>('news:vc:' + vid, () => api.get(`/api/news-versions/${vid}/comments`), { stale: 0 });
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    try { await api.post(`/api/news-versions/${vid}/comments`, { body: text.trim() }); setText(''); refetch(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="vThread">
      {(data?.items || []).map((c) => (
        <div key={c.id} className="vComment"><b>{c.author}</b> <span className="tiny faint">{fmtDate(c.created_at)}</span><div>{c.body}</div></div>
      ))}
      <div className="row" style={{ alignItems: 'flex-end' }}>
        <Textarea rows={2} className="sp" value={text} maxLength={2000} placeholder="Комментарий к этой редакции (виден только редакторам)" onChange={(e) => setText(e.target.value)} />
        <Btn size="sm" busy={busy} onClick={send}>Отправить</Btn>
      </div>
    </div>
  );
}

/** История версий: список редакций, комментарии к ним и восстановление выбранной версии в форму. */
export function NewsHistory({ id, onRestore }: { id: number; onRestore: (v: VersionFull) => void }) {
  const { data, error } = useQuery<{ items: Version[] }>('news:versions:' + id, () => api.get(`/api/news/${id}/versions`), { stale: 0 });
  const [open, setOpen] = useState<number | null>(null);
  const [busy, setBusy] = useState(0);
  async function restore(v: Version) {
    setBusy(v.id);
    try { onRestore(await api.get<VersionFull>(`/api/news/${id}/versions/${v.id}`)); toast({ title: `Версия ${v.version} загружена в форму — сохраните, чтобы применить`, kind: 'success' }, 3500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(0);
  }
  if (error) return <div className="small muted">История недоступна</div>;
  if (!data) return <Skel h={80} />;
  if (!data.items.length) return <div className="small muted">Версий пока нет — первая появится после сохранения.</div>;
  return (
    <div className="vList">
      {data.items.map((v) => (
        <div key={v.id} className={'vItem' + (open === v.id ? ' on' : '')}>
          <button type="button" className="vHead" onClick={() => setOpen(open === v.id ? null : v.id)} aria-expanded={open === v.id}>
            <span className="vNum">v{v.version}</span>
            <span className="sp vMeta"><b className="clamp1">{v.title || 'Без заголовка'}</b><span className="tiny faint">{fmtDate(v.created_at)} · {v.author || '—'}{v.change_note ? ' · ' + v.change_note : ''}</span></span>
            {v.autosave && <Badge>Черновик</Badge>}
            {v.comments > 0 && <span className="tiny muted"><I.Message size={13} /> {v.comments}</span>}
          </button>
          {open === v.id && (
            <div className="vBody">
              <div className="row"><Btn size="sm" busy={busy === v.id} onClick={() => restore(v)}><I.Clock size={14} /> Загрузить в редактор</Btn></div>
              <Thread vid={v.id} />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
