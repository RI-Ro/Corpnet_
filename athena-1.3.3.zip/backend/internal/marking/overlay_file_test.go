package marking

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Симптом, с которого всё началось: «иногда бывают проблемы с записью в tmp».
// Проверяем, что печать от этого не отказывает.
func TestCreateOverlayFileFallback(t *testing.T) {
	data := []byte("PNGDATA")

	// 1) Настроенный каталог доступен — файл создаётся там.
	good := t.TempDir()
	overlayTempDir = good
	name, err := createOverlayFile(data)
	if err != nil {
		t.Fatalf("каталог доступен, но файл не создан: %v", err)
	}
	if filepath.Dir(name) != good {
		t.Errorf("файл создан не в настроенном каталоге: %s", name)
	}
	if b, _ := os.ReadFile(name); string(b) != "PNGDATA" {
		t.Errorf("содержимое записано неверно")
	}
	os.Remove(name)

	// 2) Настроенный каталог НЕ существует — должен сработать запасной путь,
	//    а не отказ печати.
	overlayTempDir = filepath.Join(good, "нет-такого-каталога")
	name, err = createOverlayFile(data)
	if err != nil {
		t.Fatalf("при недоступном каталоге печать отказала: %v", err)
	}
	os.Remove(name)

	// 3) Каталог существует, но только для чтения.
	ro := filepath.Join(good, "ro")
	if err := os.Mkdir(ro, 0o500); err != nil {
		t.Skip("не удалось создать каталог только для чтения")
	}
	overlayTempDir = ro
	name, err = createOverlayFile(data)
	if err != nil {
		t.Fatalf("при каталоге только для чтения печать отказала: %v", err)
	}
	os.Remove(name)

	// 4) Создаётся ОДИН файл, а не каталог.
	overlayTempDir = good
	name, _ = createOverlayFile(data)
	st, err := os.Stat(name)
	if err != nil || st.IsDir() {
		t.Errorf("ожидался один файл, получено: %v (каталог=%v)", err, st != nil && st.IsDir())
	}
	os.Remove(name)
}

// Слой должен размещаться в ОЗУ (/dev/shm), когда каталог не задан явно: это и
// есть ответ на «если можно не сохранять как файл — реализовать так». Диск при
// этом не задействован, и сбои записи в /tmp печать не ломают.
func TestCreateOverlayFilePrefersRAM(t *testing.T) {
	if _, err := os.Stat("/dev/shm"); err != nil {
		t.Skip("/dev/shm недоступен в этом окружении")
	}
	overlayTempDir = ""
	name, err := createOverlayFile([]byte("PNGDATA"))
	if err != nil {
		t.Fatalf("файл слоя не создан: %v", err)
	}
	defer os.Remove(name)
	if !strings.HasPrefix(name, "/dev/shm/") {
		t.Errorf("слой размещён в %s, ожидалась файловая система в ОЗУ /dev/shm", name)
	}
}
