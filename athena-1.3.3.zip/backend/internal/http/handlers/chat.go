package handlers

import (
	"fmt"
	"io"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

const maxChatAttachment = 15 << 20 // 15 МБ на файл

// ChatHandler — REST-доступ к обсуждению документа: история (с автором, датой,
// вложениями), отправка сообщения с файлами, скачивание вложения. Живые
// сообщения приходят по WebSocket; REST нужен для загрузки истории при
// открытии карточки и для сообщений с вложениями.
type ChatHandler struct {
	pool *pgxpool.Pool
	hub  *ws.Hub
}

func NewChatHandler(pool *pgxpool.Pool, hub *ws.Hub) *ChatHandler {
	return &ChatHandler{pool: pool, hub: hub}
}

type chatAttachmentDTO struct {
	ID       int64  `json:"id"`
	FileName string `json:"file_name"`
	MimeType string `json:"mime_type"`
	Size     int64  `json:"size_bytes"`
}

// chatReadDTO — кто и когда прочитал сообщение.
type chatReadDTO struct {
	UserID   int64  `json:"user_id"`
	FullName string `json:"full_name"`
	ReadAt   string `json:"read_at"`
}

type chatMessageDTO struct {
	ID          int64               `json:"id"`
	AuthorID    int64               `json:"author_id"`
	AuthorName  string              `json:"author_name"`
	Text        string              `json:"text"`
	CreatedAt   string              `json:"created_at"`
	EditedAt    *string             `json:"edited_at,omitempty"`
	Deleted     bool                `json:"deleted"`
	Attachments []chatAttachmentDTO `json:"attachments"`
	// Отметки прочтения. Заполняются только для СВОИХ сообщений: автору важно,
	// прочитали ли его, а чужие галочки ему ни о чём не говорят и только
	// утяжеляли бы ответ.
	//
	// RecipientCount — сколько человек имеют доступ к документу, кроме автора
	// сообщения. По нему фронт решает, одна галочка или две: прочитали все
	// или только часть.
	ReadBy         []chatReadDTO `json:"read_by,omitempty"`
	RecipientCount int           `json:"recipient_count,omitempty"`
}

// History GET /api/documents/:id/chat — история обсуждения.
func (h *ChatHandler) History(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var items []chatMessageDTO
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT m.id, m.author_id, u.full_name, coalesce(m.text,''),
			       to_char(m.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       to_char(m.edited_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       (m.deleted_at IS NOT NULL)
			FROM chat_messages m
			JOIN users u ON u.id = m.author_id
			WHERE m.document_id = $1
			ORDER BY m.created_at`, docID)
		if err != nil {
			return err
		}
		defer rows.Close()
		byID := map[int64]int{}
		for rows.Next() {
			var it chatMessageDTO
			var edited *string
			if err := rows.Scan(&it.ID, &it.AuthorID, &it.AuthorName, &it.Text, &it.CreatedAt, &edited, &it.Deleted); err != nil {
				return err
			}
			it.EditedAt = edited
			if it.Deleted {
				it.Text = "" // удалённое сообщение не показываем содержимым
			}
			it.Attachments = []chatAttachmentDTO{}
			byID[it.ID] = len(items)
			items = append(items, it)
		}
		if err := rows.Err(); err != nil {
			return err
		}
		if len(items) == 0 {
			return nil
		}
		arows, err := tx.Query(c.Context(), `
			SELECT a.message_id, a.id, a.file_name, a.mime_type, a.size_bytes
			FROM chat_attachments a
			JOIN chat_messages m ON m.id = a.message_id
			WHERE m.document_id = $1
			ORDER BY a.id`, docID)
		if err != nil {
			return err
		}
		defer arows.Close()
		for arows.Next() {
			var mid int64
			var at chatAttachmentDTO
			if err := arows.Scan(&mid, &at.ID, &at.FileName, &at.MimeType, &at.Size); err != nil {
				return err
			}
			if idx, ok := byID[mid]; ok {
				items[idx].Attachments = append(items[idx].Attachments, at)
			}
		}
		if err := arows.Err(); err != nil {
			return err
		}

		// --- Отметки прочтения СВОИХ сообщений ---------------------------
		//
		// Запрашиваются одним запросом по всем своим сообщениям сразу, а не по
		// одному на сообщение: в длинном обсуждении это была бы сотня запросов
		// на каждое открытие вкладки.
		rrows, err := tx.Query(c.Context(), `
			SELECT r.message_id, r.user_id, u.full_name,
			       to_char(r.read_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			FROM chat_message_reads r
			JOIN users u ON u.id = r.user_id
			JOIN chat_messages m ON m.id = r.message_id
			WHERE m.document_id = $1 AND m.author_id = $2
			ORDER BY r.read_at`, docID, userID)
		if err != nil {
			return err
		}
		defer rrows.Close()
		for rrows.Next() {
			var mid int64
			var rd chatReadDTO
			if err := rrows.Scan(&mid, &rd.UserID, &rd.FullName, &rd.ReadAt); err != nil {
				return err
			}
			if idx, ok := byID[mid]; ok {
				items[idx].ReadBy = append(items[idx].ReadBy, rd)
			}
		}
		if err := rrows.Err(); err != nil {
			return err
		}

		// Сколько человек вообще могут прочитать: все с доступом к документу,
		// кроме автора сообщения (сам автор не считается).
		var recipients int
		if err := tx.QueryRow(c.Context(), `
			SELECT count(DISTINCT user_id) FROM document_access
			WHERE document_id = $1 AND user_id <> $2`, docID, userID).Scan(&recipients); err != nil {
			return err
		}
		for i := range items {
			if items[i].AuthorID == userID {
				items[i].RecipientCount = recipients
			}
		}

		// --- Отмечаем ЧУЖИЕ сообщения прочитанными ------------------------
		//
		// Факт открытия обсуждения и есть прочтение: отдельной кнопки
		// «прочитано» в переписке не бывает. Своё сообщение не отмечаем — оно
		// прочитано по определению, и строки в таблице на это тратить незачем.
		//
		// ON CONFLICT DO NOTHING: время первого прочтения не должно
		// переписываться при каждом последующем открытии.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO chat_message_reads (message_id, user_id)
			SELECT m.id, $2 FROM chat_messages m
			WHERE m.document_id = $1 AND m.author_id <> $2 AND m.deleted_at IS NULL
			ON CONFLICT (message_id, user_id) DO NOTHING`, docID, userID); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить обсуждение")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Post POST /api/documents/:id/chat — сообщение с необязательными вложениями
// (multipart form: text + files[]). Сохраняет и рассылает по WebSocket.
func (h *ChatHandler) Post(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	docID, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	text := c.FormValue("text")
	form, _ := c.MultipartForm()
	var fileCount int
	if form != nil {
		fileCount = len(form.File["files"])
	}
	if text == "" && fileCount == 0 {
		return fiber.NewError(fiber.StatusBadRequest, "пустое сообщение")
	}

	var msgID int64
	var authorName, createdAt string
	var fileNames []string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(), `
			INSERT INTO chat_messages (document_id, author_id, text)
			VALUES ($1, $2, $3)
			RETURNING id, to_char(created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')`,
			docID, userID, text).Scan(&msgID, &createdAt); err != nil {
			return err
		}
		if err := tx.QueryRow(c.Context(), `SELECT full_name FROM users WHERE id=$1`, userID).Scan(&authorName); err != nil {
			return err
		}
		if form != nil {
			for _, fh := range form.File["files"] {
				if fh.Size > maxChatAttachment {
					return fmt.Errorf("файл %s слишком большой (макс 15 МБ)", fh.Filename)
				}
				src, err := fh.Open()
				if err != nil {
					return err
				}
				buf, err := io.ReadAll(src)
				src.Close()
				if err != nil {
					return err
				}
				mime := fh.Header.Get("Content-Type")
				if mime == "" {
					mime = "application/octet-stream"
				}
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO chat_attachments (message_id, file_name, content, mime_type, size_bytes)
					VALUES ($1, $2, $3, $4, $5)`, msgID, fh.Filename, buf, mime, len(buf)); err != nil {
					return err
				}
				fileNames = append(fileNames, fh.Filename)
			}
		}
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отправить сообщение")
	}

	// Рассылаем сигнал перечитать историю (в т.ч. с вложениями) — не частичное
	// сообщение, иначе у подписчиков появлялось бы «пустое» сообщение без файлов.
	h.hub.Broadcast(fmt.Sprintf("doc:%d", docID), fiber.Map{"type": "chat_updated", "document_id": docID})

	// #7 — Персистентное уведомление о комментарии. Раньше комментарий уходил
	// только в realtime-канал документа: кто страницу документа не держал
	// открытой, о комментарии не узнавал вовсе, и в колоколе его не было.
	// Теперь уведомление создаётся всем, у кого есть доступ к документу (кроме
	// автора комментария), а деталью идёт сам текст — именно это даёт
	// «Иванов Иван оставил комментарий «выполнено» в документе «…»».
	//
	// Отдельной транзакцией после коммита сообщения: сообщение уже сохранено и
	// отдано клиенту, и падение рассылки уведомлений не должно его откатывать.
	// Имена файлов попадают в уведомление: «прислал файлы: договор.pdf, акт.docx».
	detail := text
	if len(fileNames) > 0 {
		files := "файл: " + strings.Join(fileNames, ", ")
		if len(fileNames) > 1 {
			files = "файлы: " + strings.Join(fileNames, ", ")
		}
		if detail == "" {
			detail = files
		} else {
			detail = detail + " (" + files + ")"
		}
	} else if detail == "" && fileCount > 0 {
		detail = fmt.Sprintf("вложение (%d шт.)", fileCount)
	}
	var notified []int64
	if err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		ids, err := service.NotifyDocumentEventDetail(c.Context(), tx, docID, "chat_message", userID, detail, "{}")
		notified = ids
		return err
	}); err != nil {
		log.Printf("chat: уведомления о комментарии к документу %d не созданы: %v", docID, err)
	} else if len(notified) > 0 {
		h.hub.NotifyUsers(notified, docID, "chat_message")
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": msgID, "created_at": createdAt})
}

// Attachment GET /api/chat/attachments/:aid — скачать вложение. RLS
// chat_messages ограничивает доступ теми документами, к которым он есть.
func (h *ChatHandler) Attachment(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	aid, err := strconv.ParseInt(c.Params("aid"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var content []byte
	var name, mime string
	var docID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(), `
			SELECT a.file_name, a.mime_type, a.content, m.document_id
			FROM chat_attachments a
			JOIN chat_messages m ON m.id = a.message_id
			WHERE a.id = $1`, aid).Scan(&name, &mime, &content, &docID); err != nil {
			return err
		}

		// Факт скачивания вложения — в историю документа.
		//
		// Запись делается В ТОЙ ЖЕ транзакции, что и чтение файла: если
		// записать её отдельно после отдачи содержимого, то при обрыве
		// соединения или падении процесса файл уже ушёл бы, а в истории
		// следа не осталось. Для учёта экземпляров документа важно обратное:
		// лучше лишняя запись о скачивании, чем пропущенная.
		//
		// Комментарием идёт имя файла: без него запись «скачал вложение» в
		// обсуждении на десяток файлов ничего не говорит.
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, comment)
			VALUES ($1, $2, 'chat_attachment_downloaded', $3)`, docID, userID, name); err != nil {
			return err
		}
		return nil
	})
	if txErr != nil {
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusNotFound, "вложение не найдено")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить вложение")
	}
	c.Set("Content-Type", mime)
	c.Set("Content-Disposition", fmt.Sprintf(`inline; filename="%s"`, name))
	return c.Send(content)
}

// EditMessage PATCH /api/chat/messages/:mid — правка своего сообщения.
// Ставит edited_at=now(); удалённые не редактируются.
func (h *ChatHandler) EditMessage(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	mid, err := strconv.ParseInt(c.Params("mid"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Text string `json:"text"`
	}
	if err := c.BodyParser(&req); err != nil || strings.TrimSpace(req.Text) == "" {
		return fiber.NewError(fiber.StatusBadRequest, "пустое сообщение")
	}
	var docID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		tag, err := tx.Exec(c.Context(), `
			UPDATE chat_messages SET text = $1, edited_at = now()
			WHERE id = $2 AND author_id = $3 AND deleted_at IS NULL`,
			strings.TrimSpace(req.Text), mid, userID)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return tx.QueryRow(c.Context(), `SELECT document_id FROM chat_messages WHERE id=$1`, mid).Scan(&docID)
	})
	if txErr != nil {
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusForbidden, "можно редактировать только своё неудалённое сообщение")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить сообщение")
	}
	if docID != 0 {
		h.hub.Broadcast(fmt.Sprintf("doc:%d", docID), fiber.Map{"type": "chat_updated", "document_id": docID})
	}
	return c.SendStatus(fiber.StatusOK)
}

// DeleteMessage DELETE /api/chat/messages/:mid — мягкое удаление своего
// сообщения (ставит deleted_at; содержимое перестаёт показываться, факт
// удаления фиксируется).
func (h *ChatHandler) DeleteMessage(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	mid, err := strconv.ParseInt(c.Params("mid"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var docID int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		tag, err := tx.Exec(c.Context(), `
			UPDATE chat_messages SET deleted_at = now()
			WHERE id = $1 AND author_id = $2 AND deleted_at IS NULL`, mid, userID)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return tx.QueryRow(c.Context(), `SELECT document_id FROM chat_messages WHERE id=$1`, mid).Scan(&docID)
	})
	if txErr != nil {
		if txErr == pgx.ErrNoRows {
			return fiber.NewError(fiber.StatusForbidden, "можно удалить только своё сообщение")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить сообщение")
	}
	if docID != 0 {
		h.hub.Broadcast(fmt.Sprintf("doc:%d", docID), fiber.Map{"type": "chat_updated", "document_id": docID})
	}
	return c.SendStatus(fiber.StatusOK)
}
