package service

import "testing"

// Требование: не менее 8 знаков и не менее 3 групп символов. Проверка
// закреплена тестом, потому что это правило про безопасность: ослабить его
// случайной правкой нельзя незаметно.
//
// Запуск: go test ./internal/service/ -run TestValidatePassword
func TestValidatePassword(t *testing.T) {
	ok := []struct{ pw, why string }{
		{"Parol123", "8 знаков, 3 группы (строчные, заглавные, цифры)"},
		{"parol12!", "8 знаков, 3 группы (строчные, цифры, знаки)"},
		{"Пароль12", "по-русски: строчные, заглавные, цифры — буквы считаются по Unicode"},
		{"ПАРОЛЬ12!", "заглавные, цифры, знаки"},
		{"aA1!aA1!", "все четыре группы"},
		{"парольный пароль 1A", "пробел считается знаком"},
	}
	for _, c := range ok {
		if err := ValidatePassword(c.pw); err != nil {
			t.Errorf("пароль %q должен быть принят (%s), но отклонён: %v", c.pw, c.why, err)
		}
	}

	bad := []struct{ pw, why string }{
		{"", "пустой"},
		{"Parol1", "6 знаков — коротко, хотя групп три"},
		{"Parol1!", "7 знаков — на один меньше предела"},
		{"parolparol", "длинный, но одна группа"},
		{"parol1234", "две группы: строчные и цифры"},
		{"PAROL1234", "две группы: заглавные и цифры"},
		{"пароль123", "по-русски, но только две группы"},
		{"12345678", "только цифры"},
		{"!!!!!!!!", "только знаки"},
	}
	for _, c := range bad {
		if err := ValidatePassword(c.pw); err == nil {
			t.Errorf("пароль %q должен быть отклонён (%s), но принят", c.pw, c.why)
		}
	}
}

// Сообщение обязано объяснять, ЧТО не так: иначе человек подбирает пароль
// наугад. Проверяем, что в тексте есть и число, и перечень групп.
func TestValidatePasswordMessageExplains(t *testing.T) {
	err := ValidatePassword("parol")
	if err == nil {
		t.Fatal("короткий пароль принят")
	}
	msg := err.Error()
	for _, want := range []string{"8", "знаков"} {
		if !contains(msg, want) {
			t.Errorf("в сообщении о коротком пароле нет %q: %s", want, msg)
		}
	}

	err = ValidatePassword("parolparol")
	if err == nil {
		t.Fatal("пароль из одной группы принят")
	}
	msg = err.Error()
	for _, want := range []string{"групп", "цифры", "заглавные"} {
		if !contains(msg, want) {
			t.Errorf("в сообщении о группах нет %q: %s", want, msg)
		}
	}
}

func TestPasswordGroups(t *testing.T) {
	cases := []struct {
		pw   string
		want int
	}{
		{"", 0},
		{"abc", 1},
		{"abcABC", 2},
		{"abcABC123", 3},
		{"abcABC123!", 4},
		{"АБВабв1!", 4},
	}
	for _, c := range cases {
		if got := len(PasswordGroups(c.pw)); got != c.want {
			t.Errorf("PasswordGroups(%q) = %d групп, ожидалось %d", c.pw, got, c.want)
		}
	}
}

func contains(s, sub string) bool {
	return len(sub) == 0 || (len(s) >= len(sub) && indexOf(s, sub) >= 0)
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
