import React, { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { animate as animeAnimate } from 'animejs'
import { spring, prefersReducedMotion } from '../motion'
import Icon from '../components/Icon'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import { playEventSound, primeAudio, loadSoundSettings, saveSoundSettings } from '../lib/sound'
import { fmtDateTime } from '../utils/format'
import { usePreference } from '../lib/usePreference'
import { startLeaderElection, isLeader, onLeaderChange, emitBus, onBus } from '../lib/tabSync'

// Рубрика уведомления — короткая метка, чтобы в потоке было видно «о чём».
function categoryOf(kind) {
  if (kind === 'chat_message') return 'Сообщение'
  if (kind.startsWith('execution') || kind === 'document_executed') return 'Исполнение'
  if (kind.startsWith('resolution')) return 'Резолюция'
  if (kind.startsWith('stage_') || kind === 'approver_added' || kind === 'route_restarted') return 'Согласование'
  if (kind === 'document_signed') return 'Подпись'
  if (kind === 'document_sent' || kind === 'document_sent_info') return 'Рассылка'
  if (kind === 'acquaintance' || kind === 'acquainted') return 'Ознакомление'
  if (kind === 'document_archived' || kind === 'document_unarchived') return 'Архив'
  if (kind === 'due_soon' || kind === 'overdue') return 'Срок'
  if (kind === 'control_assigned') return 'Контроль'
  return 'Документ'
}

const PANEL_MIN_W = 300
const PANEL_MIN_H = 200

// #7 — Текст уведомления приходит с сервера готовым (поле `text`), в едином
// виде «Иванов Иван оставил комментарий «выполнено» в документе «Подать
// сведения»». Раньше он собирался здесь по одному полю `kind`, поэтому был
// безликим: без автора, без самого комментария, без названия документа.
//
// Карта ниже оставлена ТОЛЬКО как запасной вариант для уведомлений, пришедших
// от бэкенда старой версии (во время обновления), и для неизвестных видов.
const KIND_LABELS = {
  stage_pending: 'Требуется ваше решение по документу',
  stage_approved: 'Документ согласован',
  stage_rejected: 'Документ отклонён',
  document_signed: 'Документ подписан',
  document_sent: 'Вам направлен документ',
  assignment: 'Вам дано поручение',
  assignment_status_changed: 'Изменён статус поручения',
  //, п. 3 — резолюции.
  resolution: 'Вам наложена резолюция',
  resolution_reported: 'Представлен отчёт по вашей резолюции',
  resolution_accepted: 'Ваш отчёт по резолюции принят',
  resolution_returned: 'Отчёт по резолюции возвращён на доработку',
  resolution_reassigned: 'Переназначен исполнитель резолюции',
  control_assigned: 'Вы назначены контролёром',
  acquaintance: 'Вас ознакомили с документом',
  acquainted: 'Ознакомление с документом',
  chat_message: 'Новое сообщение в обсуждении',
  execution_done: 'Поставлена отметка об исполнении',
  document_executed: 'Документ исполнен',
  execution_changed: 'Изменён отчёт об исполнении',
  execution_cancelled: 'Отметка об исполнении отменена',
  document_archived: 'Документ в архиве',
  due_soon: 'Приближается срок',
  overdue: 'Просрочен срок',
}

// Короткий звук уведомления через WebAudio — не тянем аудиофайл, генерируем
// «бип» программно. Звук включается пользователем (кнопка), т.к. браузеры
// Старый одиночный beep заменён на модуль lib/sound.js: тоны различаются по
// категории события, настройки хранятся в localStorage и разблокируются на
// первом жесте (primeAudio).

export default function NotificationsBell() {
  const [open, setOpen] = useState(false)
  const [items, setItems] = useState([])
  const [unread, setUnread] = useState(0)
  // Настройки звука — на сервере (ui.sound); локальная копия нужна модулю
  // звука, который читает её в момент сигнала.
  const [sound, setSound] = usePreference('ui.sound', loadSoundSettings())
  useEffect(() => { saveSoundSettings(sound) }, [sound])
  const soundOn = sound.enabled
  const navigate = useNavigate()
  const ref = useRef(null)
  // Размер панели — настройка пользователя: хранится на сервере и переживает
  // перезагрузку (ключ ui.notif_panel).
  const [panel, setPanel] = usePreference('ui.notif_panel', { w: 340, h: 420 })
  const [dragSize, setDragSize] = useState(null)
  // «Сбросить размер» из настроек: у модалки и колокола разные экземпляры
  // настройки, поэтому команда приходит событием окна.
  useEffect(() => {
    const reset = () => { setDragSize(null); setPanel({ w: 340, h: 420 }) }
    window.addEventListener('athena:notif_panel_reset', reset)
    return () => window.removeEventListener('athena:notif_panel_reset', reset)
  }, [setPanel])
  const [leader, setLeaderState] = useState(isLeader())

  const wsRef = useRef(null)
  // Колокольчик качается, когда число непрочитанных ВЫРОСЛО (anime.js). На
  // первой загрузке и при уменьшении (прочитал) не звенит: движение здесь —
  // сигнал «пришло новое», а не украшение.
  const bellRef = useRef(null)
  const prevUnread = useRef(null)

  const load = useCallback(async () => {
    try {
      const res = await api.getNotifications({ limit: 50 })
      setItems(prev => JSON.stringify(prev) === JSON.stringify(res.items || []) ? prev : res.items || [])
      setUnread(res.unread_count || 0)
    } catch (_) {
      /* ignore */
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  // Несколько вкладок одного пользователя: WebSocket держит только вкладка-
  // лидер и ретранслирует сообщения остальным (см. lib/tabSync). Иначе каждая
  // вкладка получала бы своё уведомление и играла бы звук.
  useEffect(() => {
    startLeaderElection()
    setLeaderState(isLeader())
    return onLeaderChange(setLeaderState)
  }, [])

  // Разбор сообщения WS — общий для лидера и для вкладок, получивших его по
  // каналу. Звук играет только лидер.
  const handleMsg = useCallback((msg, fromBus) => {
    if (msg.type === 'notification') {
      load()
      if (!fromBus) playEventSound(msg.kind || 'notification')
      // #2 — сообщаем модалке-будильнику, что пора перечитать свою выборку.
      window.dispatchEvent(new CustomEvent('athena:notification', { detail: msg }))
    }
    // #16 — живое обновление списков и вкладок.
    if (msg.type === 'document_changed') {
      window.dispatchEvent(new CustomEvent('athena:document_changed', { detail: msg }))
    }
  }, [load])

  // Не лидер получает сообщения по каналу.
  useEffect(() => onBus('ws', (msg) => handleMsg(msg, true)), [handleMsg])
  // Прочитано в другой вкладке — перечитываем список.
  useEffect(() => onBus('notif_read', () => load()), [load])

  // WS с авто-переподключением (только у лидера): после каждого
  // (пере)подключения делаем refetch — БД источник истины, WS — ускоритель.
  useEffect(() => {
    if (!leader) return undefined
    let closedByUs = false
    let retry = 0
    let reconnectTimer = null

    function connect() {
      let ws
      try {
        ws = new WebSocket(api.wsNotificationsURL())
      } catch (_) {
        scheduleReconnect()
        return
      }
      wsRef.current = ws

      ws.onopen = () => {
        retry = 0
        load()
      }
      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data)
          handleMsg(msg, false)
          emitBus('ws', msg)
        } catch (_) {
          /* ignore */
        }
      }
      ws.onclose = () => {
        if (!closedByUs) scheduleReconnect()
      }
      ws.onerror = () => {
        try { ws.close() } catch (_) { /* noop */ }
      }
    }

    function scheduleReconnect() {
      retry += 1
      const delay = Math.min(30000, 1000 * 2 ** Math.min(retry, 5)) // 2с..30с
      reconnectTimer = setTimeout(connect, delay)
    }

    function onFocus() {
      load()
      const s = wsRef.current
      if (!s || s.readyState === WebSocket.CLOSED || s.readyState === WebSocket.CLOSING) {
        clearTimeout(reconnectTimer)
        connect()
      }
    }

    connect()
    window.addEventListener('focus', onFocus)
    window.addEventListener('online', onFocus)

    return () => {
      closedByUs = true
      clearTimeout(reconnectTimer)
      window.removeEventListener('focus', onFocus)
      window.removeEventListener('online', onFocus)
      try { wsRef.current && wsRef.current.close() } catch (_) { /* noop */ }
    }
  }, [leader, load, handleMsg])

  // Фокус вкладки-не-лидера: список уведомлений подтягиваем сами.
  useEffect(() => {
    if (leader) return undefined
    const f = () => load()
    window.addEventListener('focus', f)
    return () => window.removeEventListener('focus', f)
  }, [leader, load])

  useEffect(() => {
    function onClick(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClick)
    return () => document.removeEventListener('mousedown', onClick)
  }, [])

  // #8 — Три независимых действия над уведомлением: прочитать одно, прочитать
  // все, открыть документ. Раньше действие было одно (клик = прочитать И
  // перейти), поэтому отметить прочитанным, не уходя со страницы, было нельзя.
  const markOne = useCallback(async (it) => {
    if (it.is_read) return
    try {
      await api.markNotificationRead(it.id)
      emitBus('notif_read', {})
      setUnread((u) => Math.max(0, u - 1))
      setItems((arr) => arr.map((x) => (x.id === it.id ? { ...x, is_read: true } : x)))
    } catch (_) {
      /* ignore */
    }
  }, [])

  async function onItemClick(it) {
    await markOne(it)
    if (it.document_id) {
      setOpen(false)
      navigate(`/document/${it.document_id}`)
    }
  }

  async function markAll() {
    try {
      await api.markAllNotificationsRead()
      emitBus('notif_read', {})
      setUnread(0)
      setItems((arr) => arr.map((x) => ({ ...x, is_read: true })))
    } catch (_) {
      /* ignore */
    }
  }

  function toggleSound() {
    const next = { ...sound, enabled: !sound.enabled }
    setSound(next)
    if (next.enabled) playEventSound('notification') // подтверждаем и разблокируем WebAudio
  }

  // Разблокировать звук на первом жесте (события приходят по сети, не из клика).
  useEffect(() => { primeAudio() }, [])

  useEffect(() => {
    const before = prevUnread.current
    prevUnread.current = unread
    if (before === null || unread <= before || !bellRef.current || prefersReducedMotion()) return undefined
    const a = animeAnimate(bellRef.current, {
      rotate: [0, 16, -14, 10, -7, 3, 0],
      duration: 900,
      ease: 'outQuad',
    })
    return () => a.cancel()
  }, [unread])

  // Изменение размера: тянем левый нижний угол — ширина растёт влево, высота
  // вниз. Размер сохраняется по отпусканию (usePreference → сервер).
  function startResize(e) {
    e.preventDefault()
    const startX = e.clientX
    const startY = e.clientY
    const w0 = panel.w
    const h0 = panel.h
    let last = { w: w0, h: h0 }
    const onMove = (ev) => {
      const w = Math.round(Math.max(PANEL_MIN_W, Math.min(window.innerWidth - 16, w0 + (startX - ev.clientX))))
      const h = Math.round(Math.max(PANEL_MIN_H, Math.min(window.innerHeight - 80, h0 + (ev.clientY - startY))))
      last = { w, h }
      setDragSize(last)
    }
    const onUp = () => {
      window.removeEventListener('pointermove', onMove)
      window.removeEventListener('pointerup', onUp)
      setDragSize(null)
      setPanel(last)
    }
    window.addEventListener('pointermove', onMove)
    window.addEventListener('pointerup', onUp)
  }

  function fmt(ts) {
    try {
      return fmtDateTime(ts)
    } catch (_) {
      return ts
    }
  }

  return (
    <div className="relative" ref={ref}>
      <button onClick={() => setOpen((v) => !v)} className="relative px-2 py-1.5 rounded-md hover:bg-surface-alt" title="Уведомления">
        <span ref={bellRef} className="inline-block" style={{ transformOrigin: '50% 10%' }}>
          <Icon name="bell" size={18} />
        </span>
        <AnimatePresence>
          {unread > 0 && (
            <motion.span
              key={unread}
              initial={{ scale: 0.4, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.4, opacity: 0 }}
              transition={spring}
              className="absolute -top-0.5 -right-0.5 bg-danger text-white text-[10px] rounded-full min-w-4 h-4 px-1 flex items-center justify-center"
            >
              {unread > 9 ? '9+' : unread}
            </motion.span>
          )}
        </AnimatePresence>
      </button>

      <AnimatePresence>
      {open && (
        <div




          className="absolute right-0 mt-1 surface-1 shadow-lg z-30 flex flex-col"
          style={{ transformOrigin: 'top right', width: Math.min(dragSize?.w ?? panel.w, window.innerWidth - 16), height: dragSize?.h ?? panel.h, maxHeight: 'calc(100vh - 70px)' }}
        >
          <div className="flex items-center justify-between px-3 py-2 border-b border-border">
            <span className="text-sm font-medium">Уведомления</span>
            <div className="flex items-center gap-2">
              <button onClick={toggleSound} className="text-xs text-text-secondary" title="Звук уведомлений">
                <Icon name={soundOn ? 'volume-on' : 'volume-off'} size={14} />
              </button>
              <button onClick={markAll} className="text-xs text-accent">
                Прочитать все
              </button>
            </div>
          </div>
          <div className="flex-1 min-h-0 overflow-auto">
            {items.length === 0 && <div className="px-3 py-6 text-center text-text-secondary text-sm">Нет уведомлений</div>}
            {items.map((it) => (
              <div
                key={it.id}
                style={{ opacity: it.is_read ? 0.65 : 1 }}



                className="px-3 py-2 border-b border-border last:border-0"
              >
                <div className="flex items-start gap-2">
                  {!it.is_read && <span className="mt-1.5 w-2 h-2 rounded-full bg-accent shrink-0" />}
                  <div className="flex-1 min-w-0">
                    {/* Готовый единый текст с сервера (#7). KIND_LABELS — только
                        запас для бэкенда старой версии. */}
                    <div className="text-[10px] uppercase tracking-wide text-text-secondary mb-0.5">
                      {categoryOf(it.kind || '')}
                    </div>
                    <div className="text-sm break-words">
                      {it.text || KIND_LABELS[it.kind] || 'Обновление по документу'}
                    </div>
                    <div className="text-[10px] text-text-secondary mt-0.5">{fmt(it.created_at)}</div>
                    {/* #8/#18 — явные действия, а не один клик «прочитать и уйти» */}
                    <div className="flex items-center gap-2 mt-1">
                      {it.document_id && (
                        <button onClick={() => onItemClick(it)} className="text-xs text-accent">
                          Открыть документ
                        </button>
                      )}
                      {!it.is_read && (
                        <button onClick={() => markOne(it)} className="text-xs text-text-secondary hover:text-text">
                          Прочитать
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          {/* Ручка изменения размера (левый нижний угол: панель прижата вправо) */}
          <div
            onPointerDown={startResize}
            title="Потяните, чтобы изменить размер"
            className="absolute left-0 bottom-0 w-4 h-4 cursor-nesw-resize text-text-secondary"
            style={{ touchAction: 'none' }}
          >
            <svg viewBox="0 0 16 16" width="16" height="16" aria-hidden="true">
              <path d="M2 14L14 2M2 9L9 2M2 4L4 2" stroke="currentColor" strokeWidth="1.2" fill="none" opacity="0.6" />
            </svg>
          </div>
        </div>
      )}
      </AnimatePresence>
    </div>
  )
}
