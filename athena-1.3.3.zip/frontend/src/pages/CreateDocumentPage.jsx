import { useAuth } from '../context/AuthContext'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api/client'
import FilePreview from '../components/FilePreview'
import RouteBuilder, { normalizeSteps } from '../components/RouteBuilder'
import PersonPicker from '../components/PersonPicker'
import RecipientGroupPicker from '../components/RecipientGroupPicker'
import { useMaxPdfBytes, fmtSize, checkPdf } from '../lib/pdfLimit'
import DuplicateWarning from '../components/DuplicateWarning'


export default function CreateDocumentPage() {
  const navigate = useNavigate()

  const [title, setTitle] = useState('')
  const [categoryId, setCategoryId] = useState('') // #6 — обязательная категория
  // #26 — особая отметка. В отличие от категории НЕ обязательна: отметка есть
  // не у каждого документа, и заставлять выбирать «Без особой отметки» на
  // форме незачем.
  const [specialMarkId, setSpecialMarkId] = useState('')
  const [specialMarks, setSpecialMarks] = useState([])
  const [categories, setCategories] = useState([])
  // #2 — «Готовность»: дата обязательна, время НЕОБЯЗАТЕЛЬНО и выбирается
  // (input type=time). Если время не задано — не подставляем ничего.
  const [dueDate, setDueDate] = useState('')
  const [dueTime, setDueTime] = useState('')
  const [file, setFile] = useState(null)
  //, п. 3 — предел размера PDF и текст отказа при превышении.
  const [fileError, setFileError] = useState('')
  const maxPdfBytes = useMaxPdfBytes()
  // Реквизиты отправителя (корреспондент, его исходящий номер, дата его
  // документа) убраны по требованию заказчика. Вместе с ними убран и ЖЁСТКИЙ
  // запрет повторной регистрации по этой тройке: сравнивать стало нечего, и
  // блокировать кнопку больше не на чем.
  //
  // Что осталось: предупреждение о похожих документах — по содержимому файла
  // (совпадение контрольной суммы) и по описанию. Оно НЕ запрещает
  // регистрацию: один и тот же файл законно приходит повторно (напоминание,
  // рассылка нескольким адресатам), и жёсткий запрет здесь остановил бы
  // работу. Независимый барьер по входящему номеру подразделения при этом
  // продолжает действовать на уровне БД.

  // Единый упорядоченный маршрут согласования (тип у каждого + порядок).
  const [approvers, setApprovers] = useState([])
  const [skipApproval, setSkipApproval] = useState(false)
  const [signer, setSigner] = useState([]) // #3 — один или несколько подписантов
  const [recipients, setRecipients] = useState([]) // плановые адресаты рассылки
  const [onControl, setOnControl] = useState(false)
  const [controller, setController] = useState([]) // #4 — несколько контролёров

  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  // #3 — При наличии контролёров «по умолчанию» предвыбираем их и ставим
  // галочку «на контроле». Автор может снять галочку или изменить набор —
  // контролёр добавляется только с его явной санкции (постановка выполняется
  // после создания вызовом setControl).
  useEffect(() => {
    api.listCategories().then((r) => {
      const items = r.items || []
      setCategories(items)
      if (items.length && !categoryId) setCategoryId(String(items[0].id))
    }).catch(() => {})
    // #26 — справочник особых отметок
    api.getSpecialMarks()
      .then((r) => {
        const items = r.items || []
        setSpecialMarks(items)
        // Предвыбираем значение по умолчанию: без отметки документ создать
        // нельзя, поэтому форма не должна открываться с пустым полем.
        setSpecialMarkId((cur) => {
          if (cur) return cur
          const def = items.find((m) => m.is_default && m.is_active)
          const first = items.find((m) => m.is_active)
          return String((def || first || {}).id || '')
        })
      })
      .catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    let cancelled = false
    api.getDefaultControllers().then((r) => {
      if (cancelled) return
      const items = r.items || []
      if (items.length > 0) {
        setController(items.map((u) => ({
          id: u.id, full_name: u.full_name, position: u.position,
          department_id: u.department_id, department_name: u.department_name, city: u.city,
        })))
        setOnControl(true)
      }
    }).catch(() => {})
    return () => { cancelled = true }
  }, [])

  // ПОЧЕМУ ЗДЕСЬ useMemo, А НЕ ПРОСТО ВЫРАЖЕНИЕ.
  //
  // При вводе каждой буквы в любом текстовом поле React перерисовывает всю
  // форму. Сама перерисовка дешёвая, но тяжёлыми были дети: выбор людей,
  // построитель маршрута, выбор групп адресатов и предпросмотр PDF. Они
  // перерисовывались вместе с формой, потому что получали НОВЫЕ объекты в
  // свойствах: `[currentUserId].filter(Boolean)` — это новый массив на каждой
  // перерисовке, и React.memo на таком свойстве бесполезен.
  //
  // Теперь разбор токена и список исключаемых считаются один раз, сами
  // компоненты обёрнуты в React.memo, а обработчики — это setState из
  // useState, у которых ссылка не меняется. В итоге нажатие в поле
  // «Описание» перерисовывает только поле.
  const { userId: currentUserId } = useAuth()

  // Один массив на все четыре места, где раньше создавался свой.
  const excludeSelf = React.useMemo(
    () => [currentUserId].filter(Boolean),
    [currentUserId],
  )
  const excludeForApprovers = excludeSelf

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')

    if (!file) {
      setError('Прикрепите PDF-файл документа')
      return
    }
    if (!categoryId) {
      setError('Выберите категорию документа')
      return
    }
    if (signer.length === 0) {
      setError('Выберите хотя бы одного подписанта — подпись обязательна')
      return
    }

    // Порядок в approvers = очерёдность. Бэкенд строит зависимости по этому
    // порядку, если включено последовательное согласование.
    const approversPayload = skipApproval
      ? []
      : normalizeSteps(approvers).map((a) => ({ stage_type: a.stage_type, approver_id: a.id, step: a.step }))

    const route = {
      approvers: approversPayload,
      signer_ids: signer.map((s) => s.id), // #3 — мультиподпись
    }

    const formData = new FormData()
    formData.append('title', title)
    formData.append('category_id', categoryId)
    // #26 — пустое значение не отправляем: бэкенд трактует отсутствие как
    // «без особой отметки» (NULLIF), и отправлять '0' незачем.
    // Отметка обязательна — отправляем всегда.
    formData.append('special_mark_id', specialMarkId || '')
    if (dueDate) {
      // #2 — «Готовность»: дата обязательна, время НЕОБЯЗАТЕЛЬНО. Если время
      // не задано — НЕ подставляем ничего (шлём только дату, due_datetime не
      // отправляем), чтобы нигде не выводилось искусственное время.
      formData.append('due_date', dueDate)
      if (dueTime) {
        formData.append('due_datetime', new Date(`${dueDate}T${dueTime}`).toISOString())
      }
    }
    formData.append('route', JSON.stringify(route))
    // Плановые адресаты рассылки: применятся автоматически после подписи.
    if (recipients.length > 0) {
      formData.append(
        'recipients',
        JSON.stringify(recipients.map((r) => ({ user_id: r.id, department_id: r.department_id }))),
      )
    }
    // Реквизиты отправителя (, п. 6). Пустые не отправляем:
    // NULLIF на сервере всё равно превратит их в NULL, а частичный уникальный
    // индекс по тройке реквизитов применяется только когда заполнены все три.
    formData.append('file', file)

    setSubmitting(true)
    try {
      const res = await api.createDocument(formData)
      // Постановка на контроль сразу при создании (если задано автором).
      if (onControl) {
        try {
          await api.setControl(res.id, true, controller.map((c) => c.id))
        } catch (_) {
          /* контроль вторичен — не блокируем переход */
        }
      }
      navigate(`/document/${res.id}`)
    } catch (err) {
      setError(err.message || 'Не удалось создать документ')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="font-display text-xl font-semibold mb-4">Новый документ</h1>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="surface-1 p-4 space-y-3">
          <div>
            <label className="block text-sm mb-1">Описание <span className="text-danger">*</span></label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Категория <span className="text-danger">*</span></label>
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md border border-border bg-surface-alt"
            >
              <option value="" disabled>— выберите категорию —</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          {/* Особая отметка ОБЯЗАТЕЛЬНА: пустого варианта нет, значение по
              умолчанию («Без особой отметки» — это тоже значение) выбирается
              само. Так у каждого документа отметка есть всегда, а в списках и
              журнале первая колонка никогда не пустует. На уровне БД это
              закреплено триггером, который подставляет значение по умолчанию
              даже если запрос пришёл мимо формы. */}
          <div>
            <label className="block text-sm mb-1">
              Особая отметка <span className="text-danger">*</span>
            </label>
            <select
              value={specialMarkId}
              onChange={(e) => setSpecialMarkId(e.target.value)}
              required
              className="field w-full"
            >
              {specialMarks.filter((m) => m.is_active).map((m) => (
                <option key={m.id} value={m.id}>{m.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 gap-3">
            <div>
              <label className="block text-sm mb-1">Готовность</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-md border border-border bg-surface-alt"
                />
                <input
                  type="time"
                  value={dueTime}
                  onChange={(e) => setDueTime(e.target.value)}
                  disabled={!dueDate}
                  title="Время (необязательно)"
                  className="w-28 px-2 py-2 rounded-md border border-border bg-surface-alt disabled:opacity-50"
                />
              </div>
              <p className="text-[11px] text-text-secondary mt-1">Время указывать необязательно.</p>
            </div>
          </div>

          {/* Предупреждение о похожих документах (реквизиты отправителя убраны, предупреждение осталось). Стоит
              ПОСЛЕ выбора файла, потому что главный признак совпадения —
              контрольная сумма самого файла. */}
          <div className="sm:col-span-2">
            <DuplicateWarning title={title} file={file} />
          </div>

          <div>
            <label className="block text-sm mb-1">
              Файл документа (только PDF) <span className="text-danger">*</span>
              {/*, п. 3 — предел назван ДО выбора файла. */}
              <span className="ml-2 text-[11px] font-normal text-text-secondary">
                не более {fmtSize(maxPdfBytes)}
              </span>
            </label>
            <input
              type="file"
              accept="application/pdf"
              onChange={(e) => {
                const f = e.target.files?.[0] || null
                const err = checkPdf(f, maxPdfBytes)
                if (err) {
                  // Слишком большой файл не принимаем совсем: иначе он остался
                  // бы выбранным, а отказ пришёл бы только после отправки.
                  setFileError(err)
                  setFile(null)
                  e.target.value = ''
                  return
                }
                setFileError('')
                setFile(f)
              }}
              required
              className="w-full text-sm"
            />
            {fileError && <div className="mt-1 text-xs text-danger">{fileError}</div>}
            {/* #32 — предпросмотр до сохранения: не тот файл видно сразу, а не
                после создания документа и запуска согласования. */}
            <FilePreview file={file} />
          </div>
        </div>

        {/* Согласование — единый упорядоченный маршрут */}
        <div className="surface-1 p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium text-sm">Согласование</h2>
            <label className="flex items-center gap-2 text-xs text-text-secondary">
              <input type="checkbox" checked={skipApproval} onChange={(e) => setSkipApproval(e.target.checked)} />
              Пропустить согласование (сразу на подпись)
            </label>
          </div>

          {!skipApproval && (
            <div className="space-y-3">
              <RouteBuilder value={approvers} onChange={setApprovers} excludeIds={excludeForApprovers} />
            </div>
          )}
          {skipApproval && (
            <p className="text-xs text-text-secondary">
              Согласование пропущено. Документ сразу перейдёт на подпись — используйте, если по должности
              согласование не требуется.
            </p>
          )}
        </div>

        {/* Подпись — всегда отдельно и после согласования */}
        <div className="surface-1 p-4">
          <h2 className="font-medium text-sm mb-1">Подпись <span className="text-danger">*</span></h2>
          <p className="text-xs text-text-secondary mb-2">
            Подпись обязательна и всегда выполняется после того, как согласовали все. Можно указать
            нескольких подписантов — документ подписывает любой из них (достаточно одной подписи).
            В список попадают только пользователи с правом подписи.
            {' '}Себя подписантом указать можно, если право подписи есть у вас: автор нередко сам и подписывает документ.
          </p>
          <PersonPicker
            group="signing"
            multiple
            value={signer}
            onChange={setSigner}
          />
        </div>

        {/* Рассылка — плановые адресаты, выбираются автором на этапе создания.
            Применятся автоматически после подписания документа. */}
        <div className="surface-1 p-4">
          <h2 className="font-medium text-sm mb-1">Рассылка (адресаты)</h2>
          <p className="text-xs text-text-secondary mb-2">
            Кому направить документ после подписания. Адресаты получат доступ и уведомление только
            после того, как документ будет подписан. Можно оставить пустым и направить позже.
            Можно добавить группу адресатов целиком.
          </p>
          <RecipientGroupPicker
            value={recipients}
            onChange={setRecipients}
            excludeIds={excludeSelf}
          />
          {recipients.length > 0 && (
            <div className="flex justify-end mb-1">
              <button type="button" onClick={() => setRecipients([])} className="text-xs text-danger hover:underline">
                Очистить всех
              </button>
            </div>
          )}
          <PersonPicker
            group="recipients"
            multiple
            value={recipients}
            onChange={setRecipients}
            excludeIds={excludeSelf}
          />
        </div>

        {/* Контроль */}
        <div className="surface-1 p-4">
          <label className="flex items-center gap-2 text-sm mb-1">
            <input type="checkbox" checked={onControl} onChange={(e) => setOnControl(e.target.checked)} />
            Поставить документ на контроль
          </label>
          <p className="text-xs text-text-secondary mb-2">
            Контролёры получат доступ к документу и уведомление; документ попадёт во вкладку «На контроле».
            Если заданы «контролёры по умолчанию», они предвыбраны и галочка установлена — вы можете
            изменить состав или снять контроль. Контролёров может быть несколько.
          </p>
          {onControl && (
            <div>
              <label className="block text-xs text-text-secondary mb-1">Контролёры</label>
              <PersonPicker
                group="controller"
                multiple
                value={controller}
                onChange={setController}
                excludeIds={excludeSelf}
              />
            </div>
          )}
        </div>

        {error && (
          <div className="text-danger text-sm border border-danger/40 bg-danger/5 rounded-md px-3 py-2">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="px-4 py-2 rounded-md bg-accent text-accent-contrast font-medium disabled:opacity-60"
        >
          {submitting ? 'Создание…' : 'Создать документ'}
        </button>
      </form>
    </div>
  )
}
