package scheduler

import (
	"context"
	"log"
	"time"
)

// StartStageReminders раз в час напоминает о зависших этапах согласования и
// подписи: если этап ждёт решения дольше days дней, согласующему и автору
// документа приходит уведомление — не чаще одного раза в сутки на этап.
// days < 0 — напоминания выключены.
func (s *Scheduler) StartStageReminders(ctx context.Context, days int) {
	if days < 0 {
		return
	}
	run := func() {
		// «Когда этап стал активным» отдельно не хранится; берём последнее
		// уведомление stage_pending этому согласующему по документу.
		tag, err := s.pool.Exec(ctx, `
			WITH stuck AS (
			    SELECT st.id, st.document_id, st.approver_id, d.author_id
			      FROM approval_stages st
			      JOIN documents d ON d.id = st.document_id
			     WHERE st.status = 'pending'
			       AND d.status IN ('on_approval_hierarchy','on_approval_cross_dept','on_signing')
			       AND coalesce((SELECT max(n.created_at) FROM notifications n
			                      WHERE n.document_id = st.document_id AND n.user_id = st.approver_id
			                        AND n.kind = 'stage_pending'), st.created_at) < now() - make_interval(days => $1)
			       AND NOT EXISTS (SELECT 1 FROM notifications n
			                        WHERE n.document_id = st.document_id AND n.kind = 'stage_overdue'
			                          AND n.created_at > now() - interval '24 hours')
			)
			INSERT INTO notifications (user_id, document_id, kind, payload, detail)
			SELECT u, document_id, 'stage_overdue', '{}',
			       'Документ ожидает решения дольше ' || $1 || ' дн.'
			  FROM stuck, LATERAL (VALUES (approver_id), (author_id)) AS t(u)
			 GROUP BY u, document_id`, days)
		if err != nil {
			log.Printf("напоминания о согласовании: %v", err)
			return
		}
		if n := tag.RowsAffected(); n > 0 {
			log.Printf("напоминания о согласовании: отправлено %d", n)
		}
	}
	go s.every(ctx, time.Hour, 2*time.Minute, archiveAdvisoryLockKey+1, run)
}

// StartHousekeeping раз в час убирает отслужившие служебные записи: счётчики
// неудачных входов, отметки о предъявленных билетах Kerberos, отправленные
// письма старше 30 дней, сессии, оконченные более 90 дней назад, прочитанные
// уведомления старше года.
func (s *Scheduler) StartHousekeeping(ctx context.Context) {
	run := func() {
		for _, q := range []string{
			`DELETE FROM auth_login_failures WHERE window_start < now() - interval '1 day' AND coalesce(blocked_until, now()) <= now()`,
			`DELETE FROM kerberos_seen_tokens WHERE seen_at < now() - interval '1 day'`,
			`DELETE FROM email_outbox WHERE status = 'sent' AND sent_at < now() - interval '30 days'`,
			// Сессии нужны журналу входов ещё 90 дней после окончания.
			`DELETE FROM user_sessions WHERE coalesce(revoked_at, expires_at) < now() - interval '90 days'`,
			// Прочитанные уведомления старше года никто не открывает.
			`DELETE FROM notifications WHERE is_read AND created_at < now() - interval '1 year'`,
		} {
			if _, err := s.pool.Exec(ctx, q); err != nil {
				log.Printf("обслуживание: %v", err)
			}
		}
	}
	go s.every(ctx, time.Hour, 5*time.Minute, archiveAdvisoryLockKey+2, run)
}

// every выполняет fn сразу после паузы first и далее с интервалом d. Перед
// каждым запуском берётся рекомендательная блокировка БД: при нескольких
// рабочих процессах задачу в данный момент выполняет только один.
func (s *Scheduler) every(ctx context.Context, d, first time.Duration, lockKey int64, fn func()) {
	timer := time.NewTimer(first)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			func() {
				defer func() {
					if r := recover(); r != nil {
						log.Printf("фоновая задача: сбой: %v", r)
					}
				}()
				conn, err := s.pool.Acquire(ctx)
				if err != nil {
					return
				}
				defer conn.Release()
				var got bool
				if err := conn.QueryRow(ctx, `SELECT pg_try_advisory_lock($1)`, lockKey).Scan(&got); err != nil || !got {
					return
				}
				defer conn.Exec(context.Background(), `SELECT pg_advisory_unlock($1)`, lockKey) //nolint:errcheck
				fn()
			}()
			timer.Reset(d)
		}
	}
}
