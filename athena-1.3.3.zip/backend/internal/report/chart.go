package report

import (
	"fmt"
	"math"
	"strconv"
)

// ===========================================================================
// ГРАФИКИ ДЛЯ ОТЧЁТОВ (, п. 7: «с красивыми графиками»).
//
// Графики рисуются векторными командами PDF — прямоугольниками, линиями и
// дугами. Растровых картинок нет сознательно: вектор не мылится при печати и
// при увеличении, а отчёт по дисциплине печатают и подшивают.
//
// Набор ограничен тем, что действительно нужно для дисциплины исполнения:
//   * горизонтальные полосы — сравнение подразделений или людей между собой;
//   * столбцы с накоплением — «в срок / просрочено» по месяцам;
//   * кольцо — доля исполненного в срок одним числом;
//   * линия — динамика показателя во времени.
// Больше типов не заводим: каждый лишний тип — это код, который надо
// поддерживать, а не польза для читателя отчёта.
//
// ЦВЕТ НИКОГДА НЕ ЕДИНСТВЕННЫЙ НОСИТЕЛЬ СМЫСЛА. Рядом с каждым элементом
// печатается число и подпись: отчёт распечатывают на чёрно-белом принтере, и
// «красное против зелёного» на нём неразличимо.
// ===========================================================================

// Bar — одна полоса/сегмент.
type Bar struct {
	Label string
	Value float64
	// Extra — подпись справа от значения («3 из 17»). Необязательна.
	Extra string
	Color Color
}

// HBarChart — горизонтальные полосы с подписями слева и значениями справа.
//
// Горизонтальные, а не вертикальные: подписи — это названия подразделений и
// ФИО, которые в вертикальном варианте пришлось бы поворачивать или обрезать.
func (d *Doc) HBarChart(x, width float64, bars []Bar, maxVal float64, unit string) {
	if len(bars) == 0 {
		d.Space(10)
		d.TextAt(x, d.y, "нет данных за выбранный период", 9, ColorMuted, false)
		d.Space(6)
		return
	}
	const (
		rowH     = 18.0
		labelW   = 170.0
		valueW   = 86.0
		barInset = 3.0
	)
	d.NeedSpace(float64(len(bars))*rowH + 14)

	if maxVal <= 0 {
		for _, b := range bars {
			if b.Value > maxVal {
				maxVal = b.Value
			}
		}
	}
	if maxVal <= 0 {
		maxVal = 1
	}
	plotW := width - labelW - valueW
	if plotW < 60 {
		plotW = 60
	}

	for _, b := range bars {
		d.NeedSpace(rowH)
		d.y -= rowH
		yBase := d.y + 4

		label := d.ellipsis(b.Label, 8, labelW-8)
		d.TextAt(x, yBase, label, 8, ColorText, false)

		// Подложка полосы: по ней видно, какая часть шкалы занята, даже когда
		// значение маленькое.
		d.Rect(x+labelW, yBase-2, plotW, rowH-barInset*2, ColorFill)

		w := plotW * b.Value / maxVal
		if b.Value > 0 && w < 1.5 {
			// Ненулевое значение обязано быть видно: иначе «1 из 500»
			// выглядит как ноль, и читатель делает неверный вывод.
			w = 1.5
		}
		d.Rect(x+labelW, yBase-2, w, rowH-barInset*2, b.Color)

		val := formatNum(b.Value) + unit
		if b.Extra != "" {
			val += "  " + b.Extra
		}
		d.TextRight(x+width, yBase, val, 8, ColorText, false)
	}
	d.Space(8)
}

// StackedSeries — один ряд столбца с накоплением.
type StackedSeries struct {
	Name   string
	Color  Color
	Values []float64
}

// StackedBarChart — столбцы с накоплением по категориям (обычно месяцы).
//
// Именно с накоплением, а не рядом: в дисциплине исполнения важна ДОЛЯ
// просроченного в общем объёме, а не два независимых числа. Рядом стоящие
// столбцы заставляют читателя считать долю в уме.
func (d *Doc) StackedBarChart(x, width, height float64, categories []string, series []StackedSeries) {
	if len(categories) == 0 || len(series) == 0 {
		d.Space(10)
		d.TextAt(x, d.y, "нет данных за выбранный период", 9, ColorMuted, false)
		d.Space(6)
		return
	}
	d.NeedSpace(height + 46)
	d.y -= height + 26
	baseY := d.y + 18
	plotH := height

	// Максимум суммы по категории — шкала.
	maxSum := 0.0
	for i := range categories {
		s := 0.0
		for _, ser := range series {
			if i < len(ser.Values) {
				s += ser.Values[i]
			}
		}
		if s > maxSum {
			maxSum = s
		}
	}
	if maxSum <= 0 {
		maxSum = 1
	}

	// Сетка: четыре линии с подписями значений. Без сетки столбцы можно
	// сравнить только между собой, а не с абсолютной величиной.
	const gridLines = 4
	axisW := 28.0
	plotX := x + axisW
	plotW := width - axisW
	for i := 0; i <= gridLines; i++ {
		gy := baseY + plotH*float64(i)/gridLines
		d.Line(plotX, gy, x+width, gy, 0.4, ColorLine)
		d.TextRight(plotX-4, gy-2.5, formatNum(maxSum*float64(i)/gridLines), 6.5, ColorMuted, false)
	}

	slot := plotW / float64(len(categories))
	barW := slot * 0.56
	if barW > 34 {
		barW = 34
	}
	for i, cat := range categories {
		cx := plotX + slot*float64(i) + slot/2 - barW/2
		yCur := baseY
		for _, ser := range series {
			if i >= len(ser.Values) || ser.Values[i] <= 0 {
				continue
			}
			h := plotH * ser.Values[i] / maxSum
			d.Rect(cx, yCur, barW, h, ser.Color)
			yCur += h
		}
		d.TextCenter(cx, cx+barW, baseY-10, d.ellipsis(cat, 6.5, slot), 6.5, ColorMuted, false)
	}

	d.y = baseY - 18
	d.Legend(x, series)
}

// Legend — условные обозначения рядов.
func (d *Doc) Legend(x float64, series []StackedSeries) {
	d.NeedSpace(14)
	d.y -= 12
	cx := x
	for _, s := range series {
		d.Rect(cx, d.y-1, 7, 7, s.Color)
		d.TextAt(cx+10, d.y, s.Name, 7.5, ColorMuted, false)
		cx += 10 + d.Width(s.Name, 7.5) + 18
	}
	d.Space(6)
}

// Donut — кольцевая диаграмма с крупным числом в центре.
//
// Кольцо, а не круг: в центре помещается главное число отчёта, и читатель
// видит его сразу, не разбирая секторы.
func (d *Doc) Donut(cx, cy, rOuter, rInner float64, parts []Bar, center, caption string) {
	total := 0.0
	for _, p := range parts {
		total += p.Value
	}
	if total <= 0 {
		d.Rect(cx-rOuter, cy-rOuter, rOuter*2, rOuter*2, ColorFill)
		d.TextCenter(cx-rOuter, cx+rOuter, cy, "нет данных", 8, ColorMuted, false)
		return
	}
	start := math.Pi / 2 // начинаем сверху и идём по часовой стрелке
	for _, p := range parts {
		if p.Value <= 0 {
			continue
		}
		sweep := 2 * math.Pi * p.Value / total
		d.arcSegment(cx, cy, rInner, rOuter, start, start-sweep, p.Color)
		start -= sweep
	}
	if center != "" {
		d.TextCenter(cx-rInner, cx+rInner, cy-1, center, 16, ColorText, true)
	}
	if caption != "" {
		d.TextCenter(cx-rOuter, cx+rOuter, cy-rOuter-12, caption, 7.5, ColorMuted, false)
	}
}

// arcSegment рисует сегмент кольца.
//
// Дуга приближается кубическими кривыми Безье по 30° — PDF не умеет рисовать
// дугу напрямую. 30° даёт отклонение меньше тысячной доли радиуса, то есть на
// печати неотличимо от настоящей окружности.
func (d *Doc) arcSegment(cx, cy, rIn, rOut, a0, a1 float64, c Color) {
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f rg\n", c.R, c.G, c.B)
	fmt.Fprintf(d.cur, "%.2f %.2f m\n", cx+rOut*math.Cos(a0), cy+rOut*math.Sin(a0))
	d.arcTo(cx, cy, rOut, a0, a1)
	fmt.Fprintf(d.cur, "%.2f %.2f l\n", cx+rIn*math.Cos(a1), cy+rIn*math.Sin(a1))
	d.arcTo(cx, cy, rIn, a1, a0)
	fmt.Fprint(d.cur, "h f Q\n")
}

func (d *Doc) arcTo(cx, cy, r, a0, a1 float64) {
	const maxStep = math.Pi / 6
	delta := a1 - a0
	steps := int(math.Ceil(math.Abs(delta)/maxStep)) + 1
	step := delta / float64(steps)
	for i := 0; i < steps; i++ {
		s := a0 + step*float64(i)
		e := s + step
		// Коэффициент контрольной точки для дуги угла step.
		k := 4.0 / 3.0 * math.Tan((e-s)/4)
		x1, y1 := cx+r*math.Cos(s), cy+r*math.Sin(s)
		x4, y4 := cx+r*math.Cos(e), cy+r*math.Sin(e)
		x2, y2 := x1-k*r*math.Sin(s), y1+k*r*math.Cos(s)
		x3, y3 := x4+k*r*math.Sin(e), y4-k*r*math.Cos(e)
		fmt.Fprintf(d.cur, "%.2f %.2f %.2f %.2f %.2f %.2f c\n", x2, y2, x3, y3, x4, y4)
	}
}

// LineChart — динамика показателя во времени.
func (d *Doc) LineChart(x, width, height float64, categories []string, values []float64,
	c Color, unit string) {
	if len(values) == 0 {
		d.Space(10)
		d.TextAt(x, d.y, "нет данных за выбранный период", 9, ColorMuted, false)
		d.Space(6)
		return
	}
	d.NeedSpace(height + 40)
	d.y -= height + 24
	baseY := d.y + 16

	maxV := 0.0
	for _, v := range values {
		if v > maxV {
			maxV = v
		}
	}
	if maxV <= 0 {
		maxV = 1
	}
	axisW := 28.0
	plotX := x + axisW
	plotW := width - axisW
	for i := 0; i <= 4; i++ {
		gy := baseY + height*float64(i)/4
		d.Line(plotX, gy, x+width, gy, 0.4, ColorLine)
		d.TextRight(plotX-4, gy-2.5, formatNum(maxV*float64(i)/4)+unit, 6.5, ColorMuted, false)
	}

	stepX := plotW
	if len(values) > 1 {
		stepX = plotW / float64(len(values)-1)
	}
	fmt.Fprintf(d.cur, "q %.3f %.3f %.3f RG 1.4 w\n", c.R, c.G, c.B)
	for i, v := range values {
		px := plotX + stepX*float64(i)
		py := baseY + height*v/maxV
		if i == 0 {
			fmt.Fprintf(d.cur, "%.2f %.2f m\n", px, py)
		} else {
			fmt.Fprintf(d.cur, "%.2f %.2f l\n", px, py)
		}
	}
	fmt.Fprint(d.cur, "S Q\n")

	// Точки и подписи категорий.
	for i, v := range values {
		px := plotX + stepX*float64(i)
		py := baseY + height*v/maxV
		d.Rect(px-1.8, py-1.8, 3.6, 3.6, c)
		if i < len(categories) {
			d.TextCenter(px-stepX/2, px+stepX/2, baseY-10,
				d.ellipsis(categories[i], 6.5, stepX), 6.5, ColorMuted, false)
		}
	}
	d.y = baseY - 16
	d.Space(4)
}

// KPI — крупная плашка с числом и подписью.
//
// Нужна в начале отчёта: руководитель должен увидеть главные цифры, не читая
// таблиц. Цвет плашки задаётся вызывающим кодом по смыслу значения.
func (d *Doc) KPI(x, y, w, h float64, value, label, hint string, accent Color) {
	d.Rect(x, y, w, h, ColorFill)
	// Цветная полоса слева — акцент, который виден и на чёрно-белой печати
	// как более тёмный край.
	d.Rect(x, y, 3, h, accent)
	d.TextAt(x+12, y+h-20, value, 17, accent, true)
	d.TextAt(x+12, y+h-34, label, 8, ColorText, false)
	if hint != "" {
		d.TextAt(x+12, y+8, hint, 6.5, ColorMuted, false)
	}
}

// Table — простая таблица с заголовком и выравниванием колонок.
//
// Ширины колонок задаёт вызывающий код: автоподбор по содержимому дал бы
// «пляшущие» колонки между страницами отчёта.
type Table struct {
	Headers []string
	Widths  []float64
	// Align: 'l' | 'r' | 'c' по колонкам. Пусто — всё влево.
	Align []byte
	Rows  [][]string
	// RowColor — необязательная подсветка строки (например, просрочка).
	RowColor func(i int) (Color, bool)
}

func (d *Doc) Table(x float64, t Table) {
	const (
		headH = 18.0
		rowH  = 15.0
		lineH = 9.5
		pad   = 5.0
	)
	total := 0.0
	for _, w := range t.Widths {
		total += w
	}

	drawHead := func() {
		d.NeedSpace(headH + rowH)
		d.y -= headH
		d.Rect(x, d.y, total, headH, ColorFill)
		cx := x
		for i, h := range t.Headers {
			d.TextAt(cx+pad, d.y+5.5, d.ellipsis(h, 7.5, t.Widths[i]-2*pad), 7.5, ColorText, true)
			cx += t.Widths[i]
		}
	}
	drawHead()

	for ri, row := range t.Rows {
		cells := make([][]string, len(t.Widths))
		lines := 1
		for ci, cell := range row {
			if ci >= len(cells) {
				break
			}
			cells[ci] = d.wrapText(cell, 7.5, t.Widths[ci]-2*pad)
			if len(cells[ci]) > lines {
				lines = len(cells[ci])
			}
		}
		for start := 0; start < lines; {
			room := int((d.y - marginY - 10 - 6) / lineH)
			if room < 1 || (start == 0 && lines > room && float64(lines)*lineH+6 < A4Height-2*marginY-headH-45) {
				d.AddPage()
				drawHead()
				room = int((d.y - marginY - 10 - 6) / lineH)
			}
			count := min(room, lines-start)
			h := float64(count)*lineH + 6
			d.y -= h
			if t.RowColor != nil {
				if c, ok := t.RowColor(ri); ok {
					d.Rect(x, d.y, total, h, c)
				}
			}
			cx := x
			for ci, parts := range cells {
				w := t.Widths[ci]
				for li := start; li < min(start+count, len(parts)); li++ {
					ty := d.y + h - 10.5 - float64(li-start)*lineH
					txt := parts[li]
					switch {
					case ci < len(t.Align) && t.Align[ci] == 'r':
						d.TextRight(cx+w-pad, ty, txt, 7.5, ColorText, false)
					case ci < len(t.Align) && t.Align[ci] == 'c':
						d.TextCenter(cx, cx+w, ty, txt, 7.5, ColorText, false)
					default:
						d.TextAt(cx+pad, ty, txt, 7.5, ColorText, false)
					}
				}
				cx += w
			}
			start += count
			d.Line(x, d.y, x+total, d.y, 0.3, ColorLine)
		}
	}
	d.Space(10)
}

// ellipsis обрезает строку по ширине, добавляя многоточие.
//
// Обрезка, а не перенос: в ячейке таблицы и в подписи графика перенос сломал
// бы сетку. Многоточие показывает, что текст сокращён, — иначе читатель
// решит, что название подразделения такое и есть.
func (d *Doc) ellipsis(s string, size, maxW float64) string {
	if maxW <= 0 || d.Width(s, size) <= maxW {
		return s
	}
	runes := []rune(s)
	for len(runes) > 1 {
		runes = runes[:len(runes)-1]
		if d.Width(string(runes)+"…", size) <= maxW {
			return string(runes) + "…"
		}
	}
	return "…"
}

// formatNum — число для подписи: целые без дробной части, дробные с одним
// знаком и запятой (русская типографика).
func formatNum(v float64) string {
	if v == math.Trunc(v) && math.Abs(v) < 1e9 {
		return strconv.FormatInt(int64(v), 10)
	}
	s := strconv.FormatFloat(v, 'f', 1, 64)
	return replaceDot(s)
}

// Percent — доля в процентах для подписей.
func Percent(part, total float64) string {
	if total <= 0 {
		return "—"
	}
	return replaceDot(strconv.FormatFloat(part*100/total, 'f', 1, 64)) + " %"
}

func replaceDot(s string) string {
	b := []byte(s)
	for i := range b {
		if b[i] == '.' {
			return string(b[:i]) + "," + string(b[i+1:])
		}
	}
	return s
}
