#!/usr/bin/env bash
# Генератор тестовых данных: DATABASE_URL=… ./gen-testdata.sh [подразделений] [сотрудников] [новостей] [альбомов]
set -euo pipefail
cd "$(dirname "$0")"
: "${DATABASE_URL:?укажите DATABASE_URL}"
psql "$DATABASE_URL" -X -q -v ON_ERROR_STOP=1 -v depts="${1:-220}" -v users="${2:-3200}" -v news="${3:-5200}" -v albums="${4:-220}" -f gen_testdata.sql
