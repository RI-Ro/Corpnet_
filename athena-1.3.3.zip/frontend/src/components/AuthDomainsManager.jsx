import React, { useCallback, useEffect, useState } from 'react'
import { api } from '../api/client'

// Домены аутентификации: несколько LDAP-каталогов и областей Kerberos.
//
// Пользователь домена хранится как «имя@REALM», поэтому ivanov@DOMAIN1.LOCAL и
// ivanov@DOMAIN2.LOCAL — разные учётные записи. Секреты (пароль служебной
// учётной записи LDAP, keytab) сервер принимает, но обратно не отдаёт: в форме
// видно только, заданы ли они.
const EMPTY = {
  realm: '', title: '', netbios_name: '', is_active: true, sort_order: 100,
  ldap_enabled: false, ldap_urls: [], ldap_start_tls: false, ldap_skip_verify: false, ldap_ca_pem: '',
  ldap_bind_dn: '', ldap_base_dn: '', ldap_user_filter: '(&(objectClass=user)(sAMAccountName={login}))',
  ldap_attr_full_name: 'displayName', ldap_attr_position: 'title', ldap_attr_email: 'mail', ldap_timeout_sec: 5,
  kerberos_enabled: false, kerberos_spn: '', auto_create_users: false, default_department_id: null,
}

const input = 'field w-full'
const label = 'block text-xs text-text-secondary mt-2 mb-1'

export default function AuthDomainsManager({ flash, depts = [], onChanged }) {
  const [items, setItems] = useState([])
  const [edit, setEdit] = useState(null) // объект домена (id отсутствует у нового)
  const [bindPw, setBindPw] = useState('') // '' — не менять
  const [urls, setUrls] = useState('')
  const [testLogin, setTestLogin] = useState('')
  const [testResult, setTestResult] = useState(null)
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    try {
      const r = await api.adminListAuthDomains()
      setItems(r.domains || [])
      return r.domains || []
    } catch (e) { flash?.(e.message, 'err'); return [] }
  }, [])
  useEffect(() => { load() }, [load])

  const open = (d) => {
    setEdit(d ? { ...d } : { ...EMPTY })
    setUrls(((d && d.ldap_urls) || []).join('\n'))
    setBindPw(''); setTestResult(null); setTestLogin('')
  }
  const set = (k, v) => setEdit((e) => ({ ...e, [k]: v }))

  const save = async () => {
    setBusy(true)
    try {
      const body = {
        ...edit,
        ldap_urls: urls.split(/[\s,]+/).map((s) => s.trim()).filter(Boolean),
        default_department_id: edit.default_department_id || null,
      }
      if (bindPw) body.ldap_bind_password = bindPw
      let id = edit.id
      if (id) await api.adminUpdateAuthDomain(id, body)
      else id = (await api.adminCreateAuthDomain(body)).id
      flash?.('Домен сохранён')
      const list = await load()
      const fresh = list.find((x) => x.domain.id === id)
      if (fresh) open(fresh.domain)
      onChanged?.()
    } catch (e) { flash?.(e.message, 'err') } finally { setBusy(false) }
  }

  const remove = async () => {
    if (!edit?.id || !confirm(`Удалить домен ${edit.realm}?`)) return
    try { await api.adminDeleteAuthDomain(edit.id); flash?.('Домен удалён'); setEdit(null); await load() } catch (e) { flash?.(e.message, 'err') }
  }

  const uploadKeytab = async (file) => {
    if (!file || !edit?.id) return
    try {
      const r = await api.adminUploadKeytab(edit.id, file)
      flash?.('Keytab загружен')
      setEdit((e) => ({ ...e, has_keytab: true, keytab_info: r.keytab_info }))
      load()
    } catch (e) { flash?.(e.message, 'err') }
  }
  const dropKeytab = async () => {
    if (!confirm('Удалить keytab? Вход по Kerberos для домена перестанет работать.')) return
    try { await api.adminDeleteKeytab(edit.id); setEdit((e) => ({ ...e, has_keytab: false, keytab_info: '' })); load() } catch (e) { flash?.(e.message, 'err') }
  }

  const test = async () => {
    setTestResult(null); setBusy(true)
    try { setTestResult(await api.adminTestAuthDomain(edit.id, testLogin)) } catch (e) { setTestResult({ ok: false, message: e.message }) } finally { setBusy(false) }
  }

  return (
    <div className="surface-1 p-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-semibold">Домены (LDAP и Kerberos)</h3>
        <button className="btn btn-secondary text-xs" onClick={() => open(null)}>+ Домен</button>
      </div>
      <p className="text-sm text-text-secondary mb-3">
        Доменов может быть несколько. Пользователь домена — «имя@ДОМЕН»: одинаковые имена в разных доменах — разные люди.
        Вход по паролю домена идёт через его LDAP, вход по Kerberos — на отдельном порту.
      </p>

      {items.length === 0 && !edit && <div className="text-sm text-text-secondary">Домены не заведены — работают только локальные учётные записи.</div>}
      <ul className="divide-y divide-border">
        {items.map(({ domain: d, users }) => (
          <li key={d.id} className="py-2 flex items-center justify-between gap-2 text-sm">
            <button className="text-left min-w-0" onClick={() => open(d)}>
              <span className="font-medium">{d.realm}</span>
              {d.title && <span className="text-text-secondary"> · {d.title}</span>}
              <div className="text-xs text-text-secondary">
                {d.is_active ? '' : 'выключен · '}
                LDAP: {d.ldap_enabled ? 'да' : 'нет'} · Kerberos: {d.kerberos_enabled ? (d.has_keytab ? 'да' : 'нет keytab') : 'нет'} · пользователей: {users}
              </div>
            </button>
            <button className="text-accent text-xs shrink-0" onClick={() => open(d)}>Изменить</button>
          </li>
        ))}
      </ul>

      {edit && (
        <div className="mt-4 border-t border-border pt-3">
          <div className="font-medium text-sm mb-1">{edit.id ? `Домен ${edit.realm}` : 'Новый домен'}</div>

          <label className={label}>Имя домена (realm){edit.id ? ' — не меняется: входит в логины пользователей' : ''}</label>
          <input className={input} value={edit.realm} disabled={!!edit.id} placeholder="DOMAIN1.LOCAL"
            onChange={(e) => set('realm', e.target.value.toUpperCase())} />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className={label}>Подпись</label>
              <input className={input} value={edit.title || ''} onChange={(e) => set('title', e.target.value)} placeholder="Головной офис" />
            </div>
            <div>
              <label className={label}>Короткое имя (для входа DOMAIN1\ivanov)</label>
              <input className={input} value={edit.netbios_name || ''} onChange={(e) => set('netbios_name', e.target.value)} placeholder="DOMAIN1" />
            </div>
          </div>
          <label className="flex items-center gap-2 mt-3 text-sm">
            <input type="checkbox" checked={!!edit.is_active} onChange={(e) => set('is_active', e.target.checked)} /> Домен включён
          </label>

          <div className="mt-4 text-xs uppercase tracking-wide text-text-secondary">LDAP — вход по паролю домена</div>
          <label className="flex items-center gap-2 mt-2 text-sm">
            <input type="checkbox" checked={!!edit.ldap_enabled} onChange={(e) => set('ldap_enabled', e.target.checked)} /> Проверять логин и пароль в LDAP этого домена
          </label>
          <label className={label}>Серверы (по одному в строке; перебираются по порядку)</label>
          <textarea className={input} rows={2} value={urls} onChange={(e) => setUrls(e.target.value)} placeholder={'ldaps://dc1.domain1.local:636\nldaps://dc2.domain1.local:636'} />
          <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm">
            <label className="flex items-center gap-2"><input type="checkbox" checked={!!edit.ldap_start_tls} onChange={(e) => set('ldap_start_tls', e.target.checked)} /> StartTLS (для ldap://)</label>
            <label className="flex items-center gap-2 text-warning"><input type="checkbox" checked={!!edit.ldap_skip_verify} onChange={(e) => set('ldap_skip_verify', e.target.checked)} /> Не проверять сертификат сервера</label>
          </div>
          <label className={label}>Сертификат УЦ домена (PEM; пусто — системные корневые)</label>
          <textarea className={input + ' font-mono text-xs'} rows={2} value={edit.ldap_ca_pem || ''} onChange={(e) => set('ldap_ca_pem', e.target.value)} placeholder="-----BEGIN CERTIFICATE-----" />
          <label className={label}>Служебная учётная запись (DN или UPN) — для поиска пользователей</label>
          <input className={input} value={edit.ldap_bind_dn || ''} onChange={(e) => set('ldap_bind_dn', e.target.value)} placeholder="CN=athena-svc,OU=Service,DC=domain1,DC=local" />
          <label className={label}>Пароль служебной учётной записи {edit.has_bind_password ? '(задан; введите, чтобы заменить)' : '(не задан)'}</label>
          <input className={input} type="password" autoComplete="new-password" value={bindPw} onChange={(e) => setBindPw(e.target.value)} />
          <label className={label}>Базовый DN поиска</label>
          <input className={input} value={edit.ldap_base_dn || ''} onChange={(e) => set('ldap_base_dn', e.target.value)} placeholder="DC=domain1,DC=local" />
          <label className={label}>Фильтр пользователя ({'{login}'} — введённое имя)</label>
          <input className={input + ' font-mono text-xs'} value={edit.ldap_user_filter || ''} onChange={(e) => set('ldap_user_filter', e.target.value)} />
          <div className="grid grid-cols-3 gap-2">
            <div><label className={label}>Атрибут ФИО</label><input className={input} value={edit.ldap_attr_full_name || ''} onChange={(e) => set('ldap_attr_full_name', e.target.value)} /></div>
            <div><label className={label}>Атрибут должности</label><input className={input} value={edit.ldap_attr_position || ''} onChange={(e) => set('ldap_attr_position', e.target.value)} /></div>
            <div><label className={label}>Атрибут эл. почты</label><input className={input} value={edit.ldap_attr_email || ''} onChange={(e) => set('ldap_attr_email', e.target.value)} /></div>
            <div><label className={label}>Тайм-аут, с</label><input className={input} type="number" min={1} max={60} value={edit.ldap_timeout_sec || 5} onChange={(e) => set('ldap_timeout_sec', Number(e.target.value))} /></div>
          </div>

          <div className="mt-4 text-xs uppercase tracking-wide text-text-secondary">Kerberos — вход без пароля (отдельный порт)</div>
          <label className="flex items-center gap-2 mt-2 text-sm">
            <input type="checkbox" checked={!!edit.kerberos_enabled} onChange={(e) => set('kerberos_enabled', e.target.checked)} /> Принимать билеты пользователей этого домена
          </label>
          <label className={label}>Имя службы в keytab (пусто — любая запись keytab)</label>
          <input className={input} value={edit.kerberos_spn || ''} onChange={(e) => set('kerberos_spn', e.target.value)} placeholder="HTTP/athena.domain1.local" />
          {edit.id ? (
            <div className="mt-2 text-sm">
              <div className="text-xs text-text-secondary mb-1">
                Keytab: {edit.has_keytab ? <span className="text-success">загружен</span> : <span className="text-warning">не загружен</span>}
                {edit.keytab_info ? <span className="block font-mono break-all mt-0.5">{edit.keytab_info}</span> : null}
              </div>
              <div className="flex items-center gap-3">
                <input type="file" className="text-xs" onChange={(e) => { uploadKeytab(e.target.files?.[0]); e.target.value = '' }} />
                {edit.has_keytab && <button className="text-danger text-xs" onClick={dropKeytab}>Удалить keytab</button>}
              </div>
            </div>
          ) : (
            <div className="mt-2 text-xs text-text-secondary">Keytab загружается после сохранения домена.</div>
          )}

          <div className="mt-4 text-xs uppercase tracking-wide text-text-secondary">Пользователи</div>
          <label className="flex items-center gap-2 mt-2 text-sm">
            <input type="checkbox" checked={!!edit.auto_create_users} onChange={(e) => set('auto_create_users', e.target.checked)} /> Заводить пользователя при первом входе (без ролей)
          </label>
          <div className="text-[11px] text-text-secondary">Выключено — входят только те, кого администратор завёл заранее («+ Пользователь» → домен).</div>
          <label className={label}>Подразделение для новых пользователей</label>
          <select className={input} value={edit.default_department_id || 0} onChange={(e) => set('default_department_id', Number(e.target.value) || null)}>
            <option value={0}>— не задано —</option>
            {depts.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>

          <div className="flex flex-wrap gap-2 mt-4">
            <button className="btn btn-primary font-medium" disabled={busy} onClick={save}>Сохранить</button>
            <button className="btn btn-secondary" onClick={() => setEdit(null)}>Закрыть</button>
            {edit.id && <button className="btn btn-secondary text-danger ml-auto" onClick={remove}>Удалить домен</button>}
          </div>

          {edit.id && (
            <div className="mt-4 border-t border-border pt-3">
              <div className="text-xs text-text-secondary mb-1">Проверка LDAP (по сохранённым настройкам): соединение, служебная учётная запись и поиск пользователя.</div>
              <div className="flex gap-2">
                <input className={input} value={testLogin} onChange={(e) => setTestLogin(e.target.value)} placeholder="имя пользователя (необязательно)" />
                <button className="btn btn-secondary whitespace-nowrap" disabled={busy} onClick={test}>Проверить</button>
              </div>
              {testResult && (
                <div className={'mt-2 text-xs rounded-md px-3 py-2 border break-words ' + (testResult.ok ? 'border-success/40 text-success bg-success/10' : 'border-danger/40 text-danger bg-danger/10')}>
                  {testResult.message}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
