import React, { useEffect, useMemo, useState } from 'react';
import * as I from '../lib/icons';
import { api } from '../lib/api';
import { useQuery } from '../lib/query';
import { usePersist } from '../lib/persist';
import { Badge, ErrorBox, Loading, Select } from '../ui';
import { LineChart, fmtN, type Series } from './charts';
import './monitor.css';

interface Mon {
  step: number; times: number[]; series: Record<string, (number | null)[]>; routes: { route: string; count: number; errors: number; avg_ms: number; p95_ms: number }[];
  instance: string; dc: string; version: string; uptime: number; go: string; prom_path: string;
}

const RANGES = [[5, '5 минут'], [15, '15 минут'], [60, '1 час'], [180, '3 часа'], [360, '6 часов']] as const;
const REFRESH = [[0, 'Выкл.'], [10, '10 с'], [30, '30 с'], [60, '1 мин']] as const;

const hhmm = (t: number) => new Date(t * 1000).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
const dur = (s: number) => { const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60); return d ? `${d} д ${h} ч` : h ? `${h} ч ${m} мин` : `${m} мин`; };
const last = (a?: (number | null)[]) => { if (!a) return null; for (let i = a.length - 1; i >= 0; i--) if (a[i] != null) return a[i] as number; return null; };
const ms = (v: number | null) => (v == null ? '—' : v < 1 ? '< 1 мс' : v >= 1000 ? fmtN(v / 1000) + ' с' : fmtN(v) + ' мс');

type Tone = 'ok' | 'warn' | 'bad' | '';
function Stat({ label, value, tone = '', hint }: { label: string; value: string; tone?: Tone; hint?: string }) {
  return (
    <div className={'glass monStat ' + tone} title={hint}>
      <span className="l">{label}</span>
      <span className="v">{value}</span>
      {tone && <span className="t" aria-hidden>{tone === 'ok' ? '● норма' : tone === 'warn' ? '▲ внимание' : '■ проблема'}</span>}
    </div>
  );
}

/** Встроенный мониторинг (как в Grafana): плитки состояния, графики за выбранный период, таблица маршрутов. Данные — тот же реестр, что отдаёт /metrics. */
export function MonitorAdmin() {
  const [minutes, setMinutes] = usePersist<number>('mon.minutes', 15);
  const [every, setEvery] = usePersist<number>('mon.refresh', 10);
  const q = useQuery<Mon>('admin:monitor:' + minutes, () => api.get('/api/admin/monitor?minutes=' + minutes), { stale: 0, keepPrevious: true });
  useEffect(() => {
    if (!every) return;
    const t = setInterval(() => q.refetch(), every * 1000);
    return () => clearInterval(t);
  }, [every, minutes]); // eslint-disable-line
  const d = q.data;
  // первые точки буфера без скоростей (нет предыдущего замера) не рисуем — иначе график стартует с нуля
  const from = useMemo(() => { const r = d?.series.rps || []; const i = r.findIndex((v) => v != null); return i < 0 ? 0 : i; }, [d]);
  const labels = useMemo(() => (d ? d.times.slice(from).map((t) => hhmm(t)) : []), [d, from]);
  const S = (id: string, name: string, color?: string): Series => ({ id, name, color, values: (d?.series[id] || []).slice(from).map((v) => v ?? 0) });
  if (q.error && !d) return <ErrorBox error={q.error} retry={q.refetch} />;
  if (!d) return <Loading />;
  const g = (k: string) => last(d.series[k]);
  const rps = g('rps'), e5 = g('err5xx'), p95 = g('p95'), dbA = g('db_acquired'), dbM = g('db_max');
  const errPct = rps && rps > 0 && e5 != null ? (e5 / rps) * 100 : 0;
  const poolPct = dbA != null && dbM ? (dbA / dbM) * 100 : 0;
  const empty = 'Данные копятся — первый замер через несколько секунд после старта';
  return (
    <div className="stack">
      <div className="glass-pane monHead">
        <div className="sp">
          <b>Мониторинг экземпляра</b>
          <div className="small muted">{d.instance} · площадка {d.dc} · версия {d.version} · {d.go} · работает {dur(d.uptime)}</div>
        </div>
        <div className="monCtl">
          <label>Период<Select value={minutes} onChange={(e) => setMinutes(+e.target.value)}>{RANGES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></label>
          <label>Обновлять<Select value={every} onChange={(e) => setEvery(+e.target.value)}>{REFRESH.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</Select></label>
          <button className="btn-pill" onClick={() => q.refetch()}><I.Refresh size={16} /> Обновить</button>
        </div>
      </div>
      <div className="adminScope">
        <I.Info size={18} />
        <div>Встроенные графики показывают <b>этот экземпляр</b> за последние 6 часов (хранятся в памяти). Сводка по всем экземплярам и площадкам, долгая история и оповещения — в Prometheus + Grafana: метрики отдаёт <span className="mono">{d.prom_path}</span>, готовый дашборд и конфигурация лежат в <span className="mono">deploy/monitoring</span>.</div>
      </div>
      <div className="monStats">
        <Stat label="Запросов/с" value={rps == null ? '—' : fmtN(rps)} />
        <Stat label="Ошибки 5xx" value={rps == null ? '—' : fmtN(errPct) + '%'} tone={errPct >= 5 ? 'bad' : errPct >= 1 ? 'warn' : 'ok'} hint="Доля ответов 5xx среди всех запросов" />
        <Stat label="Время ответа p95" value={ms(p95)} tone={p95 == null ? '' : p95 >= 1000 ? 'bad' : p95 >= 500 ? 'warn' : 'ok'} />
        <Stat label="В обработке" value={g('inflight') == null ? '—' : fmtN(g('inflight')!)} />
        <Stat label="WebSocket" value={g('ws') == null ? '—' : fmtN(g('ws')!)} />
        <Stat label="Пул БД" value={dbM ? `${fmtN(dbA || 0)} / ${fmtN(dbM)}` : '—'} tone={!dbM ? '' : poolPct >= 90 ? 'bad' : poolPct >= 70 ? 'warn' : 'ok'} hint="Занятые соединения / максимум" />
        <Stat label="Память (куча)" value={g('heap_mb') == null ? '—' : fmtN(g('heap_mb')!) + ' МБ'} />
        <Stat label="Горутины" value={g('goroutines') == null ? '—' : fmtN(g('goroutines')!)} />
      </div>
      <div className="monGrid">
        <div className="glass-pane monPanel"><LineChart title="Запросы в секунду" labels={labels} area series={[S('rps', 'Запросы/с')]} height={210} empty={empty} fmt={(v) => fmtN(v) + '/с'} /></div>
        <div className="glass-pane monPanel"><LineChart title="Время ответа, мс" labels={labels} series={[S('p50', 'p50'), S('p95', 'p95'), S('p99', 'p99')]} height={210} empty={empty} fmt={(v) => fmtN(v) + ' мс'} /></div>
        <div className="glass-pane monPanel"><LineChart title="Ошибки HTTP, ответов/с" labels={labels} area stacked series={[S('err4xx', '4xx', 'var(--warn)'), S('err5xx', '5xx', 'var(--danger)')]} height={210} empty={empty} fmt={(v) => fmtN(v) + '/с'} /></div>
        <div className="glass-pane monPanel"><LineChart title="База данных" labels={labels} series={[S('db_acquired', 'Занято соединений'), S('db_max', 'Максимум'), S('db_p95', 'p95 запроса, мс')]} height={210} empty={empty} /></div>
        <div className="glass-pane monPanel"><LineChart title="Redis: задержка p95, мс" labels={labels} series={[S('redis_p95', 'PING p95')]} height={210} empty={empty} fmt={(v) => fmtN(v) + ' мс'} /></div>
        <div className="glass-pane monPanel"><LineChart title="Память и горутины" labels={labels} series={[S('heap_mb', 'Куча, МБ'), S('goroutines', 'Горутины'), S('ws', 'WebSocket')]} height={210} empty={empty} /></div>
        <div className="glass-pane monPanel"><LineChart title="Паузы GC, мс/с" labels={labels} series={[S('gc_ms', 'GC')]} height={210} empty={empty} fmt={(v) => fmtN(v) + ' мс'} /></div>
        <div className="glass-pane monPanel"><LineChart title="Медленные запросы и паники, /с" labels={labels} series={[S('slow', 'Медленные'), S('panics', 'Паники', 'var(--danger)'), S('db_err', 'Ошибки SQL', 'var(--warn)')]} height={210} empty={empty} fmt={(v) => fmtN(v) + '/с'} /></div>
      </div>
      <div className="glass-pane">
        <div className="tbar"><b className="grow">Маршруты с начала работы процесса</b><Badge>{d.routes.length}</Badge></div>
        <div className="tblW"><table className="tbl monTbl">
          <thead><tr><th>Маршрут</th><th className="r">Запросов</th><th className="r">5xx</th><th className="r">Среднее</th><th className="r">p95</th></tr></thead>
          <tbody>{d.routes.map((r) => (
            <tr key={r.route}><td className="mono">{r.route}</td><td className="r">{fmtN(r.count)}</td><td className={'r' + (r.errors ? ' bad' : '')}>{fmtN(r.errors)}</td><td className="r">{ms(r.avg_ms)}</td><td className="r">{ms(r.p95_ms || null)}</td></tr>
          ))}</tbody>
        </table></div>
      </div>
    </div>
  );
}
