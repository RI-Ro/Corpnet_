"""Регрессии рабочего процесса. Запускается на отдельном стенде с 900_testdata.sql.
Для проверки будильника регистрации включить document_sent в notifications.alarm_kinds.
"""
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from urllib.parse import urlencode
import os
from api import call, create_doc, login

sessions = {}
profiles = {}
checks = 0


def verify(label, condition):
    global checks
    assert condition, label
    checks += 1


def request(who, method, path, body=None, expected=200):
    status, result = call(method, path, sessions[who], body)
    assert status == expected, (method, path, status, result)
    return result


def permissions(who, **fields):
    request("admin", "PATCH", f"/api/admin/users/{profiles[who]['user_id']}/departments", fields)


def rows(who, path):
    return request(who, "GET", path).get("items") or []


def run():
    for name in ["admin", "author1", "signer1", "duty1", "finchief1", "clerk1",
                 "crossdept1", "approver2", "approver4", "exec1", "outsider1"]:
        sessions[name] = login(name, os.environ["ATHENA_ADMIN_PASSWORD"] if name == "admin" else "password123")
        profiles[name] = request(name, "GET", "/api/me")
    departments = {r["name"]: r["id"] for r in rows("author1", "/api/departments")}
    digital, finance = departments["Департамент цифровизации"], departments["Департамент финансов"]
    operators = ["clerk1", "crossdept1"]
    for who in operators:
        permissions(who, duty_departments=[digital])
    permissions("duty1", acquaint_departments=list(departments.values()))
    candidates = rows("author1", "/api/users/candidates?" + urlencode(
        {"group": "recipients", "q": "Дежурный", "department_id": digital}))
    address = next(u["id"] for u in candidates if u["full_name"] == "Дежурный")
    recipients = [{"department_id": digital, "user_id": address},
                  {"department_id": finance, "user_id": profiles["finchief1"]["user_id"]}]
    status, created = create_doc(sessions["author1"], "Приём дежурным и разграничение истории",
                                 [], [profiles["signer1"]["user_id"]], recipients=recipients)
    verify("Документ создан", status == 201)
    doc = created["id"]
    path = f"/api/documents/{doc}"
    for who in operators:
        request(who, "GET", path, expected=404)
    stage = next(s for s in rows("signer1", path+"/stages") if s["status"] == "pending")
    request("signer1", "POST", path+f"/stages/{stage['id']}/decide", {"approve": True})
    before = {who:request(who, "GET", "/api/documents/category-counts")["pending_registration"] for who in operators}
    if os.getenv("E2E_REGISTRATION_ALARMS"):
        for who in operators:
            verify("Напоминание до регистрации", any(a["document_id"] == doc for a in rows(who, "/api/notifications/alarms")))
    with ThreadPoolExecutor(max_workers=2) as pool:
        cards = list(pool.map(lambda who: request(who, "GET", path), operators))
    verify("Одинаковый входящий номер при двух одновременных открытиях",
           cards[0]["incoming_marking"]["incoming_number"] == cards[1]["incoming_marking"]["incoming_number"])
    for who in operators:
        verify("Общий счётчик обновлён", request(who, "GET", "/api/documents/category-counts")["pending_registration"] == before[who]-1)
        verify("Напоминание о регистрации снято", not any(a["document_id"] == doc for a in rows(who, "/api/notifications/alarms")))
    dist = rows("author1", path+"/recipients")
    item = next(r for r in dist if r["department_id"] == digital)
    verify("Адрес и реальный регистратор различаются", item["user_id"] == address and
           item["registered_by_name"] in [profiles[n]["full_name"] for n in operators])
    history = rows("author1", path+"/history")
    verify("Одна регистрация", sum(e["event_type"]=="incoming_registered" for e in history)==1)
    # Руководитель ДЦ выдаёт резолюцию после ознакомления старшего, равного и младшего подразделений.
    for name in ["approver4","approver2","exec1"]:
        request("duty1","POST",path+"/acquaint",{"user_ids":[profiles[name]["user_id"]]},201)
        request(name,"GET",path)
        verify("Ознакомление не закрывает право выдать резолюцию", request("duty1","GET",path+"/resolutions")["can_issue"])
    request("finchief1","GET",path)
    actual_options=request("signer1","GET",path+"/resolutions")["eligible_departments"]
    verify("Руководитель видит оба доступных экземпляра", {r["id"] for r in actual_options}=={digital,finance})
    secret = "Расчёт для финансового подразделения"
    request("finchief1","POST",path+"/resolutions",{"text":secret,"department_id":finance,
            "responsible_id":profiles["outsider1"]["user_id"]},201)
    request("duty1","POST",path+"/resolutions",{"text":"Проверить реестр","department_id":digital,
            "responsible_id":profiles["approver2"]["user_id"]},201)
    for url in [path+"/history",f"/api/history?document_id={doc}"]:
        verify("Своя резолюция видна", any(secret in (r.get("comment") or "") for r in rows("finchief1",url)))
        verify("Чужая резолюция скрыта", not any(secret in (r.get("comment") or "") for r in rows("duty1",url)))
    request("approver2","POST",path+"/complete",{"note":"Реестр проверен"})
    item = next(r for r in rows("author1",path+"/recipients") if r["department_id"]==digital)
    verify("В рассылке указан фактический исполнитель",item["executed_by_name"]==profiles["approver2"]["full_name"])
    counts=lambda: request("author1","GET",f"/api/recipients-counts?ids={doc}")["counts"][str(doc)]
    verify("Счётчик после чужой отметки",counts()["done"]==1 and counts()["total"]==2)
    request("approver2","PATCH",path+"/complete",{"note":"Отчёт уточнён"})
    request("approver2","DELETE",path+"/complete",{"reason":"Требуется повторная сверка"})
    verify("Отмена снимает отметку",counts()["done"]==0)
    request("approver2","POST",path+"/complete",{"note":"Сверка завершена"})
    request("finchief1","POST",path+"/complete",{"note":"Завершено"})
    verify("Завершены оба подразделения",request("author1","GET",path)["document"]["status"]=="executed")
    request("author1","POST",path+"/archive")
    year=date.today().year
    for url in [f"/api/registry/archive/{year}","/api/registry/all","/api/registry/outgoing"]:
        verify("Архив доступен в журнале",doc in [r["id"] for r in rows("author1",url)])
    page=rows("author1","/api/registry/all")
    verify("Новые документы вверху",page[0]["id"]==doc)
    second=rows("author1","/api/registry/all?offset=1")
    verify("Следующая страница не повторяет первую строку", second[0]["id"]==page[1]["id"])
    permissions("clerk1",duty_departments=[])
    status, _ = call("GET", path, sessions["clerk1"])
    verify("Удаление из очереди закрывает доступ", status == 404)
    print(f"Проверки рабочего процесса пройдены: {checks}")


if __name__ == "__main__":
    run()
