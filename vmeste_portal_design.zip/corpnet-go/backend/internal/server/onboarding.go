package server

import (
	"context"
	"strings"

	"github.com/jackc/pgx/v5"
)

// Модуль предназначен для адаптации новых сотрудников (раздел 8 ТЗ): шаблоны чек-листов, автоназначение по дате
// приёма и аудитории, наставник, отметки исполнителей (сотрудник/руководитель/наставник/HR), «Знакомьтесь».

// obAssign создаёт планы адаптации тем, кто подходит под автоназначаемые шаблоны (приняты не позднее срока шаблона).
func (s *Server) obAssign(ctx context.Context) {
	_, err := s.db.Exec(ctx, `INSERT INTO ob_plans (user_id, template_id, started_on, mentor_id)
		SELECT u.id, t.id, u.hire_date, u.mentor_id FROM ob_templates t JOIN users u ON u.hire_date IS NOT NULL
		WHERE t.active AND t.auto_assign AND NOT u.blocked AND u.deleted_at IS NULL
		  AND u.hire_date >= current_date - t.duration_days AND u.hire_date <= current_date + 7
		  AND audience_has(t.audience_id, u.id)
		ON CONFLICT DO NOTHING`)
	if err != nil {
		s.log.Warn("onboarding assign", "err", err)
	}
}

// obAuto — автоматические отметки пунктов (profile_fill, intro): вызывается при просмотре плана.
func (s *Server) obAuto(ctx context.Context, uid int64) {
	s.db.Exec(ctx, `INSERT INTO ob_progress (plan_id, item_id, done_by)
		SELECT p.id, i.id, p.user_id FROM ob_plans p JOIN ob_items i ON i.template_id = p.template_id JOIN users u ON u.id = p.user_id
		WHERE p.user_id = $1 AND p.status = 'active' AND (
		  (i.auto_event = 'profile_fill' AND u.avatar <> '' AND u.phone1 <> '' AND u.birthday IS NOT NULL AND u.job_title <> '')
		  OR (i.auto_event = 'intro' AND EXISTS (SELECT 1 FROM ob_intro x WHERE x.user_id = p.user_id)))
		ON CONFLICT DO NOTHING`, uid)
}

const obPlanSQL = `SELECT p.id, p.user_id, u.full_name AS name, u.avatar, u.job_title, to_char(p.started_on,'YYYY-MM-DD') AS started_on, p.status,
		(current_date - p.started_on) AS day, t.name AS template, t.duration_days, p.mentor_id, m.full_name AS mentor_name, m.avatar AS mentor_avatar,
		(SELECT count(*) FROM ob_items i WHERE i.template_id = p.template_id) AS total,
		(SELECT count(*) FROM ob_progress g WHERE g.plan_id = p.id) AS done,
		(SELECT count(*) FROM ob_items i WHERE i.template_id = p.template_id AND i.required AND p.started_on + i.due_day < current_date
		   AND NOT EXISTS (SELECT 1 FROM ob_progress g WHERE g.plan_id = p.id AND g.item_id = i.id)) AS overdue
	FROM ob_plans p JOIN users u ON u.id = p.user_id JOIN ob_templates t ON t.id = p.template_id LEFT JOIN users m ON m.id = p.mentor_id`

// obMe — мои планы адаптации с пунктами (GET /api/onboarding/me).
func (s *Server) obMe(c *Ctx) error {
	ctx := c.Context()
	uid := c.U.ID
	if q := c.QInt64("user"); q > 0 && q != uid {
		if ok, _ := s.canSeeOb(ctx, c.U, q); !ok {
			return errForbidden
		}
		uid = q
	}
	s.obAssign(ctx)
	s.obAuto(ctx, uid)
	plans, err := s.arr(ctx, obPlanSQL+` WHERE p.user_id = $1 AND p.status <> 'cancelled' ORDER BY p.id DESC`, uid)
	if err != nil {
		return err
	}
	items, err := s.arr(ctx, `SELECT p.id AS plan_id, i.id, i.sort, i.section, i.title, i.description, i.link, i.assignee, i.due_day, i.required, i.auto_event,
			to_char(p.started_on + i.due_day, 'YYYY-MM-DD') AS due, g.done_at, (g.item_id IS NOT NULL) AS done, g.note,
			(g.item_id IS NULL AND p.started_on + i.due_day < current_date) AS overdue
		FROM ob_plans p JOIN ob_items i ON i.template_id = p.template_id LEFT JOIN ob_progress g ON g.plan_id = p.id AND g.item_id = i.id
		WHERE p.user_id = $1 AND p.status <> 'cancelled' ORDER BY p.id, i.sort, i.id`, uid)
	if err != nil {
		return err
	}
	intro, _ := s.one(ctx, `SELECT body, created_at FROM ob_intro WHERE user_id = $1`, uid)
	return c.JSON(200, map[string]any{"plans": plans, "items": items, "intro": intro, "user_id": uid})
}

// canSeeOb — адаптацию человека видит он сам, его наставник, руководитель подразделения, HR и администратор.
func (s *Server) canSeeOb(ctx context.Context, u *User, uid int64) (bool, error) {
	if u.IsAdmin() || u.HR || u.ID == uid {
		return true, nil
	}
	var ok bool
	err := s.db.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM users t WHERE t.id = $2 AND (t.mentor_id = $1 OR
		($3::boolean AND t.department_id IN (SELECT id FROM dept_subtree(ARRAY[$4::int])))))`, u.ID, uid, u.Head, u.Dept).Scan(&ok)
	return ok, err
}

// obTeam — подопечные: для наставника, руководителя и HR (GET /api/onboarding/team).
func (s *Server) obTeam(c *Ctx) error {
	ctx := c.Context()
	b, err := s.arr(ctx, obPlanSQL+` WHERE p.status = 'active' AND ($1::boolean OR p.mentor_id = $2 OR ($3::boolean AND u.department_id IN (SELECT id FROM dept_subtree(ARRAY[$4::int]))))
		ORDER BY overdue DESC, p.started_on DESC LIMIT 200`, c.U.IsAdmin() || c.U.HR, c.U.ID, c.U.Head, c.U.Dept)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// obDone — отметить/снять пункт (POST /api/onboarding/items/{id}/done {plan_id, undo, note}).
func (s *Server) obDone(c *Ctx) error {
	iid, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		PlanID int64  `json:"plan_id"`
		Undo   bool   `json:"undo"`
		Note   string `json:"note"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	ctx := c.Context()
	var owner int64
	var mentor *int64
	var assignee string
	err = s.db.QueryRow(ctx, `SELECT p.user_id, p.mentor_id, i.assignee FROM ob_plans p JOIN ob_items i ON i.template_id = p.template_id
		WHERE p.id = $1 AND i.id = $2 AND p.status = 'active'`, in.PlanID, iid).Scan(&owner, &mentor, &assignee)
	if err != nil {
		return errNotFound
	}
	// Отметить пункт плана может сам сотрудник, его наставник, руководитель (в пределах видимости) и HR/админ — любой пункт плана.
	_ = assignee
	allowed := c.U.IsAdmin() || c.U.HR || owner == c.U.ID || (mentor != nil && *mentor == c.U.ID)
	if !allowed && c.U.Head {
		ok, _ := s.canSeeOb(ctx, c.U, owner)
		allowed = ok
	}
	if !allowed {
		return errForbidden
	}
	if in.Undo {
		_, err = s.db.Exec(ctx, `DELETE FROM ob_progress WHERE plan_id = $1 AND item_id = $2`, in.PlanID, iid)
	} else {
		_, err = s.db.Exec(ctx, `INSERT INTO ob_progress (plan_id, item_id, done_by, note) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING`, in.PlanID, iid, c.U.ID, strings.TrimSpace(in.Note))
	}
	if err != nil {
		return err
	}
	var left int
	s.db.QueryRow(ctx, `SELECT count(*) FROM ob_plans p JOIN ob_items i ON i.template_id = p.template_id AND i.required
		WHERE p.id = $1 AND NOT EXISTS (SELECT 1 FROM ob_progress g WHERE g.plan_id = p.id AND g.item_id = i.id)`, in.PlanID).Scan(&left)
	finished := false
	if !in.Undo && left == 0 {
		if tag, _ := s.db.Exec(ctx, `UPDATE ob_plans SET status = 'done', finished_at = now() WHERE id = $1 AND status = 'active'`, in.PlanID); tag.RowsAffected() > 0 {
			finished = true
			s.award(ctx, owner, "onboarding_done", "ob:"+i64s(in.PlanID), nil)
			s.notify(ctx, []int64{owner}, "onboarding", "Адаптация завершена", "Все обязательные шаги выполнены. Поздравляем!", "/onboarding")
		}
	}
	if !in.Undo && owner == c.U.ID {
		s.award(ctx, owner, "onboarding_step", "ob:"+i64s(in.PlanID)+":"+i64s(iid), nil)
	}
	return c.JSON(200, map[string]any{"ok": true, "finished": finished})
}

// obIntro — «Знакомьтесь»: короткий рассказ о себе (PUT /api/onboarding/intro) и лента (GET /api/onboarding/intros).
func (s *Server) obIntro(c *Ctx) error {
	var in struct {
		Body string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if n := len([]rune(in.Body)); n < 5 || n > 2000 {
		return badReq("Расскажите о себе (от 5 до 2000 символов)")
	}
	_, err := s.db.Exec(c.Context(), `INSERT INTO ob_intro (user_id, body) VALUES ($1, $2) ON CONFLICT (user_id) DO UPDATE SET body = $2`, c.U.ID, in.Body)
	if err != nil {
		return err
	}
	s.award(c.Context(), c.U.ID, "intro", "intro", nil)
	return c.JSON(200, map[string]any{"ok": true})
}

func (s *Server) obIntros(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT i.user_id, u.full_name AS name, u.avatar, u.job_title, d.name AS department, to_char(u.hire_date,'YYYY-MM-DD') AS hire_date, i.body, i.created_at
		FROM ob_intro i JOIN users u ON u.id = i.user_id LEFT JOIN departments d ON d.id = u.department_id
		WHERE i.published AND NOT u.blocked ORDER BY i.created_at DESC LIMIT 30`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// obStart — HR назначает адаптацию вручную (POST /api/onboarding/assign {user_id, template_id, mentor_id}).
func (s *Server) obStart(c *Ctx) error {
	if err := s.needHR(c); err != nil {
		return err
	}
	var in struct {
		UserID     int64  `json:"user_id"`
		TemplateID int64  `json:"template_id"`
		MentorID   *int64 `json:"mentor_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	err := s.tx(c.Context(), func(tx pgx.Tx) error {
		if _, err := tx.Exec(c.Context(), `INSERT INTO ob_plans (user_id, template_id, mentor_id) VALUES ($1, $2, $3)
			ON CONFLICT (user_id, template_id) DO UPDATE SET mentor_id = $3, status = 'active'`, in.UserID, in.TemplateID, in.MentorID); err != nil {
			return err
		}
		if in.MentorID != nil {
			_, err := tx.Exec(c.Context(), `UPDATE users SET mentor_id = $2 WHERE id = $1`, in.UserID, in.MentorID)
			return err
		}
		return nil
	})
	if err != nil {
		return err
	}
	s.notify(c.Context(), []int64{in.UserID}, "onboarding", "Для вас открыт план адаптации", "", "/onboarding")
	if in.MentorID != nil {
		s.notify(c.Context(), []int64{*in.MentorID}, "onboarding", "Вы назначены наставником", "", "/onboarding")
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// obJob — ежедневно: автоназначение и напоминания о просроченных шагах сотруднику и руководителю.
func (s *Server) obJob(ctx context.Context) {
	s.obAssign(ctx)
	s.db.Exec(ctx, `INSERT INTO notifications (user_id, kind, title, body, link)
		SELECT p.user_id, 'onboarding', 'Шаги адаптации просрочены', count(*) || ' шаг(ов) ждут выполнения', '/onboarding'
		FROM ob_plans p JOIN ob_items i ON i.template_id = p.template_id AND i.required AND i.assignee = 'employee'
		WHERE p.status = 'active' AND p.started_on + i.due_day < current_date
		  AND NOT EXISTS (SELECT 1 FROM ob_progress g WHERE g.plan_id = p.id AND g.item_id = i.id) GROUP BY p.user_id`)
}
