package db

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// New открывает пул соединений к PostgreSQL.
func New(ctx context.Context, dsn string, maxConns, minConns int32) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("parse dsn: %w", err)
	}
	// Разумные дефолты пула для веб-бэкенда среднего размера нагрузки.
	if maxConns <= 0 {
		maxConns = 20
	}
	if minConns <= 0 {
		minConns = 2
	}
	if minConns > maxConns {
		minConns = maxConns
	}
	cfg.MaxConns = maxConns
	cfg.MinConns = minConns
	// Простаивающие соединения закрываем (не держим память PostgreSQL зря),
	// старые — периодически пересоздаём, а мёртвые находим фоновой проверкой,
	// а не на первом запросе пользователя.
	cfg.MaxConnIdleTime = 5 * time.Minute
	cfg.MaxConnLifetime = 1 * time.Hour
	cfg.HealthCheckPeriod = 30 * time.Second

	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("create pool: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		return nil, fmt.Errorf("ping db: %w", err)
	}
	return pool, nil
}

// WithUserTx открывает транзакцию и выставляет app.user_id / app.is_admin
// сессионными переменными для этой транзакции — это то, на чём строятся
// все RLS-политики (documents_access_policy, chat_access_policy,
// notifications_owner_policy). Обязателен для КАЖДОГО запроса, читающего
// или изменяющего защищённые RLS таблицы — как из HTTP-хендлеров, так и
// из WebSocket-хаба (см. internal/ws/hub.go).
func WithUserTx(ctx context.Context, pool *pgxpool.Pool, userID int64, isAdmin bool, fn func(tx pgx.Tx) error) error {
	// Явно берём ОДНО соединение из пула на весь запрос. Это критично для
	// RLS: set_config и последующие запросы обязаны идти по одному и тому же
	// физическому соединению, иначе сессионная переменная app.user_id не
	// видна запросу, и WITH CHECK политики падает. Захват conn гарантирует
	// это независимо от внутреннего поведения пула.
	conn, err := pool.Acquire(ctx)
	if err != nil {
		return fmt.Errorf("acquire conn: %w", err)
	}
	defer conn.Release()

	tx, err := conn.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin tx: %w", err)
	}
	defer tx.Rollback(ctx) // no-op если Commit уже прошёл

	// Выставляем контекст RLS. ВАЖНО: без параметров ($1) — параметризованный
	// запрос идёт по extended-протоколу как prepared statement, и LOCAL-эффект
	// set_config при этом ненадёжен. Простой строковый запрос применяет
	// настройку немедленно. Значения безопасны: userID — int64, isAdmin —
	// bool (не пользовательский ввод), инъекция невозможна.
	setSQL := fmt.Sprintf(
		"SELECT set_config('app.user_id', '%d', true), set_config('app.is_admin', '%t', true)",
		userID, isAdmin)
	if _, err := tx.Exec(ctx, setSQL); err != nil {
		return fmt.Errorf("set rls context: %w", err)
	}

	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// WithAdminTx открывает транзакцию с app.is_admin=true и ПУСТЫМ app.user_id —
// для фоновых/системных задач (авто-архив), которым нужен обход RLS. Не
// использовать в обработке пользовательских запросов: там всегда WithUserTx
// с реальным userID.
func WithAdminTx(ctx context.Context, pool *pgxpool.Pool, fn func(tx pgx.Tx) error) error {
	tx, err := pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("begin admin tx: %w", err)
	}
	defer tx.Rollback(ctx)

	// Пустой, а не '0': триггеры пишут app.user_id в столбцы-ссылки на users
	// (document_versions.changed_by и др.), и 0 нарушал внешний ключ — авто-
	// архив падал. Пустое значение превращается в NULL («система»).
	if _, err := tx.Exec(ctx, "SELECT set_config('app.user_id', '', true)"); err != nil {
		return fmt.Errorf("set app.user_id: %w", err)
	}
	if _, err := tx.Exec(ctx, "SELECT set_config('app.is_admin', 'true', true)"); err != nil {
		return fmt.Errorf("set app.is_admin: %w", err)
	}
	// Признак фоновой задачи: политика documents_select открывает документы
	// только при нём (у администратора-человека такого права нет).
	if _, err := tx.Exec(ctx, "SELECT set_config('app.system', 'scheduler', true)"); err != nil {
		return fmt.Errorf("set app.system: %w", err)
	}
	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}

// SystemPool — отдельное небольшое подключение для фоновых задач приложения
// (индексация текста, авто-архив, напоминания, очередь писем, служебные
// изменения сессий). У него на уровне сеанса выставлен признак
// app.system = 'scheduler': политики RLS открывают таким запросам документы
// и файлы. Обработчики запросов пользователей им НЕ пользуются.
var SystemPool *pgxpool.Pool

// NewSystem открывает SystemPool.
func NewSystem(ctx context.Context, dsn string) (*pgxpool.Pool, error) {
	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("parse dsn: %w", err)
	}
	cfg.MaxConns = 3
	cfg.MinConns = 0
	cfg.MaxConnIdleTime = 5 * time.Minute
	cfg.MaxConnLifetime = time.Hour
	cfg.AfterConnect = func(ctx context.Context, conn *pgx.Conn) error {
		_, err := conn.Exec(ctx, "SELECT set_config('app.system', 'scheduler', false), "+
			"set_config('app.is_admin', 'true', false), set_config('app.user_id', '', false)")
		return err
	}
	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("create system pool: %w", err)
	}
	SystemPool = pool
	return pool, nil
}
