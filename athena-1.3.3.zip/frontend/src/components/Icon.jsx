import React from 'react'

// #35 — Единый набор ИКОНОК-SVG вместо юникод-глифов (✎ 🗑 ⛶ ▸ ▾ × ↑ ↓ 🔔 …).
// Юникод-символы рисуются шрифтом операционной системы: на части машин и
// браузеров нужного глифа просто нет, и пользователь видит пустой квадрат или
// ничего. Inline-SVG рисуется самим браузером и выглядит одинаково везде,
// наследует цвет через currentColor и масштабируется размером шрифта.
//
// Использование: <Icon name="edit" />  либо <Icon name="chevron-down" size={14} />
const PATHS = {
  edit: <path d="M4 20h4L19 9l-4-4L4 16v4z M14 6l4 4" />,
  'cat-dashboard': <path d="M4 20V11M10 20V5M16 20v-6M21 20H3" />,
  warning: <path d="M12 4l9 16H3L12 4zM12 10v4M12 17h.01" />,
  clock: <path d="M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2" />,
  'check-circle': <path d="M12 21a9 9 0 100-18 9 9 0 000 18zM8 12l3 3 5-6" />,
  table: <path d="M4 5h16v14H4zM4 10h16M4 15h16M10 5v14" />,
  chart: <path d="M4 19l5-6 4 3 7-9M4 4v15h16" />,
  eye: <path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z" />,
  'eye-off': <path d="M3 3l18 18M10.6 6.1A10 10 0 0112 6c6 0 10 6 10 6a17 17 0 01-3.2 3.7M6.6 6.6C3.8 8.4 2 12 2 12s4 6 10 6a9.6 9.6 0 004.4-1M9.9 9.9a3 3 0 004.2 4.2" />,
  'arrows-h': <path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4" />,
  trash: <path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13M10 11v6M14 11v6" />,
  close: <path d="M5 5l14 14M19 5L5 19" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  'chevron-down': <path d="M6 9l6 6 6-6" />,
  'chevron-right': <path d="M9 6l6 6-6 6" />,
  'chevron-up': <path d="M6 15l6-6 6 6" />,
  'arrow-up': <path d="M12 19V5M6 11l6-6 6 6" />,
  'arrow-down': <path d="M12 5v14M6 13l6 6 6-6" />,
  'arrow-left': <path d="M19 12H5M11 6l-6 6 6 6" />,
  'arrow-right': <path d="M5 12h14M13 6l6 6-6 6" />,
  fullscreen: <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />,
  bell: <path d="M18 16V11a6 6 0 10-12 0v5l-2 3h16l-2-3zM10 22h4" />,
  'volume-on': <path d="M4 9v6h4l5 4V5L8 9H4zM17 9a4 4 0 010 6" />,
  'volume-off': <path d="M4 9v6h4l5 4V5L8 9H4zM17 10l4 4M21 10l-4 4" />,
  paperclip: <path d="M20 11l-8.5 8.5a4.5 4.5 0 01-6.4-6.4L13 5a3 3 0 014.2 4.2l-7.8 7.8a1.5 1.5 0 01-2.1-2.1l7.3-7.3" />,
  user: <path d="M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0" />,
  search: <path d="M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3" />,
  reset: <path d="M4 12a8 8 0 108-8 8 8 0 00-5.7 2.4L4 9M4 4v5h5" />,
  // Значок выбора оформления. Раньше он подключался как <img src=palette.svg>,
  // и это было ошибкой: в отдельном файле stroke="currentColor" берёт цвет
  // ИЗ САМОГО SVG, а он по умолчанию чёрный. На тёмных темах значок
  // получался чёрным на тёмном и не читался. Inline-SVG наследует цвет
  // кнопки, поэтому виден в любой из десяти тем.
  palette: (
    <>
      <path d="M12 2.5c-5.2 0-9.5 4-9.5 9 0 4.7 3.9 7.5 7.6 7.5 1.5 0 2.2-1 2.2-2 0-.6-.3-1-.6-1.4-.3-.4-.6-.8-.6-1.4 0-1 .8-1.7 1.8-1.7h2.1c3 0 5.5-2.4 5.5-5.5 0-3.3-3.8-4.9-8.5-4.5z" />
      <circle cx="7.5" cy="10.5" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="11" cy="7" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="15.5" cy="7.5" r="1.1" fill="currentColor" stroke="none" />
      <circle cx="17.5" cy="11" r="1.1" fill="currentColor" stroke="none" />
    </>
  ),
  // Иконки вкладок документа. Рисуются цветом вкладки (currentColor),
  // поэтому один набор работает во всех десяти темах.
  'tab-decision': <path d="M20 6L9 17l-5-5" />,
  // Ручка (подпись) и штамп (резолюция).
  'tab-sign': <path d="M12 20h9M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4L16.5 3.5z" />,
  // Резолюция — документ с пером: поручение, написанное на документе.
  'tab-resolution': <path d="M14 3H6a2 2 0 00-2 2v14a2 2 0 002 2h5M14 3l5 5h-5V3zM8 10h4M8 14h3M20.4 13.6l-6 6-2.9.6.6-2.9 6-6a1.6 1.6 0 012.3 2.3z" />,
  'tab-route': <path d="M6 4v6a4 4 0 004 4h4M18 20v-6a4 4 0 00-4-4h-4M16 8l2-4 2 4M8 16l-2 4-2-4" />,
  'tab-recipients': <path d="M4 20a5 5 0 0110 0M9 11a3 3 0 100-6 3 3 0 000 6zM15 20a5 5 0 017-4.6M18 11a2.5 2.5 0 100-5" />,
  'tab-execution': <path d="M9 11l3 3 7-7M4 12a8 8 0 0013.7 5.6" />,
  'tab-assignments': <path d="M9 4h6v3H9zM7 7h10v13H7zM10 12h4M10 16h4" />,
  'tab-acquaint': <path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6-10-6-10-6z M12 14a2 2 0 100-4 2 2 0 000 4z" />,
  'tab-chat': <path d="M4 6h16v10H9l-5 4V6z" />,
  'tab-copies': <path d="M8 4h9v12H8zM5 8v12h9" />,
  'tab-prints': <path d="M7 9V4h10v5M7 17H5v-6h14v6h-2M7 14h10v6H7z" />,
  'tab-links': <path d="M10 14a4 4 0 005.7 0l2.3-2.3a4 4 0 00-5.7-5.7L11 7.3M14 10a4 4 0 00-5.7 0L6 12.3a4 4 0 005.7 5.7L13 16.7" />,
  'tab-control': <path d="M12 3l7 4v5c0 4.4-3 8.3-7 9-4-0.7-7-4.6-7-9V7l7-4z M9.5 12l2 2 3.5-3.5" />,
  'tab-history': <path d="M12 7v5l4 2M3 12a9 9 0 109-9 9 9 0 00-6.4 2.7L3 8M3 3v5h5" />,
  // Иконки разделов бокового меню. Как и у вкладок — один контурный набор,
  // который рисуется цветом раздела и поэтому читается во всех десяти темах.
  'cat-all': <path d="M4 5h16M4 10h16M4 15h10M4 20h10" />,
  'cat-awaiting': <path d="M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3.5 2" />,
  'cat-outgoing': <path d="M12 19V5M6 11l6-6 6 6M4 21h16" />,
  'cat-incoming': <path d="M12 5v14M6 13l6 6 6-6M4 3h16" />,
  'cat-archive': <path d="M3 7h18v4H3zM5 11v9h14v-9M10 15h4" />,
  'cat-registry': <path d="M5 4h11l3 3v13H5zM8 10h8M8 14h8M8 18h5" />,
  'cat-executed': <path d="M4 13l4 4L20 5M4 19h10" />,
  // Избранное: контурная и залитая звезда — пустая и отмеченная.
  'star-filled': <path d="M12 3.5l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 10l6.1-.9z" />,
  star: <path d="M12 3.5l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 10l6.1-.9z" />,
  'grip': <path d="M9 6h.01M9 12h.01M9 18h.01M15 6h.01M15 12h.01M15 18h.01" />,
  // #42 — «гамбургер» для скрытия бокового меню
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  dot: <circle cx="12" cy="12" r="5" />,
}

export default function Icon({ name, size = 16, className = '', title, strokeWidth = 1.8, style }) {
  const d = PATHS[name]
  if (!d) return null
  const filled = name === 'dot' || name === 'star-filled'
  return (
    <svg
      width={typeof size === 'number' ? `calc(${size}px * var(--ui-elements, 1))` : size}
      height={typeof size === 'number' ? `calc(${size}px * var(--ui-elements, 1))` : size}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      stroke={filled ? 'none' : 'currentColor'}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`inline-block shrink-0 align-[-0.15em] ${className}`}
      style={style}
      aria-hidden={title ? undefined : true}
      role={title ? 'img' : undefined}
													focusable="false"
    >
      {title ? <title>{title}</title> : null}
      {d}
    </svg>
  )
}
