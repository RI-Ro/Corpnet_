package middleware

import (
	"bytes"
	"compress/gzip"
	"strings"
	"sync"

	"github.com/gofiber/fiber/v2"
)

// gzipMinSize — ниже этого порога сжатие не окупается: заголовок gzip и
// затраты CPU больше выигрыша, а мелкие ответы только «раздуваются».
const gzipMinSize = 1024

var gzipPool = sync.Pool{
	New: func() any {
		w, _ := gzip.NewWriterLevel(nil, gzip.BestSpeed)
		return w
	},
}

// Gzip сжимает JSON/текстовые ответы API, если клиент это поддерживает.
//
// Что НЕ сжимается (намеренно):
//   - маленькие ответы (< 1 КБ);
//   - WebSocket-апгрейды, потоковые тела, ответы 206 и запросы с Range
//     (смещения байтов относятся к несжатому телу);
//   - всё, что не JSON/текст: PDF, изображения, архивы уже сжаты или
//     сжимаются плохо, а CPU на них тратился бы зря;
//   - ответы, у которых уже есть Content-Encoding (статика, отданная
//     предсжатой).
//
// Уровень BestSpeed: для JSON даёт 5–10-кратное уменьшение при минимальной
// нагрузке на процессор — на слабых серверах это важнее лишних процентов.
func Gzip() fiber.Handler {
	return func(c *fiber.Ctx) error {
		if err := c.Next(); err != nil {
			return err
		}
		if c.Method() == fiber.MethodHead || c.Get(fiber.HeaderUpgrade) != "" || c.Get(fiber.HeaderRange) != "" {
			return nil
		}
		if !strings.Contains(c.Get(fiber.HeaderAcceptEncoding), "gzip") {
			return nil
		}
		resp := c.Response()
		if resp.StatusCode() != fiber.StatusOK || resp.IsBodyStream() || len(resp.Header.Peek(fiber.HeaderContentEncoding)) != 0 {
			return nil
		}
		ct := strings.ToLower(string(resp.Header.ContentType()))
		if !strings.HasPrefix(ct, "application/json") && !strings.HasPrefix(ct, "text/") {
			return nil
		}
		body := resp.Body()
		if len(body) < gzipMinSize {
			return nil
		}
		var buf bytes.Buffer
		buf.Grow(len(body) / 4)
		zw := gzipPool.Get().(*gzip.Writer)
		zw.Reset(&buf)
		_, werr := zw.Write(body)
		cerr := zw.Close()
		gzipPool.Put(zw)
		if werr != nil || cerr != nil || buf.Len() >= len(body) {
			return nil // не получилось или не стало меньше — отдаём как есть
		}
		resp.SetBodyRaw(buf.Bytes())
		resp.Header.Set(fiber.HeaderContentEncoding, "gzip")
		resp.Header.Add(fiber.HeaderVary, fiber.HeaderAcceptEncoding)
		return nil
	}
}
