package marking

import (
	"bytes"
	"context"
	"os"
	"strconv"
	"testing"

	"athena/backend/internal/config"
	"github.com/pdfcpu/pdfcpu/pkg/api"
)

func TestMixedPageStamping(t *testing.T) {
	input, err := os.ReadFile("testdata/mixed.pdf")
	if err != nil {
		t.Fatal(err)
	}
	if err := Configure(config.MarkingConfig{PDFCPUConfigRoot: t.TempDir(), FontFile: "../../assets/fonts/LiberationSans-Regular.ttf"}); err != nil {
		t.Fatal(err)
	}
	previous := PageMode()
	defer SetPageMode(previous)
	for _, mode := range []string{"first", "all"} {
		SetPageMode(mode)
		out, err := renderWithPDFCPU(input, []Spec{{Text: "Проверено", Position: "br", FontSize: 12, OffsetX: 24, OffsetY: 24, ColorHex: "#ff0000"}})
		if err != nil {
			t.Fatal(err)
		}
		bounds, err := api.Boxes(context.Background(), bytes.NewReader(out), nil, pdfConfiguration.Clone())
		if err != nil {
			t.Fatal(err)
		}
		sizes := [][2]float64{{595, 842}, {1191, 842}, {842, 595}, {840, 1190}}
		if len(bounds) != len(sizes) {
			t.Fatalf("pages: %d", len(bounds))
		}
		for i, b := range bounds {
			box := b.CropBox()
			w, h := box.Width(), box.Height()
			if b.Rot%180 != 0 {
				w, h = h, w
			}
			if w != sizes[i][0] || h != sizes[i][1] {
				t.Fatalf("%s page %d: %v x %v", mode, i+1, w, h)
			}
		}
		for i := range bounds {
			images, err := api.Images(context.Background(), bytes.NewReader(out), []string{strconv.Itoa(i + 1)}, pdfConfiguration.Clone())
			if err != nil {
				t.Fatal(err)
			}
			hasImage := false
			for _, entries := range images {
				if len(entries) > 0 {
					hasImage = true
				}
			}
			if hasImage != (mode == "all" || i == 0) {
				t.Fatalf("%s page %d: stamped=%t", mode, i+1, hasImage)
			}
		}
	}
}
