package http

import (
	"athena/backend/internal/printspool"
	"context"
	"crypto/subtle"
	"log"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"

	"github.com/gofiber/contrib/websocket"
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/authdom"
	"athena/backend/internal/config"
	"athena/backend/internal/http/handlers"
	appmw "athena/backend/internal/http/middleware"
	"athena/backend/internal/marking"
	"athena/backend/internal/metrics"
	"athena/backend/internal/repository"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

// NewRouter собирает все зависимости (репозитории, сервисы, хендлеры) и
// регистрирует маршруты. Простой ручной DI без фреймворка — достаточно
// для размера этого сервиса и не прячет граф зависимостей.
func NewRouter(cfg config.Config, fileCfg config.FileConfig, pool *pgxpool.Pool) *fiber.App {
	app := fiber.New(fiber.Config{
		AppName:      "athena",
		ErrorHandler: jsonErrorHandler,
		// Разрешаем загрузку крупных PDF (до 64 МБ). При превышении Fiber вернёт
		// 413 — обрабатываем понятным сообщением в jsonErrorHandler.
		BodyLimit: 64 * 1024 * 1024,
	})

	// ВАЖЕН ПОРЯДОК: CORS первым, до recover/logger. Иначе при панике или
	// ошибке ответ уходит без CORS-заголовков, и браузер показывает
	// "CORS error", маскируя реальную 500-ку — типичная ловушка при отладке.
	app.Use(cors.New(cors.Config{
		AllowOrigins: cfg.AllowedOrigins, // напр. "http://localhost:5173,http://127.0.0.1:5173"
		AllowMethods: "GET,POST,PUT,PATCH,DELETE,OPTIONS",
		AllowHeaders: "Origin, Content-Type, Accept, X-CSRF-Token",
	}))
	// #36 — учёт HTTP-запросов (количество, код ответа, длительность).
	// ПОРЯДОК ВАЖЕН: до recover.New(). Тогда паника в обработчике превращается
	// recover'ом в ошибку, которая возвращается нам из c.Next(), и запрос
	// честно учитывается как 500. При регистрации ПОСЛЕ recover паника прошла
	// бы сквозь кадр стека этого middleware, и самые интересные запросы в
	// метрики не попали бы вовсе.
	app.Use(metrics.Middleware(app))
	// Изменяющие запросы и WebSocket принимаются только со страниц этого
	// сервера: сеанс живёт в cookie, и запрос с чужого сайта не должен её
	// использовать (вторая линия — SameSite=Strict и CSRF-заголовок).
	app.Use(appmw.SameOrigin(fileCfg.HTTP.AllowedOrigins))
	app.Use(recover.New())
	app.Use(logger.New())
	// Заголовки безопасности. nginx перед приложением нет, поэтому их ставит
	// само приложение.
	tlsOn := fileCfg.TLSEnabled()
	app.Use(func(c *fiber.Ctx) error {
		c.Set("X-Content-Type-Options", "nosniff")
		c.Set("X-Frame-Options", "SAMEORIGIN")
		c.Set("Referrer-Policy", "same-origin")
		// Скрипты — только свои файлы: внедрённый в страницу чужой сценарий
		// не выполнится. Стили допускают inline (атрибуты style в разметке).
		c.Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; "+
			"style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; "+
			"connect-src 'self' ws: wss:; worker-src 'self' blob:; frame-src 'self' blob:; "+
			"object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'")
		if tlsOn {
			c.Set("Strict-Transport-Security", "max-age=31536000")
		}
		return c.Next()
	})
	// Сжатие JSON-ответов API (gzip, от 1 КБ). Статику и PDF не трогает.
	app.Use(appmw.Gzip())

	// Access-лог в файл (по аналогии с nginx/apache), если задан каталог.
	// Формат combined-подобный: time ip "METHOD url" status bytes dur "login".
	// Пишем В ДОБАВЛЕНИЕ к консольному logger выше. Ротацию оставляем внешним
	// средствам (logrotate) — открываем файл в режиме append.
	if dir := fileCfg.AccessLog.Dir; dir != "" {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			log.Printf("[warn] access-log: не удалось создать каталог %s: %v", dir, err)
		} else {
			logPath := filepath.Join(dir, "access.log")
			f, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
			if err != nil {
				log.Printf("[warn] access-log: не удалось открыть %s: %v", logPath, err)
			} else {
				log.Printf("access-лог запросов пишется в %s", logPath)
				app.Use(logger.New(logger.Config{
					Output: f,
					// ${login} берём из locals (проставляется в JWT-middleware).
					Format:     `${time} ${ip} "${method} ${url}" ${status} ${bytesSent} ${latency} "${locals:login}"` + "\n",
					TimeFormat: "2006-01-02T15:04:05Z07:00",
					TimeZone:   "Local",
				}))
			}
		}
	}

	authSvc := service.NewAuthService(cfg.JWTSecret, cfg.JWTTTL)
	accessSvc := service.NewAccessService()
	approvalSvc := service.NewApprovalService(accessSvc)
	numberingSvc := service.NewNumberingService()
	statusSvc := service.NewStatusService()
	signingSvc := service.NewSigningService(numberingSvc, fileCfg.Signing.Secret)
	documentsSvc := service.NewDocumentsService(accessSvc, approvalSvc)
	incomingSvc := service.NewIncomingService(numberingSvc)
	markingDataSvc := service.NewMarkingDataService()
	// Вжигание штампов в сам PDF (pdfcpu) включается секцией
	// marking.bake_into_pdf.enabled: true (полноценная секция с параметрами:
	// шрифт, цвет/размер/позиция по умолчанию, отступ, прозрачность — как у
	// остальных штампов). По умолчанию выключено: штампы рисуются overlay-слоем
	// на фронте по той же конфигурации. Даже при enabled, если pdfcpu не смог
	// нанести штамп, фронт покажет overlay (см. IsBaking()).
	if fileCfg.Marking.Bake.Enabled {
		if err := marking.Configure(fileCfg.Marking); err != nil {
			log.Fatalf("маркировка PDF: %v", err)
		}
	}
	sendSvc := service.NewSendService(accessSvc)
	executionSvc := service.NewExecutionService()

	docsRepo := repository.NewDocumentsRepo()
	hub := ws.NewHub(pool)
	// Redis pub/sub для межинстансной доставки WS (если задан адрес). Канал
	// по умолчанию — athena_events. Пустой redis_addr = одно-инстансный режим.
	channel := fileCfg.Realtime.EventsChannel
	if channel == "" {
		channel = "athena_events"
	}
	hub.EnableRedis(context.Background(), fileCfg.Realtime.RedisAddr, channel)

	//, п. 9 — журнал аудита. Создаётся ПЕРВЫМ: он нужен и
	// сервису сессий, и middleware, и обработчику входа.
	auditSvc := service.NewAuditService(pool)
	//, п. 8 — единственный сеанс на учётную запись.
	sessionsSvc := service.NewSessionService(pool, fileCfg.SessionConflictPolicy(), auditSvc)

	sealer, err := authdom.NewSealer(fileCfg.Auth.SecretKey)
	if err != nil {
		log.Fatalf("auth.secret_key: %v", err)
	}
	domainStore := authdom.NewStore(pool, sealer)
	appmw.ConfigureAuthPorts(fileCfg.HTTP.KerberosAddr)
	authHandler := handlers.NewAuthHandler(pool, authSvc, sessionsSvc, auditSvc, domainStore)
	authDomainsHandler := handlers.NewAuthDomainsHandler(pool, domainStore)
	auditHandler := handlers.NewAuditHandler(pool, auditSvc)
	sessionsHandler := handlers.NewSessionsHandler(pool, sessionsSvc, auditSvc)
	docsHandler := handlers.NewDocumentsHandler(pool, docsRepo, incomingSvc, markingDataSvc, fileCfg.Marking, cfg.PageSize, cfg.PageSizeMax)
	docsHandler.SetHub(hub)
	docCreateHandler := handlers.NewDocumentCreateHandler(pool, documentsSvc, hub, fileCfg.Uploads.MaxPDFBytes())
	approvalHandler := handlers.NewApprovalHandler(pool, approvalSvc, statusSvc, signingSvc, hub)
	handlers.SetSignatureVerifier(signingSvc.VerifySignature)
	usersHandler := handlers.NewUsersHandler(pool)
	sendHandler := handlers.NewSendHandler(pool, sendSvc, hub)
	executionHandler := handlers.NewExecutionHandler(pool, executionSvc, hub)
	notificationsHandler := handlers.NewNotificationsHandler(pool)
	favoritesHandler := handlers.NewFavoritesHandler(pool)
	passwordHandler := handlers.NewPasswordHandler(pool)
	registryHandler := handlers.NewRegistryHandler(pool)
	linksHandler := handlers.NewLinksHandler(pool)
	// Резолюции руководителя и переназначение исполнителей. Делегирование
	// полномочий и штатное расписание удалены.
	resolutionsHandler := handlers.NewResolutionsHandler(pool, hub)
	// Версии карточки и файла; предупреждение о повторной регистрации;
	// отчётность.
	versionsHandler := handlers.NewVersionsHandler(pool)
	duplicatesHandler := handlers.NewDuplicatesHandler(pool)
	reportsHandler := handlers.NewReportsHandler(pool, fileCfg.Branding.AppName)
	acquaintHandler := handlers.NewAcquaintanceHandler(pool, hub)
	chatHandler := handlers.NewChatHandler(pool, hub)
	adminHandler := handlers.NewAdminHandler(pool, service.NewAdminService())
	groupsHandler := handlers.NewGroupsHandler(pool)
	categoriesHandler := handlers.NewCategoriesHandler(pool)
	// #26 — справочник особых отметок; #3 — настройки пользователя;
	// #4 — состояние фоновой индексации содержимого PDF.
	specialMarksHandler := handlers.NewSpecialMarksHandler(pool)
	sysSettingsHandler := handlers.NewSystemSettingsHandler(pool)
	historyHandler := handlers.NewHistoryHandler(pool)
	sysSettingsHandler.LoadMarkingPageMode(context.Background())
	sysSettingsHandler.StartMarkingPageModeSync(context.Background(), 5*time.Second)
	preferencesHandler := handlers.NewPreferencesHandler(pool)
	dashboardHandler := handlers.NewDashboardHandler(pool, fileCfg.Approval.StageReminderDays)
	adminDashHandler := handlers.NewAdminDashboardHandler(pool)
	searchHandler := handlers.NewSearchHandler(pool)

	api := app.Group("/api")
	// Публичный конфиг брендинга (название системы + подзаголовок) — доступен
	// до авторизации, чтобы страница входа тоже показывала настроенное имя.
	appName := fileCfg.Branding.AppName
	tagline := fileCfg.Branding.Tagline
	copyright := fileCfg.Branding.Copyright
	about := fileCfg.Branding.About
	api.Get("/app-config", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"app_name": appName, "tagline": tagline, "copyright": copyright, "about": about,
			// Предел размера файла нужен форме ДО выбора файла: пользователя
			// надо предупредить заранее, а не отказом после загрузки.
			"max_pdf_bytes": fileCfg.Uploads.MaxPDFBytes()})
	})
	api.Post("/auth/login", authHandler.Login)
	// Сведения для страницы входа и вход по Kerberos (только на своём порту).
	api.Get("/auth/info", authHandler.AuthInfo(fileCfg))
	api.Get("/auth/kerberos", authHandler.KerberosLogin)

	appmw.ConfigureClientIP(fileCfg.HTTP.TrustedProxies, fileCfg.HTTP.ClientIPHeader)
	protected := api.Group("", appmw.JWTAuth(authSvc), appmw.CSRF())
	// Права администратора берутся из БД (с коротким кэшем), а не из токена:
	// смена роли применяется без перелогина.
	protected.Use(appmw.FreshUser(pool))
	// Архивный документ — только для чтения (кроме ознакомления).
	protected.Use(appmw.ArchiveGuard(pool))
	// Предел частоты обращений. Стоит ПОСЛЕ JWTAuth намеренно: только здесь
	// известен пользователь, а считать надо по нему, а не по адресу — за NAT
	// у целого подразделения адрес один, и общий предел они выбирали бы
	// втроём на всех. По умолчанию выключен (http.rate_limit.requests_per_second: 0).
	protected.Use(appmw.RateLimit(
		fileCfg.HTTP.RateLimit.RequestsPerSecond,
		fileCfg.HTTP.RateLimit.Burst,
	))
	// Отметка последней активности — для раздела «кто в системе сейчас» в
	// админ-дашборде. Пишется не чаще раза в минуту на пользователя
	// (см. middleware/lastseen.go), поэтому на нагрузку не влияет.
	protected.Use(appmw.LastSeen(pool))
	//, п. 8 — проверка, что сеанс не вытеснен и не завершён.
	// Стоит СРАЗУ после JWTAuth: все дальнейшие обработчики должны работать
	// только в живом сеансе, иначе вытесненное рабочее место продолжало бы
	// действовать до истечения срока токена.
	// Проверяется всегда, а не только при запрете одновременного входа:
	// иначе выход и смена пароля не отзывали бы сеанс.
	protected.Use(appmw.SessionGuard(sessionsSvc, auditSvc))
	//, п. 9 — журнал аудита. Выключателя нет: middleware
	// подключается всегда и для всех защищённых маршрутов. Что именно
	// попадает в журнал — см. middleware/audit.go (изменяющие запросы, события
	// входа, отказы, чтение и скачивание документов; служебные опросы — нет).
	protected.Use(appmw.Audit(auditSvc))
	// Единая проверка видимости документа для всех /documents/:id/… —
	// до любого обработчика (см. middleware/docguard.go).
	protected.Use("/documents/:id", appmw.DocumentGuard(pool))
	protected.Post("/auth/refresh", authHandler.Refresh)
	protected.Post("/auth/logout", authHandler.Logout)

	// Журнал аудита и сеансы.
	protected.Get("/audit", auditHandler.List)
	protected.Get("/audit/events", auditHandler.Events)
	protected.Get("/audit/export", auditHandler.Export)
	// п. 13 — размер журнала и удаление за период. Удаление — единственная
	// дверь в неизменяемом журнале; почему она сделана именно так, подробно
	// объяснено в handlers/audit.go и в миграции 0024.
	protected.Get("/audit/size", auditHandler.Size)
	protected.Delete("/audit", auditHandler.Purge)
	protected.Get("/sessions", sessionsHandler.List)
	protected.Delete("/sessions/:id", sessionsHandler.Revoke)
	protected.Get("/me", authHandler.Me)

	// --- Администрирование (только для admin; проверка внутри хендлеров) ---
	admin := protected.Group("/admin")
	admin.Get("/departments", adminHandler.ListDepartments)
	admin.Post("/departments", adminHandler.CreateDepartment)
	admin.Patch("/departments/:id", adminHandler.UpdateDepartment)
	admin.Patch("/departments/:id/parent", adminHandler.MoveDepartment)
	admin.Delete("/departments/:id", adminHandler.DeleteDepartment)
	admin.Get("/users", adminHandler.ListUsers)
	admin.Post("/users", adminHandler.CreateUser)
	admin.Patch("/users/:id", adminHandler.UpdateUser)
	admin.Patch("/users/:id/department", adminHandler.MoveUser)
	admin.Patch("/users/:id/departments", adminHandler.SetUserDepartments)
	admin.Patch("/users/:id/password", adminHandler.SetUserPassword)
	// Домены аутентификации: несколько LDAP и Kerberos, управление через веб.
	admin.Get("/auth-domains", authDomainsHandler.List)
	admin.Post("/auth-domains", authDomainsHandler.Create)
	admin.Put("/auth-domains/:id", authDomainsHandler.Update)
	admin.Delete("/auth-domains/:id", authDomainsHandler.Delete)
	admin.Put("/auth-domains/:id/keytab", authDomainsHandler.UploadKeytab)
	admin.Delete("/auth-domains/:id/keytab", authDomainsHandler.DeleteKeytab)
	admin.Post("/auth-domains/:id/test", authDomainsHandler.Test)
	admin.Patch("/users/:id/roles", adminHandler.SetUserRoles)
	// #4 — Группы адресатов рассылки (CRUD только admin).
	admin.Post("/recipient-groups", groupsHandler.Create)
	admin.Patch("/recipient-groups/:id", groupsHandler.Update)
	admin.Delete("/recipient-groups/:id", groupsHandler.Delete)
	admin.Put("/recipient-groups/:id/members", groupsHandler.SetMembers)
	// #6 — категории документов (CRUD только admin).
	admin.Post("/categories", categoriesHandler.Create)
	admin.Patch("/categories/:id", categoriesHandler.Update)
	admin.Delete("/categories/:id", categoriesHandler.Delete)
	// #26 — особые отметки управляются из админки.
	// #10 — технический дашборд состояния системы (только администратор).
	// Не путать с app.Get("/metrics") для Prometheus: тот без префикса /api
	// и без авторизации, этот — внутри /api/admin и под проверкой роли.
	admin.Get("/metrics", adminDashHandler.Metrics)
	admin.Get("/settings/marking", sysSettingsHandler.GetMarking)
	admin.Put("/settings/marking", sysSettingsHandler.PutMarking)
	admin.Post("/special-marks", specialMarksHandler.Create)
	admin.Patch("/special-marks/:id", specialMarksHandler.Update)
	admin.Delete("/special-marks/:id", specialMarksHandler.Delete)
	protected.Get("/documents", docsHandler.List)
	protected.Post("/documents", docCreateHandler.Create)
	// /documents/search ДО /documents/:id — иначе роутер примет "search" за
	// значение параметра :id (статичный сегмент должен матчиться первым).
	// #41 — количество документов по категориям бокового меню. Объявляется ДО
	// параметрических маршрутов /documents/:id, иначе Fiber разберёт
	// "category-counts" как значение :id.
	protected.Get("/documents/category-counts", docsHandler.CategoryCounts)
	protected.Get("/documents/search", docsHandler.Search)
	protected.Get("/documents/:id", docsHandler.Get)
	protected.Get("/documents/:id/file", docsHandler.GetFile)
	protected.Get("/documents/:id/marking", docsHandler.GetMarking)
	protected.Get("/documents/:id/stages", docsHandler.GetStages)
	protected.Post("/documents/:id/stages/:stageId/decide", approvalHandler.Decide)
	protected.Post("/documents/:id/send", sendHandler.Send)
	// Отметка об исполнении: простановка, изменение и отмена (,
	// пп. 21 и 22). Состояние отметки и перечень доступных действий отдаёт
	// сервер (GET), чтобы интерфейс не решал этот вопрос сам — именно из-за
	// такого «решал сам» отметка и не работала для того, кто не адресат.
	protected.Get("/documents/:id/execution", executionHandler.Status)
	protected.Post("/documents/:id/complete", executionHandler.Complete)
	protected.Patch("/documents/:id/complete", executionHandler.ChangeMark)
	protected.Delete("/documents/:id/complete", executionHandler.CancelMark)
	protected.Get("/documents/:id/recipients", sendHandler.Recipients)
	protected.Delete("/documents/:id/recipients/:recipientId", sendHandler.DeleteRecipient)
	protected.Get("/documents/:id/history", docsHandler.History)
	// #13 — /documents/:id/views убран: данные просмотров отдаются в составе
	// /documents/:id/copies.
	protected.Post("/documents/:id/control", docsHandler.SetControl)
	protected.Post("/documents/:id/archive", docsHandler.Archive)
	protected.Get("/documents/:id/controllers", docsHandler.Controllers)
	protected.Get("/documents/:id/signatures", docsHandler.Signatures)
	protected.Get("/default-controllers", docsHandler.DefaultControllers)
	protected.Get("/documents/:id/my-roles", docsHandler.MyRoles)
	protected.Patch("/documents/:id", docCreateHandler.Update)
	protected.Patch("/documents/:id/file", docCreateHandler.ReplaceFile)
	protected.Delete("/documents/:id", docCreateHandler.Delete)
	protected.Patch("/documents/:id/route", docCreateHandler.UpdateRoute)
	protected.Put("/documents/:id/signers", docCreateHandler.UpdateSigners)
	protected.Patch("/documents/:id/planned-recipients", docCreateHandler.UpdatePlannedRecipients)
	// Дашборд пользователя удалён: сводка по статусам дублировала счётчики
	// категорий в боковом меню, а действовать по ней было нельзя.
	// Админ-дашборд (/api/admin/metrics) — отдельная страница и остаётся.
	protected.Get("/registry/archive/years", registryHandler.ArchiveYears)
	protected.Get("/registry/archive/:year", registryHandler.ArchiveByYear)
	protected.Get("/registry/:kind", registryHandler.List)
	// Выгрузка журнала в Excel выключена по умолчанию (registry.export_enabled):
	// кнопки в интерфейсе нет, а прямой запрос получает отказ.
	protected.Get("/registry/:kind/export", func(c *fiber.Ctx) error {
		if !fileCfg.Registry.ExportEnabled {
			return fiber.NewError(fiber.StatusForbidden, "выгрузка журналов отключена администратором")
		}
		return registryHandler.Export(c)
	})
	protected.Get("/recipients-counts", sendHandler.RecipientsCounts)
	protected.Get("/documents/:id/copies", docsHandler.Copies)
	// #17 — счётчики для подписей вкладок (сообщения, файлы, экземпляры, …).
	protected.Get("/documents/:id/counts", docsHandler.Counts)
	// Избранное («звёздочка») — личный список каждого пользователя.
	protected.Post("/documents/:id/favorite", favoritesHandler.Add)
	protected.Delete("/documents/:id/favorite", favoritesHandler.Remove)

	// Печать: скачивание на печать (только роль printer, только маркированный
	// PDF), реестр скачиваний и регистрация распечатанного экземпляра.
	printSpool, err := printspool.New(fileCfg.Print.SpoolDir, time.Duration(fileCfg.Print.MaxAgeSeconds)*time.Second)
	if err != nil {
		log.Fatalf("печать: %v", err)
	}
	printSpool.StartJanitor(context.Background())
	log.Printf("печать: файлы выдачи — через %s (удаляются сразу после отдачи)", printSpool.Dir())
	printsHandler := handlers.NewPrintsHandler(pool, markingDataSvc, fileCfg.Marking, printSpool)
	protected.Post("/documents/:id/print", printsHandler.Download)
	protected.Get("/documents/:id/print-diagnostics", printsHandler.Diagnostics)
	protected.Get("/documents/:id/prints", printsHandler.List)
	protected.Patch("/documents/:id/prints/:printId/register", printsHandler.Register)
	protected.Get("/documents/:id/links", linksHandler.List)
	protected.Post("/documents/:id/links", linksHandler.Create)
	protected.Delete("/documents/:id/links/:linkId", linksHandler.Delete)
	// Резолюции руководителя (, п. 3). Прежние маршруты
	// /assignments удалены вместе с таблицей: два механизма поручений
	// означали бы вечный вопрос, в каком из них правда.
	protected.Get("/documents/:id/resolutions", resolutionsHandler.List)
	protected.Post("/documents/:id/resolutions", resolutionsHandler.Create)
	protected.Put("/resolutions/:id", resolutionsHandler.Edit)
	// Маршрутов «отменить резолюцию», «переназначить» и журнала
	// переназначений больше нет: резолюция накладывается по документу один
	// раз, и ветвления, которое они создавали, в работе не осталось.
	// Обработчики удалены вместе с маршрутами, чтобы не оставлять мёртвый код.
	protected.Post("/resolutions/:id/progress", resolutionsHandler.Progress)
	protected.Post("/resolutions/:id/report", resolutionsHandler.Report)
	protected.Post("/resolutions/:id/accept", resolutionsHandler.Accept)
	protected.Post("/resolutions/:id/return", resolutionsHandler.Return)
	protected.Post("/resolutions/:id/cancel", resolutionsHandler.Cancel)
	protected.Post("/resolutions/:id/reassign", resolutionsHandler.Reassign)
	protected.Get("/my/resolutions", resolutionsHandler.My)

	// Журнал переназначений исполнителей резолюций. Делегирование полномочий
	// удалено («убрать делегирование полномочий, сейчас
	// не работает»), а переназначение осталось: это другая и работающая вещь.

	// Версионность карточек и вложений.
	//
	// Маршрута скачивания версии файла здесь больше НЕТ (, п. 7 —
	// «версии файла документа нельзя скачивать!»). Он удалён, а не скрыт в
	// интерфейсе: скрытая кнопка оставляет работающий путь, который
	// открывается прямой ссылкой, и запрет был бы мнимым. Перечень версий
	// (кто, когда, хэш) остаётся — он нужен при разборе и ничего не выдаёт.
	protected.Get("/documents/:id/versions", versionsHandler.List)

	// Предотвращение повторной регистрации (, п. 6).
	//
	// Отдельный префикс /registration, а НЕ /documents/check-duplicate:
	// маршрут GET /documents/:id уже зарегистрирован выше, и Fiber сопоставил
	// бы «check-incoming-number» с параметром :id — обработчик документа
	// получил бы нечисловой идентификатор и ответил 400. Разводить это
	// порядком регистрации хрупко: любая перестановка строк снова всё сломает.
	protected.Post("/registration/check-duplicate", duplicatesHandler.Check)
	protected.Get("/registration/check-incoming-number", duplicatesHandler.CheckIncomingNumber)

	// Отчётность: по документу (п. 5) и сводная по исполнительской дисциплине
	// за период (п. 7). Сводная требует роли reporter или admin — проверка
	// внутри обработчика, т.к. она зависит от выбранного подразделения.
	protected.Get("/documents/:id/report", reportsHandler.DocumentReport)
	protected.Get("/documents/:id/report.pdf", reportsHandler.DocumentReportPDF)
	// Сводной отчётности (дисциплина исполнения, область отчётности) больше
	// нет: раздел ничего не показывал, и по решению заказчика оставлен
	// только отчёт по конкретному документу. Обработчики удалены вместе с
	// маршрутами, чтобы не оставлять мёртвый код.

	// Маршрутов штатного расписания здесь больше нет (// «убрать штатное расписание»). Должность пользователя осталась обычным
	// полем его карточки (users.position) и правится в админке вместе с
	// остальными его данными.
	protected.Get("/documents/:id/acquaintances", acquaintHandler.List)
	protected.Post("/documents/:id/acquaint", acquaintHandler.Create)
	protected.Get("/acquaint-candidates", acquaintHandler.Candidates)
	protected.Get("/documents/:id/chat", chatHandler.History)
	protected.Post("/documents/:id/chat", chatHandler.Post)
	protected.Get("/chat/attachments/:aid", chatHandler.Attachment)
	protected.Patch("/chat/messages/:mid", chatHandler.EditMessage)
	protected.Delete("/chat/messages/:mid", chatHandler.DeleteMessage)
	// Самостоятельная смена пароля.
	protected.Get("/password/requirements", passwordHandler.Requirements)
	protected.Post("/password", passwordHandler.Change)
	protected.Get("/notifications", notificationsHandler.List)
	// #2 — уведомления-будильники и «отложить». Статические маршруты
	// объявляются ДО параметрических с тем же префиксом, иначе Fiber разберёт
	// "alarms" и "read-all" как значение :id.
	protected.Get("/notifications/alarms", notificationsHandler.Alarms)
	// Отложить ВСЕ показанные будильники одним действием: иначе окно не
	// закрывается с первого нажатия (см. SnoozeAll).
	protected.Post("/notifications/snooze-all", notificationsHandler.SnoozeAll)
	protected.Post("/notifications/read-all", notificationsHandler.MarkAllRead)
	protected.Post("/notifications/:id/read", notificationsHandler.MarkRead)
	protected.Post("/notifications/:id/snooze", notificationsHandler.Snooze)
	protected.Get("/users", usersHandler.List)
	protected.Get("/users/candidates", usersHandler.Candidates)
	// #28 — люди для ФИЛЬТРОВ поиска: без ограничения иерархией и ролью,
	// включая уволенных (их документы никуда не делись). См. filter_people.go.
	protected.Get("/users/filter-candidates", usersHandler.FilterPeople)
	protected.Get("/departments", usersHandler.Departments)
	// #4 — Список групп адресатов (с составом) для формы рассылки.
	protected.Get("/recipient-groups", groupsHandler.List)
	protected.Get("/categories", categoriesHandler.List)
	// #26 — список особых отметок нужен формам и фильтрам всем пользователям.
	protected.Get("/special-marks", specialMarksHandler.List)
	protected.Get("/history", historyHandler.Global)
	// #4 — прогресс индексации для прелоадера рядом с поиском по содержимому.
	protected.Get("/search/index-status", searchHandler.IndexStatus)
	// #3 — состояние фильтров и прочие личные настройки интерфейса.
	// Сводная панель руководителя — по документам, доступным пользователю.
	protected.Get("/dashboard", dashboardHandler.Get)
	protected.Get("/preferences/:key", preferencesHandler.Get)
	protected.Put("/preferences/:key", preferencesHandler.Put)
	protected.Delete("/preferences/:key", preferencesHandler.Delete)

	// WebSocket: сеанс — из той же cookie, что и у API (браузер отправляет
	// её при открытии соединения); источник проверен SameOrigin выше.
	app.Use("/ws", func(c *fiber.Ctx) error {
		if websocket.IsWebSocketUpgrade(c) {
			return c.Next()
		}
		return fiber.ErrUpgradeRequired
	})
	wsAuth := func(c *fiber.Ctx) error {
		claims, err := authSvc.ParseToken(appmw.SessionToken(c))
		if err != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "требуется вход в систему")
		}
		if _, err := sessionsSvc.Check(c.Context(), claims.UserID, claims.ID); err != nil {
			return fiber.NewError(fiber.StatusUnauthorized, "сеанс завершён")
		}
		c.Locals("ws_user_id", claims.UserID)
		c.Locals("ws_is_admin", claims.IsAdmin)
		return c.Next()
	}
	app.Get("/ws/documents/:id/chat", wsAuth, websocket.New(ws.ChatWSHandler(hub)))
	app.Get("/ws/notifications", wsAuth, websocket.New(ws.NotificationsWSHandler(hub)))

	// Метрики Prometheus. Если задан metrics.token — по «Authorization:
	// Bearer <token>»; иначе только с этого же компьютера.
	metricsHandler := metrics.Handler()
	app.Get("/metrics", func(c *fiber.Ctx) error {
		if tok := fileCfg.Metrics.Token; tok != "" {
			if subtle.ConstantTimeCompare([]byte(c.Get(fiber.HeaderAuthorization)), []byte("Bearer "+tok)) != 1 {
				return fiber.ErrUnauthorized
			}
		} else if ip := c.Context().RemoteIP(); ip == nil || !ip.IsLoopback() {
			return fiber.ErrForbidden
		}
		return metricsHandler(c)
	})

	app.Get("/healthz", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"status": "ok"})
	})

	// --- Раздача статики фронтенда (SPA) одним приложением, без nginx ---
	// Явный обработчик (надёжнее filesystem-middleware и логируется): для
	// каждого GET-пути, не относящегося к /api|/ws|/healthz, отдаём файл из
	// каталога сборки, а если файла нет — index.html (клиентский роутинг).
	// Регистрируется ПОСЛЕ всех /api и /ws — они имеют приоритет.
	if dir := fileCfg.Static.Dir; dir != "" {
		absDir, _ := filepath.Abs(dir)
		indexPath := filepath.Join(dir, "index.html")
		if _, err := os.Stat(indexPath); err != nil {
			log.Printf("[warn] статика: %s не найден (%v) — проверьте static.dir/STATIC_DIR", indexPath, err)
		} else {
			log.Printf("статика фронтенда раздаётся из %s", absDir)
		}
		app.Get("/*", func(c *fiber.Ctx) error {
			p := c.Path()
			if strings.HasPrefix(p, "/api") || strings.HasPrefix(p, "/ws") || p == "/healthz" || strings.HasPrefix(p, "/metrics") {
				return fiber.ErrNotFound
			}
			// Защита от path traversal: чистим путь и приклеиваем к каталогу.
			rel := filepath.Clean("/" + strings.TrimPrefix(p, "/"))
			candidate := filepath.Join(dir, rel)
			if st, err := os.Stat(candidate); err == nil && !st.IsDir() {
				return sendStatic(c, candidate, rel)
			}
			// Файл не найден — SPA-fallback на index.html. Но для запроса
			// ресурса с расширением (js/css/png…) отдавать HTML нельзя: браузер
			// закэширует «страницу вместо скрипта» и приложение сломается до
			// очистки кэша. Для таких путей честный 404.
			if path.Ext(rel) != "" && path.Ext(rel) != ".html" {
				return fiber.ErrNotFound
			}
			return sendStatic(c, indexPath, "/index.html")
		})
	} else {
		log.Println("статика фронтенда отключена (static.dir пуст) — режим только API")
	}

	return app
}

// staticTypes — типы содержимого для файлов, которые отдаём предсжатыми:
// у «file.js.br» расширение .br, и по нему тип не определить.
var staticTypes = map[string]string{
	".js":   "text/javascript; charset=utf-8",
	".mjs":  "text/javascript; charset=utf-8",
	".css":  "text/css; charset=utf-8",
	".html": "text/html; charset=utf-8",
	".svg":  "image/svg+xml",
	".json": "application/json; charset=utf-8",
	".txt":  "text/plain; charset=utf-8",
	".map":  "application/json; charset=utf-8",
	".woff": "font/woff",
	".ttf":  "font/ttf",
}

// sendStatic отдаёт файл сборки фронтенда с правильными заголовками кэша и,
// если рядом лежит предсжатый вариант (.br или .gz, их создаёт сборка
// фронтенда), — его, в зависимости от Accept-Encoding клиента.
//
//   - /assets/* — имя содержит хеш содержимого, поэтому кэшируется на год
//     и без перепроверки (immutable);
//   - index.html и sw.js — no-cache: браузер каждый раз спрашивает «не
//     изменилось ли?» (ответ 304 без тела), так новая версия подхватывается
//     сразу после выкладки;
//   - прочее (иконки, шрифты вне /assets) — час.
func sendStatic(c *fiber.Ctx, file, rel string) error {
	ext := strings.ToLower(path.Ext(rel))
	switch {
	case strings.HasPrefix(rel, "/assets/"):
		c.Set(fiber.HeaderCacheControl, "public, max-age=31536000, immutable")
	case rel == "/index.html" || rel == "/sw.js":
		c.Set(fiber.HeaderCacheControl, "no-cache")
	default:
		c.Set(fiber.HeaderCacheControl, "public, max-age=3600")
	}
	ct, compressible := staticTypes[ext]
	if compressible {
		c.Append(fiber.HeaderVary, fiber.HeaderAcceptEncoding)
		ae := c.Get(fiber.HeaderAcceptEncoding)
		for _, v := range []struct{ enc, suffix string }{{"br", ".br"}, {"gzip", ".gz"}} {
			if !acceptsEncoding(ae, v.enc) {
				continue
			}
			if st, err := os.Stat(file + v.suffix); err == nil && !st.IsDir() {
				if err := c.SendFile(file+v.suffix, false); err != nil {
					return err
				}
				c.Set(fiber.HeaderContentType, ct)
				c.Set(fiber.HeaderContentEncoding, v.enc)
				return nil
			}
		}
	}
	return c.SendFile(file, false)
}

// acceptsEncoding — есть ли кодирование в Accept-Encoding (q=0 считается
// запретом).
func acceptsEncoding(header, enc string) bool {
	for _, part := range strings.Split(header, ",") {
		name, params, _ := strings.Cut(strings.TrimSpace(part), ";")
		if strings.EqualFold(strings.TrimSpace(name), enc) {
			return !strings.Contains(strings.ReplaceAll(params, " ", ""), "q=0") || strings.Contains(strings.ReplaceAll(params, " ", ""), "q=0.")
		}
	}
	return false
}

func jsonErrorHandler(c *fiber.Ctx, err error) error {
	code := fiber.StatusInternalServerError
	message := "внутренняя ошибка сервера"
	if fe, ok := err.(*fiber.Error); ok {
		code = fe.Code
		message = fe.Message
	}
	// Понятные пояснения для типовых кодов (файл слишком большой и т.п.).
	switch code {
	case fiber.StatusRequestEntityTooLarge:
		message = "файл слишком большой (превышен лимит загрузки 64 МБ)"
	case fiber.StatusUnsupportedMediaType:
		message = "неподдерживаемый тип файла (принимается только PDF)"
	case fiber.StatusUnauthorized:
		if message == "" || message == "Unauthorized" {
			message = "требуется вход в систему (сессия истекла)"
		}
	case fiber.StatusRequestTimeout, fiber.StatusServiceUnavailable:
		if message == "" {
			message = "сервис временно недоступен, повторите попытку"
		}
	}
	return c.Status(code).JSON(fiber.Map{"error": message})
}
