import { useMemo, useState } from 'react';
import { api } from '../../lib/api';
import { invalidate } from '../../lib/query';
import { toast, useStore } from '../../lib/store';
import { Btn, Field, Input, Modal, Select, Switch, Textarea, UserPicker, type UserLite } from '../../ui';
import { useDepartments, flattenDepts } from '../../ui/DeptSelect';
import { plural } from '../../lib/util';
import { errMsg, useAudiences } from './common';

/** Мультивыбор подразделений (строго выбранные, без учёта вложенности). */
export function DeptMulti({ value, onChange }: { value: number[]; onChange: (v: number[]) => void }) {
  const { data } = useDepartments();
  const [q, setQ] = useState('');
  const rows = useMemo(() => flattenDepts(data || []), [data]);
  const shown = rows.filter((r) => !q.trim() || r.name.toLowerCase().includes(q.trim().toLowerCase()));
  const toggle = (id: number) => onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  return (
    <div className="stackS">
      <Input placeholder="Найти подразделение…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="deptMulti" role="group" aria-label="Подразделения">
        {shown.map((r) => (
          <label key={r.id} className="chk" style={{ paddingLeft: q ? 0 : r.depth * 16 }}>
            <input type="checkbox" checked={value.includes(r.id)} onChange={() => toggle(r.id)} /> {r.name}
          </label>
        ))}
        {!shown.length && <div className="small muted">Ничего не найдено</div>}
      </div>
      {value.length > 0 && <div className="tiny muted">Выбрано: {plural(value.length, ['подразделение', 'подразделения', 'подразделений'])} <button type="button" className="linkBtn" onClick={() => onChange([])}>сбросить</button></div>}
    </div>
  );
}

/** Дружелюбная форма аудитории: без JSON. Правила собираются из полей. */
export function AudienceForm({ item, onClose, onSaved }: { item?: any; onClose: () => void; onSaved?: (id: number) => void }) {
  const r = item?.rules || {};
  const [name, setName] = useState<string>(item?.name || '');
  const [desc, setDesc] = useState<string>(item?.description || '');
  const [depts, setDepts] = useState<number[]>((r.departments || []).map(Number));
  const [subtree, setSubtree] = useState<boolean>(r.subtree ?? false);
  const [users, setUsers] = useState<UserLite[]>(r.users_info || []);
  const [titles, setTitles] = useState<string>((r.job_titles || []).join(', '));
  const [newbies, setNewbies] = useState<boolean>(!!r.newbies);
  const [all, setAll] = useState<boolean>(!!r.all);
  const [busy, setBusy] = useState(false);
  const rules = useMemo(() => {
    const o: any = {};
    if (all) o.all = true;
    if (depts.length) { o.departments = depts; o.subtree = subtree; }
    if (users.length) { o.users = users.map((u) => u.id); o.users_info = users.map((u) => ({ id: u.id, name: u.name })); }
    const jt = titles.split(',').map((x) => x.trim()).filter(Boolean);
    if (jt.length) o.job_titles = jt;
    if (newbies) o.newbies = true;
    return o;
  }, [all, depts, subtree, users, titles, newbies]);
  const [prev, setPrev] = useState<any>(null);
  async function check() { try { setPrev(await api.post('/api/audiences/preview', { rules })); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function save() {
    if (!name.trim()) return toast({ title: 'Укажите название аудитории', kind: 'error' });
    if (!Object.keys(rules).length) return toast({ title: 'Выберите, кто входит в аудиторию', kind: 'error' });
    setBusy(true);
    try {
      const body = { name: name.trim(), description: desc, rules };
      const res: any = item?.id ? await api.put('/api/audiences/' + item.id, body) : await api.post('/api/audiences', body);
      invalidate('audiences'); onSaved?.(res?.id ?? item?.id); onClose();
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <Modal title={item?.id ? 'Аудитория: ' + item.name : 'Новая аудитория'} onClose={onClose} size="lg"
      footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      <div className="stack">
        <Field label="Название"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Например: Новички отдела продаж" maxLength={120} /></Field>
        <Field label="Описание"><Textarea rows={2} value={desc} onChange={(e) => setDesc(e.target.value)} /></Field>
        <Switch checked={all} onChange={setAll} label="Все сотрудники компании" />
        {!all && <>
          <Field label="Подразделения"><DeptMulti value={depts} onChange={setDepts} /></Field>
          {depts.length > 0 && <Switch checked={subtree} onChange={setSubtree} label="Включая вложенные подразделения" />}
          <Field label="Конкретные сотрудники"><UserPicker value={users} onChange={setUsers} /></Field>
          <Field label="Должности" hint="Через запятую; подходит любое совпадение части названия"><Input value={titles} onChange={(e) => setTitles(e.target.value)} placeholder="менеджер, аналитик" /></Field>
          <Switch checked={newbies} onChange={setNewbies} label="Только новички (до 90 дней в компании)" />
        </>}
        <div className="row"><Btn onClick={check}>Проверить состав</Btn>
          {prev && <span className="small">Подходит: <b>{plural(prev.total, ['сотрудник', 'сотрудника', 'сотрудников'])}</b>{prev.sample?.length ? ' — например: ' + prev.sample.map((u: any) => u.name).join(', ') : ''}</span>}</div>
      </div>
    </Modal>
  );
}

export interface TargetValue { depts: number[]; users: UserLite[]; audience: number | null; mustRead: boolean; due: string }

/** Адресация публикации: всем / выбранным подразделениям и людям / готовой аудитории + «обязательно к прочтению». */
export function TargetingBox({ value, onChange }: { value: TargetValue; onChange: (p: Partial<TargetValue>) => void }) {
  const me = useStore((s) => s.me)!;
  const a = useAudiences();
  const [mk, setMk] = useState(false);
  const targeted = value.depts.length > 0 || value.users.length > 0 || value.audience != null;
  const [mode, setMode] = useState<'all' | 'pick'>(targeted ? 'pick' : 'all');
  const cur = a.data?.find((x) => x.id === value.audience);
  const canMake = me.role === 'admin' || me.hr_admin;
  return (
    <div className="tzTarget">
      <div className="small bold">Кому показывать</div>
      <Select value={mode} onChange={(e) => { const m = e.target.value as 'all' | 'pick'; setMode(m); if (m === 'all') onChange({ depts: [], users: [], audience: null }); }} aria-label="Адресаты">
        <option value="all">Всем сотрудникам</option>
        <option value="pick">Выбрать подразделения, сотрудников или аудиторию…</option>
      </Select>
      {mode === 'pick' && (
        <div className="stack">
          <Field label="Подразделения" hint="Только выбранные, вложенные не учитываются"><DeptMulti value={value.depts} onChange={(v) => onChange({ depts: v })} /></Field>
          <Field label="Сотрудники"><UserPicker value={value.users} onChange={(v) => onChange({ users: v })} /></Field>
          <Field label="Готовая аудитория">
            <div className="row">
              <Select value={value.audience ?? ''} onChange={(e) => onChange({ audience: e.target.value ? +e.target.value : null })} aria-label="Аудитория">
                <option value="">— не использовать —</option>
                {(a.data || []).map((x) => <option key={x.id} value={x.id}>{x.name} · {plural(x.size, ['человек', 'человека', 'человек'])}</option>)}
              </Select>
              {canMake && <Btn type="button" onClick={() => setMk(true)}>Создать…</Btn>}
            </div>
          </Field>
          {cur?.description && <div className="tiny muted">{cur.description}</div>}
          <div className="tiny muted">Видят публикацию: сотрудники выбранных подразделений, названные сотрудники и участники аудитории.</div>
        </div>
      )}
      <Switch checked={value.mustRead} onChange={(v) => onChange({ mustRead: v })} label="Обязательно к прочтению (с подтверждением ознакомления)" />
      {value.mustRead && <Field label="Ознакомиться до"><Input type="date" value={value.due} onChange={(e) => onChange({ due: e.target.value })} /></Field>}
      {mk && <AudienceForm onClose={() => setMk(false)} onSaved={(id) => { setMode('pick'); onChange({ audience: id }); }} />}
    </div>
  );
}
