import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../api/client'
import ThemeSwitcher from '../components/ThemeSwitcher'
import { loaders } from '../lazy-routes'
import ParticleButton from '../components/kokonutui/particle-button'
import { mix } from '../lib/colorMix'

export default function LoginPage() {
  const { doLogin } = useAuth()
  const navigate = useNavigate()
  const [login, setLogin] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [status, setStatus] = useState('idle') // idle | pending | success | error
  // Режим порта и домены. На порту Kerberos страница входа по паролю не
  // показывается вовсе — сразу уходим на /sso. На порту пароля показываем
  // выбор домена (LDAP) и ссылку на порт Kerberos.
  const [info, setInfo] = useState(null)
  const [domain, setDomain] = useState('')
  useEffect(() => {
    api.authInfo().then((r) => {
      if (r?.mode === 'kerberos') { navigate('/sso', { replace: true }); return }
      setInfo(r)
    }).catch(() => {})
  }, [navigate])
  const ldapDomains = (info?.domains || []).filter((d) => d.ldap)

  async function handleSubmit(e) {
    e.preventDefault()
    if (status === 'pending' || status === 'success') return
    setError('')
    setStatus('pending')
    try {
      await doLogin(login, password, /[@\\]/.test(login) ? '' : domain)
      setStatus('success')
      // Короткая пауза, чтобы успели нарисоваться галочка и частицы.
      setTimeout(() => navigate('/documents/all'), 200)
    } catch (err) {
      setError(err.message || 'Не удалось войти')
      setStatus('error')
      setTimeout(() => setStatus('idle'), 1800)
    }
  }

  // Пока человек вводит пароль, в простое подгружаем оболочку и список
  // документов: после входа они уже в кэше, переход мгновенный.
  useEffect(() => {
    const run = () => { loaders.layout().catch(() => {}); loaders.documents().catch(() => {}) }
    if ('requestIdleCallback' in window) { const id = window.requestIdleCallback(run, { timeout: 3000 }); return () => window.cancelIdleCallback(id) }
    const t = setTimeout(run, 1500); return () => clearTimeout(t)
  }, [])

  // Анимированный фон (волны) на входе убран для всех (1.3): спокойный фон,
  // меньше нагрузки на слабые ПК и старые браузеры.
  const Wrap = 'div'
  const wrapProps = { className: 'min-h-screen bg-bg text-accent font-body relative flex items-center justify-center' }
  return (
    <Wrap {...wrapProps}>
      <div className="absolute top-4 right-4 z-10 text-text-primary">
        <ThemeSwitcher />
      </div>
      <form
        onSubmit={handleSubmit}



        className="relative w-full max-w-sm surface-2 p-6 mx-4 text-text-primary"
        style={{ background: mix('var(--color-surface)', 92) }}
      >
        <div>
          <img src="/emblem.jpg" alt="Эмблема ИР «Афина»" width="128" height="128" className="mb-3 rounded-2xl shadow-sm" decoding="async" />
          <h1 className="font-display text-2xl font-semibold mb-1">
            ИР «Афина»
          </h1>
          <p className="text-sm text-text-secondary mb-5">
            Контроль доведения и исполнения указаний
          </p>

          <div>
            <label className="block text-sm mb-1" htmlFor="login">
              Логин
            </label>
            <input
              id="login"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              className="w-full mb-3 px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent transition-shadow"
              autoComplete="username"
              required
            />
          </div>

          {ldapDomains.length > 0 && (
            <div>
              <label className="block text-sm mb-1" htmlFor="domain">
                Учётная запись
              </label>
              <select
                id="domain"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                className="w-full mb-3 px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent"
              >
                <option value="">Локальная (учётная запись системы)</option>
                {ldapDomains.map((d) => (
                  <option key={d.realm} value={d.realm}>{d.title ? `${d.title} (${d.realm})` : d.realm}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-sm mb-1" htmlFor="password">
              Пароль
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full mb-4 px-3 py-2 rounded-md border border-border bg-surface-alt focus:outline-none focus:ring-2 focus:ring-accent transition-shadow"
              autoComplete="current-password"
              required
            />
          </div>

          {error && (
            <div


              className="text-danger text-sm mb-3"
              role="alert"
            >
              {error}
            </div>
          )}

          <div>
            <ParticleButton
              type="submit"
              status={status}
              pendingLabel="Вход…"
              successLabel="Добро пожаловать"
              errorLabel="Не удалось войти"
              fullWidth
              className="w-full"
            >
              Войти
            </ParticleButton>
          </div>
          {info?.kerberos_enabled && info.kerberos_url && (
            <div className="text-center mt-3">
              <a href={`${info.kerberos_url}/sso`} className="inline-block text-sm text-accent hover:underline">
                Войти через Kerberos (доменная учётная запись)
              </a>
            </div>
          )}
        </div>
      </form>
    </Wrap>
  )
}
