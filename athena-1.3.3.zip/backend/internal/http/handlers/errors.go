package handlers

import "errors"

// Внутренние маркеры отказов, общие для нескольких обработчиков.
//
// Зачем они нужны вообще: обработчики выполняют работу внутри
// db.WithUserTx(...) и могут сообщить о проблеме только через error. Если
// возвращать оттуда готовый fiber.Error, транзакция и HTTP-слой окажутся
// перемешаны, а текст ответа — размазан по местам, где делается проверка.
// Поэтому изнутри транзакции возвращается маркер, а снаружи он один раз
// переводится в код ответа и текст для человека.
//
// Файл появился при замене поручений на резолюции (, п. 3):
// прежде эти маркеры были объявлены в assignments.go, который удалён вместе с
// самой сущностью «поручение», хотя пользовались ими и другие обработчики —
// documents.go, acquaintance.go. Общие объявления в файле одной сущности и
// были ошибкой: удаление сущности ломало чужой код.
var (
	// errForbidden — общий отказ по правам внутри транзакции.
	errForbidden = errors.New("forbidden")
	// errForbiddenAcquaint — нельзя ознакомить указанного человека.
	errForbiddenAcquaint = errors.New("forbidden acquaint")
	// errResultNoteRequired — требуется комментарий о результате.
	errResultNoteRequired = errors.New("result note required")
	// errControllerRole — назначаемый контролёр не имеет роли controller.
	errControllerRole = errors.New("controller must have controller role")
	// errArchiveForbidden — передавать в архив вправе автор или подписант.
	errArchiveForbidden = errors.New("archive forbidden")
	// errNotExecuted — в архив можно только исполненный документ.
	errNotExecuted = errors.New("not executed")
	// errAlreadyArchived — документ уже в архиве.
	errAlreadyArchived = errors.New("already archived")
)
