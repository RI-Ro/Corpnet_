package middleware

import (
	"errors"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"

	"athena/backend/internal/service"
)

// CtxJTI / CtxSessionID — идентификатор сессии текущего запроса.
const (
	CtxJTI       = "jti"
	CtxSessionID = "sessionID"
)

// SessionGuard проверяет, что сессия токена не отозвана (, п. 8).
//
// Ставится ПОСЛЕ JWTAuth: нужен разобранный токен. Отзыв действует сразу —
// вытесненный АРМ получает 401 на следующем же действии и уходит на вход.
//
// Код ответа именно 401, а не 403: фронт уже умеет обрабатывать 401 переходом
// на страницу входа, и для вытесненного рабочего места это правильное
// поведение. Текст сообщения возвращается человеку, чтобы он понял причину
// («вход с другого рабочего места»), а не думал, что система сломалась.
func SessionGuard(sessions *service.SessionService, audit *service.AuditService) fiber.Handler {
	return func(c *fiber.Ctx) error {
		claims, _ := c.Locals(CtxClaims).(*service.Claims)
		jti := ""
		if claims != nil {
			jti = claims.ID
		}
		c.Locals(CtxJTI, jti)

		// userID берётся из уже разобранного токена: без него выборка сессии
		// не проходит политику RLS (видно только свои сессии), и проверка
		// всегда отвечала бы «сессии нет», то есть пропускала бы запросы по
		// вытесненной сессии.
		uid, _ := c.Locals(CtxUserID).(int64)
		sessionID, err := sessions.Check(c.Context(), uid, jti)
		c.Locals(CtxSessionID, sessionID)
		if err != nil {
			if errors.Is(err, service.ErrSessionRevoked) {
				login, _ := c.Locals(CtxLogin).(string)
				audit.Write(service.AuditEvent{
					ActorID: uid, ActorLogin: login, SessionID: sessionID,
					Event: "auth.session_revoked_access", Outcome: "denied",
					HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: fiber.StatusUnauthorized,
					IP: ClientIP(c), IPPeer: PeerIP(c), IPChain: ForwardedChain(c), UserAgent: c.Get("User-Agent"),
					Details: map[string]any{"reason": err.Error()},
				})
				ClearSessionCookies(c)
				return fiber.NewError(fiber.StatusUnauthorized, err.Error())
			}
			return fiber.NewError(fiber.StatusServiceUnavailable, "сервис временно недоступен, повторите попытку")
		}
		sessions.Touch(jti)
		return c.Next()
	}
}

// auditSkipPrefixes — пути, которые в журнал НЕ пишутся.
//
// Это сознательное решение, а не упущение. Открытая страница системы делает
// эти запросы постоянно: счётчики категорий раз в минуту, опрос будильников,
// проверка статуса индексации, продление токена раз в 20 минут. При 1000
// пользователей журнал состоял бы из них на 99 %, а события, ради которых
// журнал и ведётся (вход, подпись, резолюция, отказ в доступе), в нём было бы
// не найти. Хуже того: распухший журнал первым делом начинают чистить, и тогда
// теряется всё.
//
// Важно: сюда попадают только ЧТЕНИЯ служебных данных. Любой изменяющий
// запрос пишется всегда, независимо от пути.
var auditSkipPrefixes = []string{
	"/api/documents/category-counts",
	"/api/notifications",
	"/api/search/index-status",
	"/api/recipients-counts",
	"/api/preferences",
	"/api/app-config",
	"/api/me",
	"/api/metrics",
}

// auditReadPaths — ЧТЕНИЯ, которые писать обязательно.
//
// Факт ознакомления с документом и особенно скачивание файла — это то, что
// спрашивают при разборе утечки: кто видел документ с особой отметкой и когда.
// Поэтому эти GET'ы пишутся, несмотря на общее правило «листинги не пишем».
var auditReadSuffixes = []string{
	"/file",
	"/print",
	"/signatures",
	"/versions",
	"/report",
}

func shouldAudit(c *fiber.Ctx) bool {
	method := c.Method()
	path := c.Path()

	// Изменяющие запросы — всегда.
	switch method {
	case fiber.MethodPost, fiber.MethodPut, fiber.MethodPatch, fiber.MethodDelete:
		return true
	}
	// Отказы — всегда, даже на чтении: именно по ним видно попытки добраться
	// до недоступного.
	if c.Response().StatusCode() >= 400 {
		return true
	}
	for _, p := range auditSkipPrefixes {
		if strings.HasPrefix(path, p) {
			return false
		}
	}
	for _, sfx := range auditReadSuffixes {
		if strings.HasSuffix(path, sfx) {
			return true
		}
	}
	// Просмотр карточки документа: /api/documents/<число>.
	if isDocumentCardPath(path) {
		return true
	}
	return false
}

// isDocumentCardPath распознаёт /api/documents/<id> (без дальнейших сегментов).
func isDocumentCardPath(path string) bool {
	const pfx = "/api/documents/"
	if !strings.HasPrefix(path, pfx) {
		return false
	}
	rest := strings.Trim(strings.TrimPrefix(path, pfx), "/")
	if rest == "" || strings.Contains(rest, "/") {
		return false
	}
	_, err := strconv.ParseInt(rest, 10, 64)
	return err == nil
}

// documentIDFromPath вытаскивает id документа из пути, если он там есть.
// Нужно, чтобы выборка «что делали с этим документом» работала по индексу, а
// не разбором http_path.
func documentIDFromPath(path string) int64 {
	const pfx = "/api/documents/"
	if !strings.HasPrefix(path, pfx) {
		return 0
	}
	rest := strings.TrimPrefix(path, pfx)
	if i := strings.IndexByte(rest, '/'); i >= 0 {
		rest = rest[:i]
	}
	id, err := strconv.ParseInt(rest, 10, 64)
	if err != nil {
		return 0
	}
	return id
}

// eventName строит имя события из метода и пути: «document.create»,
// «resolution.update», «signature.read». Имя нужно стабильное и
// группируемое — по нему строятся выборки и индекс idx_audit_event.
func eventName(method, path string) string {
	area := "api"
	seg := strings.Split(strings.Trim(strings.TrimPrefix(path, "/api/"), "/"), "/")
	if len(seg) > 0 && seg[0] != "" {
		area = strings.TrimSuffix(seg[0], "s")
	}
	// Уточняем область по последнему нечисловому сегменту: для
	// /api/documents/12/favorite это «favorite», а не «document».
	for i := len(seg) - 1; i > 0; i-- {
		if seg[i] == "" {
			continue
		}
		if _, err := strconv.ParseInt(seg[i], 10, 64); err != nil {
			area = strings.TrimSuffix(seg[i], "s")
			break
		}
	}
	action := "read"
	switch method {
	case fiber.MethodPost:
		action = "create"
	case fiber.MethodPut, fiber.MethodPatch:
		action = "update"
	case fiber.MethodDelete:
		action = "delete"
	}
	return area + "." + action
}

// Audit пишет событие в журнал после обработки запроса.
//
// Пишется ПОСЛЕ c.Next(), потому что в событии нужен код ответа: по нему
// отличается выполненное действие от отказа, а отказы — самое ценное в
// журнале.
func Audit(audit *service.AuditService) fiber.Handler {
	return func(c *fiber.Ctx) error {
		err := c.Next()

		// Код ответа при ошибке ещё не записан в Response: обработчик ошибок
		// Fiber отработает позже. Поэтому берём его из самой ошибки.
		status := c.Response().StatusCode()
		if err != nil {
			var fe *fiber.Error
			if errors.As(err, &fe) {
				status = fe.Code
			} else {
				status = fiber.StatusInternalServerError
			}
		}
		// Подменяем код в ответе на время решения «писать или нет», иначе
		// shouldAudit не увидит отказ.
		if status >= 400 {
			c.Response().SetStatusCode(status)
		}
		if !shouldAudit(c) {
			return err
		}

		outcome := "ok"
		switch {
		case status == fiber.StatusUnauthorized || status == fiber.StatusForbidden:
			outcome = "denied"
		case status >= 400:
			outcome = "error"
		}

		uid, _ := c.Locals(CtxUserID).(int64)
		login, _ := c.Locals(CtxLogin).(string)
		sid, _ := c.Locals(CtxSessionID).(int64)

		details := map[string]any{}
		if err != nil {
			details["error"] = err.Error()
		}
		if q := string(c.Request().URI().QueryString()); q != "" {
			details["query"] = q
		}

		audit.Write(service.AuditEvent{
			ActorID: uid, ActorLogin: login, SessionID: sid,
			Event:      eventName(c.Method(), c.Path()),
			DocumentID: documentIDFromPath(c.Path()),
			Outcome:    outcome,
			HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: status,
			IP: ClientIP(c), IPPeer: PeerIP(c), IPChain: ForwardedChain(c), UserAgent: c.Get("User-Agent"),
			Details: details,
		})
		return err
	}
}
