import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Icon from '../components/Icon'
import { api } from '../api/client'
import { usePreference } from '../lib/usePreference'
import { useAuth } from '../context/AuthContext'
import {
  BarList, Legend, LineChart, Meter, Sparkline, SplitBars, STATUS, fmtInt, useChartPalette,
} from '../components/dashboard/charts'

// Сводная панель руководителя.
//
// Показывает всё по документам, доступным пользователю (права считает база).
// Руководитель настраивает панель под себя: период и отборы, какие блоки
// показывать, их порядок (перетаскиванием или стрелками) и ширину, вид графика
// (линии или таблица), скрытые ряды. Всё сохраняется в настройках учётной
// записи на сервере (ui.dashboard) и действует после перезагрузки страницы и
// на другом компьютере.

const PERIODS = [
  { id: '7', label: '7 дней' },
  { id: '30', label: '30 дней' },
  { id: '90', label: '90 дней' },
  { id: '180', label: 'Полгода' },
  { id: '365', label: 'Год' },
  { id: 'ytd', label: 'С начала года' },
]

const STATUS_LABEL = {
  on_approval_hierarchy: 'Согласование в подразделении',
  on_approval_cross_dept: 'Межведомственное согласование',
  on_signing: 'На подписи',
  signed: 'Подписан, не направлен',
  sent: 'Направлен адресатам',
  in_progress: 'На исполнении',
  executed: 'Исполнен',
  rejected: 'На доработке у автора',
}
const STAGE_LABEL = { hierarchy: 'согласование', cross_dept: 'межвед. согласование', signing: 'подпись' }

const WIDGETS = [
  { id: 'kpi', title: 'Состояние сейчас', wide: true },
  { id: 'period', title: 'Итоги периода', wide: true },
  { id: 'trend', title: 'Динамика', wide: true },
  { id: 'overdue', title: 'Просрочено', wide: false },
  { id: 'upcoming', title: 'Сроки в ближайшие 14 дней', wide: false },
  { id: 'departments', title: 'Исполнительская дисциплина подразделений', wide: true },
  { id: 'bottlenecks', title: 'Где ждут решения', wide: false },
  { id: 'stalled', title: 'Зависшие документы', wide: false },
  { id: 'resolutions', title: 'Резолюции и исполнители', wide: false },
  { id: 'speed', title: 'Скорость согласования', wide: false },
  { id: 'status', title: 'Действующие документы по стадиям', wide: false },
  { id: 'categories', title: 'По категориям', wide: false },
  { id: 'marks', title: 'По особым отметкам', wide: false },
]
const WIDGET_BY_ID = Object.fromEntries(WIDGETS.map((w) => [w.id, w]))

const DEFAULTS = {
  period: '90', category: '', mark: '', department: '',
  order: WIDGETS.map((w) => w.id), hidden: [], wide: {},
  autoRefresh: true, trendView: 'chart', trendHidden: [],
}

// --- форматирование ---------------------------------------------------------
const MONTHS = ['янв', 'фев', 'мар', 'апр', 'май', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек']
const dt = (v) => (v ? new Date(v) : null)
const fmtDay = (v) => { const d = dt(v); return d ? d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) : '' }
const fmtDateFull = (v) => { const d = dt(v); return d ? d.toLocaleDateString('ru-RU') : '—' }
function fmtHours(h) {
  if (h == null || Number.isNaN(h)) return '—'
  if (h < 1) return '< 1 ч'
  if (h < 48) return `${Math.round(h)} ч`
  return `${(h / 24).toFixed(1).replace('.', ',')} дн`
}
const fmtDays = (d) => (d == null ? '—' : `${d.toFixed(1).replace('.', ',')} дн`)
const pct = (a, b) => (b > 0 ? (a / b) * 100 : null)
function plural(n, one, few, many) {
  const m10 = n % 10; const m100 = n % 100
  if (m10 === 1 && m100 !== 11) return one
  if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few
  return many
}
const daysWord = (n) => `${n} ${plural(n, 'день', 'дня', 'дней')}`

// Изменение к прошлому периоду. good: 'up' — рост хорош, 'down' — хорошо
// снижение, null — нейтрально. Цвет только у значка, текст — цвет текста.
function Delta({ cur, prev, good = 'up', unit = '%', points = false }) {
  if (cur == null || prev == null) return <span className="text-xs text-text-secondary">нет данных для сравнения</span>
  let diff; let text
  if (points) {
    diff = cur - prev
    text = `${diff > 0 ? '+' : diff < 0 ? '−' : ''}${Math.abs(Math.round(diff))} п. п.`
  } else {
    if (prev === 0) return <span className="text-xs text-text-secondary">в прошлом периоде — 0</span>
    diff = ((cur - prev) / prev) * 100
    text = `${diff > 0 ? '+' : diff < 0 ? '−' : ''}${Math.abs(Math.round(diff))}${unit}`
  }
  const flat = Math.abs(diff) < 0.5
  const better = flat || good == null ? null : (diff > 0) === (good === 'up')
  const color = better == null ? 'var(--color-text-secondary)' : better ? STATUS.good : STATUS.critical
  return (
    <span className="inline-flex items-center gap-1 text-xs text-text-secondary">
      {!flat && <Icon name={diff > 0 ? 'arrow-up' : 'arrow-down'} size={12} style={{ color }} />}
      <span>{flat ? 'без изменений' : text}</span>
      <span>к прошлому периоду</span>
    </span>
  )
}

function StatTile({ label, value, hint, delta, spark, onClick, tone }) {
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={`text-left rounded-lg border border-border bg-surface-alt/40 p-3 flex flex-col gap-1 min-w-0 ${onClick ? 'hover:border-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent' : ''}`}
    >
      <span className="text-xs text-text-secondary flex items-center gap-1.5">
        {tone && <Icon name={tone.icon} size={13} style={{ color: tone.color }} />}
        {label}
      </span>
      <span className="flex items-end justify-between gap-2">
        <span className="text-2xl font-semibold text-text-primary leading-none">{value}</span>
        {spark}
      </span>
      {delta}
      {hint && <span className="text-xs text-text-secondary">{hint}</span>}
    </Tag>
  )
}

// Строка списка сроков: значок и подпись состояния — не только цвет.
function DueRow({ r, overdue, onOpen }) {
  const tone = overdue
    ? { icon: 'warning', color: STATUS.critical, text: `просрочено на ${daysWord(r.days)}` }
    : r.days === 0
      ? { icon: 'clock', color: STATUS.serious, text: 'срок сегодня' }
      : { icon: 'clock', color: r.days <= 3 ? STATUS.warning : 'var(--color-text-secondary)', text: `через ${daysWord(r.days)}` }
  return (
    <li>
      <button type="button" onClick={() => onOpen(r.document_id)} className="w-full text-left rounded-md px-2 py-2 hover:bg-surface-alt focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent">
        <div className="flex items-start gap-2">
          <Icon name={tone.icon} size={15} className="mt-0.5" style={{ color: tone.color }} />
          <div className="min-w-0 flex-1">
            <div className="text-sm text-text-primary truncate">{r.title}</div>
            <div className="text-xs text-text-secondary truncate">
              {r.kind === 'resolution' ? 'Резолюция' : 'Исполнение'} · {r.who || '—'}{r.number ? ` · ${r.number}` : ''}
            </div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-xs font-semibold text-text-primary">{tone.text}</div>
            <div className="text-xs text-text-secondary">срок {fmtDateFull(r.due_date)}</div>
          </div>
        </div>
      </button>
    </li>
  )
}

export default function DashboardPage() {
  const navigate = useNavigate()
  const { fullName, dashboardDepartments } = useAuth()
  const { series: palette } = useChartPalette()
  const [prefs, setPrefs, { loaded: prefsLoaded }] = usePreference('ui.dashboard', DEFAULTS, { debounceMs: 400 })
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [edit, setEdit] = useState(false)
  const [dragId, setDragId] = useState(null)
  const [cats, setCats] = useState([])
  const [deps, setDeps] = useState([])
  const [marks, setMarks] = useState([])
  const reqId = useRef(0)

  // Порядок блоков: сохранённый + новые блоки (появившиеся в обновлениях) в конец.
  const order = useMemo(() => {
    const known = (prefs.order || []).filter((id) => WIDGET_BY_ID[id])
    return [...known, ...WIDGETS.map((w) => w.id).filter((id) => !known.includes(id))]
  }, [prefs.order])
  const hidden = prefs.hidden || []
  const isWide = (id) => (prefs.wide && id in prefs.wide ? prefs.wide[id] : WIDGET_BY_ID[id].wide)

  const params = useMemo(() => ({
    period: prefs.period || '90', category: prefs.category || '', mark: prefs.mark || '', department: prefs.department || '',
  }), [prefs.period, prefs.category, prefs.mark, prefs.department])

  const load = useCallback(() => {
    const id = ++reqId.current
    setLoading(true)
    api.getDashboard(params)
      .then((r) => { if (id === reqId.current) { setData(r); setError('') } })
      .catch((e) => { if (id === reqId.current) { setData(null); setError(e.message || 'Не удалось построить сводку') } })
      .finally(() => { if (id === reqId.current) setLoading(false) })
  }, [params])

  // Ждём сохранённые отборы, чтобы не считать сводку дважды.
  useEffect(() => { if (prefsLoaded) load() }, [load, prefsLoaded])
  useEffect(() => {
    if (!prefs.autoRefresh) return undefined
    const t = setInterval(() => { if (document.visibilityState === 'visible') load() }, 5 * 60 * 1000)
    return () => clearInterval(t)
  }, [prefs.autoRefresh, load])
  // Изменения документов в этой или другой вкладке — пересчитать.
  useEffect(() => {
    let t
    const on = () => { clearTimeout(t); t = setTimeout(load, 1500) }
    window.addEventListener('athena:changed', on)
    return () => { window.removeEventListener('athena:changed', on); clearTimeout(t) }
  }, [load])
  useEffect(() => {
    api.listCategories().then((r) => setCats(r.items || r || [])).catch(() => {})
    api.listDepartments().then((r) => setDeps(r.items || [])).catch(() => {})
    api.getSpecialMarks().then((r) => setMarks(r.items || r || [])).catch(() => {})
  }, [])

  const openDoc = (id) => navigate(`/document/${id}`)

  // --- настройка блоков ------------------------------------------------------
  const move = (id, dir) => {
    const ids = [...order]; const i = ids.indexOf(id); const j = i + dir
    if (i < 0 || j < 0 || j >= ids.length) return
    ;[ids[i], ids[j]] = [ids[j], ids[i]]
    setPrefs({ order: ids })
  }
  const dropOn = (targetId) => {
    if (!dragId || dragId === targetId) return
    const ids = order.filter((x) => x !== dragId)
    ids.splice(ids.indexOf(targetId), 0, dragId)
    setPrefs({ order: ids }); setDragId(null)
  }
  const hide = (id) => setPrefs({ hidden: [...new Set([...hidden, id])] })
  const show = (id) => setPrefs({ hidden: hidden.filter((x) => x !== id) })
  const toggleWide = (id) => setPrefs((cur) => ({ ...cur, wide: { ...(cur.wide || {}), [id]: !isWide(id) } }))
  const reset = () => setPrefs({ ...DEFAULTS })

  // --- данные для блоков ------------------------------------------------------
  const k = data?.kpi || {}
  const tm = data?.timing || {}
  const res = data?.resolutions || {}
  const trend = data?.trend || []
  const bucket = data?.period?.bucket || 'day'
  const fmtX = (v) => { const d = dt(v); if (!d) return ''; return bucket === 'month' ? MONTHS[d.getMonth()] : fmtDay(v) }
  const fmtXLong = (v) => {
    const d = dt(v); if (!d) return ''
    if (bucket === 'month') return d.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' })
    if (bucket === 'week') { const e = new Date(d); e.setDate(e.getDate() + 6); return `неделя ${fmtDay(d)}–${fmtDay(e)}` }
    return d.toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'long' })
  }
  const spark = (key) => trend.slice(-12).map((p) => p[key] || 0)
  const trendSeries = [
    { key: 'created', label: 'Создано', color: palette[0] },
    { key: 'signed', label: 'Подписано', color: palette[1] },
    { key: 'executed', label: 'Исполнено', color: palette[2] },
  ]
  const discCur = pct(k.ontime_cur || 0, k.due_cur || 0)
  const discPrev = pct(k.ontime_prev || 0, k.due_prev || 0)
  const periodLabel = (PERIODS.find((p) => p.id === params.period) || {}).label || ''

  const renderWidget = (id) => {
    switch (id) {
      case 'kpi':
        return (
          <div className="grid gap-3 grid-cols-2 md:grid-cols-4 xl:grid-cols-7">
            <div className="col-span-2 md:col-span-4 xl:col-span-2 rounded-lg border border-border p-4 flex flex-col justify-between gap-2">
              <span className="text-xs text-text-secondary">Исполнено в срок · {periodLabel.toLowerCase()}</span>
              <span className="text-5xl font-semibold text-text-primary leading-none">{discCur == null ? '—' : `${Math.round(discCur)} %`}</span>
              <Delta cur={discCur} prev={discPrev} points good="up" />
              <span className="text-xs text-text-secondary">
                {fmtInt(k.ontime_cur)} из {fmtInt(k.due_cur)} поручений подразделениям, срок которых наступил в периоде
              </span>
            </div>
            <StatTile label="Действующих документов" value={fmtInt(k.active)} hint={`на доработке у авторов: ${fmtInt(k.on_revision)}`} onClick={() => navigate('/documents/all')} />
            <StatTile label="На согласовании" value={fmtInt(k.on_approval)} onClick={() => navigate('/documents/on_approval')} />
            <StatTile label="На подписи" value={fmtInt(k.on_signing)} onClick={() => navigate('/documents/on_signing')} />
            <StatTile label="Просрочено документов" value={fmtInt(k.overdue_docs)} tone={{ icon: 'warning', color: STATUS.critical }}
              hint={`не исполнено подразделениями в срок: ${fmtInt(k.overdue_instances)} ${plural(k.overdue_instances || 0, 'поручение', 'поручения', 'поручений')}`}
              onClick={() => document.getElementById('w-overdue')?.scrollIntoView({ behavior: 'smooth' })} />
            <StatTile label="Срок в ближайшие 7 дней" value={fmtInt(k.due_soon_docs)} tone={{ icon: 'clock', color: STATUS.warning }}
              hint={`на контроле: ${fmtInt(k.on_control)}`} onClick={() => navigate('/documents/control')} />
          </div>
        )
      case 'period':
        return (
          <div className="grid gap-3 grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
            <StatTile label="Создано документов" value={fmtInt(k.created_cur)} delta={<Delta cur={k.created_cur} prev={k.created_prev} good={null} />} spark={<Sparkline values={spark('created')} color={palette[0]} />} />
            <StatTile label="Подписано" value={fmtInt(k.signed_cur)} delta={<Delta cur={k.signed_cur} prev={k.signed_prev} good="up" />} spark={<Sparkline values={spark('signed')} color={palette[1]} />} />
            <StatTile label="Исполнено полностью" value={fmtInt(k.executed_cur)} delta={<Delta cur={k.executed_cur} prev={k.executed_prev} good="up" />} spark={<Sparkline values={spark('executed')} color={palette[2]} />} />
            <StatTile label="Согласование до подписи" value={fmtHours(tm.approval_avg_h_cur)} delta={<Delta cur={tm.approval_avg_h_cur} prev={tm.approval_avg_h_prev} good="down" />} hint={`медиана ${fmtHours(tm.approval_median_h_cur)}`} />
            <StatTile label="Исполнение подразделением" value={fmtDays(tm.execution_avg_d_cur)} delta={<Delta cur={tm.execution_avg_d_cur} prev={tm.execution_avg_d_prev} good="down" />} hint={`медиана ${fmtDays(tm.execution_median_d_cur)}`} />
            <StatTile label="Резолюций исполнено" value={fmtInt(res.done_cur)} delta={<Delta cur={res.done_cur} prev={res.done_prev} good="up" />}
              hint={res.done_with_due_cur ? `в срок: ${Math.round(pct(res.done_on_time_cur, res.done_with_due_cur))} %` : ''} />
          </div>
        )
      case 'trend': {
        const th = prefs.trendHidden || []
        return (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <Legend series={trendSeries} hidden={th} onToggle={(key) => setPrefs({ trendHidden: th.includes(key) ? th.filter((x) => x !== key) : [...th, key] })} />
              <div className="flex rounded-md border border-border overflow-hidden text-xs" role="group" aria-label="Вид">
                {[['chart', 'chart', 'График'], ['table', 'table', 'Таблица']].map(([v, icon, l]) => (
                  <button key={v} type="button" onClick={() => setPrefs({ trendView: v })} aria-pressed={prefs.trendView === v}
                    className={`px-2.5 py-1 flex items-center gap-1 ${prefs.trendView === v ? 'bg-accent text-accent-contrast' : 'hover:bg-surface-alt text-text-secondary'}`}>
                    <Icon name={icon} size={13} />{l}
                  </button>
                ))}
              </div>
            </div>
            {prefs.trendView === 'table' ? (
              <div className="overflow-auto max-h-80">
                <table className="w-full text-sm tabular-nums">
                  <thead className="sticky top-0 bg-surface"><tr className="text-left text-xs text-text-secondary">
                    <th className="py-1.5 pr-3 font-medium">{bucket === 'month' ? 'Месяц' : bucket === 'week' ? 'Неделя' : 'День'}</th>
                    {trendSeries.map((s) => <th key={s.key} className="py-1.5 px-3 font-medium text-right">{s.label}</th>)}
                    <th className="py-1.5 pl-3 font-medium text-right">Исполнено с опозданием</th>
                  </tr></thead>
                  <tbody>{trend.map((p) => (
                    <tr key={p.bucket} className="border-t border-border">
                      <td className="py-1.5 pr-3">{fmtXLong(p.bucket)}</td>
                      {trendSeries.map((s) => <td key={s.key} className="py-1.5 px-3 text-right">{fmtInt(p[s.key])}</td>)}
                      <td className="py-1.5 pl-3 text-right">{fmtInt(p.executed_late)}</td>
                    </tr>
                  ))}</tbody>
                </table>
              </div>
            ) : (
              <LineChart points={trend} series={trendSeries} hidden={th} formatX={fmtX} formatXLong={fmtXLong}
                ariaLabel={`Динамика за период: создано ${k.created_cur}, подписано ${k.signed_cur}, исполнено ${k.executed_cur}. Стрелки влево и вправо — значения по ${bucket === 'month' ? 'месяцам' : bucket === 'week' ? 'неделям' : 'дням'}.`} />
            )}
          </div>
        )
      }
      case 'overdue': {
        const rows = data?.overdue || []
        return rows.length ? (
          <ul className="divide-y divide-border max-h-96 overflow-auto -mx-2">{rows.map((r, i) => <DueRow key={i} r={r} overdue onOpen={openDoc} />)}</ul>
        ) : <Empty icon="check-circle" text="Просроченных поручений нет" good />
      }
      case 'upcoming': {
        const rows = data?.upcoming || []
        return rows.length ? (
          <ul className="divide-y divide-border max-h-96 overflow-auto -mx-2">{rows.map((r, i) => <DueRow key={i} r={r} onOpen={openDoc} />)}</ul>
        ) : <Empty icon="check-circle" text="В ближайшие 14 дней сроков нет" />
      }
      case 'departments': {
        const rows = data?.departments || []
        if (!rows.length) return <Empty text="Документы подразделениям не направлялись" />
        return (
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead><tr className="text-left text-xs text-text-secondary">
                <th className="py-2 pr-3 font-medium">Подразделение</th>
                <th className="py-2 px-3 font-medium text-right">Получено</th>
                <th className="py-2 px-3 font-medium text-right">Исполнено</th>
                <th className="py-2 px-3 font-medium">В срок</th>
                <th className="py-2 px-3 font-medium text-right">Средний срок</th>
                <th className="py-2 px-3 font-medium text-right">В работе</th>
                <th className="py-2 pl-3 font-medium text-right">Просрочено</th>
              </tr></thead>
              <tbody className="tabular-nums">{rows.map((r) => (
                <tr key={r.department_id} className="border-t border-border">
                  <td className="py-2 pr-3 text-text-primary">{r.name}</td>
                  <td className="py-2 px-3 text-right">{fmtInt(r.received)}</td>
                  <td className="py-2 px-3 text-right">{fmtInt(r.executed)}</td>
                  <td className="py-2 px-3"><Meter pct={pct(r.executed_on_time, r.executed_with_due)} /></td>
                  <td className="py-2 px-3 text-right">{fmtDays(r.avg_days)}</td>
                  <td className="py-2 px-3 text-right">{fmtInt(r.in_work)}</td>
                  <td className="py-2 pl-3 text-right">
                    {r.overdue > 0
                      ? <span className="inline-flex items-center gap-1 font-semibold text-text-primary"><Icon name="warning" size={13} style={{ color: STATUS.critical }} />{fmtInt(r.overdue)}</span>
                      : <span className="text-text-secondary">0</span>}
                  </td>
                </tr>
              ))}</tbody>
            </table>
            <p className="text-xs text-text-secondary mt-2">
              «Получено» и «Исполнено» — за {periodLabel.toLowerCase()}; «В срок» — доля исполненных не позже срока документа; «В работе» и «Просрочено» — на сейчас.
            </p>
          </div>
        )
      }
      case 'bottlenecks':
        return (
          <BarList rows={data?.bottlenecks || []} value={(r) => r.pending} label={(r) => r.full_name}
            sub={(r) => `дольше всех ждёт ${fmtHours(r.oldest_h)}${r.signing ? ` · на подписи: ${r.signing}` : ''}`}
            color={palette[0]} emptyText="Сейчас никто не задерживает документы"
            tip={(r) => (<div className="space-y-0.5">
              <div className="text-text-primary font-semibold">{r.full_name}</div>
              <div className="text-text-secondary">{[r.position, r.department].filter(Boolean).join(' · ')}</div>
              <div><b className="text-text-primary">{r.pending}</b> <span className="text-text-secondary">ждут решения, из них на подписи {r.signing}</span></div>
              <div><span className="text-text-secondary">в среднем ждут</span> <b className="text-text-primary">{fmtHours(r.avg_h)}</b></div>
            </div>)} />
        )
      case 'stalled': {
        const rows = data?.stalled || []
        if (!rows.length) return <Empty icon="check-circle" text={`Нет документов, ожидающих решения дольше ${daysWord(data?.reminder_days || 3)}`} good />
        return (
          <ul className="divide-y divide-border max-h-96 overflow-auto -mx-2">
            {rows.map((r) => (
              <li key={`${r.document_id}-${r.approver}`}>
                <button type="button" onClick={() => openDoc(r.document_id)} className="w-full text-left rounded-md px-2 py-2 hover:bg-surface-alt focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent">
                  <div className="flex items-start gap-2">
                    <Icon name="clock" size={15} className="mt-0.5" style={{ color: r.waiting_h >= 24 * 7 ? STATUS.critical : STATUS.warning }} />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm text-text-primary truncate">{r.title}</div>
                      <div className="text-xs text-text-secondary truncate">{r.approver} · шаг {r.step_no}, {STAGE_LABEL[r.stage_type] || 'Другой этап'}</div>
                    </div>
                    <div className="text-xs font-semibold text-text-primary shrink-0">ждёт {fmtHours(r.waiting_h)}</div>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )
      }
      case 'resolutions':
        return (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <StatTile label="Открыто" value={fmtInt(res.open)} onClick={() => navigate('/resolutions')} />
              <StatTile label="Просрочено" value={fmtInt(res.overdue)} tone={{ icon: 'warning', color: STATUS.critical }} />
              <StatTile label="Срок за 7 дней" value={fmtInt(res.due_soon)} tone={{ icon: 'clock', color: STATUS.warning }} />
              <StatTile label="Ждут приёма отчёта" value={fmtInt(res.on_report)} />
            </div>
            <div>
              <div className="text-xs text-text-secondary mb-1">Исполнители с открытыми поручениями</div>
              <SplitBars rows={data?.executors || []} label={(r) => r.full_name} sub={(r) => (r.reported ? `отчитался, ждёт приёма: ${r.reported}` : r.position)}
                parts={[
                  { key: 'overdue', label: 'Просрочено', color: STATUS.critical, value: (r) => r.overdue },
                  { key: 'ok', label: 'В срок', color: palette[0], value: (r) => r.open - r.overdue },
                ]} />
            </div>
          </div>
        )
      case 'speed':
        return (
          <BarList rows={data?.approver_speed || []} value={(r) => r.avg_h} label={(r) => r.full_name} format={(v) => fmtHours(v)}
            sub={(r) => `решений: ${r.decided}${r.rejected ? `, отклонено: ${r.rejected}` : ''} · медиана ${fmtHours(r.median_h)}`}
            color={palette[1]} emptyText="За период решений не было"
            tip={(r) => (<div className="space-y-0.5">
              <div className="text-text-primary font-semibold">{r.full_name}</div>
              <div><span className="text-text-secondary">в среднем</span> <b className="text-text-primary">{fmtHours(r.avg_h)}</b> <span className="text-text-secondary">от поступления до решения</span></div>
              <div><span className="text-text-secondary">медиана</span> <b className="text-text-primary">{fmtHours(r.median_h)}</b></div>
              <div><span className="text-text-secondary">решений</span> <b className="text-text-primary">{r.decided}</b></div>
            </div>)} />
        )
      case 'status':
        return (
          <BarList rows={(data?.status || []).filter((r) => r.status !== 'executed')} value={(r) => r.n} label={(r) => STATUS_LABEL[r.status] || 'Другой статус'} color={palette[0]} />
        )
      case 'categories':
        return (
          <BarList rows={data?.categories || []} value={(r) => r.created} label={(r) => r.name} sub={(r) => `действующих: ${r.active}`} color={palette[0]}
            emptyText="За период документов нет" onSelect={(r) => setPrefs({ category: String(r.id) })}
            tip={(r) => <div><b className="text-text-primary">{r.created}</b> <span className="text-text-secondary">создано за период · щелчок — отобрать панель по категории</span></div>} />
        )
      case 'marks':
        return (
          <SplitBars rows={data?.special_marks || []} label={(r) => r.name}
            sub={(r) => `создано за период: ${fmtInt(r.created)}`}
            onSelect={(r) => setPrefs({ mark: String(r.id) })}
            parts={[
              { key: 'overdue', label: 'Просрочено', color: STATUS.critical, value: (r) => r.overdue },
              { key: 'ok', label: 'Остальные действующие', color: palette[0], value: (r) => r.active - r.overdue },
            ]} />
        )
      default:
        return null
    }
  }

  const visibleIds = order.filter((id) => !hidden.includes(id))
  const filtersOn = params.category || params.mark || params.department

  return (
    <div className="p-4 md:p-6 space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-semibold">Сводная панель</h1>
          <p className="text-sm text-text-secondary">
            Все документы, доступные {fullName ? `пользователю ${fullName}` : 'вам'}
            {data?.generated_at && <> · обновлено {new Date(data.generated_at).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}</>}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs text-text-secondary">
            <input type="checkbox" checked={!!prefs.autoRefresh} onChange={(e) => setPrefs({ autoRefresh: e.target.checked })} />
            обновлять каждые 5 минут
          </label>
          <button type="button" className="btn btn-secondary" onClick={load} disabled={loading}>
            <Icon name="reset" size={14} /> Обновить
          </button>
          <button type="button" className={`btn ${edit ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setEdit((v) => !v)} aria-pressed={edit}>
            <Icon name={edit ? 'check-circle' : 'edit'} size={14} /> {edit ? 'Готово' : 'Настроить панель'}
          </button>
        </div>
      </div>

      {/* Отборы — одной строкой над всеми блоками, действуют на все цифры. */}
      <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Отборы сводки">
        <div className="flex rounded-md border border-border overflow-hidden text-sm" role="radiogroup" aria-label="Период">
          {PERIODS.map((p) => (
            <button key={p.id} type="button" role="radio" aria-checked={params.period === p.id} onClick={() => setPrefs({ period: p.id })}
              className={`px-3 py-1.5 ${params.period === p.id ? 'bg-accent text-accent-contrast font-semibold' : 'hover:bg-surface-alt text-text-secondary'}`}>
              {p.label}
            </button>
          ))}
        </div>
        <select className="field w-auto text-sm" value={params.department} onChange={(e) => setPrefs({ department: e.target.value })} aria-label="Подразделение">
          <option value="">Все доступные подразделения</option>
          {deps.filter((d) => dashboardDepartments.includes(d.id)).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
        <select className="field w-auto text-sm" value={params.category} onChange={(e) => setPrefs({ category: e.target.value })} aria-label="Категория">
          <option value="">Все категории</option>
          {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
        <select className="field w-auto text-sm" value={params.mark} onChange={(e) => setPrefs({ mark: e.target.value })} aria-label="Особая отметка">
          <option value="">Любая особая отметка</option>
          {marks.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        {filtersOn && (
          <button type="button" className="text-sm text-accent hover:underline" onClick={() => setPrefs({ category: '', mark: '', department: '' })}>
            Сбросить отборы
          </button>
        )}
      </div>

      {edit && (
        <div className="rounded-lg border border-accent/50 bg-accent/5 p-3 text-sm space-y-2">
          <p className="text-text-secondary">
            Перетащите блоки за заголовок или используйте стрелки. Кнопкой <Icon name="arrows-h" size={13} /> блок занимает всю ширину или половину,
            кнопкой <Icon name="eye-off" size={13} /> скрывается. Настройка сохраняется для вашей учётной записи.
          </p>
          <div className="flex flex-wrap items-center gap-2">
            {hidden.length > 0 && <span className="text-text-secondary">Скрытые блоки:</span>}
            {hidden.filter((id) => WIDGET_BY_ID[id]).map((id) => (
              <button key={id} type="button" className="btn btn-secondary text-xs py-1" onClick={() => show(id)}>
                <Icon name="eye" size={13} /> {WIDGET_BY_ID[id].title}
              </button>
            ))}
            <button type="button" className="ml-auto text-xs text-text-secondary hover:text-accent" onClick={reset}>Вернуть исходный вид</button>
          </div>
        </div>
      )}

      {error && (
        <div className="rounded-md border border-danger/40 bg-danger/5 px-3 py-2 text-sm text-text-primary flex items-center gap-2">
          <Icon name="warning" size={15} style={{ color: STATUS.critical }} /> {error}
        </div>
      )}

      {!data && !error && <div className="text-sm text-text-secondary" role="status">Считаем сводку…</div>}

      {data && (
        <div className={`grid grid-cols-1 xl:grid-cols-2 gap-4 transition-opacity ${loading ? 'opacity-60' : ''}`} aria-busy={loading}>
          {visibleIds.map((id, idx) => (
            <section
              key={id}
              id={`w-${id}`}
              aria-labelledby={`wt-${id}`}
              className={`surface-1 p-4 min-w-0 ${isWide(id) ? 'xl:col-span-2' : ''} ${edit ? 'ring-1 ring-accent/40' : ''} ${dragId === id ? 'opacity-50' : ''}`}
              draggable={edit}
              onDragStart={(e) => { setDragId(id); e.dataTransfer.effectAllowed = 'move' }}
              onDragEnd={() => setDragId(null)}
              onDragOver={(e) => { if (edit && dragId) e.preventDefault() }}
              onDrop={(e) => { e.preventDefault(); dropOn(id) }}
            >
              <header className="flex items-center justify-between gap-2 mb-3">
                <h2 id={`wt-${id}`} className={`font-display font-semibold text-base flex items-center gap-2 ${edit ? 'cursor-move' : ''}`}>
                  {edit && <Icon name="grip" size={15} className="text-text-secondary" />}
                  {WIDGET_BY_ID[id].title}
                </h2>
                {edit && (
                  <div className="flex items-center gap-0.5">
                    <IconBtn icon="arrow-up" label="Выше" onClick={() => move(id, -1)} disabled={idx === 0} />
                    <IconBtn icon="arrow-down" label="Ниже" onClick={() => move(id, 1)} disabled={idx === visibleIds.length - 1} />
                    <IconBtn icon="arrows-h" label={isWide(id) ? 'Половина ширины' : 'Во всю ширину'} onClick={() => toggleWide(id)} />
                    <IconBtn icon="eye-off" label="Скрыть блок" onClick={() => hide(id)} />
                  </div>
                )}
              </header>
              {renderWidget(id)}
            </section>
          ))}
          {visibleIds.length === 0 && (
            <div className="xl:col-span-2 text-sm text-text-secondary">Все блоки скрыты. Нажмите «Настроить панель», чтобы вернуть нужные.</div>
          )}
        </div>
      )}
    </div>
  )
}

function IconBtn({ icon, label, onClick, disabled }) {
  return (
    <button type="button" onClick={onClick} disabled={disabled} title={label} aria-label={label}
      className="p-1.5 rounded-md text-text-secondary hover:bg-surface-alt hover:text-text-primary disabled:opacity-30">
      <Icon name={icon} size={15} />
    </button>
  )
}

function Empty({ text, icon, good }) {
  return (
    <div className="flex items-center gap-2 py-6 text-sm text-text-secondary">
      {icon && <Icon name={icon} size={16} style={{ color: good ? STATUS.good : undefined }} />}
      {text}
    </div>
  )
}
