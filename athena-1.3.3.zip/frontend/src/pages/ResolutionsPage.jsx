import React, { useCallback, useEffect, useState } from 'react'
import { usePreference } from '../lib/usePreference'
import { Link } from 'react-router-dom'
import { motion } from 'motion/react'
import { api } from '../api/client'

// «Ваши резолюции» — все резолюции пользователя строками (по резолюциям, а не
// по документам): наложенные им самим и адресованные ему.
const TABS = [
  ['author', 'Наложенные мной'],
  ['executor', 'Адресованные мне'],
]

const STATUS_TONE = {
  done: 'var(--color-success)',
  accepted: 'var(--color-success)',
  returned: 'var(--color-danger)',
  cancelled: 'var(--color-text-secondary)',
}

export default function ResolutionsPage() {
  const [resPref, setResPref] = usePreference('ui.resolutions', { tab: 'author', onlyOpen: true })
  const tab = resPref.tab || 'author'
  const onlyOpen = resPref.onlyOpen !== false
  const setTab = (t) => setResPref({ tab: t })
  const setOnlyOpen = (v) => setResPref({ onlyOpen: v })
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    try {
      const r = await api.myResolutions(onlyOpen ? 'open' : 'all', tab === 'author' ? 'author' : '')
      setItems(r.items || [])
      setError('')
    } catch (e) {
      setError(e.message || 'Не удалось загрузить резолюции')
    } finally {
      setLoading(false)
    }
  }, [tab, onlyOpen])

  useEffect(() => { setLoading(true); load() }, [load])

  // Онлайн-обновление: резолюции меняются событиями документа.
  useEffect(() => {
    let timer = null
    const onChanged = () => { clearTimeout(timer); timer = setTimeout(load, 600) }
    window.addEventListener('athena:document_changed', onChanged)
    window.addEventListener('athena:changed', onChanged)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('athena:document_changed', onChanged)
      window.removeEventListener('athena:changed', onChanged)
    }
  }, [load])

  return (
    <div className="p-6 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-xl font-semibold">Ваши резолюции</h1>
        <label className="flex items-center gap-2 text-sm cursor-pointer">
          <input type="checkbox" checked={onlyOpen} onChange={(e) => setOnlyOpen(e.target.checked)} />
          Только незавершённые
        </label>
      </div>

      <div className="flex gap-1 border-b border-border">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`px-3 py-2 text-sm -mb-px border-b-2 ${
              tab === id ? 'border-accent text-text-primary font-medium' : 'border-transparent text-text-secondary hover:text-text-primary'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {error && <div className="text-danger text-sm">{error}</div>}

      <div className="surface-1 overflow-x-auto">
        <table className="w-full text-sm align-top">
          <thead>
            <tr className="text-left text-text-secondary border-b border-border">
              <th className="px-3 py-2 font-medium">Документ</th>
              <th className="px-3 py-2 font-medium">Резолюция</th>
              <th className="px-3 py-2 font-medium">{tab === 'author' ? 'Исполнители' : 'Автор'}</th>
              <th className="px-3 py-2 font-medium">Срок</th>
              <th className="px-3 py-2 font-medium">Статус</th>
            </tr>
          </thead>
          <tbody>
            {items.map((r, i) => (
              <motion.tr
                key={`${r.resolution_id}-${i}`}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: Math.min(i, 10) * 0.02 }}
                className="border-b border-border last:border-0 hover:bg-surface-alt"
              >
                <td className="px-3 py-2">
                  <Link to={`/document/${r.document_id}`} className="text-accent hover:underline">
                    {r.document_title || `Документ № ${r.document_id}`}
                  </Link>
                  {r.outgoing_number && <div className="text-[11px] text-text-secondary">№ {r.outgoing_number}</div>}
                </td>
                <td className="px-3 py-2 max-w-md break-words">{r.text}</td>
                <td className="px-3 py-2">{tab === 'author' ? (r.executors || '—') : (r.author_name || '—')}</td>
                <td className="px-3 py-2 whitespace-nowrap">
                  {r.due_date ? (
                    <span className={r.overdue ? 'text-danger font-medium' : ''}>{new Date(r.due_date).toLocaleDateString('ru-RU')}</span>
                  ) : '—'}
                </td>
                <td className="px-3 py-2">
                  <span className="chip" style={{ color: STATUS_TONE[r.status] || 'var(--color-text-primary)' }}>
                    {r.status_label}
                  </span>
                </td>
              </motion.tr>
            ))}
            {!loading && items.length === 0 && (
              <tr><td colSpan={5} className="px-3 py-8 text-center text-text-secondary">Резолюций нет</td></tr>
            )}
            {loading && (
              <tr><td colSpan={5} className="px-3 py-8 text-center text-text-secondary">Загрузка…</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
