package handlers

import (
	"strconv"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
)

// SessionsHandler — сеансы работы (, п. 8).
//
// Зачем это в интерфейсе, а не только в БД: при политике «новый вход
// отклоняется» человек, у которого упал браузер, заблокирован до истечения
// срока токена. Администратор должен иметь возможность завершить его сеанс —
// иначе запрет одновременного входа превращается в постоянные звонки.
//
// Свои сеансы человек видит сам (политика sessions_select): это даёт ему
// возможность заметить чужой вход под его учётной записью.
type SessionsHandler struct {
	pool     *pgxpool.Pool
	sessions *service.SessionService
	audit    *service.AuditService
}

func NewSessionsHandler(pool *pgxpool.Pool, sessions *service.SessionService,
	audit *service.AuditService) *SessionsHandler {
	return &SessionsHandler{pool: pool, sessions: sessions, audit: audit}
}

type sessionRow struct {
	ID          int64      `json:"id"`
	UserID      int64      `json:"user_id"`
	UserName    string     `json:"user_name"`
	Login       string     `json:"login"`
	IP          string     `json:"ip,omitempty"`
	Workstation string     `json:"workstation,omitempty"`
	UserAgent   string     `json:"user_agent,omitempty"`
	CreatedAt   time.Time  `json:"created_at"`
	LastSeenAt  time.Time  `json:"last_seen_at"`
	ExpiresAt   time.Time  `json:"expires_at"`
	RevokedAt   *time.Time `json:"revoked_at,omitempty"`
	RevokeNote  string     `json:"revoke_reason,omitempty"`
	Active      bool       `json:"active"`
	Current     bool       `json:"current"`
}

// List GET /api/sessions?active=true — сеансы.
//
// Что видно — решает RLS: обычный пользователь получит только свои.
func (h *SessionsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	curSession, _ := c.Locals(middleware.CtxSessionID).(int64)
	onlyActive := c.Query("active") == "true"

	cond := ""
	if onlyActive {
		cond = " AND s.revoked_at IS NULL AND s.expires_at > now()"
	}
	items := []sessionRow{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT s.id, s.user_id, coalesce(u.full_name,''), coalesce(u.login,''),
			       coalesce(host(s.ip),''), coalesce(s.workstation,''), coalesce(s.user_agent,''),
			       s.created_at, s.last_seen_at, s.expires_at, s.revoked_at,
			       coalesce(s.revoke_reason,''),
			       (s.revoked_at IS NULL AND s.expires_at > now()) AS active
			  FROM user_sessions s LEFT JOIN users u ON u.id = s.user_id
			 WHERE true`+cond+`
			 ORDER BY (s.revoked_at IS NULL) DESC, s.last_seen_at DESC
			 LIMIT 500`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r sessionRow
			if err := rows.Scan(&r.ID, &r.UserID, &r.UserName, &r.Login, &r.IP, &r.Workstation,
				&r.UserAgent, &r.CreatedAt, &r.LastSeenAt, &r.ExpiresAt, &r.RevokedAt,
				&r.RevokeNote, &r.Active); err != nil {
				return err
			}
			r.Current = r.ID == curSession
			items = append(items, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить сеансы")
	}
	return c.JSON(fiber.Map{"items": items, "policy": string(h.sessions.Policy())})
}

// Revoke DELETE /api/sessions/:id — завершить сеанс.
//
// Своим сеансом распоряжается сам пользователь, чужим — только администратор.
// Проверка здесь, а не в RLS: политика sessions_update намеренно разрешающая,
// т.к. сеансы создаются и отзываются серверным кодом в момент, когда
// app.user_id ещё не установлен (вход). Поэтому именно здесь проверяется, кому
// принадлежит сеанс.
func (h *SessionsHandler) Revoke(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var ownerID int64
	var jti string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT user_id, jti FROM user_sessions WHERE id = $1 AND revoked_at IS NULL`, id).
			Scan(&ownerID, &jti)
	})
	if txErr != nil {
		// Не различаем «нет такого сеанса» и «сеанс уже завершён»: для
		// пользователя результат один и тот же.
		return fiber.NewError(fiber.StatusNotFound, "действующий сеанс не найден")
	}
	if ownerID != userID && !isAdmin {
		return fiber.NewError(fiber.StatusForbidden, "завершить чужой сеанс может только администратор")
	}

	reason := "завершено пользователем"
	if ownerID != userID {
		reason = "завершено администратором"
	}
	if err := h.sessions.Close(c.Context(), jti, reason); err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось завершить сеанс")
	}
	h.audit.Write(service.AuditEvent{
		ActorID: userID, ActorLogin: login, Event: "session.revoke", Outcome: "ok",
		ObjectKind: "user_session", ObjectID: id,
		HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: fiber.StatusOK,
		IP: middleware.ClientIP(c), UserAgent: c.Get("User-Agent"),
		Details: map[string]any{"owner_id": ownerID, "reason": reason},
	})
	return c.SendStatus(fiber.StatusOK)
}
