package server

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"time"

	"corpnet/internal/kv"
)

// Run starts the realtime hub and the periodic jobs. Every job is guarded by a
// Redis lock, so with N instances each job still runs once per period.
func (s *Server) Run(ctx context.Context) {
	s.hub.start(ctx)
	go s.every(ctx, 10*time.Second, monJob("heartbeat", s.heartbeat))
	go s.every(ctx, 15*time.Second, monJob("flush_views", s.flushViews))
	go s.every(ctx, time.Hour, monJob("daily", s.dailyJobs))
	go s.every(ctx, time.Minute, monJob("minute", s.minuteJobs))
	go s.every(ctx, 5*time.Second, s.monRedisProbe) // задержка Redis для /metrics (mon_trace.go)
	go s.every(ctx, monStep, s.monSample)           // встроенный мониторинг: кольцевой буфер для панели (mon_tsdb.go)
	s.anRun(ctx)                                    // аналитика: очередь поиска, сброс счётчиков, rollup-задачи
	// Тяжёлые фоновые циклы (конвертация медиа, синхронизация и индексация файлов) живут в одном процессе:
	// при prefork его выбирают выборы лидера в job_locks (аренда продлевается, при падении лидера её подхватывает другой рабочий).
	start := func() {
		s.mediaLoop(ctx)     // фоновая конвертация фото/видео (media_jobs.go)
		s.fileIndexLoop(ctx) // извлечение текста файлов для поиска (filesearch.go)
	}
	// Циклы уровня узла (не пишут в БД или пишут только на мастере): один лидер на узел — по файловой блокировке.
	go s.electLocalLeader(ctx, func() {
		go s.clusterLoop(ctx) // проверка узлов, автопереключение мастера (nodes.go)
		s.fileSyncLoop(ctx)   // синхронизация файлов с соседними узлами (filesync.go, nodes.go)
	})
	if s.cfg.Background {
		start()
	} else {
		go s.electLeader(ctx, start)
	}
}

// minuteJobs — глобальные задачи: каждая безопасна при любом числе экземпляров и ЦОДов
// (атомарный UPDATE … RETURNING или блокировка в основной БД).
func (s *Server) minuteJobs(ctx context.Context) {
	s.announceDue(ctx, 0) // отложенные новости стали видимыми
	s.ldapSyncJob(ctx)
	s.outboxCleanup(ctx)
	s.kvSweep(ctx)
	s.lmsJobs(ctx)     // LMS: автоназначение, напоминания, сроки действия
	s.mailJob(ctx)     // email-рассылки: очередь с ограничением скорости (mailer.go)
	s.mustReadJob(ctx) // обязательное ознакомление: напоминания и эскалация (news_tz.go)
	s.requestsJob(ctx) // заявки: напоминания, просрочка, эскалация (requests_jobs.go)
}

func (s *Server) every(ctx context.Context, d time.Duration, fn func(context.Context)) {
	t := time.NewTicker(d)
	defer t.Stop()
	fn(ctx)
	for {
		select {
		case <-t.C:
			fn(ctx)
		case <-ctx.Done():
			return
		}
	}
}

// heartbeat lets the admin dashboard list live app instances.
func (s *Server) heartbeat(ctx context.Context) {
	now := time.Now().Unix()
	info, _ := json.Marshal(map[string]any{"ws": s.hub.conns.Load(), "since": s.up.Unix()})
	s.rdb.HSet(ctx, "insts", s.cfg.InstanceID, string(info))
	s.rdb.ZAdd(ctx, "instances", kv.Z{Score: float64(now), Member: s.cfg.InstanceID})
	s.rdb.ZRemRangeByScore(ctx, "instances", "-inf", strconv.FormatInt(now-30, 10))
}

// flushViews moves buffered view counters of this DC from Redis to Postgres in one UPDATE.
func (s *Server) flushViews(ctx context.Context) {
	key := "views:" + s.cfg.DCID
	if !s.rdb.SetNX(ctx, "lock:"+key, s.cfg.InstanceID, 20*time.Second).Val() {
		return
	}
	defer s.rdb.Del(ctx, "lock:"+key)
	s.rdb.RenameNX(ctx, key, key+":flush") // fails harmlessly if there is nothing to flush
	m, err := s.rdb.HGetAll(ctx, key+":flush").Result()
	if err != nil || len(m) == 0 {
		return
	}
	ids, cnt := make([]int64, 0, len(m)), make([]int32, 0, len(m))
	for k, v := range m {
		id, e1 := strconv.ParseInt(k, 10, 64)
		n, e2 := strconv.ParseInt(v, 10, 32)
		if e1 == nil && e2 == nil {
			ids, cnt = append(ids, id), append(cnt, int32(n))
		}
	}
	if _, err := s.db.Exec(ctx, `UPDATE news n SET views_count = n.views_count + v.c
		FROM unnest($1::bigint[], $2::int[]) AS v(id, c) WHERE n.id = v.id`, ids, cnt); err != nil {
		s.log.Warn("flush views failed", "err", err)
		return
	}
	s.rdb.Del(ctx, key+":flush")
	s.anNewsViews(ctx, ids, cnt) // дневной rollup просмотров для аналитики
	s.bumpNews(ctx)
}

func (s *Server) dailyJobs(ctx context.Context) {
	day := time.Now().Format("2006-01-02")
	if !s.lock(ctx, "daily:"+day, 26*time.Hour) {
		return
	}
	s.obJob(ctx) // адаптация: автоназначение планов и напоминания (onboarding.go)
	// Дни рождения: поздравляют коллеги из того же подразделения (а не вся компания — иначе при большом штате
	// на каждого именинника пришлось бы создавать десятки тысяч уведомлений).
	tag, err := s.db.Exec(ctx, `INSERT INTO notifications (user_id, kind, title, body, link)
		SELECT r.id, 'birthday', 'Сегодня день рождения: ' || b.full_name, b.job_title, '/people/' || b.id
		FROM users b JOIN users r ON r.department_id = b.department_id
		WHERE b.birthday IS NOT NULL AND NOT b.blocked AND NOT r.blocked AND r.id <> b.id
		  AND extract(month FROM b.birthday) = extract(month FROM now()) AND extract(day FROM b.birthday) = extract(day FROM now())`)
	if err == nil && tag.RowsAffected() > 0 {
		s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
	}
	s.db.Exec(ctx, `DELETE FROM notifications WHERE created_at < now() - interval '90 days' AND read_at IS NOT NULL`)
	s.db.Exec(ctx, `DELETE FROM sessions WHERE expires_at < now()`)
	s.log.Info("daily jobs done", "birthdays_notified", tag.RowsAffected())
}

// kvSweep удаляет просроченные строки kv_store (только для KV_BACKEND=pg).
func (s *Server) kvSweep(ctx context.Context) {
	b, ok := s.rdb.Backend().(*kv.PG)
	if !ok || !s.lock(ctx, "kv-sweep", 50*time.Second) {
		return
	}
	if _, err := b.Sweep(ctx); err != nil {
		s.log.Warn("kv sweep", "err", err)
	}
}

// electLeader раз в 15 с продлевает или пытается взять аренду «bg-leader»; став лидером, однократно запускает start.
func (s *Server) electLeader(ctx context.Context, start func()) {
	me := fmt.Sprintf("%s-%d", s.cfg.InstanceID, os.Getpid())
	started := false
	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for {
		var got string
		var err error = errNotMaster
		if s.isMasterNode(ctx) { // фоновые задачи пишут в БД: только на мастере
			err = s.db.Pool.QueryRow(ctx, `INSERT INTO job_locks (name, holder, locked_until) VALUES ('bg-leader', $1, now() + interval '45 seconds')
			ON CONFLICT (name) DO UPDATE SET holder = $1, locked_until = now() + interval '45 seconds'
			WHERE job_locks.holder = $1 OR job_locks.locked_until < now() RETURNING holder`, me).Scan(&got)
		}
		if err == nil && got == me && !started {
			started = true
			s.log.Info("фоновые циклы: этот процесс стал лидером", "pid", os.Getpid())
			start()
		}
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
	}
}
