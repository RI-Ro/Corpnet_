package middleware

import (
	"athena/backend/internal/service"
	"github.com/gofiber/fiber/v2"
)

const (
	CtxUserID  = "userID"
	CtxIsAdmin = "isAdmin"
	CtxLogin   = "login"
	// CtxClaims — разобранный токен целиком. Нужен SessionGuard: он берёт
	// оттуда jti (идентификатор сессии). Складывать сюда весь объект, а не
	// только jti, правильнее: следующему middleware может понадобиться другое
	// поле, и разбирать токен второй раз не придётся.
	CtxClaims = "claims"
)

// JWTAuth проверяет токен сеанса из cookie (см. session_cookie.go) и кладёт
// userID/isAdmin в контекст запроса. Заголовок Authorization не
// принимается: токен никогда не попадает в скрипты страницы. Все хендлеры, работающие с защищёнными RLS-таблицами, обязаны
// использовать db.WithUserTx с этими значениями.
func JWTAuth(auth *service.AuthService) fiber.Handler {
	return func(c *fiber.Ctx) error {
		tokenStr := SessionToken(c)
		if tokenStr == "" {
			return fiber.NewError(fiber.StatusUnauthorized, "требуется вход в систему")
		}
		claims, err := auth.ParseToken(tokenStr)
		if err != nil {
			ClearSessionCookies(c)
			return fiber.NewError(fiber.StatusUnauthorized, "сеанс истёк, войдите заново")
		}
		c.Locals(CtxUserID, claims.UserID)
		c.Locals(CtxIsAdmin, claims.IsAdmin)
		c.Locals(CtxLogin, claims.Login)
		c.Locals(CtxClaims, claims)
		return c.Next()
	}
}
