package report

import (
	"strings"
	"testing"
)

func TestLongRegistrationNumbersSurviveTablePagination(t *testing.T) {
	doc := NewDoc("Отчёт", "Проверка")
	number := "ВХ-" + strings.Repeat("АБВ-2026/12/", 95) + "КОНЕЦ"
	text := "Департамент " + number
	lines := doc.wrapText(text, 7.5, 52)
	if strings.Join(lines, "") != text {
		t.Fatal("потеряны символы номера")
	}
	for _, line := range lines {
		if doc.Width(line, 7.5) > 52.001 {
			t.Fatalf("выход за границу: %q", line)
		}
	}
	doc.Table(42, Table{Headers: []string{"Вх. №"}, Widths: []float64{62}, Rows: [][]string{{text}}})
	if doc.pageNo < 2 {
		t.Fatal("длинную строку нужно перенести на другую страницу")
	}
	if _, err := doc.Bytes(); err != nil {
		t.Fatal(err)
	}
}
