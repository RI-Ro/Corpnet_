package server

import (
	"regexp"
	"strings"
)

// Внутренние ссылки (уведомления, баннеры) — абсолютные пути SPA, которые есть в frontend/src/main.tsx (ROUTES).
// Параметры, которые понимает фронтенд: /groups/:id?post=ID#comment-ID, /messages?chat=ID, /calendar?event=ID&date=YYYY-MM-DD,
// /documents|photos|videos?folder=ID, /search?q=, /news/:id#comment-ID, /ideas/:id#comment-ID.
var appRouteRe = regexp.MustCompile(`^/(?:` + strings.Join([]string{
	``, // главная
	`news/new`, `news/\d+`, `news/\d+/edit`,
	`people`, `people/\d+`, `departments`, `departments/\d+`, `directions`,
	`groups`, `groups/\d+`, `messages`, `calendar`, `documents`, `photos`, `videos`,
	`company`, `resources`, `search`, `settings`, `ideas`, `ideas/\d+`, `vacations`, `notifications`,
	`onboarding`, `rewards`, `surveys`, `surveys/\d+`, `surveys/\d+/results`, `ask`, `feedback`, `editorial`, `must-read`, `birthdays`, `learning(?:/[A-Za-z0-9._~/-]*)?`, `requests(?:/[A-Za-z0-9._~/-]*)?`, `wiki(?:/[A-Za-z0-9._~/-]*)?`, `admin`, `admin/[a-z-]+`,
}, "|") + `)/?$`)

// validAppLink — путь существует в SPA (query и #hash не проверяются). Пустая ссылка допустима.
func validAppLink(link string) bool {
	if link == "" {
		return true
	}
	if !strings.HasPrefix(link, "/") || strings.HasPrefix(link, "//") {
		return false
	}
	p := link
	if i := strings.IndexAny(p, "?#"); i >= 0 {
		p = p[:i]
	}
	return appRouteRe.MatchString(p)
}

// Модуль предназначен для проверки ссылок, вводимых пользователями.
// Допустимы адреса с любой безопасной схемой (https, http, ftp, sftp, smb, file, mailto, tel, rtsp и др.),
// внутренние пути портала (/news/5) и сетевые пути Windows (\\сервер\папка). Запрещены схемы, исполняющие код.

var schemeRe = regexp.MustCompile(`^([a-zA-Z][a-zA-Z0-9+.\-]{1,19}):`)

var badSchemes = map[string]bool{"javascript": true, "data": true, "vbscript": true, "blob": true, "about": true}

// linkOK — ссылка с любой безопасной схемой (не путь портала).
func linkOK(u string) bool {
	u = strings.TrimSpace(u)
	if len(u) < 4 || len(u) > 2048 || strings.ContainsAny(u, " \t\r\n<>\"") {
		return false
	}
	if strings.HasPrefix(u, `\\`) { // UNC: \\server\share
		return len(u) > 3
	}
	m := schemeRe.FindStringSubmatch(u)
	if m == nil {
		return false
	}
	return !badSchemes[strings.ToLower(m[1])] && len(u) > len(m[0])
}

// linkOrPathOK — ссылка либо внутренний путь портала (/news/5, но не //хост).
func linkOrPathOK(u string) bool {
	u = strings.TrimSpace(u)
	if strings.HasPrefix(u, "/") && !strings.HasPrefix(u, "//") && len(u) <= 2048 && !strings.ContainsAny(u, " \t\r\n<>\"") {
		return true
	}
	return linkOK(u)
}
