const fs = require('fs');
const d = require('docx');
const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType,
  BorderStyle, ShadingType, AlignmentType, LevelFormat, ImageRun, Footer, PageNumber, TabStopType } = d;
const B = JSON.parse(fs.readFileSync('blocks.json', 'utf8'));
const FONT = 'Arial', NAVY = '1F4E9C';
const W = 9638; // ширина текста A4 при полях 2 см (11906 - 2*1134)

function tr(r, extra = {}) {
  const out = [];
  for (const x of r) {
    if (x.br) { out.push(new TextRun({ break: 1 })); continue; }
    let t = x.t.replace(/\s+/g, ' ');
    if (x.btn) out.push(new TextRun({ text: `[${t}]`, bold: true, color: '2B4A7A', font: FONT, ...extra }));
    else if (x.code) out.push(new TextRun({ text: t, font: 'Consolas', ...extra }));
    else out.push(new TextRun({ text: t, bold: !!x.b || !!extra.bold, font: FONT, ...extra }));
  }
  // обрезка пробелов в начале/конце абзаца
  return out;
}
const trim = (r) => {
  const c = r.map((x) => ({ ...x }));
  if (c.length && c[0].t) c[0].t = c[0].t.replace(/^\s+/, '');
  if (c.length && c[c.length - 1].t) c[c.length - 1].t = c[c.length - 1].t.replace(/\s+$/, '');
  return c;
};
const border = { style: BorderStyle.SINGLE, size: 4, color: 'B7C4D8' };
const borders = { top: border, bottom: border, left: border, right: border };
const children = [];
let olRef = 0;
const numberingConfigs = [{ reference: 'bul', levels: [{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT,
  style: { paragraph: { indent: { left: 567, hanging: 283 } } } }] }];

function box(r, fill, line) {
  return new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [W], rows: [new TableRow({ children: [
    new TableCell({ width: { size: W, type: WidthType.DXA }, shading: { fill, type: ShadingType.CLEAR, color: 'auto' },
      borders: { top: { style: BorderStyle.SINGLE, size: 4, color: line }, bottom: { style: BorderStyle.SINGLE, size: 4, color: line },
        left: { style: BorderStyle.SINGLE, size: 18, color: line }, right: { style: BorderStyle.SINGLE, size: 4, color: line } },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ children: tr(trim(r)) })] })] })] });
}

for (const b of B) {
  switch (b.k) {
    case 'cover': {
      children.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: [2000, W - 2000],
        borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE }, insideHorizontal: { style: BorderStyle.NONE }, insideVertical: { style: BorderStyle.NONE } },
        rows: [new TableRow({ children: [
          new TableCell({ width: { size: 2000, type: WidthType.DXA }, borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
            children: [new Paragraph({ children: [new ImageRun({ type: 'png', data: fs.readFileSync('emblem.png'), transformation: { width: 100, height: 100 },
              altText: { title: 'Эмблема', description: 'Эмблема ИР «Афина»', name: 'emblem' } })] })] }),
          new TableCell({ width: { size: W - 2000, type: WidthType.DXA }, borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
            children: [new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun({ text: b.title })] }),
              ...b.sub.map((s) => new Paragraph({ spacing: { after: 40 }, children: [new TextRun({ text: s, color: '555555', font: FONT, size: 20 })] }))] }),
        ] })] }));
      children.push(new Paragraph({ spacing: { after: 120 }, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: NAVY, space: 4 } }, children: [] }));
      break;
    }
    case 'h1': children.push(new Paragraph({ heading: HeadingLevel.TITLE, children: tr(trim(b.r)) })); break;
    case 'h2': children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, children: tr(trim(b.r)) })); break;
    case 'h3': children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, children: tr(trim(b.r)) })); break;
    case 'p': children.push(new Paragraph({ spacing: { after: 120 }, children: tr(trim(b.r)) })); break;
    case 'toc': {
      children.push(new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: 'Содержание', bold: true, font: FONT })] }));
      for (const it of b.items) children.push(new Paragraph({ spacing: { after: 20 }, indent: { left: 284 }, children: [new TextRun({ text: it, font: FONT, size: 20 })] }));
      children.push(new Paragraph({ children: [] }));
      break;
    }
    case 'ul':
      for (const it of b.items) children.push(new Paragraph({ numbering: { reference: 'bul', level: 0 }, spacing: { after: 60 }, children: tr(trim(it)) }));
      break;
    case 'ol': {
      const ref = `ol${olRef++}`;
      numberingConfigs.push({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 567, hanging: 340 } }, run: { bold: true, color: NAVY } } }] });
      for (const it of b.items) children.push(new Paragraph({ numbering: { reference: ref, level: 0 }, spacing: { after: 60 }, children: tr(trim(it)) }));
      break;
    }
    case 'note': children.push(box(b.r, 'FFF6E5', 'E0A23A')); children.push(new Paragraph({ children: [] })); break;
    case 'tip': children.push(box(b.r, 'EEF6FD', '6FA3D8')); children.push(new Paragraph({ children: [] })); break;
    case 'flow': {
      const n = b.items.length, cw = Math.floor(W / n), widths = Array(n).fill(cw); widths[n - 1] = W - cw * (n - 1);
      children.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: widths, rows: [new TableRow({ children: b.items.map(([h, t], i) =>
        new TableCell({ width: { size: widths[i], type: WidthType.DXA }, borders, shading: { fill: 'F6F9FD', type: ShadingType.CLEAR, color: 'auto' },
          margins: { top: 60, bottom: 60, left: 80, right: 80 },
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: NAVY, font: FONT, size: 18 })] }),
            new Paragraph({ children: [new TextRun({ text: t.trim(), font: FONT, size: 18 })] })] })) })] }));
      children.push(new Paragraph({ children: [] }));
      break;
    }
    case 'table': {
      const n = Math.max(...b.rows.map((r) => r.c.length));
      const widths = n === 2 ? [2700, W - 2700] : n === 3 ? [2400, 3200, W - 5600] : Array(n).fill(Math.floor(W / n));
      if (n > 3) widths[n - 1] = W - widths.slice(0, -1).reduce((a, x) => a + x, 0);
      children.push(new Table({ width: { size: W, type: WidthType.DXA }, columnWidths: widths,
        rows: b.rows.map((r) => new TableRow({ tableHeader: r.h, cantSplit: true, children: r.c.map((c, i) =>
          new TableCell({ width: { size: widths[i], type: WidthType.DXA }, borders,
            shading: r.h ? { fill: 'E8EEF7', type: ShadingType.CLEAR, color: 'auto' } : undefined,
            margins: { top: 60, bottom: 60, left: 100, right: 100 },
            children: [new Paragraph({ children: tr(trim(c), r.h ? { bold: true, size: 19 } : { size: 19 }) })] })) })) }));
      children.push(new Paragraph({ children: [] }));
      break;
    }
  }
}

const doc = new Document({
  creator: 'ИР «Афина»', title: 'Инструкция по работе с информационным ресурсом ИР «Афина»',
  styles: {
    default: { document: { run: { font: FONT, size: 21 } } },
    paragraphStyles: [
      { id: 'Title', name: 'Title', basedOn: 'Normal', next: 'Normal', run: { font: FONT, size: 44, bold: true, color: '1B2A44' }, paragraph: { spacing: { before: 0, after: 80 }, keepNext: true } },
      { id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 28, bold: true, color: NAVY }, paragraph: { spacing: { before: 280, after: 120 }, keepNext: true, outlineLevel: 0,
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'B7C4D8', space: 2 } } } },
      { id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true, run: { font: FONT, size: 23, bold: true, color: '1B2A44' }, paragraph: { spacing: { before: 180, after: 80 }, keepNext: true, outlineLevel: 1 } },
    ],
  },
  numbering: { config: numberingConfigs },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, bottom: 1134, left: 1134, right: 1134 } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [
      new TextRun({ text: 'ИР «Афина» · Инструкция по работе с информационным ресурсом · стр. ', size: 16, color: '777777', font: FONT }),
      new TextRun({ children: [PageNumber.CURRENT], size: 16, color: '777777', font: FONT })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then((buf) => fs.writeFileSync('user-guide.docx', buf));
