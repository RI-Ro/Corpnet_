package server

import (
	"fmt"
	"io"
	"net"
	"os"
	"regexp"
	"slices"
	"strconv"
	"strings"

	"gopkg.in/yaml.v3"
)

var configKeys = map[string]string{
	"server.addr": "HTTP_ADDR", "server.tls_cert": "TLS_CERT", "server.tls_key": "TLS_KEY", "server.http_redirect": "HTTP_REDIRECT_ADDR",
	"server.trusted_proxies": "TRUSTED_PROXIES", "server.allowed_origins": "ALLOWED_ORIGINS", "server.static_dir": "STATIC_DIR",
	"server.data_dir": "DATA_DIR", "server.max_upload_mb": "MAX_UPLOAD_MB", "server.cookie_secure": "COOKIE_SECURE",
	"server.session_ttl_hours": "SESSION_TTL_HOURS", "server.instance_id": "INSTANCE_ID", "server.dc_id": "DC_ID", "server.tz": "TZ",
	"server.prefork": "PREFORK", "server.internal_allow": "INTERNAL_ALLOW", "server.metrics_addr": "METRICS_ADDR",
	"database.url": "DATABASE_URL", "database.replica_url": "DATABASE_REPLICA_URL", "database.pool_size": "PG_POOL_MAX",
	"storage.redis_url": "REDIS_URL", "storage.kv_backend": "KV_BACKEND", "storage.session_store": "SESSION_STORE", "storage.realtime": "REALTIME_MODE",
	"auth.secret_key": "SECRET_KEY", "auth.internal_token": "INTERNAL_TOKEN",
	"logging.access_log": "ACCESS_LOG", "logging.error_log": "ERROR_LOG", "logging.console": "LOG_CONSOLE",
	"logging.slow_request_ms": "SLOW_REQUEST_MS", "logging.slow_sql_ms": "SLOW_SQL_MS",
	"kerberos.enabled": "KRB5_ENABLED", "kerberos.service_principal": "KRB5_SERVICE_PRINCIPAL", "kerberos.keytab": "KRB5_KEYTAB",
	"kerberos.realm": "KRB5_REALM", "kerberos.conf": "KRB5_CONF", "kerberos.clock_skew_sec": "KRB5_CLOCK_SKEW_SEC",
	"kerberos.user_map": "KRB5_USER_MAP", "kerberos.auto_create": "KRB5_AUTO_CREATE",
	"files.media_workers": "MEDIA_WORKERS", "files.ffmpeg": "FFMPEG_BIN", "files.peers": "FILE_PEERS", "files.sync": "FILE_SYNC",

	"server.peer_allow": "PEER_ALLOW", "server.node_code": "NODE_CODE",
	"server.node_fence": "NODE_FENCE", "server.node_switch_hook": "NODE_SWITCH_HOOK",
	"server.analytics_retention_days": "ANALYTICS_RETENTION_DAYS", "server.version": "APP_VERSION",
	"security.csp_report_only": "CSP_REPORT_ONLY", "security.csp_extra": "CSP_EXTRA", "security.rls_disable": "RLS_DISABLE", "security.csrf_disable": "CSRF_DISABLE",
	"files.index": "FILE_INDEX", "files.index_workers": "FILE_INDEX_WORKERS", "files.sync_interval_sec": "FILE_SYNC_INTERVAL_SEC", "files.sync_workers": "FILE_SYNC_WORKERS", "files.ffmpeg_timeout_min": "MEDIA_FFMPEG_TIMEOUT_MIN",
}

var configRef = regexp.MustCompile(`^\$\{([A-Za-z_][A-Za-z_0-9]*)\}$`)

var fileValues map[string]string // populated once before the server starts

// ApplyConfigFile resolves only explicitly referenced environment variables.

func ApplyConfigFile(path string) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	dec := yaml.NewDecoder(f)
	var sections map[string]map[string]any
	if err = dec.Decode(&sections); err != nil {
		return fmt.Errorf("конфигурация YAML: %w", err)
	}
	var extra any
	if err = dec.Decode(&extra); err != io.EOF {
		return fmt.Errorf("ожидается один документ YAML")
	}
	values := make(map[string]string)
	for section, fields := range sections {
		known := false
		for k := range configKeys {
			if strings.HasPrefix(k, section+".") {
				known = true
				break
			}
		}
		if !known {
			return fmt.Errorf("неизвестный раздел %s", section)
		}
		for field, raw := range fields {
			key := section + "." + field
			name, ok := configKeys[key]
			if !ok {
				return fmt.Errorf("неизвестный параметр %s", key)
			}
			var value string
			switch v := raw.(type) {
			case string:
				value = v
			case int, bool:
				value = fmt.Sprint(v)
			case []any:
				switch name {
				case "ALLOWED_ORIGINS", "TRUSTED_PROXIES", "INTERNAL_ALLOW", "PEER_ALLOW", "FILE_PEERS", "KRB5_REALM":
				default:
					return fmt.Errorf("%s: список недопустим", key)
				}
				var items []string
				for _, item := range v {
					s, ok := item.(string)
					if !ok {
						return fmt.Errorf("%s: ожидаются строки", key)
					}
					items = append(items, s)
				}
				value = strings.Join(items, ",")
			default:
				return fmt.Errorf("%s: неверный тип", key)
			}
			if m := configRef.FindStringSubmatch(value); m != nil {
				value, ok = os.LookupEnv(m[1])
				if !ok {
					return fmt.Errorf("%s: задайте переменную %s", key, m[1])
				}
			}
			values[name] = value
		}
	}
	if strings.TrimSpace(values["DATABASE_URL"]) == "" {
		return fmt.Errorf("задайте database.url")
	}
	secret := values["SECRET_KEY"]
	if len(secret) < 32 || strings.HasPrefix(secret, "test_secret_key") || strings.Contains(secret, "ОБЩИЙ_КЛЮЧ") {
		return fmt.Errorf("auth.secret_key: задайте собственный ключ длиной от 32 байт")
	}
	if (values["TLS_KEY"] == "") != (values["TLS_CERT"] == "") {
		return fmt.Errorf("server.tls_cert и server.tls_key задаются вместе")
	}
	for _, key := range []string{"INTERNAL_ALLOW", "PEER_ALLOW", "TRUSTED_PROXIES"} {
		for _, addr := range splitList(values[key]) {
			if len(parseCIDRs([]string{addr})) != 1 {
				return fmt.Errorf("%s: неверная сеть", key)
			}
		}
	}
	for _, key := range []string{"HTTP_ADDR", "METRICS_ADDR", "HTTP_REDIRECT_ADDR"} {
		if addr := values[key]; addr != "" {
			_, port, err := net.SplitHostPort(addr)
			n, e := strconv.Atoi(port)
			if err != nil || e != nil || n < 1 || n > 65535 {
				return fmt.Errorf("%s: неверный адрес", key)
			}
		}
	}
	for _, key := range []string{"COOKIE_SECURE", "CSP_REPORT_ONLY", "CSRF_DISABLE", "RLS_DISABLE", "FILE_SYNC", "KRB5_ENABLED", "KRB5_AUTO_CREATE", "LOG_CONSOLE"} {
		if v, ok := values[key]; ok {
			switch strings.ToLower(v) {
			case "0", "1", "true", "false", "no", "yes", "on", "off":
			default:
				return fmt.Errorf("%s: неверное логическое значение", key)
			}
		}
	}
	for _, key := range []string{"PG_POOL_MAX", "MAX_UPLOAD_MB", "SESSION_TTL_HOURS"} {
		if v, ok := values[key]; ok {
			n, err := strconv.Atoi(v)
			if err != nil || n < 1 || n > 100000 {
				return fmt.Errorf("%s: ожидается число от 1 до 100000", key)
			}
		}
	}
	allowed := map[string][]string{
		"KV_BACKEND": {"auto", "pg", "redis", "memory"}, "SESSION_STORE": {"kv", "redis", "pg"}, "REALTIME_MODE": {"auto", "pg", "redis"},
	}
	for key, choices := range allowed {
		if value, ok := values[key]; ok && !slices.Contains(choices, strings.ToLower(value)) {
			return fmt.Errorf("%s: ожидается %s", key, strings.Join(choices, ", "))
		}
	}
	for _, key := range []string{"MEDIA_WORKERS", "FILE_SYNC_WORKERS", "MEDIA_FFMPEG_TIMEOUT_MIN", "FILE_SYNC_INTERVAL_SEC", "FILE_INDEX_WORKERS", "SLOW_SQL_MS", "SLOW_REQUEST_MS", "ANALYTICS_RETENTION_DAYS", "KRB5_CLOCK_SKEW_SEC"} {
		if v, ok := values[key]; ok {
			n, err := strconv.Atoi(v)
			if err != nil || n < 0 {
				return fmt.Errorf("%s: ожидается неотрицательное число", key)
			}
		}
	}
	if v, ok := values["PREFORK"]; ok {
		switch strings.ToLower(v) {
		case "auto", "on", "off", "true", "false", "yes", "no":
		default:
			n, err := strconv.Atoi(v)
			if err != nil || n < 0 {
				return fmt.Errorf("server.prefork: ожидается число или auto")
			}
		}
	}
	if values["FILE_PEERS"] != "" && len(values["INTERNAL_TOKEN"]) < 32 {
		return fmt.Errorf("для межплощадочной связи задайте auth.internal_token длиной от 32 байт")
	}
	fileValues = values
	return nil
}
