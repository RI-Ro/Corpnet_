import React from 'react'

export default function AppearanceFields({value, update, error}) {
  return <fieldset className="space-y-3">
    <legend className="text-sm font-medium">Масштаб и шрифт</legend>
    {[['elements','Размер элементов',80,120],['text','Размер шрифта',50,150]].map(([key,label,min,max]) =>
      <label key={key} className="block text-sm">
        {label} <output>{value[key]}%</output>
        <input className="block w-full" type="range" aria-label={label} min={min} max={max}
          value={value[key]} onChange={e => update({[key]: Number(e.target.value)})} />
      </label>)}
    <label className="block text-sm">Шрифт
      <select className="field w-full" value={value.family} onChange={e => update({family:e.target.value})}>
        {window.athenaAppearance.families.map(name => <option key={name} value={name}>
          {name === 'Liberation Serif' ? 'Liberation Serif (аналог Times New Roman)' : name}
        </option>)}
      </select>
    </label>
    <div className="flex gap-4 text-sm">
      <label><input type="checkbox" checked={value.bold} onChange={e => update({bold:e.target.checked})} /> Полужирный</label>
      <label><input type="checkbox" checked={value.italic} onChange={e => update({italic:e.target.checked})} /> Курсив</label>
    </div>
    <button className="btn btn-secondary" onClick={() => update(window.athenaAppearance.defaults)}>Вернуть стандартное оформление</button>
    {error && <div role="alert">{error} <button className="btn" onClick={() => update({})}>Повторить</button></div>}
  </fieldset>
}
