package server

import (
	"bytes"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"sync"
	"syscall"
	"time"
)

// Модуль предназначен для журналов в стиле apache2: access.log (формат Combined + время обработки в мкс)
// и error.log (служебные сообщения и ошибки в JSON). Пути задаются logging.access_log / logging.error_log.
// Пустой путь — файл не ведётся. Каталог создаётся автоматически (0750), файлы — 0640.
// По SIGHUP файлы открываются заново (logrotate: postrotate kill -HUP $(pidof corpnet)).

type fileLog struct {
	mu   sync.Mutex
	path string
	f    *os.File
}

func openFileLog(path string) (*fileLog, error) {
	l := &fileLog{path: path}
	return l, l.reopen()
}

func (l *fileLog) reopen() error {
	if err := os.MkdirAll(filepath.Dir(l.path), 0o750); err != nil {
		return err
	}
	f, err := os.OpenFile(l.path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o640)
	if err != nil {
		return err
	}
	l.mu.Lock()
	old := l.f
	l.f = f
	l.mu.Unlock()
	if old != nil {
		old.Close()
	}
	return nil
}

func (l *fileLog) Write(p []byte) (int, error) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.f == nil {
		return len(p), nil
	}
	return l.f.Write(p)
}

var accessLog *fileLog

// errorOnly пропускает в error.log всё, кроме обычных записей access уровня info.
type errorOnly struct{ w io.Writer }

func (e errorOnly) Write(p []byte) (int, error) {
	if bytes.Contains(p, []byte(`"msg":"access"`)) && bytes.Contains(p, []byte(`"level":"info"`)) {
		return len(p), nil
	}
	return e.w.Write(p)
}

// SetupLogs открывает файловые журналы и возвращает приёмник для slog: файл error.log (+ консоль, если нужно).
func SetupLogs(accessPath, errorPath string, console bool, stdout io.Writer) (io.Writer, error) {
	var files []*fileLog
	if accessPath != "" {
		l, err := openFileLog(accessPath)
		if err != nil {
			return nil, err
		}
		accessLog = l
		files = append(files, l)
	}
	out := stdout
	if errorPath != "" {
		l, err := openFileLog(errorPath)
		if err != nil {
			return nil, err
		}
		files = append(files, l)
		if console {
			out = io.MultiWriter(stdout, errorOnly{l})
		} else {
			out = errorOnly{l}
		}
	}
	if len(files) > 0 {
		ch := make(chan os.Signal, 1)
		signal.Notify(ch, syscall.SIGHUP)
		go func() {
			for range ch {
				for _, l := range files {
					l.reopen()
				}
			}
		}()
	}
	return out, nil
}

// writeAccess пишет строку Combined: host - user [дата] "METHOD uri HTTP/x" status bytes "referer" "user-agent" время_мкс.
func writeAccess(host string, uid int64, t time.Time, method, uri, proto string, status int, bytesOut int64, referer, ua string, dur time.Duration) {
	if accessLog == nil {
		return
	}
	user := "-"
	if uid > 0 {
		user = strconv.FormatInt(uid, 10)
	}
	b := make([]byte, 0, 256)
	b = append(b, host...)
	b = append(b, " - "...)
	b = append(b, user...)
	b = append(b, " ["...)
	b = t.AppendFormat(b, "02/Jan/2006:15:04:05 -0700")
	b = append(b, `] "`...)
	b = append(b, method...)
	b = append(b, ' ')
	b = append(b, quoteLog(uri)...)
	b = append(b, ' ')
	b = append(b, proto...)
	b = append(b, `" `...)
	b = strconv.AppendInt(b, int64(status), 10)
	b = append(b, ' ')
	if bytesOut == 0 {
		b = append(b, '-')
	} else {
		b = strconv.AppendInt(b, bytesOut, 10)
	}
	b = append(b, ` "`...)
	b = append(b, quoteLog(dash(referer))...)
	b = append(b, `" "`...)
	b = append(b, quoteLog(dash(ua))...)
	b = append(b, `" `...)
	b = strconv.AppendInt(b, dur.Microseconds(), 10)
	b = append(b, '\n')
	accessLog.Write(b)
}

func dash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}

// quoteLog экранирует кавычки и управляющие символы, чтобы строка не ломала формат (защита от подмены записей журнала).
func quoteLog(s string) string {
	var out []byte
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == '"' || c == '\\' || c < 0x20 || c == 0x7f {
			if out == nil {
				out = append(out, s[:i]...)
			}
			out = append(out, '\\', 'x', "0123456789abcdef"[c>>4], "0123456789abcdef"[c&15])
			continue
		}
		if out != nil {
			out = append(out, c)
		}
	}
	if out == nil {
		return s
	}
	return string(out)
}
