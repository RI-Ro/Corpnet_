// Самохостинг шрифтов интерфейса (портал работает без доступа к внешним CDN).
// Берёт woff2 из @fontsource/*, копирует нужные начертания в <dist>/ui-fonts/<пакет>/ и пишет реестр src/lib/fontlist.ts.
// В браузер файлы попадают только после выбора шрифта пользователем (lib/appearance.ts → loadFont).
import fs from 'node:fs';
import path from 'node:path';

const FONTS = [
  ['tinos', 'Tinos (как Times New Roman)', 'Tinos', 'serif'],
  ['arimo', 'Arimo (как Arial)', 'Arimo', 'sans'],
  ['cousine', 'Cousine (как Courier New)', 'Cousine', 'mono'],
  ['roboto', 'Roboto', 'Roboto', 'sans'],
  ['open-sans', 'Open Sans', 'Open Sans', 'sans'],
  ['pt-sans', 'PT Sans', 'PT Sans', 'sans'],
  ['pt-serif', 'PT Serif', 'PT Serif', 'serif'],
  ['pt-mono', 'PT Mono', 'PT Mono', 'mono'],
  ['noto-sans', 'Noto Sans', 'Noto Sans', 'sans'],
  ['lora', 'Lora', 'Lora', 'serif'],
  ['merriweather', 'Merriweather', 'Merriweather', 'serif'],
  ['fira-sans', 'Fira Sans', 'Fira Sans', 'sans'],
  ['source-sans-3', 'Source Sans', 'Source Sans 3', 'sans'],
  ['ubuntu', 'Ubuntu', 'Ubuntu', 'sans'],
  ['ibm-plex-sans', 'IBM Plex Sans', 'IBM Plex Sans', 'sans'],
  ['montserrat', 'Montserrat', 'Montserrat', 'sans'],
  ['jetbrains-mono', 'JetBrains Mono', 'JetBrains Mono', 'mono'],
  ['playfair-display', 'Playfair Display', 'Playfair Display', 'display'],
  ['exo-2', 'Exo 2', 'Exo 2', 'display'],
  ['comfortaa', 'Comfortaa', 'Comfortaa', 'display'],
];
const SUBSETS = ['cyrillic', 'latin'];
const FACES = [['400', 'normal'], ['700', 'normal'], ['400', 'italic'], ['700', 'italic']];

export function emitFonts(dist) {
  const list = [];
  for (const [pkg, label, family, kind] of FONTS) {
    const root = path.join('node_modules', '@fontsource', pkg, 'files');
    if (!fs.existsSync(root)) continue;
    const faces = [];
    for (const sub of SUBSETS) for (const [w, st] of FACES) {
      const f = `${pkg}-${sub}-${w}-${st}.woff2`;
      if (!fs.existsSync(path.join(root, f))) continue;
      fs.mkdirSync(path.join(dist, 'ui-fonts', pkg), { recursive: true });
      fs.copyFileSync(path.join(root, f), path.join(dist, 'ui-fonts', pkg, f));
      faces.push([sub, +w, st === 'italic' ? 1 : 0]);
    }
    if (faces.length) list.push({ id: pkg, label, family, kind, faces });
  }
  const out = `// Файл создаётся scripts/fonts.mjs при сборке — вручную не править.\nexport interface FontDef { id: string; label: string; family: string; kind: 'sans' | 'serif' | 'mono' | 'display'; faces: [string, number, number][] }\nexport const FONT_LIST: FontDef[] = ${JSON.stringify(list)};\n`;
  fs.writeFileSync('src/lib/fontlist.ts', out);
}
