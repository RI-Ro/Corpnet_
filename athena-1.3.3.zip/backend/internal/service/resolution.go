package service

import (
	"context"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5"
)

// ===========================================================================
// РЕЗОЛЮЦИИ РУКОВОДИТЕЛЯ.
//
// Чем резолюция отличается от прежнего «поручения»:
//   - её накладывает РУКОВОДИТЕЛЬ, а не любой участник документа;
//   - у неё ответственный исполнитель и соисполнители, а не один адресат;
//   - она может порождать резолюции нижестоящих руководителей (иерархия),
//     и срок дочерней не может быть позже срока родительской (это
//     обеспечивает триггер в БД, миграция 0023);
//   - закрывается она ОТЧЁТОМ, который ПРИНИМАЕТ автор резолюции, а не сам
//     исполнитель. Прежнее поручение исполнитель закрывал сам — то есть
//     контроль исполнения был формальным.
// ===========================================================================

// CanIssueResolution — вправе ли пользователь наложить резолюцию по документу.
//
// ЧТО ИЗМЕНИЛОСЬ В v52 И ПОЧЕМУ (замечания пп. 4 и 15).
//
// Было (v51): право давали пять разных оснований — должность руководителя из
// штатного расписания, авторство документа, подпись, контроль и полномочие,
// переданное через делегирование. На практике это означало, что резолюцию мог наложить почти любой
// участник документа, в том числе по чужому подразделению. Руководитель как
// фигура из этой проверки фактически исчез.
//
// Стало — ровно два условия, и выполниться должны ОБА:
//
//  1. РОЛЬ «может ставить резолюции» (chief). Пункт 15: «резолюцию может
//     ставить только пользователь с ролью руководитель подразделения».
//     Проверяется роль, а не должность: штатное расписание убрано (п. 14),
//     и роль теперь единственный источник ответа на вопрос «он
//     руководитель»;
//
//  2. ОБЛАСТЬ ДЕЙСТВИЯ. Пункт 4: «резолюцию можно давать только своему
//     подразделению и вниз по иерархии; дополнительно через админку задать
//     доп. подразделения». Область считается так:
//     * подразделения, где у человека выдана роль chief
//     (user_roles.department_id) — руководителем можно быть не только в
//     своём основном подразделении;
//     * его основное подразделение (users.primary_department_id), если
//     роль chief выдана без привязки к подразделению;
//     * подразделения из user_resolution_departments (админка, п. 4);
//     и дальше ВСЁ, что ниже любого из них по иерархии.
//
//     Документ попадает в область, если в ней находится подразделение автора
//     документа ЛИБО любое подразделение-получатель. Второе обязательно: входящий
//     документ приходит в подразделение, и резолюцию по нему накладывает
//     руководитель ПОЛУЧАТЕЛЯ, а не автора.
//
// Администратор вправе всегда — это обычное исключение для администратора во
// всей системе, и проверяется оно вызывающим кодом (isAdmin), а не здесь.
//
// Делегирование полномочий из проверки УБРАНО (п. 18): механизм удалён целиком,
// остаётся замещение, которое действует через app_effective_user_ids и
// видимость документов.
func CanIssueResolution(ctx context.Context, tx pgx.Tx, documentID, actorID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx, resolutionScopeSQL+`
		SELECT EXISTS (SELECT 1 FROM user_roles WHERE user_id = $1 AND role = 'chief')
		   AND EXISTS (
		        SELECT 1 FROM subtree s
		         WHERE s.id IN (SELECT d.author_department_id FROM documents d WHERE d.id = $2)
		            OR s.id IN (SELECT dii.receiving_department_id
		                          FROM document_incoming_instances dii
		                         WHERE dii.document_id = $2)
		       )`, actorID, documentID).Scan(&ok)
	if err != nil {
		return false, fmt.Errorf("проверка права на резолюцию: %w", err)
	}
	return ok, nil
}

// resolutionScopeSQL — общее начало запросов об области действия резолюций.
//
// Вынесено в константу, потому что тот же набор подразделений нужен в трёх
// местах: проверка права (CanIssueResolution), подсказка интерфейсу
// (ResolutionScope) и выбор кандидатов в исполнители. Три копии одного
// рекурсивного запроса рано или поздно разошлись бы, и тогда человек видел бы
// кнопку, нажатие на которую даёт отказ.
//
// $1 — идентификатор пользователя. Нумерация начинается с него, потому что
// это общее начало запроса: всё остальное нумеруется дальше.
const resolutionScopeSQL = `
	WITH RECURSIVE roots AS (
	    -- подразделения, где выдана роль руководителя
	    SELECT ur.department_id AS id FROM user_roles ur
	     WHERE ur.user_id = $1 AND ur.role = 'chief' AND ur.department_id IS NOT NULL
	    UNION
	    -- основное подразделение, если роль chief выдана без привязки
	    SELECT u.primary_department_id FROM users u
	     WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
	       AND EXISTS (SELECT 1 FROM user_roles ur2
	                    WHERE ur2.user_id = $1 AND ur2.role = 'chief'
	                      AND ur2.department_id IS NULL)
	    UNION
	    -- дополнительные подразделения из админки (п. 4)
	    SELECT urd.department_id FROM user_resolution_departments urd
	     WHERE urd.user_id = $1
	),
	subtree AS (
	    SELECT d.id FROM departments d JOIN roots r ON d.id = r.id
	    UNION
	    SELECT c.id FROM departments c JOIN subtree s ON c.parent_id = s.id
	)
`

// ResolutionScope возвращает подразделения, по документам которых пользователь
// вправе накладывать резолюцию.
//
// Нужно интерфейсу и подсказкам об отказе: когда руководитель не понимает,
// почему по этому документу резолюцию наложить нельзя, система обязана назвать
// область его полномочий, а не отвечать «запрещено».
func ResolutionScope(ctx context.Context, tx pgx.Tx, actorID int64) ([]string, error) {
	rows, err := tx.Query(ctx, resolutionScopeSQL+`
		SELECT d.name FROM departments d JOIN subtree s ON s.id = d.id ORDER BY d.name`,
		actorID)
	if err != nil {
		return nil, fmt.Errorf("область действия резолюций: %w", err)
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var n string
		if err := rows.Scan(&n); err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

// ResolutionExecutorsOutOfScope возвращает ФИО тех из указанных людей, кому
// этот руководитель НЕ вправе давать резолюцию (, п. 4:
// «резолюцию можно давать только своему подразделению и вниз по иерархии;
// дополнительно через админку задать доп. подразделения»).
//
// Проверяются именно исполнители, а не документ: «давать резолюцию
// подразделению» — это и означает «назначать исполнителями его сотрудников».
// Проверка документа (попадает ли он в область руководителя) делается отдельно
// в CanIssueResolution; нужны обе, и ни одна не заменяет другую — иначе
// руководитель либо накладывал бы резолюции по чужим документам, либо поручал
// бы их чужим людям.
//
// Возвращаются ФИО, а не идентификаторы: это текст сообщения об отказе, и
// «нельзя поручить пользователю 417» человеку ничего не объясняет.
func ResolutionExecutorsOutOfScope(ctx context.Context, tx pgx.Tx, actorID int64, userIDs []int64) ([]string, error) {
	if len(userIDs) == 0 {
		return nil, nil
	}
	rows, err := tx.Query(ctx, resolutionExecScopeSQL+`
		SELECT u.full_name
		  FROM users u
		 WHERE u.id = ANY($2::bigint[])
		   AND (u.primary_department_id IS NULL
		        OR u.primary_department_id NOT IN (SELECT id FROM subtree))
		 ORDER BY u.full_name`, actorID, userIDs)
	if err != nil {
		return nil, fmt.Errorf("проверка исполнителей резолюции: %w", err)
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var n string
		if err := rows.Scan(&n); err != nil {
			return nil, err
		}
		out = append(out, n)
	}
	return out, rows.Err()
}

// ResolutionExecutorCandidatesSQL — условие отбора кандидатов в исполнители
// резолюции для текущего пользователя.
//
// Отдаётся обработчику поиска кандидатов, чтобы в списке выбора появлялись
// ровно те, кому резолюцию дать МОЖНО. Показывать всех и отказывать при
// сохранении — худший из вариантов: руководитель выбирает человека, пишет
// текст, нажимает «Наложить» и получает отказ.
//
// $1 — идентификатор пользователя (как и в resolutionScopeSQL).
const ResolutionExecutorCandidatesSQL = resolutionExecScopeSQL + `
	SELECT id FROM subtree
`

// resolutionExecScopeSQL — подразделения, СОТРУДНИКАМ которых пользователь
// вправе давать резолюцию (назначать исполнителями).
//
// Правило (1.3): ровно подразделения, выбранные пользователю в
// администрировании («Резолюции»), — без автоматического захвата
// подчинённых: администратор отмечает каждое явно, и в списке исполнителей
// нет никого сверх отмеченного. Если не выбрано ничего — только своё
// основное подразделение.
//
// Это область ИСПОЛНИТЕЛЕЙ. Область ДОКУМЕНТОВ (на чьи экземпляры можно
// наложить резолюцию) — resolutionScopeSQL / chief_scope_has, она прежняя.
//
// Имя CTE «subtree» сохранено, чтобы запросы-потребители не менялись.
const resolutionExecScopeSQL = `
	WITH subtree AS (
	    SELECT urd.department_id AS id FROM user_resolution_departments urd
	     WHERE urd.user_id = $1
	    UNION
	    SELECT u.primary_department_id FROM users u
	     WHERE u.id = $1 AND u.primary_department_id IS NOT NULL
	       AND NOT EXISTS (SELECT 1 FROM user_resolution_departments x WHERE x.user_id = $1)
	)
`

// IsChief — есть ли у пользователя роль «может ставить резолюции».
//
// Отдельная проверка нужна там, где документа ещё нет (например, чтобы решить,
// показывать ли вообще раздел резолюций), и чтобы отличить «не руководитель»
// от «руководитель, но не по этому документу»: это два разных сообщения
// человеку.
func IsChief(ctx context.Context, tx pgx.Tx, userID int64) (bool, error) {
	var ok bool
	err := tx.QueryRow(ctx,
		`SELECT EXISTS (SELECT 1 FROM user_roles WHERE user_id = $1 AND role = 'chief')`,
		userID).Scan(&ok)
	return ok, err
}

// RecalcResolutionStatus приводит статус резолюции в соответствие со
// статусами её исполнителей.
//
// Почему пересчётом, а не установкой статуса в каждом обработчике: статус
// зависит от нескольких строк (исполнителей), и каждый обработчик, который
// менял бы его сам, рано или поздно разошёлся бы с остальными. Один пересчёт в
// одном месте — один ответ на вопрос «в каком состоянии резолюция».
//
// Правила:
//   - все исполнители приняты       -> done   (+ closed_at)
//   - ответственный отчитался       -> on_report (ждёт решения автора)
//   - кто-то взял в работу          -> in_progress
//   - иначе                         -> issued
//
// Статус 'cancelled' не пересчитывается: отмена — решение человека, и
// вернуть её пересчётом было бы неверно.
func RecalcResolutionStatus(ctx context.Context, tx pgx.Tx, resolutionID, actorID int64) error {
	var total, accepted, reported, inProgress, cancelled int
	var respReported bool
	err := tx.QueryRow(ctx, `
		SELECT count(*),
		       count(*) FILTER (WHERE status = 'accepted'),
		       count(*) FILTER (WHERE status = 'reported'),
		       count(*) FILTER (WHERE status = 'in_progress'),
		       count(*) FILTER (WHERE status = 'cancelled'),
		       coalesce(bool_or(is_responsible AND status IN ('reported','accepted')), false)
		  FROM resolution_executors WHERE resolution_id = $1`, resolutionID).
		Scan(&total, &accepted, &reported, &inProgress, &cancelled, &respReported)
	if err != nil {
		return fmt.Errorf("подсчёт исполнителей резолюции: %w", err)
	}
	if total == 0 {
		return nil
	}

	// Отменённые исполнители не должны мешать закрытию резолюции: если
	// соисполнителя сняли, резолюция закрывается по остальным.
	effective := total - cancelled
	switch {
	case effective > 0 && accepted >= effective:
		_, err = tx.Exec(ctx, `
			UPDATE resolutions SET status = 'done', closed_at = coalesce(closed_at, now()),
			       closed_by = coalesce(closed_by, $2)
			 WHERE id = $1 AND status <> 'cancelled'`, resolutionID, actorID)
	case respReported || reported > 0:
		_, err = tx.Exec(ctx, `
			UPDATE resolutions SET status = 'on_report', closed_at = NULL, closed_by = NULL
			 WHERE id = $1 AND status NOT IN ('cancelled','done')`, resolutionID)
	case inProgress > 0:
		_, err = tx.Exec(ctx, `
			UPDATE resolutions SET status = 'in_progress', closed_at = NULL, closed_by = NULL
			 WHERE id = $1 AND status NOT IN ('cancelled','done')`, resolutionID)
	default:
		_, err = tx.Exec(ctx, `
			UPDATE resolutions SET status = 'issued', closed_at = NULL, closed_by = NULL
			 WHERE id = $1 AND status NOT IN ('cancelled','done')`, resolutionID)
	}
	if err != nil {
		return fmt.Errorf("пересчёт статуса резолюции: %w", err)
	}
	return nil
}

// ResolutionLabel — человекочитаемый статус резолюции (для истории и отчётов).
func ResolutionLabel(s string) string {
	switch s {
	case "issued":
		return "Наложена"
	case "in_progress":
		return "В работе"
	case "on_report":
		return "На отчёте у руководителя"
	case "done":
		return "Исполнена"
	case "cancelled":
		return "Отменена"
	}
	return s
}

// ResolutionExecLabel — статус исполнителя.
func ResolutionExecLabel(s string) string {
	switch s {
	case "open":
		return "Не начато"
	case "in_progress":
		return "В работе"
	case "reported":
		return "Отчёт представлен"
	case "accepted":
		return "Отчёт принят"
	case "returned":
		return "Возвращено на доработку"
	case "cancelled":
		return "Снято"
	}
	return s
}

// ResolutionScopeSubquery возвращает ПОДЗАПРОС, выбирающий подразделения, по
// которым пользователь вправе накладывать резолюцию. placeholder — номер
// параметра с идентификатором пользователя в вызывающем запросе ("$4" и т. п.).
//
// Зачем функция, а не ещё одна копия запроса рядом. Рекурсивный обход
// иерархии здесь уже используется тремя способами: проверка права, перечень
// подразделений для подсказок и отбор кандидатов в исполнители. Копии
// неизбежно разошлись бы, и тогда человек видел бы в списке того, кому
// система потом откажет назначить поручение, — худший вид расхождения:
// интерфейс обещает, сервер отказывает.
func ResolutionScopeSubquery(placeholder string) string {
	return strings.ReplaceAll(resolutionExecScopeSQL, "$1", placeholder) +
		" SELECT id FROM subtree"
}
