package server

import (
	"context"
	"strings"

	"github.com/go-ldap/ldap/v3"
	"github.com/jackc/pgx/v5"
)

// Несколько доменов. Пользователь каталога однозначно определяется парой «домен + логин внутри домена»:
// ii-ivanov@DOMAIN1.LOCAL и ii-ivanov@DOMAIN2.LOCAL — два разных пользователя портала, с разными профилями,
// правами и перепиской. Если у каталога задан домен, логин в портале хранится как «sam@domain».
//
// Вводить логин можно так: «sam» (с выбранным на странице входа каталогом), «sam@domain» (UPN),
// «DOMAIN\sam» (NetBIOS). Домен в логине важнее выбранного каталога.

// parseLoginInput разбирает введённый логин на имя в домене и имя домена (пусто — домен не указан).
func parseLoginInput(raw string) (sam, dom string) {
	raw = strings.TrimSpace(raw)
	if i := strings.Index(raw, `\`); i > 0 && i < len(raw)-1 {
		return strings.TrimSpace(raw[i+1:]), strings.ToLower(strings.TrimSpace(raw[:i]))
	}
	if i := strings.LastIndex(raw, "@"); i > 0 && i < len(raw)-1 {
		return strings.TrimSpace(raw[:i]), strings.ToLower(strings.TrimSpace(raw[i+1:]))
	}
	return raw, ""
}

// principal — логин пользователя в портале: sam@domain (нижний регистр); без домена у каталога — просто sam.
func (l *ldapSrv) principal(sam string) string {
	sam = strings.ToLower(strings.TrimSpace(sam))
	if sam == "" || l.Domain == "" || strings.Contains(sam, "@") {
		return sam
	}
	return sam + "@" + strings.ToLower(l.Domain)
}

// userFilterFor подставляет в фильтр входа: %s — имя в домене, %u — полное UPN-имя (sam@domain), %d — домен.
func (l *ldapSrv) userFilterFor(sam string) string {
	f := strings.ReplaceAll(l.UserFilter, "%u", ldap.EscapeFilter(l.principal(sam)))
	f = strings.ReplaceAll(f, "%d", ldap.EscapeFilter(strings.ToLower(l.Domain)))
	return strings.ReplaceAll(f, "%s", ldap.EscapeFilter(sam))
}

// findLDAPByDomain находит включённый каталог по домену: DNS-имя, NetBIOS, псевдоним или первая метка домена.
// Точные совпадения приоритетнее; если подходит несколько каталогов — nil (неоднозначно).
func (s *Server) findLDAPByDomain(ctx context.Context, dom string) (*ldapSrv, error) {
	dom = strings.ToLower(strings.TrimSpace(dom))
	if dom == "" {
		return nil, nil
	}
	rows, err := s.db.Query(ctx, `SELECT id, CASE
			WHEN lower(domain) = $1 THEN 0
			WHEN lower(netbios) = $1 OR $1 = ANY(string_to_array(replace(lower(aliases), ' ', ''), ',')) THEN 1
			WHEN lower(split_part(domain, '.', 1)) = $1 THEN 2 END AS rank
		FROM ldap_servers WHERE enabled AND domain <> '' ORDER BY rank NULLS LAST, sort, id`, dom)
	if err != nil {
		return nil, err
	}
	type hit struct {
		id   int64
		rank *int
	}
	var hits []hit
	for rows.Next() {
		var h hit
		if err := rows.Scan(&h.id, &h.rank); err != nil {
			rows.Close()
			return nil, err
		}
		if h.rank != nil {
			hits = append(hits, h)
		}
	}
	rows.Close()
	if len(hits) == 0 || (len(hits) > 1 && *hits[0].rank == *hits[1].rank) {
		return nil, nil
	}
	return s.loadLDAP(ctx, hits[0].id)
}

// normDomainFields приводит домен, NetBIOS и псевдонимы к виду для хранения.
func normDomainFields(domain, netbios, aliases string) (string, string, string) {
	var al []string
	for _, a := range strings.FieldsFunc(aliases, func(r rune) bool { return r == ',' || r == ';' || r == ' ' || r == '\n' }) {
		if a = strings.ToLower(strings.TrimSpace(a)); a != "" {
			al = append(al, a)
		}
	}
	return strings.ToLower(strings.TrimSpace(domain)), strings.TrimSpace(netbios), strings.Join(al, ",")
}

// loginUsers сопоставляет логины из упоминаний (@sam или @sam@domain) пользователям портала.
// Полная форма совпадает точно; короткая «@sam» — только если такое имя в портале одно (иначе упоминание неоднозначно).
func (s *Server) loginUsers(ctx context.Context, logins []string, excludeBlocked bool) (map[string]mentionUser, error) {
	out := map[string]mentionUser{}
	if len(logins) == 0 {
		return out, nil
	}
	rows, err := s.db.Query(ctx, `SELECT lower(login), id, full_name, avatar FROM users
		WHERE lower(login) = ANY($1) AND ($2 OR NOT blocked) AND deleted_at IS NULL`, logins, !excludeBlocked)
	if err != nil {
		return nil, err
	}
	for rows.Next() {
		var l string
		var u mentionUser
		if err := rows.Scan(&l, &u.ID, &u.Name, &u.Avatar); err != nil {
			rows.Close()
			return nil, err
		}
		out[l] = u
	}
	rows.Close()
	var short []string
	for _, l := range logins {
		if _, ok := out[l]; !ok && !strings.Contains(l, "@") {
			short = append(short, l)
		}
	}
	if len(short) == 0 {
		return out, nil
	}
	rows, err = s.db.Query(ctx, `SELECT split_part(lower(login), '@', 1) AS sam, id, full_name, avatar FROM users
		WHERE position('@' in login) > 0 AND split_part(lower(login), '@', 1) = ANY($1) AND ($2 OR NOT blocked) AND deleted_at IS NULL`, short, !excludeBlocked)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	cnt := map[string]int{}
	cand := map[string]mentionUser{}
	for rows.Next() {
		var sam string
		var u mentionUser
		if err := rows.Scan(&sam, &u.ID, &u.Name, &u.Avatar); err != nil {
			return nil, err
		}
		cnt[sam]++
		cand[sam] = u
	}
	for sam, n := range cnt {
		if n == 1 {
			out[sam] = cand[sam]
		}
	}
	return out, rows.Err()
}

type mentionUser struct {
	ID     int64  `json:"id"`
	Name   string `json:"name"`
	Avatar string `json:"avatar"`
}

var _ = pgx.ErrNoRows
