import { useAuth } from '../context/AuthContext'
import React, { useEffect, useRef, useState, useCallback } from 'react'
import { useParams, useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import DocumentViewer from '../components/DocumentViewer'
import ChatPanel from '../components/ChatPanel'
import ApprovalPanel from '../components/ApprovalPanel'
import DocumentTabs from '../components/DocumentTabs'
import EditDocumentModal from '../components/EditDocumentModal'
import NotFound from '../components/NotFound'
import Icon from '../components/Icon'
import { fmtDateTime, fmtDate } from '../utils/format'
import { usePreference } from '../lib/usePreference'


export default function DocumentDetailPage() {
  const { id } = useParams()
  const navigate = useNavigate()
  // #40 — активная вкладка хранится в АДРЕСЕ (?tab=...). Тогда она сохраняется
  // не только при обновлении данных, но и при настоящей перезагрузке страницы
  // (F5), при переходе «назад/вперёд» и при отправке ссылки коллеге.
  const [searchParams, setSearchParams] = useSearchParams()
  const activeTab = searchParams.get('tab') || ''
  const setActiveTab = useCallback((t) => {
    const next = new URLSearchParams(searchParams)
    if (t) next.set('tab', t)
    else next.delete('tab')
    // replace: переключение вкладки не должно засорять историю браузера —
    // иначе «назад» уводило бы по вкладкам вместо возврата к списку.
    setSearchParams(next, { replace: true })
  }, [searchParams, setSearchParams])
  const [doc, setDoc] = useState(null)
  const [myCopy, setMyCopy] = useState(null)
  const [incomingMarking, setIncomingMarking] = useState(null)
  const [marks, setMarks] = useState({ stamps: [], baked: false })
  const [error, setError] = useState('')
  const [editing, setEditing] = useState(false)
  // #40 — РАЗДЕЛЕНИЕ «первая загрузка» и «обновление».
  //
  // Раньше был один флаг loading, и любое действие во вкладке (отметка
  // исполнения, поручение, связь, постановка на контроль) вызывало
  // onChanged → load() → loading=true → страница возвращала «Загрузка…».
  // При этом ВСЁ поддерево, включая панель вкладок, размонтировалось, и при
  // повторном монтировании активная вкладка сбрасывалась на первую. Внешне
  // это и выглядело как перезагрузка страницы с перебросом на первую вкладку.
  //
  // Теперь «Загрузка…» вместо содержимого показывается только пока документа
  // ещё нет (первый вход). Обновление данных ничего не размонтирует — меняется
  // только неброский индикатор в заголовке.
  const [firstLoad, setFirstLoad] = useState(true)
  // Тот же признак, но в рефе: нужен внутри load, у которого зависимость
  // только [id] (см. пояснение в load).
  const firstLoadRef = useRef(true)
  const quietRef = useRef(false)
  const [refreshing, setRefreshing] = useState(false)
  const [roles, setRoles] = useState(null) // #8 — для кнопки «В архив» (автор/подписант)
  // Ширина панелей, настраиваемая пользователем. Хранится на сервере, поэтому
  // переживает перезагрузку страницы и вход с другого компьютера.
  //
  // Храним ПРОЦЕНТ, а не пиксели: у людей разные экраны, и 900 px — это
  // полэкрана на ноутбуке и треть на мониторе. Процент переносится между ними
  // осмысленно.
  const [panes, setPanes] = usePreference('ui.doc_panes', { docPercent: 60 })
  const dragRef = useRef(null)

  // Избранное (, п. 4). Отдельное состояние, а не чтение из
  // doc.is_favorite напрямую: звёздочка должна переключаться мгновенно, а
  // перезагружать всю карточку ради личной пометки незачем.
  const [fav, setFav] = useState(false)
  const toggleFavorite = async () => {
    const next = !fav
    setFav(next)
    try {
      await (next ? api.addFavorite(id) : api.removeFavorite(id))
    } catch (e) {
      setFav(!next) // откат: иначе звёздочка врала бы о сохранённом состоянии
      alert(e.message || 'Не удалось изменить избранное')
    }
  }

  const { userId: currentUserId } = useAuth()

  // Пределы ширины: ниже 25% панель документа нечитаема, выше 80% —
  // нечитаема панель сведений.
  const clampPercent = (v) => Math.min(80, Math.max(25, Math.round(v)))

  // Перетаскивание разделителя. Слушатели вешаются на document, а не на сам
  // разделитель: если курсор обгонит узкую полоску (а он обгоняет), события
  // перестали бы приходить и панель «залипала» бы на полпути.
  const startDrag = (e) => {
    e.preventDefault()
    const box = dragRef.current
    if (!box) return
    const rect = box.getBoundingClientRect()
    const onMove = (ev) => {
      const pct = ((ev.clientX - rect.left) / rect.width) * 100
      setPanes({ docPercent: clampPercent(pct) })
    }
    const onUp = () => {
      document.removeEventListener('mousemove', onMove)
      document.removeEventListener('mouseup', onUp)
      // Пока тянут, выделение текста мешает: возвращаем его после.
      document.body.style.userSelect = ''
      document.body.style.cursor = ''
    }
    document.body.style.userSelect = 'none'
    document.body.style.cursor = 'col-resize'
    document.addEventListener('mousemove', onMove)
    document.addEventListener('mouseup', onUp)
  }

  const load = useCallback(async () => {
    setRefreshing(true)
    setError('')
    try {
      // Ответ { document, incoming_marking } — второе поле заполняется
      // бэкендом при регистрации входящего экземпляра (первый просмотр
      // получателем), см. IncomingService.RegisterView.
      const res = await api.getDocument(id)
      setDoc(res.document)
      if (res.registration_error) setError('Не удалось сохранить просмотр или регистрацию. Обновите карточку, чтобы повторить.')
      setFav(!!res.document?.is_favorite)
      setIncomingMarking(res.incoming_marking)
      setMyCopy(res.my_copy_number ?? null)
      // Маркировка (штампы по конфигу). Если бэкенд вжигает штампы в PDF —
      // baked=true и overlay на фронте не рисуем.
      api.getDocumentMarking(id).then(setMarks).catch(() => setMarks({ stamps: [], baked: false }))
      api.getMyRoles(id).then(setRoles).catch(() => setRoles(null))

      // ПОВТОРНАЯ загрузка карточки означает,
      // что состояние документа изменилось НАШИМ действием: подпись,
      // резолюция, отметка об исполнении, правка маршрута. Своих действий
      // сервер уведомлениями не рассылает (актору уведомление не создаётся),
      // поэтому ни счётчики в меню, ни список документов, ни схема маршрута
      // об изменении не узнавали — до следующего опроса, то есть до минуты.
      //
      // Одно событие на всё приложение вместо того, чтобы каждое место
      // вызывало свою перезагрузку: подписчиков у него трое (меню со
      // счётчиками, список документов, панель вкладок со схемой маршрута), и
      // перечислять их в каждом обработчике кнопки значило бы однажды
      // кого-то забыть.
      //
      // Признак первой загрузки берётся из РЕФА, а не из состояния firstLoad:
      // load — useCallback с зависимостью [id], и значение состояния в нём
      // осталось бы навсегда тем, каким было при создании замыкания, то есть
      // событие не отправлялось бы НИКОГДА. Ошибка незаметная: всё выглядит
      // работающим, просто ничего не обновляется — ровно то, на что и была
      // жалоба.
      // quietRef — перезагрузка вызвана самим событием 'athena:changed' (своё
      // действие или другая вкладка): повторно объявлять изменение нельзя,
      // иначе вкладки бесконечно перезагружали бы друг друга.
      if ((!firstLoadRef.current || res.incoming_marking) && !quietRef.current) {
        window.dispatchEvent(new CustomEvent('athena:changed', { detail: { documentId: id, fromLoad: true } }))
      }
      quietRef.current = false
      firstLoadRef.current = false
    } catch (err) {
      setError(err.message || 'Документ не найден или недоступен')
    } finally {
      setRefreshing(false)
      setFirstLoad(false)
    }
  }, [id])

  // Сброс признака первой загрузки при переходе на ДРУГОЙ документ: иначе
  // при переходе с карточки на карточку сразу уходило бы лишнее событие
  // «документ изменился», и меню со списком перечитывались бы без причины.
  useEffect(() => {
    firstLoadRef.current = true
  }, [id])

  useEffect(() => {
    load()
  }, [load])

  // #16 — Живое обновление открытой карточки: только по событиям про ЭТОТ
  // документ (иначе чужая активность перезагружала бы карточку впустую).
  // Благодаря #40 обновление уже ничего не размонтирует, поэтому активная
  // вкладка при этом не теряется.
  useEffect(() => {
    let timer = null
    function onChanged(e) {
      if (String(e.detail?.document_id) !== String(id)) return
      clearTimeout(timer)
      timer = setTimeout(load, 700)
    }
    // Изменение, сделанное пользователем (в этой или другой его вкладке):
    // атрибуты документа (статус исполнения и др.) обновляем онлайн.
    function onLocalChange(e) {
      if (e.detail?.fromLoad) return
      if (e.detail?.documentId !== undefined && String(e.detail.documentId) !== String(id)) return
      clearTimeout(timer)
      timer = setTimeout(() => { quietRef.current = true; load() }, 400)
    }
    window.addEventListener('athena:document_changed', onChanged)
    window.addEventListener('athena:changed', onLocalChange)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('athena:document_changed', onChanged)
      window.removeEventListener('athena:changed', onLocalChange)
    }
  }, [id, load])

  // Содержимое подменяем ТОЛЬКО когда документа ещё нет. Иначе любое
  // обновление размонтировало бы панель вкладок (#40).
  if (firstLoad && !doc) return <div className="p-6 text-text-secondary">Загрузка…</div>
  // Экран 404 — только если документа нет вовсе. Ошибка при ОБНОВЛЕНИИ уже
  // открытого документа (сеть мигнула, сервер перезапустился) не должна
  // подменять карточку на «не найдено» и терять то, что пользователь делал:
  // она показывается полоской в заголовке (#40).
  if (!doc) {
    if (error) return <NotFound />
    return null
  }

  const preSigned = !['signed', 'sent', 'in_progress', 'executed', 'archived'].includes(doc.status)

  // Маркировка — исходящий номер/место хранения (после подписания) плюс,
  // если применимо, номер входящего экземпляра (после регистрации у
  // получателя). Оба слоя показываются overlay поверх вьювера, не
  // "вшиваются" в сам PDF (см. архитектурную спецификацию, п.4.3).
  const markingLines = []
  if (doc.outgoing_number) {
    markingLines.push(doc.outgoing_number)
    markingLines.push(`ИР «Афина» / Архив ${new Date(doc.created_at).getFullYear()}`)
  }
  if (incomingMarking) {
    markingLines.push(`${incomingMarking.incoming_number} · ${incomingMarking.instance_label}`)
  }
  const marking = markingLines.length ? markingLines.join('\n') : null
  // #3 — уведомление о факте фиксации первого ознакомления (показываем, когда
  // получателю зарегистрирован входящий экземпляр — это и есть момент фиксации).
  const firstViewNotice = incomingMarking
    ? `Зафиксирован факт первого ознакомления с документом. Присвоен входящий № ${incomingMarking.incoming_number}${incomingMarking.instance_label ? ` (${incomingMarking.instance_label})` : ''}.`
    : null

  return (
    <div className="h-[calc(100vh-56px)] flex flex-col">
      {doc.status === 'archived' && (
        <div className="px-6 py-2 text-sm bg-warning/15 text-warning border-b border-warning/40 flex items-center gap-2" role="status">
          <Icon name="cat-archive" size={16} />
          <span>
            <b>Документ помещён в архив.</b> Изменения (резолюции, комментарии, отметки, правка и т. д.) невозможны.
            Доступно только ознакомление.
          </span>
        </div>
      )}
      <div className="px-6 py-4 border-b border-border bg-surface flex items-start justify-between gap-4">
        <div>
          <button className="text-accent text-sm mb-1" onClick={() => navigate(-1)}>
            ← Назад к списку
          </button>
          <h1 className="font-display text-lg font-semibold">
            {doc.title}
            {/* #40 — обновление данных больше не подменяет страницу; вместо
                этого — неброская отметка рядом с заголовком. */}
            {refreshing && (
              <span className="ml-2 text-xs font-normal text-text-secondary align-middle">обновление…</span>
            )}
          </h1>
          {error && (
            <div className="mt-1 text-xs text-danger">
              Не удалось обновить данные: {error}. Показаны последние загруженные.
            </div>
          )}
          <div className="kicker mt-0.5">
            {doc.outgoing_number || `Черновик #${doc.id}`}
            {doc.category_name && ` · категория: ${doc.category_name}`}
            {doc.signed_at && ` · подписан ${fmtDateTime(doc.signed_at)}`}
            {` · создан ${fmtDateTime(doc.created_at)}`}
            {(doc.due_datetime || doc.due_date) &&
              ` · готовность ${doc.due_datetime ? fmtDateTime(doc.due_datetime) : fmtDate(doc.due_date)}`}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
          {/* Избранное (, п. 4). Личный список: отметка видна
              только самому пользователю и не меняет документ. */}
          <button
            onClick={toggleFavorite}
            className={`p-1.5 rounded-md hover:bg-surface-alt ${
              fav ? 'text-warning' : 'text-text-secondary opacity-50 hover:opacity-100'
            }`}
            title={fav ? 'Убрать из избранного' : 'Добавить в избранное'}
            aria-pressed={fav}
          >
            <Icon name={fav ? 'star-filled' : 'star'} size={18} />
          </button>
          {/*, п. 5 — отчёт по документу: маршрут, сроки,
              резолюции, нарушения сроков. PDF, потому что отчёт по
              конкретному документу обычно печатают и подшивают. */}
          {/*, п. 8 — «отчёт о документе показывать автору и
              подписанту». Право считает сервер (флаг can_report из
              /my-roles) той же функцией, которой проверяет сам запрос
              отчёта. Прежде кнопка показывалась каждому, кто видит документ,
              то есть и любому адресату рассылки, — а отчёт сводит воедино
              сроки, задержки и фамилии тех, кто задержал. */}
          {roles?.can_report && (
            <button
              onClick={async () => {
                try {
                  // Имя файла задаёт сервер (Отчет_о_документе_№_…
                  // _сформирован_ДД.ММ.ГГГГ_ЧЧ-ММ.pdf): только он знает
                  // исходящий номер и время формирования.
                  await api.download(api.documentReportPdfUrl(doc.id))
                } catch (e) {
                  alert(e.message || 'Не удалось сформировать отчёт')
                }
              }}
              className="btn btn-secondary"
              title="Отчёт по документу: маршрут, сроки, резолюции, факты исполнения, нарушения"
            >
              <Icon name="cat-registry" size={14} /> Отчёт
            </button>
          )}
          {myCopy != null && (
            <span className="inline-flex items-center gap-1 shrink-0 whitespace-nowrap text-xs px-2 py-1 rounded-full border border-accent/40 bg-accent/10 text-accent" title="Ваш номер экземпляра документа">
              Экз. № {myCopy}
            </span>
          )}
          {doc.on_control && (
            <span className="inline-flex items-center gap-1 shrink-0 whitespace-nowrap text-xs px-2 py-1 rounded-full border border-danger/40 bg-danger/10 text-danger">
              ● На контроле
            </span>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button onClick={() => setEditing(true)} className="btn btn-secondary">
              Изменить
            </button>
          )}
          {doc.author_id === currentUserId && preSigned && (
            <button
              onClick={async () => {
                if (!confirm('Удалить документ безвозвратно?')) return
                try {
                  await api.deleteDocument(doc.id)
                  navigate('/documents/all')
                } catch (e) {
                  alert(e.message)
                }
              }}
              className="btn btn-danger"
            >
              Удалить
            </button>
          )}
          {/* #8 — В архив: автор или подписант, только исполненный документ. */}
          {doc.status === 'executed' && (roles?.is_author || roles?.is_signer) && (
            <button
              onClick={async () => {
                if (!confirm('Направить документ в архив?')) return
                try {
                  await api.archiveDocument(doc.id)
                  await load()
                } catch (e) {
                  alert(e.message)
                }
              }}
              className="btn btn-secondary"
            >
              В архив
            </button>
          )}
        </div>
      </div>

      {/* Ширину панелей тянет сам пользователь за разделитель между ними.
          Процент ограничен 25–80%: за этими пределами одна из панелей
          становится нечитаемой, и «настройка» превращалась бы в способ
          случайно сломать себе экран. */}
      <div className="flex-1 flex gap-0 p-4 min-h-0" ref={dragRef}>
        {/* Ширину панели документа задаёт ТОЛЬКО пользователь (разделитель,
            сохраняется в его настройках). flex: 0 0 — панель не сжимается и не
            растягивается, сколько бы места ни просило содержимое вкладок
            справа (широкая схема маршрута, длинные номера): иначе ширина
            документа «прыгала» при переключении вкладок. */}
        <div className="min-h-0 min-w-0 flex flex-col gap-2" style={{ flex: `0 0 ${panes.docPercent}%`, maxWidth: `${panes.docPercent}%` }}>
          {/* #3 — уведомление о фиксации первого ознакомления */}
          {firstViewNotice && (
            <div className="bg-accent/10 border border-accent/40 text-accent rounded-lg px-3 py-2 text-sm">
              {firstViewNotice}
            </div>
          )}
          <div className="flex-1 min-h-0">
            <DocumentViewer documentId={doc.id} marking={marking} stamps={marks.stamps} pageMode={marks.page_mode || 'first'} />
          </div>
        </div>
        {/* #38 — Обсуждение перенесено В ВКЛАДКУ, поэтому панель вкладок
            занимает всю высоту колонки. Раньше колонка делилась пополам:
            вкладки получали 45% высоты и в них приходилось скроллить даже
            короткий маршрут, а переписка всё равно не помещалась. */}
        {/* Разделитель. role=separator с aria-valuenow — чтобы с клавиатуры
            тоже можно было менять ширину (стрелки влево/вправо). */}
        <div
          role="separator"
          aria-orientation="vertical"
          aria-valuenow={panes.docPercent}
          aria-valuemin={25}
          aria-valuemax={80}
          tabIndex={0}
          onMouseDown={startDrag}
          onKeyDown={(e) => {
            if (e.key === 'ArrowLeft') setPanes({ docPercent: clampPercent(panes.docPercent - 2) })
            if (e.key === 'ArrowRight') setPanes({ docPercent: clampPercent(panes.docPercent + 2) })
          }}
          title="Потяните, чтобы изменить ширину панелей"
          className="w-2 mx-1 shrink-0 cursor-col-resize rounded-full hover:bg-accent/40 focus-visible:bg-accent/60 transition-colors"
        />
        <div className="min-h-0 min-w-0 flex flex-col overflow-hidden" style={{ flex: '1 1 0' }}>
          <DocumentTabs
            documentId={doc.id}
            currentUserId={currentUserId}
            docStatus={doc.status}
            doc={doc}
            onChanged={load}
            patchDoc={(p) => setDoc((d) => (d ? { ...d, ...p } : d))}
            routeSlot={
              <ApprovalPanel documentId={doc.id} onChanged={load} section="route" />
            }
            // #15 — блок решения (согласовать/подписать/отклонить/донаправить)
            // живёт в своей первой вкладке, а не внизу схемы маршрута.
            decisionSlot={
              <ApprovalPanel documentId={doc.id} onChanged={load} section="decision" />
            }
            chatSlot={<ChatPanel documentId={doc.id} currentUserId={currentUserId} readOnly={doc.status === 'archived'} />}
            tab={activeTab}
            onTabChange={setActiveTab}
          />
        </div>
      </div>
      {editing && (
        <EditDocumentModal
          doc={doc}
          currentUserId={currentUserId}
          onClose={() => setEditing(false)}
          onSaved={load}
        />
      )}
    </div>
  )
}
