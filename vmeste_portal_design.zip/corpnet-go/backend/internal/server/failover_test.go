package server

import "testing"

func TestFailoverQuorum(t *testing.T) {
	n := func(codes ...string) []nodeInfo {
		var o []nodeInfo
		for _, c := range codes {
			o = append(o, nodeInfo{Code: c, Enabled: true})
		}
		return o
	}
	see := func(m map[string]bool) map[string]bool { return m }
	cases := []struct {
		name  string
		nodes []nodeInfo
		peers map[string]map[string]bool
		want  bool
	}{
		{"два узла — кворума нет", n("m", "b"), nil, false},
		{"три узла, два не видят мастера", n("m", "b", "c"), map[string]map[string]bool{"c": see(map[string]bool{"m": false})}, true},
		{"три узла, другой видит мастера (разрыв только у нас)", n("m", "b", "c"), map[string]map[string]bool{"c": see(map[string]bool{"m": true})}, false},
		{"три узла, о соседе нет данных", n("m", "b", "c"), nil, false},
		{"пять узлов, три не видят", n("m", "b", "c", "d", "e"), map[string]map[string]bool{"c": {"m": false}, "d": {"m": false}, "e": {"m": true}}, true},
	}
	for _, c := range cases {
		if got := failoverQuorum(c.nodes, "m", "b", c.peers); got != c.want {
			t.Errorf("%s: получили %v, ожидали %v", c.name, got, c.want)
		}
	}
}
