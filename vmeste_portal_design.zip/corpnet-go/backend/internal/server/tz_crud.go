package server

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strconv"
	"strings"
)

// Модуль предназначен для универсального CRUD справочников администратора (аудитории, правила геймификации,
// шаблоны адаптации, темы обращений и т. п.): колонки задаются белым списком, значения приводит к типам сама СУБД
// (jsonb_populate_record), поэтому для каждого справочника не нужен отдельный код разбора.

var identRe = regexp.MustCompile(`^[a-z_][a-z0-9_]*$`)

type crud struct {
	table   string
	cols    []string // допустимые колонки (без id)
	order   string   // ORDER BY
	check   func(*Ctx) error
	where   string // дополнительное условие списка, например "template_id = $1"
	whereQ  string // имя параметра запроса для where
	extra   string // дополнительные выражения SELECT (с запятой в начале)
	onWrite func(*Ctx, int64)
}

func (s *Server) needHR(c *Ctx) error {
	if c.U.IsAdmin() || c.U.HR {
		return nil
	}
	return errForbidden
}

func (s *Server) needEditor(c *Ctx) error {
	if c.U.CanEdit() {
		return nil
	}
	return errForbidden
}

func (cr crud) list(s *Server) http.HandlerFunc {
	return s.h("user", func(c *Ctx) error {
		if cr.check != nil {
			if err := cr.check(c); err != nil {
				return err
			}
		}
		q := `SELECT t.*` + cr.extra + ` FROM ` + cr.table + ` t`
		var args []any
		if cr.where != "" {
			v := c.QInt64(cr.whereQ)
			if v == 0 {
				return badReq("Не указан " + cr.whereQ)
			}
			q += ` WHERE ` + cr.where
			args = append(args, v)
		}
		if cr.order != "" {
			q += ` ORDER BY ` + cr.order
		}
		b, err := s.arr(c.Context(), q, args...)
		if err != nil {
			return err
		}
		return c.Raw(200, b)
	})
}

func (cr crud) save(s *Server) http.HandlerFunc {
	return s.h("user", func(c *Ctx) error {
		if cr.check != nil {
			if err := cr.check(c); err != nil {
				return err
			}
		}
		var in map[string]json.RawMessage
		if err := c.Decode(&in); err != nil {
			return err
		}
		allowed := map[string]bool{}
		for _, k := range cr.cols {
			allowed[k] = true
		}
		var keys []string
		for k := range in {
			if allowed[k] {
				keys = append(keys, k)
			}
		}
		if len(keys) == 0 {
			return badReq("Нет данных для сохранения")
		}
		body, _ := json.Marshal(in)
		var id int64
		if v := c.R.PathValue("id"); v != "" {
			var err error
			if id, err = strconv.ParseInt(v, 10, 64); err != nil {
				return badReq("Некорректный идентификатор")
			}
			sets := make([]string, len(keys))
			for i, k := range keys {
				sets[i] = k + " = r." + k
			}
			tag, err := s.db.Exec(c.Context(), fmt.Sprintf(`UPDATE %s t SET %s FROM jsonb_populate_record(NULL::%s, $1::jsonb) r WHERE t.id = $2`,
				cr.table, strings.Join(sets, ", "), cr.table), string(body), id)
			if err != nil {
				return err
			}
			if tag.RowsAffected() == 0 {
				return errNotFound
			}
		} else {
			list := strings.Join(keys, ", ")
			if err := s.db.QueryRow(c.Context(), fmt.Sprintf(`INSERT INTO %s (%s) SELECT %s FROM jsonb_populate_record(NULL::%s, $1::jsonb) RETURNING id`,
				cr.table, list, list, cr.table), string(body)).Scan(&id); err != nil {
				return err
			}
		}
		s.audit(c, "admin."+cr.table+".save", cr.table, id, nil)
		if cr.onWrite != nil {
			cr.onWrite(c, id)
		}
		b, err := s.one(c.Context(), `SELECT t.*`+cr.extra+` FROM `+cr.table+` t WHERE t.id = $1`, id)
		if err != nil {
			return err
		}
		return c.Raw(200, b)
	})
}

func (cr crud) del(s *Server) http.HandlerFunc {
	return s.h("user", func(c *Ctx) error {
		if cr.check != nil {
			if err := cr.check(c); err != nil {
				return err
			}
		}
		id, err := c.ID("id")
		if err != nil {
			return err
		}
		if _, err := s.db.Exec(c.Context(), `DELETE FROM `+cr.table+` WHERE id = $1`, id); err != nil {
			return err
		}
		s.audit(c, "admin."+cr.table+".delete", cr.table, id, nil)
		return c.JSON(200, map[string]any{"ok": true})
	})
}

// mount регистрирует GET /api/<path>, POST /api/<path>, PUT и DELETE /api/<path>/{id}.
func (cr crud) mount(s *Server, m *http.ServeMux, path string) {
	if !identRe.MatchString(cr.table) {
		panic("crud: bad table " + cr.table)
	}
	m.HandleFunc("GET /api/"+path, cr.list(s))
	m.HandleFunc("POST /api/"+path, cr.save(s))
	m.HandleFunc("PUT /api/"+path+"/{id}", cr.save(s))
	m.HandleFunc("DELETE /api/"+path+"/{id}", cr.del(s))
}

// mountWrite — список для редактора (GET без проверки HR) и запись для HR; нужен для аудиторий.
func (cr crud) mountWrite(s *Server, m *http.ServeMux, path string) {
	m.HandleFunc("POST /api/"+path, cr.save(s))
	m.HandleFunc("PUT /api/"+path+"/{id}", cr.save(s))
	m.HandleFunc("DELETE /api/"+path+"/{id}", cr.del(s))
}
