import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore, isHR } from '../../lib/store';
import { Avatar, Badge, Btn, Empty, Loading, Modal, Tabs, Textarea, UserPicker, Switch } from '../../ui';
import { Link, useTitle } from '../../lib/router';
import { cx, fmtShort as fmtDate, plural } from '../../lib/util';
import * as I from '../../lib/icons';
import { GfIcon, errMsg } from './common';

const KIND_ICON: Record<string, string> = { merch: '🎁', dayoff: '🏖️', charity: '💚', privilege: '⭐', other: '🎫' };
const STATUS: Record<string, [string, any]> = { pending: ['На рассмотрении', 'warn'], approved: ['Одобрено', 'accent'], issued: ['Выдано', 'ok'], rejected: ['Отклонено', 'dng'], cancelled: ['Отменено', undefined] };

function Medal({ b }: { b: any }) {
  return (
    <div className={cx('tzBadge', !b.earned && 'off')} title={b.description}>
      <span className="tzMedal" data-s={b.shape} data-t={b.tier} style={{ ['--c' as any]: b.color }}><GfIcon name={b.icon} size={26} /></span>
      <b className="small">{b.title}</b>
      <span className="tiny muted">{b.earned ? 'Получено ' + fmtDate(b.awarded_at) : b.description}</span>
    </div>
  );
}

function Overview({ g }: { g: any }) {
  const lv = g.level, nx = g.next_level;
  return (
    <div className="stack">
      <div className="card tzHero">
        <div className="tzLevel" style={{ ['--lv' as any]: lv.color }}><GfIcon name={lv.icon} size={38} /></div>
        <div className="stackS">
          <div className="row" style={{ flexWrap: 'wrap' }}><h2>{lv.title}</h2><Badge kind="accent">Уровень {g.level_index + 1}</Badge>{g.rank > 0 && <Badge>Место в рейтинге: {g.rank}</Badge>}</div>
          <div className="tzBar"><i style={{ width: g.percent + '%' }} /></div>
          <div className="small muted">{nx ? `До уровня «${nx.title}» осталось ${nx.xp_from - g.xp} XP` : 'Максимальный уровень — вы великолепны!'}</div>
        </div>
      </div>
      <div className="tzStats">
        <div className="tzStat"><span className="small muted">Баллы</span><b>{g.config.currency_icon} {g.balance}</b></div>
        <div className="tzStat"><span className="small muted">Опыт</span><b>{g.xp}</b></div>
        <div className="tzStat"><span className="small muted">Серия дней</span><b>{g.streak}</b></div>
        <div className="tzStat"><span className="small muted">Лучшая серия</span><b>{g.best_streak}</b></div>
      </div>
      <div className="card pad stack"><h3>Достижения</h3>
        <div className="tzBadges">{g.badges.map((b: any) => <Medal key={b.id} b={b} />)}</div></div>
      <div className="tzGrid">
        <div className="card pad stackS"><h3>Как зарабатывать баллы</h3>
          {g.rules.map((r: any) => <div key={r.id} className="row small"><span className="sp">{r.title}</span><Badge kind="ok">+{r.points}{r.xp ? ` · ${r.xp} XP` : ''}</Badge></div>)}</div>
        <div className="card pad stackS"><h3>История</h3>
          {g.ledger.length === 0 && <div className="small muted">Пока пусто — начните с заполнения профиля.</div>}
          {g.ledger.slice(0, 12).map((l: any) => <div key={l.id} className="row small"><span className="sp clip">{l.reason}</span><span style={{ color: l.points < 0 ? 'var(--danger)' : 'var(--ok)', fontWeight: 700 }}>{l.points > 0 ? '+' : ''}{l.points}</span></div>)}</div>
      </div>
      <label className="row small" style={{ gap: 8 }}><input type="checkbox" checked={g.hidden} onChange={async (e) => { await api.put('/api/gf/hidden', { hidden: e.target.checked }); invalidate('gf'); }} /> Не показывать меня в рейтингах</label>
    </div>
  );
}

function Leaderboard() {
  const me = useStore((s) => s.me)!;
  const [scope, setScope] = useState<'company' | 'dept' | 'teams'>('company');
  const [period, setPeriod] = useState('month');
  const q = useQuery<any>(`gf:lb:${scope}:${period}`, () => api.get(`/api/gf/leaderboard?scope=${scope}&period=${period}`), { stale: 30000 });
  const d = q.data;
  const rows = (arr: any[]) => arr.map((r) => <Link key={r.id} to={`/people/${r.id}`} className={cx('tzLb', r.id === me.id && 'me')}><span className="n">{r.rank}</span><Avatar name={r.name} src={r.avatar} size={36} /><span className="sp clip small"><b>{r.name}</b><div className="tiny muted clip">{r.job_title}</div></span><b>{r.score}</b></Link>);
  return (
    <div className="stack">
      <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
        <Tabs value={scope} onChange={(v) => setScope(v as any)} items={[{ id: 'company', label: 'Вся компания' }, { id: 'dept', label: 'Моё подразделение' }, { id: 'teams', label: 'Команды' }]} />
        <select className="sel" style={{ width: 'auto' }} value={period} onChange={(e) => setPeriod(e.target.value)} aria-label="Период"><option value="week">Неделя</option><option value="month">Месяц</option><option value="quarter">Квартал</option><option value="all">Всё время</option></select>
      </div>
      {!d ? <Loading /> : d.enabled === false ? <Empty icon={I.Star} title="Рейтинг отключён">Администратор отключил рейтинги.</Empty> : scope === 'teams' ? (
        <div className="card pad stackS">{(d.teams || []).length === 0 ? <div className="muted small">Недостаточно данных: команды показываются от трёх участников.</div> : d.teams.map((t: any, i: number) => <div key={t.id} className="tzLb"><span className="n">{i + 1}</span><I.Building size={22} /><span className="sp clip small"><b>{t.name}</b><div className="tiny muted">{plural(t.members, ['участник', 'участника', 'участников'])} · среднее на человека</div></span><b>{t.avg}</b></div>)}</div>
      ) : (
        <div className="card pad stackS">
          {d.top.length === 0 ? <div className="muted small">За выбранный период ещё нет начислений.</div> : rows(d.top)}
          {d.around.length > 0 && !d.top.some((r: any) => r.id === me.id) && <><div className="tiny muted" style={{ textAlign: 'center' }}>· · ·</div>{rows(d.around)}</>}
        </div>
      )}
    </div>
  );
}

function Shop({ g }: { g: any }) {
  const q = useQuery<any[]>('gf:rewards', () => api.get('/api/gf/rewards'));
  const [busy, setBusy] = useState(0);
  async function buy(r: any) {
    if (!confirm(`Обменять ${r.price} баллов на «${r.title}»?`)) return;
    setBusy(r.id);
    try { await api.post(`/api/gf/rewards/${r.id}/order`); invalidate('gf'); toast({ title: r.approval ? 'Заказ отправлен на рассмотрение' : 'Награда ваша!', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(0);
  }
  return (
    <div className="stack">
      <div className="small muted">Ваш баланс: <b>{g.config.currency_icon} {g.balance}</b></div>
      {!q.data ? <Loading /> : <div className="tzShop">{q.data.map((r) => {
        const lack = g.balance < r.price, out = r.stock != null && r.stock <= 0, maxed = r.per_user_limit > 0 && r.mine >= r.per_user_limit;
        return (
          <div key={r.id} className="card tzReward">
            <div className="ic">{KIND_ICON[r.kind] || '🎁'}</div><b>{r.title}</b><div className="small muted">{r.description}</div>
            <div className="row"><Badge kind="accent">{g.config.currency_icon} {r.price}</Badge>{r.stock != null && <span className="tiny muted">осталось {r.stock}</span>}</div>
            <Btn kind="pri" disabled={lack || out || maxed} busy={busy === r.id} onClick={() => buy(r)}>{out ? 'Закончилось' : maxed ? 'Уже получено' : lack ? `Не хватает ${r.price - g.balance}` : 'Получить'}</Btn>
          </div>
        );
      })}</div>}
      {g.orders.length > 0 && <div className="card pad stackS"><h3>Мои заказы</h3>{g.orders.map((o: any) => <div key={o.id} className="row small"><span className="sp">{o.title}</span><span className="muted">{fmtDate(o.created_at)}</span><Badge kind={STATUS[o.status]?.[1]}>{STATUS[o.status]?.[0]}</Badge></div>)}</div>}
    </div>
  );
}

function Thanks({ g }: { g: any }) {
  const feed = useQuery<any[]>('gf:thanks', () => api.get('/api/gf/thanks'));
  const [to, setTo] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  async function send() {
    if (!to[0]) return toast({ title: 'Выберите коллегу', kind: 'error' });
    setBusy(true);
    try { await api.post('/api/gf/thanks', { to_id: to[0].id, message: msg }); setMsg(''); setTo([]); invalidate('gf'); toast({ title: 'Спасибо отправлено', kind: 'success' }, 2500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="stack">
      <div className="card pad stack"><h3>Сказать спасибо коллеге</h3>
        <UserPicker single value={to} onChange={setTo} placeholder="Кого благодарите?" />
        <Textarea rows={3} placeholder="За что вы благодарите? Расскажите конкретнее — это ценят" value={msg} maxLength={600} onChange={(e) => setMsg(e.target.value)} />
        <div className="row"><span className="small muted sp">Сегодня осталось благодарностей: {g.thanks_left}</span><Btn kind="pri" busy={busy} disabled={g.thanks_left <= 0} onClick={send}><I.Heart size={16} /> Отправить</Btn></div></div>
      <div className="stackS">{(feed.data || []).map((t) => <div key={t.id} className="card pad row"><Avatar name={t.to_name} src={t.to_avatar} size={40} /><div className="sp"><div className="small"><b>{t.from_name}</b> благодарит <b>{t.to_name}</b></div><div className="small muted">{t.message}</div></div><span className="tiny muted">{fmtDate(t.created_at)}</span></div>)}</div>
    </div>
  );
}

function Orders() {
  const q = useQuery<any[]>('gf:orders:all', () => api.get('/api/gf/orders?all=1&status=pending'));
  async function decide(id: number, status: string) {
    const comment = status === 'rejected' ? prompt('Причина отказа') || '' : '';
    try { await api.post(`/api/gf/orders/${id}/decide`, { status, comment }); invalidate('gf'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  if (!q.data) return <Loading />;
  return <div className="card pad stackS"><h3>Заказы на рассмотрении</h3>{q.data.length === 0 && <div className="small muted">Новых заказов нет.</div>}
    {q.data.map((o) => <div key={o.id} className="row"><Avatar name={o.user_name} src={o.avatar} size={32} /><span className="sp small"><b>{o.user_name}</b> · {o.title} · {o.price} баллов</span><button className="btn sm" onClick={() => decide(o.id, 'issued')}>Выдать</button><button className="btn sm" onClick={() => decide(o.id, 'rejected')}>Отклонить</button></div>)}</div>;
}

export function RewardsPage() {
  useTitle('Достижения');
  const me = useStore((s) => s.me)!;
  const [tab, setTab] = useState<'me' | 'top' | 'shop' | 'thanks' | 'orders'>('me');
  const q = useQuery<any>('gf:me', () => api.get('/api/gf/me'), { stale: 15000 });
  const g = q.data;
  if (!g) return <Loading />;
  if (!g.config.enabled) return <div className="card"><Empty icon={I.Star} title="Геймификация отключена">Администратор пока не включил систему поощрений.</Empty></div>;
  return (
    <div className={cx('stack', g.config.style === 'playful' && 'tzPlayful')}>
      <div className="pageH"><h1>Достижения и награды</h1></div>
      <Tabs value={tab} onChange={(v) => setTab(v as any)} items={[{ id: 'me', label: 'Мой прогресс' }, { id: 'top', label: 'Рейтинг' }, { id: 'shop', label: 'Магазин наград' }, ...(isHR(me) ? [{ id: 'orders' as const, label: 'Заказы' }] : [])]} />
      {tab === 'me' && <Overview g={g} />}
      {tab === 'top' && <Leaderboard />}
      {tab === 'shop' && <Shop g={g} />}
      {tab === 'orders' && <Orders />}
    </div>
  );
}
