// Звуковые уведомления без файлов: короткие тоны WebAudio (закрытый контур, ничего не загружается).
import { getAppearance } from './appearance';

export type SoundKind = 'message' | 'news' | 'notify';
let ctx: AudioContext | null = null;
let last = 0;

const TONES: Record<SoundKind, [number, number][]> = {
  message: [[880, 0.09], [1175, 0.12]],
  news: [[660, 0.1], [880, 0.1], [1320, 0.16]],
  notify: [[740, 0.14]],
};

export function playSound(kind: SoundKind, force = false) {
  const s = getAppearance().sound;
  if (!force && (!s.on || !s.kinds[kind])) return;
  const now = Date.now();
  if (!force && now - last < 800) return; // не чаще раза в 0,8 с
  last = now;
  try {
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    ctx = ctx || new AC();
    if (ctx.state === 'suspended') ctx.resume();
    let t = ctx.currentTime;
    for (const [f, d] of TONES[kind]) {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine'; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.001, (s.vol / 100) * 0.35), t + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g).connect(ctx.destination);
      o.start(t); o.stop(t + d + 0.02);
      t += d * 0.9;
    }
  } catch { /* звук необязателен */ }
}
