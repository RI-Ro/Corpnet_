import { createPortal } from 'react-dom';
import React, { useEffect, useLayoutEffect, useRef, useState, useCallback } from 'react';
import * as I from '../lib/icons';
import { cx, hue, initials, thumb, view, avatarPos, withPos, original, imgFallback, useDebounced, fileKind, extLabel } from '../lib/util';
import { useStore, dismissToast, setState } from '../lib/store';
import { useQuery } from '../lib/query';
import { api, errMsg } from '../lib/api';
import { openLink } from '../lib/router';
import { usePdfPreview } from './PdfViewer';

// ---------------------------------------------------------------- avatar
/** Аватар. По умолчанию круглый; shape="rect" — вертикальный прямоугольник 4:5 (профиль, карточки). Положение лица берётся из адреса (#p=x,y). */
export function Avatar({ name = '', src, size = 40, online, userId, shape }: { name?: string; src?: string; size?: number; online?: boolean; userId?: number; shape?: 'rect' }) {
  const onl = useStore((s) => (userId != null && online === undefined ? s.online.has(userId) : !!online));
  const style = { '--s': size + 'px', '--h': hue(name), objectPosition: avatarPos(src) } as React.CSSProperties;
  const cls = shape === 'rect' ? 'av avRect' : 'av';
  const inner = src ? <img className={cls} src={shape === 'rect' ? view(src) : thumb(src)} alt="" loading="lazy" decoding="async" style={style} onError={imgFallback} /> : <span className={cls} style={style} title={name}><svg viewBox="0 0 24 24" width="62%" height="62%" aria-hidden="true" fill="currentColor"><circle cx="12" cy="8.2" r="4.2"/><path d="M3.6 21.2c.4-4.6 3.8-7.4 8.4-7.4s8 2.8 8.4 7.4z"/></svg></span>;
  return (
    <span className="avWrap" style={{ '--s': size + 'px' } as any}>
      {inner}
      {onl && <span className="on" />}
    </span>
  );
}

export function Img({ src, alt = '', className, style, eager }: { src?: string; alt?: string; className?: string; style?: React.CSSProperties; eager?: boolean }) {
  // 0 — как передали; 1 — вариант (превью/просмотр) не нашёлся, пробуем оригинал; 2 — картинки нет
  const [stage, setStage] = useState(0);
  useEffect(() => setStage(0), [src]);
  const cur = stage === 1 ? original(src) : src;
  if (!cur || stage > 1) return <div className={className} style={{ ...style, background: 'var(--surface3)' }} />;
  return <img className={className} style={style} src={cur} alt={alt} loading={eager ? 'eager' : 'lazy'} decoding="async" onError={() => setStage((x) => (x === 0 && original(src) !== src ? 1 : 2))} />;
}

// ---------------------------------------------------------------- misc
export const Spinner = () => <span className="spin" />;
export const Loading = () => <div className="loadCenter"><Spinner /></div>;
export const Skel = ({ h = 16, w = '100%', r }: { h?: number; w?: number | string; r?: number }) => <div className="skel" style={{ height: h, width: w, borderRadius: r }} />;

export function Empty({ icon: Ic = I.Info, title, children }: { icon?: any; title: string; children?: React.ReactNode }) {
  return (
    <div className="empty">
      <Ic size={40} />
      <div className="bold">{title}</div>
      {children}
    </div>
  );
}

export function ErrorBox({ error, retry }: { error: any; retry?: () => void }) {
  return (
    <div className="empty">
      <I.Alert size={40} />
      <div className="bold">{errMsg(error)}</div>
      {retry && <button className="btn" onClick={retry}><I.Refresh /> Повторить</button>}
    </div>
  );
}

export function Badge({ children, kind }: { children: React.ReactNode; kind?: 'accent' | 'ok' | 'warn' | 'dng' | 'lime' }) {
  return <span className={cx('badge', kind)}>{children}</span>;
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: { id: T; label: string; count?: number }[] }) {
  return (
    <div className="tabs" role="tablist">
      {items.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} className={cx('tab', value === t.id && 'on')} onClick={() => onChange(t.id)}>
          {t.label}{t.count != null ? ` · ${t.count}` : ''}
        </button>
      ))}
    </div>
  );
}

/** Пагинация: 1 … 4 5 [6] 7 8 … N. С `href` страницы — обычные ссылки (открываются в новой вкладке, копируются), клик без модификаторов — onChange. */
export function Pager({ page, total, per, pages: pagesProp, onChange, href, capped }: { page: number; total: number; per: number; pages?: number; onChange: (p: number) => void; href?: (p: number) => string; capped?: boolean }) {
  const pages = pagesProp ?? Math.ceil(total / per);
  if (pages <= 1) return null;
  const set = new Set([1, pages, page, page - 1, page + 1, page - 2, page + 2].filter((p) => p >= 1 && p <= pages));
  const list = [...set].sort((a, b) => a - b);
  const item = (p: number, content: React.ReactNode, props: { className?: string; label?: string; disabled?: boolean; current?: boolean }) => {
    if (props.disabled) return <button type="button" className={props.className} disabled aria-label={props.label}>{content}</button>;
    if (!href) return <button type="button" className={props.className} aria-label={props.label} aria-current={props.current ? 'page' : undefined} onClick={() => onChange(p)}>{content}</button>;
    return (
      <a href={href(p)} className={props.className} aria-label={props.label} aria-current={props.current ? 'page' : undefined}
        onClick={(e) => { if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return; e.preventDefault(); onChange(p); }}>{content}</a>
    );
  };
  return (
    <nav className="pager" aria-label="Страницы">
      {item(page - 1, <I.ChevronLeft />, { label: 'Назад', disabled: page <= 1 })}
      {list.map((p, i) => (
        <React.Fragment key={p}>
          {i > 0 && p - list[i - 1] > 1 && <span className="faint" style={{ alignSelf: 'center' }}>…</span>}
          {item(p, capped && p === pages ? p + '+' : p, { className: cx(p === page && 'on'), current: p === page })}
        </React.Fragment>
      ))}
      {item(page + 1, <I.ChevronRight />, { label: 'Вперёд', disabled: page >= pages })}
    </nav>
  );
}

// ---------------------------------------------------------------- form fields
export function Field({ label, hint, children, className }: { label?: string; hint?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cx('field', className)}>
      {label && <label>{label}</label>}
      {children}
      {hint && <div className="hint">{hint}</div>}
    </div>
  );
}
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(({ className, ...p }, ref) => <input ref={ref} className={cx('inp', className)} {...p} />);
export const Select = ({ className, children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement>) => <select className={cx('sel', className)} {...p}>{children}</select>;
export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(({ className, ...p }, ref) => <textarea ref={ref} className={cx('txt', className)} {...p} />);
export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: React.ReactNode }) {
  return (
    <label className="chk">
      <span className="switch"><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} /><i /></span>
      {label}
    </label>
  );
}
export function Check({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: React.ReactNode }) {
  return <label className="chk"><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />{label}</label>;
}

export function Btn({ busy, children, kind, size, icon, className, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { busy?: boolean; kind?: 'pri' | 'dng' | 'dngF' | 'ghost'; size?: 'sm' | 'lg'; icon?: boolean }) {
  return (
    <button className={cx('btn', kind, size, icon && 'icon', className)} {...p} disabled={p.disabled || busy}>
      {busy && <Spinner />}
      {children}
    </button>
  );
}

// ---------------------------------------------------------------- modal
/** Стек открытых окон: Esc и фон закрывают только верхнее, прокрутка страницы блокируется, пока открыто хотя бы одно. */
const modalStack: number[] = [];
let modalSeq = 0;
let modalOv = '';

export function Modal({ title, onClose, children, footer, size }: { title: React.ReactNode; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; size?: 'sm' | 'lg' }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  const [lvl] = useState(() => ++modalSeq);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && modalStack[modalStack.length - 1] === lvl) { e.stopPropagation(); closeRef.current(); }
    };
    if (modalStack.length === 0) { modalOv = document.body.style.overflow; document.body.style.overflow = 'hidden'; }
    modalStack.push(lvl);
    addEventListener('keydown', onKey);
    const first = ref.current?.querySelector<HTMLElement>('input:not([type=hidden]),textarea,select');
    first?.focus();
    return () => {
      removeEventListener('keydown', onKey);
      const i = modalStack.indexOf(lvl);
      if (i >= 0) modalStack.splice(i, 1);
      if (modalStack.length === 0) document.body.style.overflow = modalOv;
      prev?.focus?.();
    };
  }, []);
  // портал в body: окно всегда поверх страницы и не обрезается контейнерами с transform/overflow
  return createPortal(
    <div className="modalBack" style={{ zIndex: 200 + lvl * 2 }} onMouseDown={(e) => e.target === e.currentTarget && modalStack[modalStack.length - 1] === lvl && closeRef.current()}>
      <div className={cx('modal', size)} ref={ref} role="dialog" aria-modal="true">
        <div className="mh">
          <h3>{title}</h3>
          <button className="btn ghost icon sm" onClick={() => closeRef.current()} aria-label="Закрыть"><I.X /></button>
        </div>
        <div className="mb">{children}</div>
        {footer && <div className="mf">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

export function useConfirm() {
  const [st, setSt] = useState<null | { title: string; text?: string; ok: string; danger: boolean; res: (v: boolean) => void }>(null);
  const confirm = useCallback((title: string, o: { text?: string; ok?: string; danger?: boolean } = {}) => new Promise<boolean>((res) => setSt({ title, text: o.text, ok: o.ok || 'Подтвердить', danger: o.danger ?? true, res })), []);
  const node = st ? (
    <Modal title={st.title} size="sm" onClose={() => { st.res(false); setSt(null); }}
      footer={<><Btn onClick={() => { st.res(false); setSt(null); }}>Отмена</Btn><Btn kind={st.danger ? 'dngF' : 'pri'} onClick={() => { st.res(true); setSt(null); }}>{st.ok}</Btn></>}>
      {st.text && <p className="muted">{st.text}</p>}
    </Modal>
  ) : null;
  return [confirm, node] as const;
}

/** Click-outside + Esc popover container */
export function usePopover() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const d = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && !(e.target as HTMLElement).closest?.('[data-popmenu]') && setOpen(false);
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    addEventListener('mousedown', d);
    addEventListener('keydown', k);
    return () => { removeEventListener('mousedown', d); removeEventListener('keydown', k); };
  }, [open]);
  return { open, setOpen, ref };
}

/**
 * Выпадающее меню, нарисованное в <body> по координатам кнопки (position: fixed): его не обрезают блоки с overflow:hidden
 * (баннеры, карточки, прокручиваемые области) и не ломают предки с transform/backdrop-filter. Само переворачивается вверх
 * и прижимается к краям окна. anchor — ref из usePopover (контейнер с кнопкой).
 */
export function PopMenu({ anchor, children, onClick, className = 'menu' }: { anchor: React.RefObject<HTMLElement | null>; children: React.ReactNode; onClick?: () => void; className?: string }) {
  const el = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  useLayoutEffect(() => {
    const place = () => {
      const a = anchor.current, m = el.current;
      if (!a || !m) return;
      const r = a.getBoundingClientRect(), w = m.offsetWidth, h = m.offsetHeight;
      let left = r.right - w;
      left = Math.max(8, Math.min(left, innerWidth - w - 8));
      let top = r.bottom + 6;
      if (top + h > innerHeight - 8) top = r.top - h - 6 >= 8 ? r.top - h - 6 : Math.max(8, innerHeight - h - 8);
      setPos({ top, left });
    };
    place();
    addEventListener('resize', place);
    addEventListener('scroll', place, true);
    return () => { removeEventListener('resize', place); removeEventListener('scroll', place, true); };
  }, [anchor]);
  return createPortal(
    <div ref={el} data-popmenu className={className} role="menu" onClick={onClick}
      style={{ position: 'fixed', right: 'auto', bottom: 'auto', top: pos?.top ?? 0, left: pos?.left ?? 0, zIndex: 2000, visibility: pos ? 'visible' : 'hidden', maxHeight: 'calc(100vh - 16px)' }}>
      {children}
    </div>,
    document.body
  );
}

// ---------------------------------------------------------------- toasts
export function Toasts() {
  const toasts = useStore((s) => s.toasts);
  if (!toasts.length) return null;
  return (
    <div className="toasts" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={cx('toast', t.kind)} onClick={() => { dismissToast(t.id); openLink(t.link); }}>
          <div className="sp" style={{ minWidth: 0 }}>
            <div className="bold clamp2">{t.title}</div>
            {t.body && <div className="small muted clamp2">{t.body}</div>}
          </div>
          <button className="btn ghost icon sm" onClick={(e) => { e.stopPropagation(); dismissToast(t.id); }}><I.X size={14} /></button>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------- pickers
export interface UserLite { id: number; name: string; job_title?: string; avatar?: string }

export function UserPicker({ value, onChange, single, exclude = [], placeholder = 'Найти сотрудника…' }: { value: UserLite[]; onChange: (v: UserLite[]) => void; single?: boolean; exclude?: number[]; placeholder?: string }) {
  const [q, setQ] = useState('');
  const dq = useDebounced(q, 200);
  const { data } = useQuery<{ items: UserLite[] }>('pick:' + dq, () => api.get('/api/users?per=12&q=' + encodeURIComponent(dq)), { stale: 60000 });
  const ids = new Set(value.map((v) => v.id));
  const items = (data?.items || []).filter((u) => !ids.has(u.id) && !exclude.includes(u.id));
  return (
    <div className="stackS">
      {value.length > 0 && (
        <div className="tokens">
          {value.map((u) => (
            <span className="token" key={u.id}>
              <Avatar name={u.name} src={u.avatar} size={22} />{u.name}
              <button type="button" onClick={() => onChange(value.filter((x) => x.id !== u.id))} aria-label="Убрать"><I.X size={14} /></button>
            </span>
          ))}
        </div>
      )}
      {!(single && value.length) && (
        <div className="pick">
          <input className="sel" placeholder={placeholder} value={q} onChange={(e) => setQ(e.target.value)} />
          <div className="lst">
            {items.map((u) => (
              <div key={u.id} className="pickRow" onClick={() => { onChange(single ? [u] : [...value, u]); setQ(''); }}>
                <Avatar name={u.name} src={u.avatar} size={30} />
                <div style={{ minWidth: 0 }}><div className="bold small clip">{u.name}</div><div className="tiny muted clip">{u.job_title}</div></div>
              </div>
            ))}
            {!items.length && <div className="small muted" style={{ padding: 12 }}>Никого не найдено</div>}
          </div>
        </div>
      )}
    </div>
  );
}

export function ImageUpload({ value, onChange, label = 'Изображение', avatar }: { value: string; onChange: (url: string) => void; label?: string; avatar?: boolean }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const inp = useRef<HTMLInputElement>(null);
  async function pick(f?: File) {
    if (!f) return;
    setBusy(true); setErr('');
    try { const r = await api.upload<{ url: string }>('/api/uploads/public', f); onChange(avatar ? withPos(r.url, 50, 30) : r.url); } catch (e) { setErr(errMsg(e)); }
    setBusy(false);
  }
  return (
    <Field label={label}>
      <div className="imgUp">
        <div className="pv" style={value ? { backgroundImage: `url(${thumb(value)})` } : undefined}>{!value && <I.Image />}</div>
        <div className="stackS">
          <div className="row">
            <Btn size="sm" busy={busy} onClick={() => inp.current?.click()} type="button"><I.Upload size={15} /> Загрузить</Btn>
            {value && <Btn size="sm" kind="ghost" type="button" onClick={() => onChange('')}>Убрать</Btn>}
          </div>
          <input className="inp" style={{ minHeight: 32, padding: '4px 10px', fontSize: 13 }} placeholder="или вставьте ссылку https://…" value={value.startsWith('/media/') ? '' : value} onChange={(e) => onChange(e.target.value)} />
        </div>
        <input ref={inp} type="file" accept="image/*" hidden onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
      </div>
      {err && <div className="err">{err}</div>}
    </Field>
  );
}

// ---------------------------------------------------------------- ACL editor (folders / calendars)
export interface AclEntry { subject_type: 'user' | 'department'; subject_id: number; level: number; name?: string }
const LEVELS = [{ v: 1, l: 'Просмотр' }, { v: 2, l: 'Добавление' }, { v: 3, l: 'Редактирование' }, { v: 4, l: 'Управление' }];

export function AclEditor({ type, id, onClose }: { type: 'folder' | 'calendar'; id: number; onClose: () => void }) {
  const { data, error } = useQuery<{ resource: { visibility: string }; entries: AclEntry[] }>(`acl:${type}:${id}`, () => api.get(`/api/acl/${type}/${id}`), { stale: 0 });
  const [vis, setVis] = useState('company');
  const [entries, setEntries] = useState<AclEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [kind, setKind] = useState<'user' | 'department'>('user');
  const depts = useQuery<any[]>('departments', () => api.get('/api/departments'), { stale: 120000 });
  useEffect(() => { if (data) { setVis(data.resource.visibility); setEntries(data.entries); } }, [data]);
  async function save() {
    setBusy(true); setErr('');
    try {
      await api.put(`/api/acl/${type}/${id}`, { visibility: vis, entries: entries.map(({ subject_type, subject_id, level }) => ({ subject_type, subject_id, level })) });
      onClose();
    } catch (e) { setErr(errMsg(e)); setBusy(false); }
  }
  const add = (e: AclEntry) => !entries.some((x) => x.subject_type === e.subject_type && x.subject_id === e.subject_id) && setEntries([...entries, e]);
  return (
    <Modal title="Права доступа" onClose={onClose} footer={<><Btn onClick={onClose}>Отмена</Btn><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
      {error ? <ErrorBox error={error} /> : !data ? <Loading /> : (
        <>
          <Field label="Кто видит по умолчанию">
            <Select value={vis} onChange={(e) => setVis(e.target.value)}>
              <option value="company">Все сотрудники компании (просмотр)</option>
              <option value="restricted">Только указанные ниже</option>
            </Select>
          </Field>
          <div className="stackS">
            <div className="lbl">Доступ для сотрудников и подразделений</div>
            {entries.map((e, i) => (
              <div className="row" key={e.subject_type + e.subject_id}>
                {e.subject_type === 'user' ? <I.Users size={16} /> : <I.Building size={16} />}
                <div className="sp clip">{e.name || '#' + e.subject_id}</div>
                <Select style={{ width: 170 }} value={e.level} onChange={(ev) => setEntries(entries.map((x, j) => (j === i ? { ...x, level: +ev.target.value } : x)))}>
                  {LEVELS.map((l) => <option key={l.v} value={l.v}>{l.l}</option>)}
                </Select>
                <Btn kind="ghost" size="sm" icon onClick={() => setEntries(entries.filter((_, j) => j !== i))}><I.X size={15} /></Btn>
              </div>
            ))}
            {!entries.length && <div className="small muted">Пока никого не добавлено</div>}
          </div>
          <div className="stackS">
            <div className="chips">
              <button type="button" className={cx('chip', kind === 'user' && 'on')} onClick={() => setKind('user')}>Сотрудник</button>
              <button type="button" className={cx('chip', kind === 'department' && 'on')} onClick={() => setKind('department')}>Подразделение</button>
            </div>
            {kind === 'user' ? (
              <UserPicker value={[]} onChange={(v) => v[0] && add({ subject_type: 'user', subject_id: v[0].id, level: 1, name: v[0].name })} />
            ) : (
              <Select value="" onChange={(e) => { const d = depts.data?.find((x) => x.id === +e.target.value); d && add({ subject_type: 'department', subject_id: d.id, level: 1, name: d.name }); }}>
                <option value="">Выберите подразделение…</option>
                {depts.data?.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </Select>
            )}
          </div>
          {err && <div className="err">{err}</div>}
        </>
      )}
    </Modal>
  );
}

// ---------------------------------------------------------------- file bits
export function FileIcon({ name, mime }: { name?: string; mime?: string }) {
  const k = fileKind(name, mime);
  const Ic = { image: I.FileImage, video: I.FileVideo, pdf: I.FileText, sheet: I.Sheet, slides: I.Slides, zip: I.Zip, text: I.FileText, file: I.File }[k];
  return <div className={cx('fico', k)}><Ic size={20} /></div>;
}

export function FileLink({ f }: { f: { id: number; name: string; mime?: string; size?: number; external_url?: string } }) {
  const href = f.external_url || `/files/${f.id}`;
  const pdf = usePdfPreview(); // клик по PDF — просмотр без скачивания всего файла
  return (
    <>
    <a className="attach" href={href} target="_blank" rel="noopener noreferrer" download={f.external_url ? undefined : f.name} onClick={(e) => !f.external_url && pdf.onLinkClick(e, f)}>
      <FileIcon name={f.name} mime={f.mime} />
      <div className="sp" style={{ minWidth: 0 }}>
        <div className="bold clip">{f.name}</div>
        <div className="tiny muted">{extLabel(f.name)}{f.size ? ' · ' + (f.size < 1048576 ? Math.ceil(f.size / 1024) + ' КБ' : (f.size / 1048576).toFixed(1) + ' МБ') : ''}</div>
      </div>
      <I.Download size={18} className="muted" />
    </a>
    {pdf.node}
    </>
  );
}

export function setBooted() { setState({ booted: true }); }

/** Выбор положения лица: перетащите фото в рамке — справа показано, как оно будет выглядеть в круге и в прямоугольнике. */
export function AvatarPos({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const ref = useRef<HTMLDivElement>(null);
  const m = /#p=(\d+),(\d+)$/.exec(value);
  const [pos, setPos] = useState<[number, number]>(m ? [+m[1], +m[2]] : [50, 30]);
  const base = value.replace(/#.*$/, '');
  if (!value) return null;
  const set = (cx_: number, cy_: number) => {
    const r = ref.current!.getBoundingClientRect();
    const x = Math.min(100, Math.max(0, ((cx_ - r.left) / r.width) * 100)), y = Math.min(100, Math.max(0, ((cy_ - r.top) / r.height) * 100));
    setPos([x, y]); onChange(withPos(base, x, y));
  };
  const down = (e: React.PointerEvent) => {
    e.preventDefault(); set(e.clientX, e.clientY);
    const mv = (ev: PointerEvent) => set(ev.clientX, ev.clientY);
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
  };
  const op = `${pos[0]}% ${pos[1]}%`;
  return (
    <div className="avPos">
      <div ref={ref} className="avPosFrame" onPointerDown={down} role="slider" aria-label="Положение лица в кадре" tabIndex={0}
        onKeyDown={(e) => { const d: Record<string, [number, number]> = { ArrowLeft: [-3, 0], ArrowRight: [3, 0], ArrowUp: [0, -3], ArrowDown: [0, 3] }; const v = d[e.key]; if (v) { e.preventDefault(); const n: [number, number] = [Math.min(100, Math.max(0, pos[0] + v[0])), Math.min(100, Math.max(0, pos[1] + v[1]))]; setPos(n); onChange(withPos(base, n[0], n[1])); } }}>
        <img src={view(base)} alt="" draggable={false} />
        <i className="avPosDot" style={{ left: pos[0] + '%', top: pos[1] + '%' }} />
      </div>
      <div className="stackS" style={{ alignItems: 'center' }}>
        <img className="av avRect" style={{ ['--s' as any]: '84px', objectPosition: op }} src={view(base)} alt="" />
        <img className="av" style={{ ['--s' as any]: '48px', objectPosition: op }} src={thumb(base)} alt="" />
        <span className="tiny muted" style={{ maxWidth: 150, textAlign: 'center' }}>Нажмите на лицо или перетащите точку</span>
      </div>
    </div>
  );
}
