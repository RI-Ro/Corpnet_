package config

import (
	"os"
	"strconv"
	"time"
)

// Config — основные параметры приложения (env имеет приоритет над файлом).
type Config struct {
	HTTPAddr string
	// DatabaseURL — подключение ОБЫЧНОЙ ролью (без SUPERUSER/BYPASSRLS).
	// Схему создаёт администратор БД через psql (backend/sql), приложение
	// DDL не выполняет.
	DatabaseURL    string
	JWTSecret      string
	JWTTTL         time.Duration
	PageSize       int // размер страницы списков документов
	PageSizeMax    int // защита от злоупотребления ?page_size=100000
	AllowedOrigins string
}

func getEnvInt(key string, fallback int) int {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return fallback
}
