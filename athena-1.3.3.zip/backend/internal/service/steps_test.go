package service

import (
	"reflect"
	"testing"
)

func TestValidateSteps(t *testing.T) {
	ok := [][]int{{}, {1}, {1, 1, 1}, {1, 2, 2, 3}, {3, 1, 2, 2}, {1, 2, 3, 4, 5}}
	for _, s := range ok {
		if err := ValidateSteps(s); err != nil {
			t.Errorf("%v должно быть допустимо: %v", s, err)
		}
	}
	bad := [][]int{{2}, {0}, {0, 1}, {1, 2, 2, 4}, {1, 2, 2, 4, 5}, {1, 3}, {2, 3}, {-1, 1}, {1, 1, 3}}
	for _, s := range bad {
		if err := ValidateSteps(s); err != ErrBadSteps {
			t.Errorf("%v должно отклоняться, получили %v", s, err)
		}
	}
}

func TestValidateRoute_StepsGap(t *testing.T) {
	roles := map[int64][]string{2: {"approver_hierarchy"}, 3: {"approver_hierarchy"}, 4: {"approver_hierarchy"}, 9: {"signer"}}
	in := RouteInput{Approvers: []ApproverInput{
		{StageType: "hierarchy", ApproverID: 2, Step: 1},
		{StageType: "hierarchy", ApproverID: 3, Step: 2},
		{StageType: "hierarchy", ApproverID: 4, Step: 4},
	}, SignerIDs: []int64{9}}
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != ErrBadSteps {
		t.Fatalf("1-2-4 должно отклоняться, получили %v", err)
	}
	in.Approvers[2].Step = 2
	if err := ValidateRoute(in, 1, mkRoleOK(roles), mkSignerOK(roles)); err != nil {
		t.Fatalf("1-2-2 допустимо: %v", err)
	}
}

// Иванов-1, Петров-2, Сидоров-2, Курочкин-3, затем подпись.
func TestBuildStages_Numbered(t *testing.T) {
	in := RouteInput{Approvers: []ApproverInput{
		{StageType: "hierarchy", ApproverID: 10, Step: 1},
		{StageType: "hierarchy", ApproverID: 20, Step: 2},
		{StageType: "cross_dept", ApproverID: 30, Step: 2},
		{StageType: "hierarchy", ApproverID: 40, Step: 3},
	}, SignerIDs: []int64{90}}
	st := BuildStages(in)
	want := [][]int{nil, {0}, {0}, {1, 2}, {3}}
	steps := []int{1, 2, 2, 3, 4}
	for i := range st {
		got := st[i].DependsOnIdx
		if len(got) == 0 {
			got = nil
		}
		if !reflect.DeepEqual(got, want[i]) || st[i].StepNo != steps[i] {
			t.Errorf("этап %d: зависимости %v (ждали %v), шаг %d (ждали %d)", i, got, want[i], st[i].StepNo, steps[i])
		}
	}
	if st[4].StageType != "signing" {
		t.Error("последний этап — подпись")
	}
}

func TestNormalizeSteps(t *testing.T) {
	in := RouteInput{Sequential: true, Approvers: []ApproverInput{{ApproverID: 1}, {ApproverID: 2}, {ApproverID: 3}}}
	out := NormalizeSteps(in)
	if out.Approvers[0].Step != 1 || out.Approvers[2].Step != 3 {
		t.Errorf("цепочка: %+v", out.Approvers)
	}
	in.Sequential = false
	out = NormalizeSteps(in)
	if out.Approvers[0].Step != 1 || out.Approvers[2].Step != 1 {
		t.Errorf("параллельно: %+v", out.Approvers)
	}
	// Частично заданные номера не трогаем — пусть отклонит проверка.
	in.Approvers[1].Step = 5
	if out = NormalizeSteps(in); out.Approvers[0].Step != 0 {
		t.Errorf("частично заданные номера изменены: %+v", out.Approvers)
	}
}

// Номера после вставок «перед собой» и «после себя» всегда подряд.
func TestComputeSteps_DynamicInserts(t *testing.T) {
	// Исходно: 1(Иванов) -> 2(Петров), 3(Сидоров) -> 4(Курочкин) -> 5(подпись)
	ids := []int64{1, 2, 3, 4, 5}
	deps := map[int64][]int64{2: {1}, 3: {1}, 4: {2, 3}, 5: {4}}
	check := func(name string, ids []int64, deps map[int64][]int64, want map[int64]int) {
		t.Helper()
		got := ComputeSteps(ids, deps)
		if !reflect.DeepEqual(got, want) {
			t.Errorf("%s: %v, ждали %v", name, got, want)
		}
		all := make([]int, 0, len(got))
		for _, v := range got {
			all = append(all, v)
		}
		if err := ValidateSteps(all); err != nil {
			t.Errorf("%s: номера с пропуском: %v", name, got)
		}
	}
	check("исходный", ids, deps, map[int64]int{1: 1, 2: 2, 3: 2, 4: 3, 5: 4})

	// Петров (2) направил документ «перед собой» сотруднику 6: 6 наследует
	// зависимости Петрова, Петров ждёт 6. Сидоров (3) не затронут.
	ids = append(ids, 6)
	deps[6] = []int64{1}
	deps[2] = []int64{6}
	check("перед собой", ids, deps, map[int64]int{1: 1, 6: 2, 3: 2, 2: 3, 4: 4, 5: 5})

	// Сидоров (3) согласовал и направил «после себя» сотруднику 7: всё, что
	// ждало Сидорова, теперь ждёт 7.
	ids = append(ids, 7)
	deps[7] = []int64{3}
	deps[4] = []int64{2, 7}
	check("после себя", ids, deps, map[int64]int{1: 1, 6: 2, 3: 2, 2: 3, 7: 3, 4: 4, 5: 5})

	// Цикл не должен зависать.
	got := ComputeSteps([]int64{1, 2}, map[int64][]int64{1: {2}, 2: {1}})
	if len(got) != 2 {
		t.Errorf("цикл: %v", got)
	}
}
