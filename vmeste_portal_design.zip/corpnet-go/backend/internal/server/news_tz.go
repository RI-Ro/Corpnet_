package server

import (
	"context"
	"encoding/csv"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// Модуль предназначен для разделов 3.2–3.4 ТЗ: обязательное ознакомление с подтверждением и напоминаниями,
// отчёт «кто не ознакомился», очередь согласования публикаций (автор → редактор).

// ackNews — сотрудник подтверждает ознакомление (POST /api/news/{id}/ack).
func (s *Server) ackNews(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var due *time.Time
	err = s.db.QueryRow(ctx, `SELECT n.must_read_due FROM news n WHERE n.id = $1 AND n.must_read AND `+visibleNow+`
		AND news_targeted(n.target_depts, n.target_users, n.audience_id, $2)`, id, c.U.ID).Scan(&due)
	if err != nil {
		return errNotFound
	}
	tag, err := s.db.Exec(ctx, `INSERT INTO news_acks (news_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, c.U.ID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() > 0 && (due == nil || !time.Now().After(due.Add(24*time.Hour))) {
		s.award(ctx, c.U.ID, "must_read", "news:"+strconv.FormatInt(id, 10), nil)
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// listMustRead — «Обязательно к прочтению»: что я ещё не подтвердил (GET /api/must-read).
func (s *Server) listMustRead(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT n.id, n.title, n.must_read_due AS due, n.published_at,
			(n.must_read_due IS NOT NULL AND n.must_read_due < current_date) AS overdue, c.name AS category
		FROM news n LEFT JOIN categories c ON c.id = n.category_id
		WHERE n.must_read AND `+visibleNow+` AND news_targeted(n.target_depts, n.target_users, n.audience_id, $1)
		  AND NOT EXISTS (SELECT 1 FROM news_acks a WHERE a.news_id = n.id AND a.user_id = $1)
		ORDER BY (n.must_read_due IS NULL), n.must_read_due, n.id DESC LIMIT 50`, c.U.ID)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// canSeeNewsReports — отчёты по публикации видит тот, кто ею управляет.
func (s *Server) canManageNewsID(c *Ctx, id int64) error {
	var dept, author *int64
	if err := s.db.QueryRow(c.Context(), `SELECT department_id, author_id FROM news WHERE id = $1`, id).Scan(&dept, &author); err != nil {
		return err
	}
	sc, err := s.scopeOf(c.Context(), c.U)
	if err != nil {
		return err
	}
	if !sc.canManageNews(c.U, dept, author) {
		return errForbidden
	}
	return nil
}

// newsAcks — отчёт по ознакомлению (GET /api/news/{id}/acks[?csv=1&dept=ID]).
func (s *Server) newsAcks(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.canManageNewsID(c, id); err != nil {
		return err
	}
	ctx := c.Context()
	dept := c.QInt64("dept")
	var title string
	var must bool
	var due *time.Time
	if err := s.db.QueryRow(ctx, `SELECT title, must_read, must_read_due FROM news WHERE id = $1`, id).Scan(&title, &must, &due); err != nil {
		return err
	}
	const base = `FROM news_audience_of($1) au JOIN users u ON u.id = au.id LEFT JOIN departments d ON d.id = u.department_id
		LEFT JOIN news_acks a ON a.news_id = $1 AND a.user_id = u.id WHERE ($2::bigint = 0 OR u.department_id IN (SELECT id FROM dept_subtree(ARRAY[$2::int])))`
	if c.Q("csv") == "1" {
		rows, err := s.db.Query(ctx, `SELECT u.full_name, d.name, u.job_title, a.acked_at `+base+` ORDER BY u.last_name, u.first_name`, id, dept)
		if err != nil {
			return err
		}
		defer rows.Close()
		c.W.Header().Set("Content-Type", "text/csv; charset=utf-8")
		c.W.Header().Set("Content-Disposition", fmt.Sprintf(`attachment; filename="ack-%d.csv"`, id))
		c.W.Write([]byte("\xEF\xBB\xBF"))
		w := csv.NewWriter(c.W)
		w.Comma = ';'
		w.Write([]string{"Сотрудник", "Подразделение", "Должность", "Ознакомился"})
		for rows.Next() {
			var n, j string
			var dn *string
			var at *time.Time
			if err := rows.Scan(&n, &dn, &j, &at); err != nil {
				return err
			}
			d, a := "", "нет"
			if dn != nil {
				d = *dn
			}
			if at != nil {
				a = at.Format("02.01.2006 15:04")
			}
			w.Write([]string{n, d, j, a})
		}
		w.Flush()
		return nil
	}
	var total, acked int
	if err := s.db.QueryRow(ctx, `SELECT count(*), count(a.user_id) `+base, id, dept).Scan(&total, &acked); err != nil {
		return err
	}
	pending, err := s.arr(ctx, `SELECT u.id, u.full_name AS name, u.avatar, u.job_title, d.name AS department `+base+` AND a.user_id IS NULL
		ORDER BY u.last_name, u.first_name LIMIT 300`, id, dept)
	if err != nil {
		return err
	}
	byDept, err := s.arr(ctx, `SELECT coalesce(d.name, 'Без подразделения') AS department, count(*) AS total, count(a.user_id) AS acked
		FROM news_audience_of($1) au JOIN users u ON u.id = au.id LEFT JOIN departments d ON d.id = u.department_id
		LEFT JOIN news_acks a ON a.news_id = $1 AND a.user_id = u.id GROUP BY d.name ORDER BY count(*) - count(a.user_id) DESC, 1 LIMIT 50`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"title": title, "must_read": must, "due": due, "total": total, "acked": acked, "pending": pending, "by_dept": byDept})
}

// remindNewsAcks — редактор вручную напоминает тем, кто не ознакомился (POST /api/news/{id}/acks/remind).
func (s *Server) remindNewsAcks(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.canManageNewsID(c, id); err != nil {
		return err
	}
	ctx := c.Context()
	if !s.lock(ctx, fmt.Sprintf("ackremind:%d", id), 10*time.Minute) {
		return conflict("Напоминание уже отправлено недавно — подождите 10 минут")
	}
	var uids []int64
	rows, err := s.db.Query(ctx, `SELECT au.id FROM news n, news_audience_of(n.id) au
		WHERE n.id = $1 AND NOT EXISTS (SELECT 1 FROM news_acks a WHERE a.news_id = n.id AND a.user_id = au.id)`, id)
	if err != nil {
		return err
	}
	for rows.Next() {
		var u int64
		if rows.Scan(&u) == nil {
			uids = append(uids, u)
		}
	}
	rows.Close()
	var title string
	s.db.QueryRow(ctx, `SELECT title FROM news WHERE id = $1`, id).Scan(&title)
	s.notify(ctx, uids, "mustread", "Напоминание: ознакомьтесь с публикацией", title, fmt.Sprintf("/news/%d", id))
	s.audit(c, "news.ack_remind", "news", id, map[string]any{"count": len(uids)})
	return c.JSON(200, map[string]any{"sent": len(uids)})
}

// ---------------------------------------------------------------- согласование

// reviewQueue — публикации, ожидающие согласования, и мои отклонённые/черновики (GET /api/news-review).
func (s *Server) reviewQueue(c *Ctx) error {
	ctx := c.Context()
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	const cols = `n.id, n.title, n.status, n.submitted_at, n.review_note, n.author_id, u.full_name AS author, d.name AS department, n.audience_id, n.must_read`
	const from = ` FROM news n LEFT JOIN users u ON u.id = n.author_id LEFT JOIN departments d ON d.id = n.department_id`
	var queue any = []any{}
	if c.U.CanEdit() {
		q := `SELECT ` + cols + from + ` WHERE n.status = 'review' AND ($1::boolean OR n.department_id = ANY($2::bigint[]) OR (n.department_id IS NULL AND $3::boolean)) ORDER BY n.submitted_at LIMIT 100`
		if queue, err = s.arr(ctx, q, sc.All, sc.IDs, c.U.CoNews || c.U.IsAdmin()); err != nil {
			return err
		}
	}
	mine, err := s.arr(ctx, `SELECT `+cols+from+` WHERE n.author_id = $1 AND n.status IN ('review','rejected','draft') ORDER BY n.updated_at DESC LIMIT 50`, c.U.ID)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"queue": queue, "mine": mine})
}

// submitNews — автор отправляет черновик на согласование (POST /api/news/{id}/submit).
func (s *Server) submitNews(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	var title string
	var dept *int64
	err = s.db.QueryRow(ctx, `UPDATE news SET status = 'review', submitted_at = now(), review_note = '' WHERE id = $1 AND author_id = $2 AND status IN ('draft','rejected')
		RETURNING title, department_id`, id, c.U.ID).Scan(&title, &dept)
	if err != nil {
		return errNotFound
	}
	s.notifyReviewers(c, dept, "Новая публикация на согласовании", title, id)
	s.audit(c, "news.submit", "news", id, nil)
	return c.JSON(200, map[string]any{"ok": true})
}

func (s *Server) notifyReviewers(c *Ctx, dept *int64, title, body string, id int64) {
	ctx := c.Context()
	var uids []int64
	rows, err := s.db.Query(ctx, `SELECT u.id FROM users u WHERE NOT u.blocked AND u.id <> $3 AND (u.role = 'admin' OR (u.role = 'editor' AND (
			$1::bigint IS NULL AND u.company_news OR u.department_id IN (SELECT id FROM dept_subtree(ARRAY[$2::int])) OR
			EXISTS (SELECT 1 FROM editor_departments e WHERE e.user_id = u.id AND e.department_id IN (SELECT id FROM dept_subtree(ARRAY[$2::int]))))))`, dept, dept, c.U.ID)
	if err != nil {
		return
	}
	for rows.Next() {
		var u int64
		if rows.Scan(&u) == nil {
			uids = append(uids, u)
		}
	}
	rows.Close()
	s.notify(ctx, uids, "review", title, body, "/editorial")
}

// approveNews / rejectNews — решение редактора (POST /api/news/{id}/approve|reject).
func (s *Server) approveNews(c *Ctx) error { return s.reviewDecision(c, true) }
func (s *Server) rejectNews(c *Ctx) error  { return s.reviewDecision(c, false) }

func (s *Server) reviewDecision(c *Ctx, ok bool) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Note string `json:"note"`
	}
	c.Decode(&in)
	in.Note = strings.TrimSpace(in.Note)
	if !ok && in.Note == "" {
		return badReq("Укажите причину возврата на доработку")
	}
	if err := s.canManageNewsID(c, id); err != nil {
		return err
	}
	ctx := c.Context()
	st := "rejected"
	if ok {
		st = "published"
	}
	var author *int64
	var title string
	err = s.db.QueryRow(ctx, `UPDATE news SET status = $2, reviewer_id = $3, review_note = $4, published_at = CASE WHEN $2 = 'published' THEN greatest(published_at, now()) ELSE published_at END,
		updated_at = now() WHERE id = $1 AND status = 'review' RETURNING author_id, title`, id, st, c.U.ID, in.Note).Scan(&author, &title)
	if err != nil {
		return conflict("Публикация уже обработана или не находится на согласовании")
	}
	if author != nil {
		if ok {
			s.notify(ctx, []int64{*author}, "review", "Публикация согласована", title, fmt.Sprintf("/news/%d", id))
		} else {
			s.notify(ctx, []int64{*author}, "review", "Публикация возвращена на доработку", title+": "+in.Note, "/editorial")
		}
	}
	if ok {
		s.bumpNews(ctx)
		s.announceDue(ctx, id)
	}
	s.audit(c, map[bool]string{true: "news.approve", false: "news.reject"}[ok], "news", id, map[string]any{"note": in.Note})
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- фоновые напоминания

// mustReadJob — напоминания по обязательным публикациям: первое (через сутки), в день срока и эскалация руководителю.
func (s *Server) mustReadJob(ctx context.Context) {
	if !s.lock(ctx, "mustread-job", 4*time.Minute) {
		return
	}
	const pending = `FROM news n CROSS JOIN LATERAL news_audience_of(n.id) au JOIN users u ON u.id = au.id
		WHERE n.must_read AND ` + visibleNow + ` AND NOT EXISTS (SELECT 1 FROM news_acks a WHERE a.news_id = n.id AND a.user_id = u.id)`
	exec := func(kind, cond, title string, target string) {
		q := `WITH ins AS (INSERT INTO news_ack_reminders (news_id, user_id, kind) SELECT n.id, u.id, '` + kind + `' ` + pending + ` AND ` + cond + `
			AND NOT EXISTS (SELECT 1 FROM news_ack_reminders r WHERE r.news_id = n.id AND r.user_id = u.id AND r.kind = '` + kind + `')
			ON CONFLICT DO NOTHING RETURNING news_id, user_id)
		INSERT INTO notifications (user_id, kind, title, body, link) ` + target
		_ = title
		if _, err := s.db.Exec(ctx, q); err != nil {
			s.log.Warn("mustread job", "kind", kind, "err", err)
		}
	}
	exec("first", `n.published_at < now() - interval '1 day' AND (n.must_read_due IS NULL OR n.must_read_due > current_date + 1)`, "",
		`SELECT i.user_id, 'mustread', 'Обязательно к прочтению', n.title, '/news/' || n.id FROM ins i JOIN news n ON n.id = i.news_id`)
	exec("due", `n.must_read_due IS NOT NULL AND n.must_read_due <= current_date + 1`, "",
		`SELECT i.user_id, 'mustread', CASE WHEN n.must_read_due < current_date THEN 'Срок ознакомления истёк' ELSE 'Срок ознакомления истекает' END, n.title, '/news/' || n.id
		 FROM ins i JOIN news n ON n.id = i.news_id`)
	exec("escalate", `n.must_read_due IS NOT NULL AND n.must_read_due < current_date - 2 AND u.department_id IS NOT NULL`, "",
		`SELECT d.head_id, 'mustread', 'Сотрудник не ознакомился в срок', u.full_name || ': ' || n.title, '/news/' || n.id
		 FROM ins i JOIN news n ON n.id = i.news_id JOIN users u ON u.id = i.user_id JOIN departments d ON d.id = u.department_id WHERE d.head_id IS NOT NULL`)
	s.hub.Emit(ctx, "feed", "refresh", map[string]string{"what": "notifications"})
}
