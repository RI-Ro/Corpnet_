// Внешний вид, настраиваемый пользователем: дизайн, палитра внутри дизайна, масштаб элементов (--ui) и шрифта (--fs),
// шрифт (самохостинг, подгрузка только после выбора), ширина/сворачивание меню.
// Источник истины — сервер (users.settings.ui); localStorage хранит копию для мгновенного применения до ответа сервера.
import { useSyncExternalStore } from 'react';
import { api } from './api';
import { getState, setState, applyTheme, setTheme } from './store';
import { FONT_LIST } from './fontlist';
import { bgCss, validBg, validPhoto } from './bg';

export interface Appearance {
  design: string;
  /** запомненная палитра для каждого дизайна: при возврате в дизайн восстанавливается его последняя палитра */
  themes: Record<string, string>;
  ui: number; // масштаб элементов, %
  fs: number; // размер шрифта, %
  font: string; // id из FONT_LIST; '' — шрифт дизайна
  bold: boolean;
  italic: boolean;
  sideW: number; // ширина меню, px
  sideOff: boolean;
  /** порядок пунктов меню (плоский список id; внутри групп) и скрытые пользователем пункты */
  menuOrder: string[];
  menuHidden: string[];
  /** фон страницы: id пресета (lib/bg.ts) или #rrggbb */
  bg: string;
  /** фото фона (при bg = 'photo'): загруженное в портал или ссылка; затемнение вуалью, % */
  bgPhoto: string;
  bgDim: number;
  sound: { on: boolean; vol: number; kinds: { message: boolean; news: boolean; notify: boolean } };
  /** время последнего изменения (мс): при загрузке побеждает более свежая копия — серверная или локальная */
  _t?: number;
  /** ключи, которые пользователь менял сам: только они не перезаписываются умолчаниями администратора */
  _u: string[];
}

export interface DesignDef { id: string; label: string; hint: string; themes: string[]; def: string }
/** Дизайн меняет форму: радиусы, рамки, плотность, тени. Палитры — те же `data-theme`, но у каждого дизайна свой рекомендуемый набор. */
export const DESIGNS: DesignDef[] = [
  { id: 'editorial', label: 'Журнал', hint: 'Крупные заголовки, спокойные поверхности и тонкие разделители', themes: ['glassl', 'light', 'paper', 'midnight', 'mint', 'frost', 'rose', 'glass', 'graphite', 'green', 'orange', 'carbon', 'ember', 'kteam', 'balun', 'cyber'], def: 'glassl' },
  { id: 'glass', label: 'Стекло', hint: 'Полупрозрачные панели, мягкие градиенты', themes: ['glassl', 'glass', 'green', 'orange'], def: 'glassl' },
  { id: 'enterprise', label: 'Строгий', hint: 'Плоско, малые радиусы, плотная вёрстка', themes: ['light', 'glassl', 'green', 'glass'], def: 'light' },
  { id: 'classic', label: 'Классика', hint: 'Тонкие рамки, без теней, моно-метки', themes: ['light', 'glass', 'orange', 'green'], def: 'light' },
  { id: 'soft', label: 'Мягкий', hint: 'Крупные радиусы, воздух, пастель', themes: ['glassl', 'green', 'orange', 'light'], def: 'glassl' },
  { id: 'contrast', label: 'Контраст', hint: 'Чёткие рамки, максимальная читаемость', themes: ['cyber', 'light', 'glass'], def: 'light' },
  { id: 'balun', label: 'Современная', hint: 'Тёмный инженерный стиль: тонкие рамки, моно-метки', themes: ['balun', 'midnight', 'carbon', 'graphite', 'ember', 'paper', 'mint', 'frost', 'rose'], def: 'balun' },
  { id: 'softnight', label: 'Мягкая тёмная', hint: 'Закруглённая «Мягкая» в тёмных цветах «Современной»', themes: ['balun', 'midnight', 'carbon', 'graphite', 'ember'], def: 'balun' },
  { id: 'kteam', label: 'Свежая', hint: 'Фиолетовая панель, пастельные секции, белые карточки', themes: ['kteam', 'light', 'glassl', 'green'], def: 'kteam' },
  { id: 'board', label: 'Доска', hint: 'Серые колонки и белые карточки, как на канбан-доске', themes: ['light', 'glassl', 'green', 'orange'], def: 'light' },
];
export const designById = (id: string) => DESIGNS.find((d) => d.id === id) || DESIGNS[0];

export const DEFAULTS: Appearance = { design: 'editorial', themes: {}, ui: 100, fs: 100, font: '', bold: false, italic: false, sideW: 0, sideOff: false, menuOrder: [], menuHidden: [], bg: 'none', bgPhoto: '', bgDim: 55, _u: [], sound: { on: true, vol: 60, kinds: { message: true, news: true, notify: true } } };
export const clampScale = (v: unknown) => { const n = Math.round(Number(v) / 5) * 5; return Number.isFinite(n) ? Math.min(150, Math.max(50, n)) : 100; };

let cur: Appearance = { ...DEFAULTS };
const subs = new Set<() => void>();
const lsKey = (uid?: number) => `cn:${uid ?? getState().me?.id ?? 0}:appearance`;

function sanitize(raw: any): Appearance {
  const a = { ...DEFAULTS, ...(raw && typeof raw === 'object' ? raw : {}) };
  a.design = DESIGNS.some((d) => d.id === a.design) ? a.design : DEFAULTS.design;
  a.ui = clampScale(a.ui); a.fs = clampScale(a.fs);
  a.font = FONT_LIST.some((f) => f.id === a.font) ? a.font : '';
  a.sideW = a.sideW ? Math.min(420, Math.max(200, Math.round(a.sideW))) : 0;
  a._t = Number(a._t) || 0;
  a.bold = !!a.bold; a.italic = !!a.italic; a.sideOff = !!a.sideOff;
  a.menuOrder = Array.isArray(a.menuOrder) ? a.menuOrder.filter((x: any) => typeof x === 'string').slice(0, 100) : [];
  a.menuHidden = Array.isArray(a.menuHidden) ? a.menuHidden.filter((x: any) => typeof x === 'string').slice(0, 100) : [];
  a.bg = validBg(a.bg) ? a.bg : 'none';
  a.bgPhoto = validPhoto(a.bgPhoto) ? a.bgPhoto : '';
  if (a.bg === 'photo' && !a.bgPhoto) a.bg = 'none';
  a.bgDim = Math.min(90, Math.max(0, Math.round(Number(a.bgDim ?? 55))));
  a._u = Array.isArray(a._u) ? a._u.filter((x: any) => typeof x === 'string').slice(0, 40) : [];
  const so = a.sound && typeof a.sound === 'object' ? a.sound : {};
  a.sound = { on: so.on !== false, vol: Math.min(100, Math.max(0, Math.round(Number(so.vol ?? 60)))), kinds: { message: so.kinds?.message !== false, news: so.kinds?.news !== false, notify: so.kinds?.notify !== false } };
  a.themes = a.themes && typeof a.themes === 'object' ? a.themes : {};
  return a;
}

const loaded = new Set<string>();
/** Подключает @font-face выбранного шрифта (однократно); файлы берутся с собственного сервера. */
export function loadFont(id: string) {
  const f = FONT_LIST.find((x) => x.id === id);
  if (!f || loaded.has(id)) return;
  loaded.add(id);
  const range: Record<string, string> = {
    cyrillic: 'U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116',
    latin: 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD',
  };
  const css = f.faces.map(([sub, w, it]) => `@font-face{font-family:"${f.family}";font-style:${it ? 'italic' : 'normal'};font-weight:${w};font-display:swap;src:url(/ui-fonts/${f.id}/${f.id}-${sub}-${w}-${it ? 'italic' : 'normal'}.woff2) format("woff2");unicode-range:${range[sub]}}`).join('');
  const st = document.createElement('style');
  st.dataset.uiFont = id;
  st.textContent = css;
  document.head.appendChild(st);
}

export function applyAppearance(a: Appearance) {
  const r = document.documentElement;
  r.dataset.design = a.design;
  r.style.setProperty('--ui', String(a.ui / 100));
  r.style.setProperty('--fs', String(a.fs / 100));
  r.style.setProperty('--side-w', a.sideW ? a.sideW + 'px' : '');
  r.style.zoom = a.ui === 100 ? '' : String(a.ui / 100);
  const f = FONT_LIST.find((x) => x.id === a.font);
  if (f) {
    loadFont(f.id);
    const fb = f.kind === 'serif' ? 'Georgia, "Times New Roman", serif' : f.kind === 'mono' ? 'ui-monospace, Consolas, monospace' : 'system-ui, "Segoe UI", Arial, sans-serif';
    r.style.setProperty('--font-user', `"${f.family}", ${fb}`);
    r.dataset.userFont = '1';
  } else { r.style.removeProperty('--font-user'); delete r.dataset.userFont; }
  const bg = bgCss(a.bg, a.bgPhoto, a.bgDim);
  r.style.setProperty('--page-bg', bg.image || 'none');
  r.style.setProperty('--page-bg-size', bg.size);
  r.dataset.bg = a.bg === 'none' ? '' : '1';
  r.dataset.fontBold = a.bold ? '1' : '';
  r.dataset.fontItalic = a.italic ? '1' : '';
}

let timer: any;
let dirty = false;
function flush(keepalive = false) {
  const me = getState().me;
  if (!me || !dirty) return;
  dirty = false;
  fetch('/api/me/prefs', { method: 'PUT', keepalive, credentials: 'same-origin', headers: { 'content-type': 'application/json', 'X-CSRF-Token': (document.cookie.match(/(?:^|; )cn_csrf=([^;]+)/) || [])[1] || '' }, body: JSON.stringify({ key: 'ui', value: cur }) }).then((res) => { if (!res.ok) dirty = true; }).catch(() => { dirty = true; });
  setState({ me: { ...me, settings: { ...(me.settings || {}), ui: cur } } });
}
if (typeof addEventListener === 'function') { addEventListener('pagehide', () => flush(true)); document.addEventListener('visibilitychange', () => document.visibilityState === 'hidden' && flush(true)); }
function persist() {
  cur._t = Date.now();
  dirty = true;
  try { localStorage.setItem(lsKey(), JSON.stringify(cur)); localStorage.setItem('cn_last_ui', JSON.stringify(cur)); } catch {}
  clearTimeout(timer);
  timer = setTimeout(() => flush(), 600);
}

export function setAppearance(patch: Partial<Appearance>, system = false) {
  const u = system ? cur._u : [...new Set([...cur._u, ...((patch as any)._u || []), ...Object.keys(patch).filter((k) => !k.startsWith('_'))])];
  cur = sanitize({ ...cur, ...patch, _u: u });
  applyAppearance(cur);
  subs.forEach((f) => f());
  persist();
}

/** Смена дизайна: восстанавливает последнюю палитру этого дизайна (или рекомендуемую), запоминает текущую палитру старого. */
export function setDesign(id: string) {
  const st = getState();
  const old = designById(cur.design);
  const themes = { ...cur.themes };
  themes[old.id] = st.theme;
  const d = designById(id);
  const mem = themes[d.id]; const next = mem === 'system' || d.themes.includes(mem) ? mem : d.def;
  setAppearance({ design: d.id, themes, _u: [...new Set([...cur._u, 'theme'])] } as any);
  setTheme(next);
}
/** Смена палитры внутри дизайна запоминается за этим дизайном. */
export function pickTheme(t: string) {
  setTheme(t);
  setAppearance({ themes: { ...cur.themes, [cur.design]: t }, _u: [...new Set([...cur._u, 'theme'])] } as any);
}
/** Сброс личных настроек: снова действуют умолчания администратора. */
export function resetAppearance(defaults?: any) {
  cur = sanitize(withDefaults({ _u: [] }, defaults));
  applyAppearance(cur);
  const dt = defaults?.theme || (defaults?.design ? designById(cur.design).def : 'glassl');
  setTheme(dt);
  subs.forEach((f) => f());
  persist();
}

/** Умолчания администратора: действуют только на то, что пользователь не менял сам (ключи вне _u). Тема — отдельно. */
function withDefaults(user: any, defaults: any): any {
  const d = defaults && typeof defaults === 'object' ? defaults : {};
  const u = user && typeof user === 'object' ? user : {};
  let mine: string[] = Array.isArray(u._u) ? u._u : Object.keys(u).filter((k) => !k.startsWith('_') && JSON.stringify(u[k]) !== JSON.stringify((DEFAULTS as any)[k])); // старые записи без _u: всё, что отличается от стандартного, считаем личным
  const out: any = { ...DEFAULTS };
  for (const k of Object.keys(d)) if (k !== 'theme' && k !== 'sound') out[k] = d[k];
  if (d.sound !== undefined) out.sound = typeof d.sound === 'object' ? d.sound : { ...DEFAULTS.sound, on: d.sound !== false };
  for (const k of mine) if (k in u) out[k] = u[k];
  out._u = mine; out._t = u._t || 0;
  if (!mine.includes('themes')) out.themes = {};
  else out.themes = u.themes || {};
  return out;
}

/** После входа: пользовательские настройки (более свежая копия — сервер или localStorage) поверх умолчаний администратора. */
export function loadAppearance(uid: number, server: any, defaults?: any) {
  let raw = server;
  let loc: any = null;
  try { loc = JSON.parse(localStorage.getItem(lsKey(uid)) || 'null'); } catch {}
  if (!raw || (loc && Number(loc._t) > Number(raw._t || 0))) { if (loc) { raw = loc; dirty = Number(loc._t) > Number(server?._t || 0); if (dirty) setTimeout(() => flush(), 1500); } }
  cur = sanitize(withDefaults(raw, defaults));
  applyAppearance(cur);
  // тема: личный выбор, иначе тема администратора, иначе рекомендуемая для дизайна (если дизайн задан администратором)
  if (!cur._u.includes('theme')) {
    const dt = defaults?.theme;
    const t = dt || (defaults?.design && !cur._u.includes('design') ? designById(cur.design).def : '');
    if (t) { setState({ theme: t }); applyTheme(t); }
  }
  try { localStorage.setItem(lsKey(uid), JSON.stringify(cur)); localStorage.setItem('cn_last_ui', JSON.stringify(cur)); } catch {}
  subs.forEach((f) => f());
}
export const getAppearance = () => cur;
export function useAppearance(): Appearance {
  return useSyncExternalStore((cb) => (subs.add(cb), () => subs.delete(cb)), () => cur);
}
export { applyTheme };
