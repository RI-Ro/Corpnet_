package handlers

import (
	"errors"
	"io"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/authdom"
	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// AuthDomainsHandler — управление доменами аутентификации (LDAP, Kerberos)
// через веб. Только для администратора. Секреты (пароль служебной учётной
// записи LDAP, keytab) принимаются, но никогда не возвращаются.
type AuthDomainsHandler struct {
	pool  *pgxpool.Pool
	store *authdom.Store
}

func NewAuthDomainsHandler(pool *pgxpool.Pool, store *authdom.Store) *AuthDomainsHandler {
	return &AuthDomainsHandler{pool: pool, store: store}
}

func (h *AuthDomainsHandler) admin(c *fiber.Ctx) (int64, error) {
	userID, _ := c.Locals(middleware.CtxUserID).(int64)
	isAdmin, _ := c.Locals(middleware.CtxIsAdmin).(bool)
	if !isAdmin {
		return 0, fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return userID, nil
}

func (h *AuthDomainsHandler) withKeytabInfo(d authdom.Domain) authdom.Domain {
	if d.HasKeytab {
		if raw, err := h.store.KeytabBytes(d); err != nil {
			d.KeytabInfo = err.Error()
		} else if info, err := authdom.ParseKeytab(raw); err == nil {
			d.KeytabInfo = info
		}
	}
	return d
}

// List GET /api/admin/auth-domains
func (h *AuthDomainsHandler) List(c *fiber.Ctx) error {
	if _, err := h.admin(c); err != nil {
		return err
	}
	h.store.Invalidate()
	all, err := h.store.All(c.Context())
	if err != nil {
		log.Printf("auth domains list: %v", err)
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить домены")
	}
	out := make([]fiber.Map, 0, len(all))
	for _, d := range all {
		d = h.withKeytabInfo(d)
		var users int
		_ = h.pool.QueryRow(c.Context(), `SELECT count(*) FROM users WHERE domain_id = $1`, d.ID).Scan(&users)
		out = append(out, fiber.Map{"domain": d, "users": users})
	}
	return c.JSON(fiber.Map{"domains": out})
}

type domainRequest struct {
	authdom.Domain
	// LDAPBindPassword: nil — не менять; "" — стереть; иначе — задать.
	LDAPBindPassword *string `json:"ldap_bind_password"`
}

func mapDomainErr(err error) error {
	var pg *pgconn.PgError
	if errors.As(err, &pg) {
		switch pg.Code {
		case "23505":
			return fiber.NewError(fiber.StatusConflict, "домен с таким именем уже есть")
		case "23503":
			return fiber.NewError(fiber.StatusConflict, "к домену привязаны пользователи — сначала отключите или перенесите их")
		case "23514":
			return fiber.NewError(fiber.StatusBadRequest, "недопустимое значение: "+pg.Message)
		}
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return fiber.NewError(fiber.StatusNotFound, "домен не найден")
	}
	log.Printf("auth domain: %v", err)
	return fiber.NewError(fiber.StatusInternalServerError, "не удалось сохранить домен")
}

// Create POST /api/admin/auth-domains
func (h *AuthDomainsHandler) Create(c *fiber.Ctx) error {
	userID, err := h.admin(c)
	if err != nil {
		return err
	}
	var req domainRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if err := req.Domain.Validate(); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}
	var pwEnc []byte
	if req.LDAPBindPassword != nil && *req.LDAPBindPassword != "" {
		if pwEnc, err = h.store.Seal([]byte(*req.LDAPBindPassword)); err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось зашифровать пароль")
		}
	}
	d := req.Domain
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			INSERT INTO auth_domains (realm, title, netbios_name, is_active, sort_order,
				ldap_enabled, ldap_urls, ldap_start_tls, ldap_skip_verify, ldap_ca_pem, ldap_bind_dn,
				ldap_bind_password_enc, ldap_base_dn, ldap_user_filter, ldap_attr_full_name,
				ldap_attr_position, ldap_timeout_sec, kerberos_enabled, kerberos_spn,
				auto_create_users, default_department_id, ldap_attr_email)
			VALUES ($1,$2,NULLIF($3,''),$4,$5,$6,$7,$8,$9,NULLIF($10,''),NULLIF($11,''),$12,NULLIF($13,''),$14,$15,$16,$17,$18,NULLIF($19,''),$20,$21,$22)
			RETURNING id`,
			d.Realm, d.Title, d.NetBIOS, d.IsActive, d.SortOrder,
			d.LDAPEnabled, d.LDAPURLs, d.LDAPStartTLS, d.LDAPSkipVerify, d.LDAPCAPEM, d.LDAPBindDN,
			pwEnc, d.LDAPBaseDN, d.LDAPUserFilter, d.LDAPAttrFullName,
			d.LDAPAttrPosition, d.LDAPTimeoutSec, d.KerberosEnabled, strings.TrimSpace(d.KerberosSPN),
			d.AutoCreateUsers, d.DefaultDepartmentID, d.LDAPAttrEmail).Scan(&id)
	})
	if txErr != nil {
		return mapDomainErr(txErr)
	}
	h.store.Invalidate()
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

// Update PUT /api/admin/auth-domains/:id
//
// Имя области (realm) после создания не меняется: оно входит в логины
// пользователей домена, и переименование превратило бы их в «чужих».
func (h *AuthDomainsHandler) Update(c *fiber.Ctx) error {
	userID, err := h.admin(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req domainRequest
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	cur, err := h.store.Get(c.Context(), id)
	if err != nil {
		return mapDomainErr(err)
	}
	req.Domain.Realm = cur.Realm
	if err := req.Domain.Validate(); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}
	d := req.Domain
	setPw := req.LDAPBindPassword != nil
	var pwEnc []byte
	if setPw && *req.LDAPBindPassword != "" {
		if pwEnc, err = h.store.Seal([]byte(*req.LDAPBindPassword)); err != nil {
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось зашифровать пароль")
		}
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE auth_domains SET title=$2, netbios_name=NULLIF($3,''), is_active=$4, sort_order=$5,
				ldap_enabled=$6, ldap_urls=$7, ldap_start_tls=$8, ldap_skip_verify=$9, ldap_ca_pem=NULLIF($10,''),
				ldap_bind_dn=NULLIF($11,''),
				ldap_bind_password_enc = CASE WHEN $12 THEN $13 ELSE ldap_bind_password_enc END,
				ldap_base_dn=NULLIF($14,''), ldap_user_filter=$15, ldap_attr_full_name=$16,
				ldap_attr_position=$17, ldap_timeout_sec=$18, kerberos_enabled=$19, kerberos_spn=NULLIF($20,''),
				auto_create_users=$21, default_department_id=$22, ldap_attr_email=$23, updated_at=now()
			WHERE id=$1`,
			id, d.Title, d.NetBIOS, d.IsActive, d.SortOrder,
			d.LDAPEnabled, d.LDAPURLs, d.LDAPStartTLS, d.LDAPSkipVerify, d.LDAPCAPEM,
			d.LDAPBindDN, setPw, pwEnc,
			d.LDAPBaseDN, d.LDAPUserFilter, d.LDAPAttrFullName,
			d.LDAPAttrPosition, d.LDAPTimeoutSec, d.KerberosEnabled, strings.TrimSpace(d.KerberosSPN),
			d.AutoCreateUsers, d.DefaultDepartmentID, d.LDAPAttrEmail)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		return mapDomainErr(txErr)
	}
	h.store.Invalidate()
	return c.SendStatus(fiber.StatusOK)
}

// Delete DELETE /api/admin/auth-domains/:id — только если в домене нет
// пользователей (их документы и подписи ссылаются на учётные записи).
func (h *AuthDomainsHandler) Delete(c *fiber.Ctx) error {
	userID, err := h.admin(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `DELETE FROM auth_domains WHERE id=$1`, id)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		return mapDomainErr(txErr)
	}
	h.store.Invalidate()
	return c.SendStatus(fiber.StatusOK)
}

// UploadKeytab PUT /api/admin/auth-domains/:id/keytab — multipart, поле file.
func (h *AuthDomainsHandler) UploadKeytab(c *fiber.Ctx) error {
	userID, err := h.admin(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	fh, err := c.FormFile("file")
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "приложите файл keytab")
	}
	if fh.Size <= 0 || fh.Size > 1<<20 {
		return fiber.NewError(fiber.StatusBadRequest, "keytab пуст или больше 1 МБ")
	}
	f, err := fh.Open()
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "файл не читается")
	}
	defer f.Close()
	raw, err := io.ReadAll(io.LimitReader(f, 1<<20))
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "файл не читается")
	}
	info, err := authdom.ParseKeytab(raw)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	}
	enc, err := h.store.Seal(raw)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось зашифровать keytab")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE auth_domains SET kerberos_keytab_enc=$2, kerberos_keytab_uploaded_at=now(), updated_at=now()
			 WHERE id=$1`, id, enc)
		if err != nil {
			return err
		}
		if ct.RowsAffected() == 0 {
			return pgx.ErrNoRows
		}
		return nil
	})
	if txErr != nil {
		return mapDomainErr(txErr)
	}
	h.store.Invalidate()
	return c.JSON(fiber.Map{"keytab_info": info})
}

// DeleteKeytab DELETE /api/admin/auth-domains/:id/keytab
func (h *AuthDomainsHandler) DeleteKeytab(c *fiber.Ctx) error {
	userID, err := h.admin(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, true, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `
			UPDATE auth_domains SET kerberos_keytab_enc=NULL, kerberos_keytab_uploaded_at=NULL, updated_at=now()
			 WHERE id=$1`, id)
		return err
	})
	if txErr != nil {
		return mapDomainErr(txErr)
	}
	h.store.Invalidate()
	return c.SendStatus(fiber.StatusOK)
}

// Test POST /api/admin/auth-domains/:id/test — проверка LDAP сохранённого
// домена: соединение, служебная учётная запись и (если задан login) поиск
// пользователя. Тело: { "login": "ivanov" } (необязательно).
func (h *AuthDomainsHandler) Test(c *fiber.Ctx) error {
	if _, err := h.admin(c); err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Login string `json:"login"`
	}
	_ = c.BodyParser(&req)
	d, err := h.store.Get(c.Context(), id)
	if err != nil {
		return mapDomainErr(err)
	}
	if len(d.LDAPURLs) == 0 {
		return c.JSON(fiber.Map{"ok": false, "message": "не задан адрес сервера LDAP"})
	}
	msg, err := h.store.TestLDAP(d, req.Login)
	if err != nil {
		return c.JSON(fiber.Map{"ok": false, "message": err.Error()})
	}
	return c.JSON(fiber.Map{"ok": true, "message": msg})
}
