package authdom

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Domain — один домен аутентификации.
type Domain struct {
	ID          int64  `json:"id"`
	Realm       string `json:"realm"`        // DOMAIN1.LOCAL (верхний регистр)
	Title       string `json:"title"`        // подпись для людей
	NetBIOS     string `json:"netbios_name"` // короткое имя для входа вида DOMAIN1\ivanov
	IsActive    bool   `json:"is_active"`
	SortOrder   int    `json:"sort_order"`
	LDAPEnabled bool   `json:"ldap_enabled"`
	// LDAPURLs — один или несколько серверов (ldap://host:389, ldaps://host:636);
	// перебираются по порядку до первого доступного.
	LDAPURLs       []string `json:"ldap_urls"`
	LDAPStartTLS   bool     `json:"ldap_start_tls"`
	LDAPSkipVerify bool     `json:"ldap_skip_verify"`
	LDAPCAPEM      string   `json:"ldap_ca_pem"`
	LDAPBindDN     string   `json:"ldap_bind_dn"`
	LDAPBaseDN     string   `json:"ldap_base_dn"`
	// LDAPUserFilter — фильтр поиска пользователя; {login} заменяется на
	// введённый логин (с экранированием).
	LDAPUserFilter   string `json:"ldap_user_filter"`
	LDAPAttrFullName string `json:"ldap_attr_full_name"`
	LDAPAttrPosition string `json:"ldap_attr_position"`
	LDAPAttrEmail    string `json:"ldap_attr_email"`
	LDAPTimeoutSec   int    `json:"ldap_timeout_sec"`
	KerberosEnabled  bool   `json:"kerberos_enabled"`
	// KerberosSPN — имя службы в keytab (HTTP/athena.domain1.local). Пусто —
	// подходит любая запись keytab.
	KerberosSPN string `json:"kerberos_spn"`
	// AutoCreateUsers — заводить пользователя при первом успешном входе
	// (без ролей, кроме «исполнитель»). Выключено — входят только те, кого
	// администратор завёл заранее.
	AutoCreateUsers     bool   `json:"auto_create_users"`
	DefaultDepartmentID *int64 `json:"default_department_id"`

	// Секреты наружу не отдаются — только признаки наличия.
	HasBindPassword  bool       `json:"has_bind_password"`
	HasKeytab        bool       `json:"has_keytab"`
	KeytabUploadedAt *time.Time `json:"keytab_uploaded_at"`
	KeytabInfo       string     `json:"keytab_info,omitempty"`

	bindPasswordEnc []byte
	keytabEnc       []byte
}

var realmRe = regexp.MustCompile(`^[A-Z0-9][A-Z0-9.\-]{0,253}$`)
var netbiosRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_\-]{0,14}$`)

// NormalizeRealm приводит имя области к каноническому виду (верхний регистр).
func NormalizeRealm(s string) string { return strings.ToUpper(strings.TrimSpace(s)) }

// CanonicalLogin — логин доменного пользователя в том виде, в каком он
// хранится в users.login: имя в нижнем регистре + «@» + REALM.
func CanonicalLogin(name, realm string) string {
	return strings.ToLower(strings.TrimSpace(name)) + "@" + NormalizeRealm(realm)
}

// Validate проверяет поля перед сохранением.
func (d *Domain) Validate() error {
	d.Realm = NormalizeRealm(d.Realm)
	d.NetBIOS = strings.TrimSpace(d.NetBIOS)
	d.Title = strings.TrimSpace(d.Title)
	if !realmRe.MatchString(d.Realm) {
		return errors.New("имя домена (realm) — латинские буквы, цифры, точка и дефис, например DOMAIN1.LOCAL")
	}
	if d.NetBIOS != "" && !netbiosRe.MatchString(d.NetBIOS) {
		return errors.New("короткое имя домена — до 15 латинских букв/цифр")
	}
	urls := make([]string, 0, len(d.LDAPURLs))
	for _, u := range d.LDAPURLs {
		u = strings.TrimSpace(u)
		if u == "" {
			continue
		}
		low := strings.ToLower(u)
		if !strings.HasPrefix(low, "ldap://") && !strings.HasPrefix(low, "ldaps://") {
			return fmt.Errorf("адрес сервера %q должен начинаться с ldap:// или ldaps://", u)
		}
		urls = append(urls, u)
	}
	d.LDAPURLs = urls
	if d.LDAPEnabled {
		if len(d.LDAPURLs) == 0 {
			return errors.New("для LDAP укажите хотя бы один адрес сервера")
		}
		if strings.TrimSpace(d.LDAPBaseDN) == "" {
			return errors.New("для LDAP укажите базовый DN поиска")
		}
	}
	if strings.TrimSpace(d.LDAPUserFilter) == "" {
		d.LDAPUserFilter = "(&(objectClass=user)(sAMAccountName={login}))"
	}
	if !strings.Contains(d.LDAPUserFilter, "{login}") {
		return errors.New("фильтр пользователя должен содержать {login}")
	}
	if d.LDAPAttrFullName == "" {
		d.LDAPAttrFullName = "displayName"
	}
	if d.LDAPAttrEmail == "" {
		d.LDAPAttrEmail = "mail"
	}
	if d.LDAPAttrPosition == "" {
		d.LDAPAttrPosition = "title"
	}
	if d.LDAPTimeoutSec <= 0 || d.LDAPTimeoutSec > 60 {
		d.LDAPTimeoutSec = 5
	}
	return nil
}

// Store — хранилище доменов с коротким кэшем: вход не должен ходить в БД за
// настройками на каждую попытку, но изменения из веб-интерфейса обязаны
// подхватываться всеми экземплярами приложения за несколько секунд.
type Store struct {
	pool   *pgxpool.Pool
	sealer *Sealer

	mu     sync.Mutex
	cache  []Domain
	cached time.Time
}

const cacheTTL = 5 * time.Second

func NewStore(pool *pgxpool.Pool, sealer *Sealer) *Store {
	return &Store{pool: pool, sealer: sealer}
}

const selectCols = `id, realm, title, coalesce(netbios_name,''), is_active, sort_order,
	ldap_enabled, ldap_urls, ldap_start_tls, ldap_skip_verify, coalesce(ldap_ca_pem,''),
	coalesce(ldap_bind_dn,''), coalesce(ldap_base_dn,''), ldap_user_filter,
	ldap_attr_full_name, ldap_attr_position, ldap_attr_email, ldap_timeout_sec,
	kerberos_enabled, coalesce(kerberos_spn,''), auto_create_users, default_department_id,
	ldap_bind_password_enc, kerberos_keytab_enc, kerberos_keytab_uploaded_at`

func scanDomain(row pgx.Row) (Domain, error) {
	var d Domain
	err := row.Scan(&d.ID, &d.Realm, &d.Title, &d.NetBIOS, &d.IsActive, &d.SortOrder,
		&d.LDAPEnabled, &d.LDAPURLs, &d.LDAPStartTLS, &d.LDAPSkipVerify, &d.LDAPCAPEM,
		&d.LDAPBindDN, &d.LDAPBaseDN, &d.LDAPUserFilter,
		&d.LDAPAttrFullName, &d.LDAPAttrPosition, &d.LDAPAttrEmail, &d.LDAPTimeoutSec,
		&d.KerberosEnabled, &d.KerberosSPN, &d.AutoCreateUsers, &d.DefaultDepartmentID,
		&d.bindPasswordEnc, &d.keytabEnc, &d.KeytabUploadedAt)
	d.HasBindPassword = len(d.bindPasswordEnc) > 0
	d.HasKeytab = len(d.keytabEnc) > 0
	if d.LDAPURLs == nil {
		d.LDAPURLs = []string{}
	}
	return d, err
}

// All возвращает все домены (из кэша, если он свежий).
func (s *Store) All(ctx context.Context) ([]Domain, error) {
	s.mu.Lock()
	if s.cache != nil && time.Since(s.cached) < cacheTTL {
		out := s.cache
		s.mu.Unlock()
		return out, nil
	}
	s.mu.Unlock()
	rows, err := s.pool.Query(ctx, `SELECT `+selectCols+` FROM auth_domains ORDER BY sort_order, realm`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []Domain{}
	for rows.Next() {
		d, err := scanDomain(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	s.mu.Lock()
	s.cache, s.cached = out, time.Now()
	s.mu.Unlock()
	return out, nil
}

// Invalidate сбрасывает кэш (после изменения из веб-интерфейса).
func (s *Store) Invalidate() {
	s.mu.Lock()
	s.cache = nil
	s.mu.Unlock()
}

// Get — домен по идентификатору (мимо кэша).
func (s *Store) Get(ctx context.Context, id int64) (Domain, error) {
	return scanDomain(s.pool.QueryRow(ctx, `SELECT `+selectCols+` FROM auth_domains WHERE id = $1`, id))
}

// Resolve находит АКТИВНЫЙ домен по имени области или короткому имени
// (без учёта регистра).
func (s *Store) Resolve(ctx context.Context, name string) (Domain, bool) {
	all, err := s.All(ctx)
	if err != nil {
		return Domain{}, false
	}
	name = strings.TrimSpace(name)
	for _, d := range all {
		if !d.IsActive {
			continue
		}
		if strings.EqualFold(d.Realm, name) || (d.NetBIOS != "" && strings.EqualFold(d.NetBIOS, name)) {
			return d, true
		}
	}
	return Domain{}, false
}

// BindPassword — расшифрованный пароль служебной учётной записи LDAP.
func (s *Store) BindPassword(d Domain) (string, error) {
	if len(d.bindPasswordEnc) == 0 {
		return "", nil
	}
	b, err := s.sealer.Open(d.bindPasswordEnc)
	return string(b), err
}

// KeytabBytes — расшифрованный keytab домена.
func (s *Store) KeytabBytes(d Domain) ([]byte, error) {
	if len(d.keytabEnc) == 0 {
		return nil, errors.New("keytab не загружен")
	}
	return s.sealer.Open(d.keytabEnc)
}

// Seal шифрует секрет для записи в БД.
func (s *Store) Seal(plain []byte) ([]byte, error) { return s.sealer.Seal(plain) }

// SplitLogin разбирает введённый логин: «ivanov@DOMAIN1.LOCAL»,
// «DOMAIN1\ivanov» или просто «ivanov» (локальная учётная запись).
func SplitLogin(input string) (name, domain string) {
	input = strings.TrimSpace(input)
	if i := strings.Index(input, `\`); i > 0 {
		return input[i+1:], input[:i]
	}
	if i := strings.LastIndex(input, "@"); i > 0 {
		return input[:i], input[i+1:]
	}
	return input, ""
}
