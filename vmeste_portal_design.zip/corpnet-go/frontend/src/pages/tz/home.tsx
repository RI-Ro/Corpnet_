import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore } from '../../lib/store';
import { Avatar, Btn, Modal, Textarea, Input } from '../../ui';
import { Link } from '../../lib/router';
import { fmtShort as fmtDate, plural } from '../../lib/util';
import * as I from '../../lib/icons';
import { GfIcon, errMsg } from './common';

const STICKERS = ['🎉', '🎂', '🥳', '🎁', '🌟', '💐', '👏', '🚀'];

function Greet({ p, onClose }: { p: any; onClose: () => void }) {
  const [body, setBody] = useState(p.kind === 'birthday' ? 'С днём рождения! Желаю здоровья, ярких идей и отличного настроения!' : `Поздравляю с ${p.years}-летием работы в компании! Спасибо за вклад в общее дело!`);
  const [st, setSt] = useState(STICKERS[0]);
  const [busy, setBusy] = useState(false);
  async function send() {
    setBusy(true);
    try { await api.post('/api/greetings', { to_id: p.id, kind: p.kind, body, sticker: st }); invalidate('greet'); toast({ title: 'Поздравление отправлено', kind: 'success' }, 2500); onClose(); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <Modal title={`Поздравить: ${p.name}`} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Отмена</button><Btn kind="pri" busy={busy} onClick={send}><I.Send size={16} /> Отправить</Btn></>}>
      <div className="stack">
        <div className="row" style={{ flexWrap: 'wrap', gap: 6 }}>{STICKERS.map((s) => <button key={s} className={'chip' + (st === s ? ' on' : '')} onClick={() => setSt(s)} aria-label={'Стикер ' + s}>{s}</button>)}</div>
        <Textarea rows={4} value={body} maxLength={500} onChange={(e) => setBody(e.target.value)} />
      </div>
    </Modal>
  );
}

function Birthdays() {
  const q = useQuery<any[]>('greet:list', () => api.get('/api/greetings?days=7'), { stale: 60000 });
  const [g, setG] = useState<any>(null);
  const list = q.data || [];
  if (q.data && !list.length) return null;
  return (
    <div className="card tzW">
      <h4><I.Cake size={18} style={{ color: 'var(--danger)' }} /> Поздравляем</h4>
      {list.slice(0, 6).map((p) => (
        <div key={p.id + p.kind} className="it">
          <Avatar name={p.name} src={p.avatar} size={34} />
          <div className="sp"><Link to={`/people/${p.id}`} className="small bold clip">{p.name}</Link>
            <div className="tiny muted clip">{p.kind === 'birthday' ? 'День рождения' : `${plural(p.years, ['год', 'года', 'лет'])} в компании`} · {fmtDate(p.on_date)}</div></div>
          {p.greeted ? <span className="tiny muted"><I.Check size={14} /> Вы поздравили</span> : <button className="btn sm" onClick={() => setG(p)}>Поздравить</button>}
        </div>
      ))}
      {g && <Greet p={g} onClose={() => setG(null)} />}
    </div>
  );
}

function QuickLinks({ links, rail }: { links: any[]; rail?: boolean }) {
  const [add, setAdd] = useState(false);
  const [f, setF] = useState({ title: '', url: '' });
  async function save() {
    try { await api.post('/api/quick-links', f); setF({ title: '', url: '' }); setAdd(false); invalidate('home'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function del(id: number) { await api.del('/api/quick-links/' + id).catch(() => {}); invalidate('home'); }
  return (
    <div className={rail ? 'card railC tzRailW' : 'card tzW'}>
      <h4><I.Link size={18} style={{ color: 'var(--accent)' }} /> Быстрые ссылки <span className="sp" /><button className="btn ghost sm" onClick={() => setAdd(!add)} aria-label="Добавить ссылку"><I.Plus size={15} /></button></h4>
      {links.length === 0 && !add && <div className="small muted">Добавьте ссылки на сервисы, которыми пользуетесь каждый день.</div>}
      {links.map((l) => {
        const ext = /^https?:/.test(l.url);
        return (
          <div key={l.id} className="it">
            {ext ? <a className="sp small bold clip" href={l.url} target="_blank" rel="noopener noreferrer">{l.title}</a> : <Link className="sp small bold clip" to={l.url}>{l.title}</Link>}
            <button className="btn ghost sm" onClick={() => del(l.id)} aria-label={'Удалить ' + l.title}><I.X size={14} /></button>
          </div>
        );
      })}
      {add && <div className="stackS"><Input placeholder="Название" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /><Input placeholder="https://… или /путь" value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} /><Btn kind="pri" size="sm" onClick={save}>Добавить</Btn></div>}
    </div>
  );
}

/** Блок над лентой на главной: «Требует внимания» и адаптация. Прогресс — в шапке, быстрые ссылки и «Спросите директора» — в правой колонке. */
export default function HomeWidgets() {
  const me = useStore((s) => s.me)!;
  const q = useQuery<any>('home', () => api.get('/api/home'), { stale: 30000 });
  const d = q.data;
  if (!d) return null;
  const plan = d.onboarding?.[0];
  const pct = plan && plan.total ? Math.round((plan.done * 100) / plan.total) : 0;
  const attn = d.must_read.length + d.surveys.length + (plan && plan.overdue ? 1 : 0);
  const gf = d.gf;
  const pctLv = gf?.level && gf.next ? Math.min(100, Math.round(((gf.xp - gf.level.xp_from) * 100) / Math.max(1, gf.next.xp_from - gf.level.xp_from))) : 100;
  return (
    <section className="stack" aria-label="Для вас">
      <div className="tzMasonry">
        {(attn > 0 || plan) && (
          <div className={'card tzW' + (attn > 0 ? ' tzAttn' : '')}>
            <h4><I.Alert size={18} style={{ color: 'var(--warn)' }} /> {attn > 0 ? 'Требует внимания' : 'Ваша адаптация'}</h4>
            {d.must_read.map((n: any) => <Link key={n.id} to={`/news/${n.id}`} className="it"><I.FileText size={17} /><span className="sp small clamp2">{n.title}</span>{n.due && <span className={'tiny ' + (n.overdue ? 'dngT' : 'muted')} style={n.overdue ? { color: 'var(--danger)' } : undefined}>до {fmtDate(n.due)}</span>}</Link>)}
            {d.surveys.map((s: any) => <Link key={s.id} to={`/surveys/${s.id}`} className="it"><I.Chart size={17} /><span className="sp small clamp2">Опрос: {s.title}</span></Link>)}
            {plan && <Link to="/onboarding" className="it"><div className="tzRing" style={{ ['--p' as any]: pct, width: 44, height: 44 }}><b style={{ width: 34, height: 34, fontSize: 11 }}>{pct}%</b></div><span className="sp small"><b>Адаптация: день {plan.day}</b><div className="tiny muted">выполнено {plan.done} из {plan.total}{plan.overdue ? `, просрочено ${plan.overdue}` : ''}</div></span></Link>}
          </div>
        )}
      </div>
    </section>
  );
}

const GF_PCT = (gf: any) => (gf?.level && gf.next ? Math.min(100, Math.round(((gf.xp - gf.level.xp_from) * 100) / Math.max(1, gf.next.xp_from - gf.level.xp_from))) : 100);

/** Быстрые ссылки — в правой колонке под днями рождения. */
export function RailQuickLinks() {
  const q = useQuery<any>('home', () => api.get('/api/home'), { stale: 30000 });
  return q.data ? <QuickLinks links={q.data.links} rail /> : null;
}

/** «Спросите директора» — в самом низу правой колонки. */
export function RailAsk() {
  const q = useQuery<any>('home', () => api.get('/api/home'), { stale: 30000 });
  const qa = q.data?.qa?.[0];
  if (!qa) return null;
  return (
    <Link to="/ask" className="card railC" style={{ color: 'inherit' }}>
      <h4><I.Message size={17} style={{ color: 'var(--accent)' }} /> Спросите директора</h4>
      <div className="small bold clamp2" style={{ padding: '0 18px' }}>{qa.question}</div>
      <div className="small muted clamp3" style={{ padding: '4px 18px 0' }}>{qa.answer}</div>
      <div className="small" style={{ color: 'var(--accent)', padding: '8px 18px 14px' }}>Все вопросы и ответы →</div>
    </Link>
  );
}

/** Прогресс геймификации — компактный блок в шапке, рядом с профилем. */
export function HeaderProgress() {
  const q = useQuery<any>('home', () => api.get('/api/home'), { stale: 30000 });
  const gf = q.data?.gf;
  if (!gf) return null;
  const pct = GF_PCT(gf);
  return (
    <Link to="/rewards" className="hdrProg" title={`${gf.level?.title}: ${gf.xp} XP${gf.next ? `, до «${gf.next.title}» ${gf.next.xp_from - gf.xp}` : ''} · ★ ${gf.balance}`}>
      <span className="tzLevel" style={{ ['--lv' as any]: gf.level?.color, width: 30, height: 30, fontSize: 14 }}><GfIcon name={gf.level?.icon} size={16} /></span>
      <span className="hp"><b className="tiny clip">{gf.level?.title}</b><span className="tzBar"><i style={{ width: pct + '%' }} /></span></span>
      <span className="tiny mono hide-m">★ {gf.balance}</span>
    </Link>
  );
}
