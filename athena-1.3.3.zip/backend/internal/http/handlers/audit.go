package handlers

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/search"
	"athena/backend/internal/service"
)

// AuditHandler — просмотр журнала аудита (, п. 9).
//
// Доступ ограничивает RLS (политика audit_select): администратор и роль
// auditor. Проверять права ещё и здесь было бы дублированием, которое со
// временем разойдётся с политикой; выборка под обычным пользователем просто
// вернёт пусто.
//
// Роль auditor отделена от admin намеренно: смысл журнала в том, чтобы
// действия администратора тоже были кому-то видны. Если читать журнал может
// только администратор, журнал контролирует сам себя.
type AuditHandler struct {
	pool  *pgxpool.Pool
	audit *service.AuditService
}

func NewAuditHandler(pool *pgxpool.Pool, audit *service.AuditService) *AuditHandler {
	return &AuditHandler{pool: pool, audit: audit}
}

type auditRow struct {
	ID         int64     `json:"id"`
	OccurredAt time.Time `json:"occurred_at"`
	ActorID    *int64    `json:"actor_id,omitempty"`
	ActorLogin string    `json:"actor_login,omitempty"`
	ActorName  string    `json:"actor_name,omitempty"`
	SessionID  *int64    `json:"session_id,omitempty"`
	Event      string    `json:"event"`
	ObjectKind string    `json:"object_kind,omitempty"`
	ObjectID   *int64    `json:"object_id,omitempty"`
	DocumentID *int64    `json:"document_id,omitempty"`
	Outcome    string    `json:"outcome"`
	HTTPMethod string    `json:"http_method,omitempty"`
	HTTPPath   string    `json:"http_path,omitempty"`
	HTTPStatus *int      `json:"http_status,omitempty"`
	IP         string    `json:"ip,omitempty"`
	// Адрес подключения и цепочка прокси — рядом с фактическим адресом.
	// По одному фактическому разобраться нельзя: он берётся из заголовка,
	// который подставляет прокси, а адрес подключения подделать нельзя.
	IPPeer    string         `json:"ip_peer,omitempty"`
	IPChain   string         `json:"ip_chain,omitempty"`
	UserAgent string         `json:"user_agent,omitempty"`
	Details   map[string]any `json:"details,omitempty"`
}

// auditFilter строит условие выборки.
//
// Все фильтры опциональны. Сортировка всегда по времени вниз: журнал читают
// «что было только что», а не с начала времён.
func auditFilter(c *fiber.Ctx) (string, []any) {
	var where []string
	var args []any
	add := func(cond string, v any) {
		args = append(args, v)
		where = append(where, strings.ReplaceAll(cond, "$?", "$"+strconv.Itoa(len(args))))
	}

	if v := strings.TrimSpace(c.Query("from")); v != "" {
		add("a.occurred_at >= $?::timestamptz", v)
	}
	if v := strings.TrimSpace(c.Query("to")); v != "" {
		// Включительно по дате: «по 10.10» должно захватывать весь день,
		// иначе события последнего дня в отчёт не попадут.
		add("a.occurred_at < ($?::date + 1)::timestamptz", v)
	}
	if v, err := strconv.ParseInt(c.Query("actor_id"), 10, 64); err == nil && v > 0 {
		add("a.actor_id = $?", v)
	}
	if v, err := strconv.ParseInt(c.Query("document_id"), 10, 64); err == nil && v > 0 {
		add("a.document_id = $?", v)
	}
	if v := strings.TrimSpace(c.Query("event")); v != "" {
		// Префиксом: «auth» находит auth.login, auth.logout, auth.login_failed.
		add("a.event LIKE $? || '%'", v)
	}
	if v := strings.TrimSpace(c.Query("outcome")); v != "" && v != "all" {
		add("a.outcome = $?", v)
	}
	if v := strings.TrimSpace(c.Query("q")); v != "" {
		// Свободный поиск по логину, пути и IP. Свёртка регистра — той же
		// функцией, что и везде в системе (в локали C ILIKE для кириллицы не
		// работает, см. миграцию 0015).
		add(`(fold_ru(coalesce(a.actor_login,'')) LIKE '%' || fold_ru($?) || '%'
		      OR coalesce(a.http_path,'') LIKE '%' || $? || '%'
		      OR coalesce(host(a.ip),'') LIKE '%' || $? || '%')`, search.FoldRU(v))
		// Три вхождения $? в одном условии: подставляем один и тот же номер
		// параметра, поэтому add вызван один раз, а дальше правим вручную.
		n := strconv.Itoa(len(args))
		where[len(where)-1] = strings.ReplaceAll(where[len(where)-1], "$?", "$"+n)
	}

	if len(where) == 0 {
		return "", nil
	}
	return " WHERE " + strings.Join(where, " AND "), args
}

// List GET /api/audit — страница журнала.
func (h *AuditHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize, _ := strconv.Atoi(c.Query("page_size", "50"))
	if pageSize < 1 || pageSize > 500 {
		pageSize = 50
	}
	whereSQL, args := auditFilter(c)

	var total int64
	items := []auditRow{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM audit_log a`+whereSQL, args...).Scan(&total); err != nil {
			return err
		}
		q := `SELECT a.id, a.occurred_at, a.actor_id, coalesce(a.actor_login,''),
		             coalesce(u.full_name,''), a.session_id, a.event,
		             coalesce(a.object_kind,''), a.object_id, a.document_id, a.outcome,
		             coalesce(a.http_method,''), coalesce(a.http_path,''), a.http_status,
		             coalesce(host(a.ip),''), coalesce(host(a.ip_peer),''),
		             coalesce(a.ip_chain,''), coalesce(a.user_agent,''), a.details
		        FROM audit_log a
		        LEFT JOIN users u ON u.id = a.actor_id` + whereSQL + `
		       ORDER BY a.occurred_at DESC, a.id DESC
		       LIMIT $` + strconv.Itoa(len(args)+1) + ` OFFSET $` + strconv.Itoa(len(args)+2)
		rows, err := tx.Query(c.Context(), q, append(args, pageSize, (page-1)*pageSize)...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r auditRow
			if err := rows.Scan(&r.ID, &r.OccurredAt, &r.ActorID, &r.ActorLogin, &r.ActorName,
				&r.SessionID, &r.Event, &r.ObjectKind, &r.ObjectID, &r.DocumentID, &r.Outcome,
				&r.HTTPMethod, &r.HTTPPath, &r.HTTPStatus, &r.IP, &r.IPPeer, &r.IPChain,
				&r.UserAgent, &r.Details); err != nil {
				return err
			}
			items = append(items, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить журнал аудита")
	}
	return c.JSON(fiber.Map{
		"items": items, "page": page, "page_size": pageSize, "total_count": total,
	})
}

// Events GET /api/audit/events — список встречающихся имён событий.
// Нужен фильтру в интерфейсе: перечень событий зависит от версии системы, и
// зашивать его в фронтенд пришлось бы править при каждом новом событии.
func (h *AuditHandler) Events(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	out := []fiber.Map{}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT event, count(*) FROM audit_log
			 WHERE occurred_at > now() - interval '90 days'
			 GROUP BY event ORDER BY 2 DESC LIMIT 200`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var e string
			var n int64
			if err := rows.Scan(&e, &n); err != nil {
				return err
			}
			out = append(out, fiber.Map{"event": e, "count": n})
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить перечень событий")
	}
	return c.JSON(fiber.Map{"items": out})
}

// Export GET /api/audit/export — выгрузка отфильтрованного журнала в CSV.
//
// Зачем выгрузка: журнал нужен не только для просмотра, но и для передачи
// проверяющему и для хранения вне системы (от администратора СУБД журнал
// внутри самой СУБД защитить нельзя — см. комментарий в service/audit.go).
//
// CSV, а не XLSX: выгрузка может содержать сотни тысяч строк, и поток в CSV
// пишется без удержания всего объёма в памяти. Разделитель — точка с запятой,
// кодировка — UTF-8 с BOM: иначе русский текст в Excel рассыпается.
//
// Сам факт выгрузки журнала пишется В ЖУРНАЛ. Это обязательно: выгрузка
// сведений о действиях всех сотрудников — событие, о котором должно остаться
// свидетельство.
func (h *AuditHandler) Export(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	sid, _ := c.Locals(middleware.CtxSessionID).(int64)
	whereSQL, args := auditFilter(c)

	const maxExport = 200000
	var b strings.Builder
	b.WriteString(bomUTF8)
	b.WriteString("Время;Пользователь;Логин;Событие;Результат;Метод;Путь;Код;Документ;IP (фактический);IP подключения;Цепочка прокси;Подробности\n")

	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT a.occurred_at, coalesce(u.full_name,''), coalesce(a.actor_login,''),
			       a.event, a.outcome, coalesce(a.http_method,''), coalesce(a.http_path,''),
			       coalesce(a.http_status,0), coalesce(a.document_id,0),
			       coalesce(host(a.ip),''), coalesce(host(a.ip_peer),''),
			       coalesce(a.ip_chain,''), coalesce(a.details::text,'')
			  FROM audit_log a LEFT JOIN users u ON u.id = a.actor_id`+whereSQL+`
			 ORDER BY a.occurred_at DESC, a.id DESC LIMIT `+strconv.Itoa(maxExport), args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var t time.Time
			var name, lg, ev, oc, m, p, ip, ipPeer, ipChain, det string
			var st, doc int64
			if err := rows.Scan(&t, &name, &lg, &ev, &oc, &m, &p, &st, &doc,
				&ip, &ipPeer, &ipChain, &det); err != nil {
				return err
			}
			b.WriteString(strings.Join([]string{
				t.Local().Format("02.01.2006 15:04:05"),
				csvCell(name), csvCell(lg), csvCell(ev), csvCell(oc), csvCell(m), csvCell(p),
				strconv.FormatInt(st, 10), docCell(doc),
				csvCell(ip), csvCell(ipPeer), csvCell(ipChain), csvCell(det),
			}, ";"))
			b.WriteByte('\n')
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выгрузить журнал аудита")
	}

	h.audit.Write(service.AuditEvent{
		ActorID: userID, ActorLogin: login, SessionID: sid,
		Event: "audit.export", Outcome: "ok",
		HTTPMethod: c.Method(), HTTPPath: c.Path(), HTTPStatus: fiber.StatusOK,
		IP: middleware.ClientIP(c), UserAgent: c.Get("User-Agent"),
		Details: map[string]any{"filter": string(c.Request().URI().QueryString())},
	})

	c.Set("Content-Type", "text/csv; charset=utf-8")
	c.Set("Content-Disposition", `attachment; filename="audit_`+
		time.Now().Format("2006-01-02_1504")+`.csv"`)
	return c.SendString(b.String())
}

// bomUTF8 — метка порядка байтов. Excel без неё открывает UTF-8 CSV как
// однобайтовую кодировку, и русский текст превращается в мусор.
const bomUTF8 = "\ufeff"

// csvCell экранирует значение для CSV с разделителем «;».
// Кавычки удваиваются, значение берётся в кавычки, если содержит разделитель,
// кавычку или перевод строки. Без этого одна многострочная подробность
// сдвинула бы весь дальнейший файл.
func csvCell(s string) string {
	if !strings.ContainsAny(s, ";\"\n\r") {
		return s
	}
	return `"` + strings.ReplaceAll(s, `"`, `""`) + `"`
}

func docCell(id int64) string {
	if id == 0 {
		return ""
	}
	return strconv.FormatInt(id, 10)
}

// ---------------------------------------------------------------------------
// п. 13 — РАЗМЕР ЖУРНАЛА И УДАЛЕНИЕ ЗА ПЕРИОД
// ---------------------------------------------------------------------------

// Size GET /api/audit/size — размер журнала в МБ и его границы по времени.
//
// Зачем отдельный запрос, а не поле в списке: размер считается по таблице
// целиком (pg_total_relation_size), и тащить его вместе с каждой страницей
// журнала — лишняя работа на запрос, который делается постранично. Нужен он
// ровно в одном месте — рядом с кнопкой очистки.
func (h *AuditHandler) Size(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	if !isAdmin {
		return fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}

	var bytes, rows int64
	var oldest, newest *string
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(), `
			SELECT audit_log_bytes(),
			       (SELECT count(*) FROM audit_log),
			       (SELECT to_char(min(occurred_at), 'YYYY-MM-DD') FROM audit_log),
			       (SELECT to_char(max(occurred_at), 'YYYY-MM-DD') FROM audit_log)`).
			Scan(&bytes, &rows, &oldest, &newest)
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось определить размер журнала")
	}
	return c.JSON(fiber.Map{
		"bytes": bytes,
		// Мегабайты считаются на сервере и округляются до десятых: две
		// независимых формулы перевода (здесь и в интерфейсе) однажды
		// разошлись бы, и администратор видел бы разные числа в разных местах.
		"megabytes": float64(bytes) / (1024 * 1024),
		"rows":      rows,
		"oldest":    oldest,
		"newest":    newest,
	})
}

// Purge DELETE /api/audit?from=YYYY-MM-DD&to=YYYY-MM-DD — удаление журнала за
// период.
//
// ЧЕСТНО О ТОМ, ЧТО ЗДЕСЬ ПРОИСХОДИТ. В версии 51 журнал аудита сделан
// неотключаемым и НЕИЗМЕНЯЕМЫМ: у роли приложения отозваны UPDATE/DELETE/
// TRUNCATE, политик на изменение и удаление нет. Этот пункт требует
// противоположного, и полностью совместить требования невозможно — гарантия
// неизменяемости ослабляется. Ослабление сделано настолько узким, насколько
// это возможно:
//
//   - удаляет не обработчик, а функция БД audit_purge (миграция 0024), и
//     только по диапазону дат. Произвольного DELETE у приложения по-прежнему
//     нет — отзыв прав остаётся в силе;
//   - функция сама, ПЕРЕД удалением, пишет в журнал запись о том, кто и за
//     какой период чистит и сколько строк затронуто. Запись ставится текущим
//     временем, то есть заведомо вне удаляемого периода, и переживает
//     очистку;
//   - удалить «сегодняшнее» нельзя: верхняя граница обязана быть в прошлом.
//     Иначе очистка стёрла бы и запись о себе;
//   - доступно только администратору, и сам запрос попадает в журнал ещё и
//     через общий механизм (middleware.Audit пишет все изменяющие запросы).
//
// Чего администратор по-прежнему НЕ может: удалить отдельные записи, изменить
// запись, стереть журнал без следа и удалить свидетельство о своём удалении.
func (h *AuditHandler) Purge(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	login, _ := c.Locals(middleware.CtxLogin).(string)
	if !isAdmin {
		return fiber.NewError(fiber.StatusForbidden, "удаление журнала аудита доступно только администратору")
	}

	from := strings.TrimSpace(c.Query("from"))
	to := strings.TrimSpace(c.Query("to"))
	if from == "" || to == "" {
		return fiber.NewError(fiber.StatusBadRequest,
			"укажите период удаления: from и to в формате ГГГГ-ММ-ДД")
	}
	// Формат проверяется здесь, чтобы человек получил понятный ответ, а не
	// ошибку приведения типа из базы.
	for _, v := range []string{from, to} {
		if _, err := time.Parse("2006-01-02", v); err != nil {
			return fiber.NewError(fiber.StatusBadRequest,
				"даты периода указываются в формате ГГГГ-ММ-ДД")
		}
	}

	var deleted int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return tx.QueryRow(c.Context(),
			`SELECT audit_purge($1::date, $2::date, $3, $4)`,
			from, to, userID, login).Scan(&deleted)
	})
	if txErr != nil {
		// Проверки периода живут в самой функции БД (чтобы их нельзя было
		// обойти другим вызывающим кодом), и её сообщения уже написаны
		// по-русски и по делу. Передаём их человеку как есть.
		msg := txErr.Error()
		switch {
		case strings.Contains(msg, "завершившиеся дни"):
			return fiber.NewError(fiber.StatusUnprocessableEntity,
				"удалять можно только завершившиеся дни: конец периода должен быть раньше сегодняшнего. "+
					"Это сделано для того, чтобы очистка не удалила запись о самой себе")
		case strings.Contains(msg, "позже его конца"):
			return fiber.NewError(fiber.StatusUnprocessableEntity, "начало периода позже его конца")
		case strings.Contains(msg, "обе границы"):
			return fiber.NewError(fiber.StatusBadRequest, "нужно указать обе границы периода")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось удалить записи журнала")
	}
	return c.JSON(fiber.Map{
		"deleted": deleted,
		"message": fmt.Sprintf("Удалено записей: %d. Запись о самой очистке оставлена в журнале.", deleted),
	})
}
