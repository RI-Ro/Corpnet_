import { THEMES } from '../lib/themes';
import { DESIGNS, designById, setDesign, pickTheme, setAppearance, resetAppearance, useAppearance, clampScale } from '../lib/appearance';
import { FONT_LIST } from '../lib/fontlist';
import { useStore } from '../lib/store';
import { ThemeDot } from './ThemePicker';
import { cx } from '../lib/util';
import { BackgroundSettings, MenuSettings, SoundSettings } from './AppearanceExtra';

const Slider = ({ label, k, value }: { label: string; k: 'ui' | 'fs'; value: number }) => (
    <div className="apRow">
      <label htmlFor={'ap-' + k}>{label}</label>
      <input id={'ap-' + k} type="range" min={50} max={150} step={5} value={value} onChange={(e) => setAppearance({ [k]: clampScale(e.target.value) })} />
      <b className="small">{value}%</b>
    </div>
  );

/** Раздел «Внешний вид» на странице настроек: дизайн → палитра, масштабы, шрифт, меню. Всё применяется сразу и сохраняется на сервере. */
export function AppearancePanel() {
  const a = useAppearance();
  const theme = useStore((s) => s.theme);
  const uiDefaults = useStore((s) => s.uiDefaults);
  const d = designById(a.design);
  const themes = [...new Set([...d.themes])].map((id) => THEMES.find((t) => t.id === id)!).filter(Boolean);
  const f = FONT_LIST.find((x) => x.id === a.font);
  return (
    <div className="card pad stack" id="appearance">
      <div className="row"><h3 className="sp">Внешний вид</h3><button className="btn ghost sm" onClick={() => resetAppearance(uiDefaults)} title="Вернуть оформление, заданное администратором">Сбросить</button></div>
      <div className="small muted">Изменения применяются сразу и запоминаются в вашей учётной записи — на любом компьютере портал выглядит так, как вам удобно.</div>

      <details className="designChoice"><summary>Стиль интерфейса <strong>{d.label}</strong></summary>
        <div className="apGrid" role="radiogroup" aria-label="Дизайн">
          {DESIGNS.map((x) => (
            <button key={x.id} role="radio" aria-checked={a.design === x.id} className={cx('apDesign', a.design === x.id && 'on')} onClick={() => setDesign(x.id)}>
              <span className="apPrev" data-d={x.id}><i /><i /><i /></span><b>{x.label}</b><span className="h">{x.hint}</span>
            </button>
          ))}
        </div>
      </details>

      <div><div className="small bold" style={{ marginBottom: 8 }}>Цветовая палитра</div>
        <div className="chips">
          {themes.map((t) => <button key={t.id} className={cx('chip', theme === t.id && 'on')} onClick={() => pickTheme(t.id)} aria-pressed={theme === t.id}><ThemeDot swatch={t.swatch} /> {t.label}</button>)}
          <button className={cx('chip', theme === 'system' && 'on')} onClick={() => pickTheme('system')} aria-pressed={theme === 'system'}><ThemeDot system /> Как в системе</button>
        </div>
      </div>

      <div className="stack" style={{ gap: 10 }}>
        <Slider label="Масштаб элементов" k="ui" value={a.ui} />
        <Slider label="Размер шрифта" k="fs" value={a.fs} />
      </div>

      <div className="stack" style={{ gap: 10 }}>
        <div className="apRow" style={{ gridTemplateColumns: '170px minmax(0,1fr)' }}>
          <label htmlFor="ap-font">Шрифт</label>
          <select id="ap-font" className="sel" value={a.font} onChange={(e) => setAppearance({ font: e.target.value })}>
            <option value="">Как в дизайне (по умолчанию)</option>
            {(['sans', 'serif', 'mono', 'display'] as const).map((k) => (
              <optgroup key={k} label={{ sans: 'Без засечек', serif: 'С засечками', mono: 'Моноширинные', display: 'Декоративные' }[k]}>
                {FONT_LIST.filter((x) => x.kind === k).map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}
              </optgroup>
            ))}
          </select>
        </div>
        <div className="row" style={{ flexWrap: 'wrap', gap: 16 }}>
          <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={a.bold} onChange={(e) => setAppearance({ bold: e.target.checked })} /> Жирный</label>
          <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={a.italic} onChange={(e) => setAppearance({ italic: e.target.checked })} /> Курсив</label>
        </div>
        <div className="apFontSample" style={f ? { fontFamily: `"${f.family}", serif` } : undefined}>Съешь ещё этих мягких французских булок, да выпей чаю — 0123456789</div>
      </div>

      <BackgroundSettings />

      <div className="row" style={{ flexWrap: 'wrap', gap: 16 }}>
        <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={a.sideOff} onChange={(e) => setAppearance({ sideOff: e.target.checked })} /> Свернуть меню (кнопка-«гамбургер» в шапке вернёт его)</label>
        <button className="btn ghost sm" disabled={!a.sideW} onClick={() => setAppearance({ sideW: 0 })}>Ширина меню: {a.sideW ? a.sideW + ' px' : 'авто'} — сбросить</button>
        <span className="tiny muted">Ширину меню можно менять перетаскиванием его правой границы.</span>
      </div>

      <MenuSettings />
      <SoundSettings />
    </div>
  );
}
