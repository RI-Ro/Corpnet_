package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

type IncomingService struct {
	numbering *NumberingService
}

func NewIncomingService(numbering *NumberingService) *IncomingService {
	return &IncomingService{numbering: numbering}
}

// IncomingMarking — то, что накладывается overlay-слоем поверх вьювера при
// отображении полученного документа (см. фронтенд DocumentViewer): номер
// входящего экземпляра и его метка.
type IncomingMarking struct {
	IncomingNumber string `json:"incoming_number"`
	InstanceLabel  string `json:"instance_label"`
}

// RegisterView вызывается при каждом открытии карточки документа (см.
// handlers.DocumentsHandler.Get). Идемпотентно: если для подразделения
// пользователя уже зарегистрирован входящий экземпляр — просто фиксирует
// first_viewed_at (если ещё не была зафиксирована) и возвращает существующую
// маркировку; если нет — атомарно выдаёт номер через NumberingService и
// создаёт запись. Возвращает nil, если этот пользователь не является
// получателем документа (нет смысла регистрировать вход для автора/
// согласующего — только для реального получателя-адресата).
func (s *IncomingService) RegisterView(ctx context.Context, tx pgx.Tx, documentID, userID int64) (*IncomingMarking, error) {
	// Сериализует регистрацию, выдачу номеров и одновременное удаление адресата.
	var lockedID int64
	if err := tx.QueryRow(ctx, `SELECT id FROM documents WHERE id=$1 FOR UPDATE`, documentID).Scan(&lockedID); err != nil {
		return nil, err
	}
	var receivingDepartmentID int64
	err := tx.QueryRow(ctx, `
		SELECT r.recipient_department_id FROM document_recipients r
		WHERE r.document_id = $1 AND NOT r.is_planned
		  AND app_handles_recipient(r.recipient_user_id,r.recipient_department_id,$2)
		ORDER BY EXISTS (SELECT 1 FROM document_incoming_instances i WHERE i.document_id=r.document_id AND i.receiving_department_id=r.recipient_department_id),
		         r.recipient_department_id LIMIT 1`, documentID, userID).Scan(&receivingDepartmentID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, nil // пользователь не адресат этого документа — не регистрируем
		}
		return nil, fmt.Errorf("lookup recipient: %w", err)
	}

	var existingID int64
	var existingNumber, existingLabel string
	err = tx.QueryRow(ctx, `
		SELECT id, incoming_number, coalesce(instance_label, '')
		FROM document_incoming_instances
		WHERE document_id = $1 AND receiving_department_id = $2`, documentID, receivingDepartmentID).
		Scan(&existingID, &existingNumber, &existingLabel)
	if err == nil {
		// Уже зарегистрирован ранее (кем-то из подразделения) — фиксируем
		// first_viewed_at только если это первый просмотр вообще (COALESCE
		// не перезаписывает уже установленное значение).
		_, err = tx.Exec(ctx, `
			UPDATE document_incoming_instances
			SET first_viewed_at = COALESCE(first_viewed_at, now())
			WHERE id = $1`, existingID)
		if err != nil {
			return nil, fmt.Errorf("update first_viewed_at: %w", err)
		}
		return &IncomingMarking{IncomingNumber: existingNumber, InstanceLabel: existingLabel}, nil
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return nil, fmt.Errorf("lookup existing instance: %w", err)
	}

	// Номер экземпляра берётся из ЕДИНОГО реестра — document_copies.
	//
	// ЧТО БЫЛО НЕ ТАК. Здесь номер считался отдельно:
	//     SELECT count(*) + 2 FROM document_incoming_instances WHERE document_id = $1
	// то есть по числу подразделений-получателей, уже зарегистрировавших
	// входящий. А настоящий учёт экземпляров ведётся в document_copies — там
	// строка на КАЖДОГО, кто получил экземпляр, с номером по документу
	// (UNIQUE document_id, copy_number). Это два независимых счёта, и они
	// расходились: если документ до этого открыли трое, реальный следующий
	// экземпляр — четвёртый, а первое подразделение-получатель получало
	// метку «Экз. № 2». Отсюда и жалоба «всегда пишет экз. 2, хотя он может
	// быть 3, 4 и так далее».
	//
	// Теперь номер один и тот же в обоих местах: и в метке на документе, и в
	// реестре экземпляров карточки.
	instanceOrdinal, err := EnsureCopyNumber(ctx, tx, documentID, userID, "incoming")
	if err != nil {
		return nil, err
	}

	incomingNumber, err := s.numbering.NextIncoming(ctx, tx, receivingDepartmentID)
	if err != nil {
		return nil, fmt.Errorf("assign incoming number: %w", err)
	}
	instanceLabel := fmt.Sprintf("Экз. № %d", instanceOrdinal)

	// Идемпотентная вставка: при первом открытии документа возможны ДВА
	// почти одновременных запроса (React StrictMode вызывает эффекты дважды;
	// возможен и быстрый повтор). Оба проходят проверку "экземпляра нет",
	// оба доходят сюда — без ON CONFLICT второй INSERT падает на UNIQUE
	// (document_id, receiving_department_id) и роняет весь запрос Get
	// ("failed to get document"), из-за чего документ не открывался с первого
	// раза. ON CONFLICT DO NOTHING + повторное чтение делает регистрацию
	// безопасной к гонке: победитель пишет экземпляр и историю, проигравший
	// просто читает уже созданный номер.
	var insertedID int64
	err = tx.QueryRow(ctx, `
		INSERT INTO document_incoming_instances
			(document_id, receiving_department_id, received_by, incoming_number, instance_label, first_viewed_at)
		VALUES ($1, $2, $3, $4, $5, now())
		ON CONFLICT (document_id, receiving_department_id) DO NOTHING
		RETURNING id`,
		documentID, receivingDepartmentID, userID, incomingNumber, instanceLabel).Scan(&insertedID)
	if errors.Is(err, pgx.ErrNoRows) {
		// Конфликт: экземпляр уже создан параллельным запросом — читаем его.
		var num, label string
		if e := tx.QueryRow(ctx, `
			SELECT incoming_number, coalesce(instance_label,'')
			FROM document_incoming_instances
			WHERE document_id = $1 AND receiving_department_id = $2`,
			documentID, receivingDepartmentID).Scan(&num, &label); e != nil {
			return nil, fmt.Errorf("read conflicting instance: %w", e)
		}
		return &IncomingMarking{IncomingNumber: num, InstanceLabel: label}, nil
	}
	if err != nil {
		return nil, fmt.Errorf("insert incoming instance: %w", err)
	}

	// История: входящий номер присваивается ОДИН раз на подразделение-получатель
	// (даже если адресатов из него несколько) — фиксируем это событие.
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		SELECT $1, $2, 'incoming_registered',
		       'вх. № ' || $3 || ' (' || COALESCE((SELECT name FROM departments WHERE id = $4), '') || ')'`,
		documentID, userID, incomingNumber, receivingDepartmentID)
	if err != nil {
		return nil, fmt.Errorf("insert incoming history: %w", err)
	}

	return &IncomingMarking{IncomingNumber: incomingNumber, InstanceLabel: instanceLabel}, nil
}

// EnsureCopyNumber выдаёт пользователю номер экземпляра документа и
// возвращает его. Идемпотентна: у одного человека по одному документу всегда
// один и тот же номер (UNIQUE document_id, user_id).
//
// ЕДИНСТВЕННОЕ место, где номера экземпляров выдаются. Раньше их выдавали
// два: обработчик открытия карточки писал строку в document_copies, а
// регистрация входящего отдельно считала свой порядковый номер по числу
// подразделений. Номера расходились. Один счёт расходиться не может.
//
// Экз. № 1 закреплён за ИСХОДЯЩИМ — оригиналом у автора. Автор обычно
// открывает документ первым и получает 1 естественным образом, но
// полагаться на это нельзя: документ может быть создан одним человеком и
// отправлен без открытия. Поэтому если реестр пуст, а номер просит не автор,
// строка автора заводится первой — и единица остаётся за оригиналом.
func EnsureCopyNumber(ctx context.Context, tx pgx.Tx, documentID, userID int64, reason string) (int, error) {
	if reason == "" {
		reason = "view"
	}

	// Единица — автору, если реестр пуст и просит не он.
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_copies (document_id, user_id, copy_number, reason)
		SELECT d.id, d.author_id, 1, 'original'
		  FROM documents d
		 WHERE d.id = $1
		   AND d.author_id <> $2
		   AND NOT EXISTS (SELECT 1 FROM document_copies WHERE document_id = $1)
		ON CONFLICT DO NOTHING`, documentID, userID); err != nil {
		return 0, fmt.Errorf("выдача экземпляра автору: %w", err)
	}

	if _, err := tx.Exec(ctx, `
		INSERT INTO document_copies (document_id, user_id, copy_number, reason)
		SELECT $1, $2, COALESCE(MAX(copy_number),0)+1, $3
		  FROM document_copies WHERE document_id = $1
		ON CONFLICT (document_id, user_id) DO NOTHING`, documentID, userID, reason); err != nil {
		return 0, fmt.Errorf("выдача номера экземпляра: %w", err)
	}

	var n int
	if err := tx.QueryRow(ctx, `
		SELECT copy_number FROM document_copies
		 WHERE document_id = $1 AND user_id = $2`, documentID, userID).Scan(&n); err != nil {
		return 0, fmt.Errorf("чтение номера экземпляра: %w", err)
	}
	return n, nil
}
