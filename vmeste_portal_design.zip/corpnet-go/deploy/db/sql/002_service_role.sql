-- Пользовательский SQL работает под corpnet_app. Отсутствие uid в этой роли
-- не должно превращать такой запрос в служебный.
CREATE OR REPLACE FUNCTION app_service() RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT current_user <> 'corpnet_app' AND app_uid() IS NULL
$$;

REVOKE ALL ON schema_migrations FROM corpnet_app;
