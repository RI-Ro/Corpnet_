package server

import (
	"context"
	"strconv"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
)

// История версий новостей, комментарии к редакциям, автосохранение, филиалы и аналитика чтения (миграция 017).

const maxVersionsPerNews = 200

// snapshotNews сохраняет текущее состояние новости как новую версию. Для автосохранения предыдущее автосохранение
// этого автора заменяется, а не копится.
func snapshotNews(ctx context.Context, tx pgx.Tx, newsID, authorID int64, note string, autosave bool) error {
	if autosave {
		if _, err := tx.Exec(ctx, `DELETE FROM news_revisions WHERE news_id = $1 AND autosave AND author_id = $2`, newsID, authorID); err != nil {
			return err
		}
	}
	note = strings.TrimSpace(note)
	if r := []rune(note); len(r) > 500 {
		note = string(r[:500])
	}
	_, err := tx.Exec(ctx, `INSERT INTO news_revisions (news_id, version, title, summary, body, cover, category_id, department_id,
			status, published_at, change_note, autosave, author_id)
		SELECT n.id, coalesce((SELECT max(version) FROM news_revisions WHERE news_id = n.id), 0) + 1, n.title, n.summary, n.body, n.cover,
			n.category_id, n.department_id, n.status, n.published_at, $2, $3, $4
		FROM news n WHERE n.id = $1`, newsID, note, autosave, authorID)
	if err != nil {
		return err
	}
	// ограничиваем историю: самые старые версии вытесняются
	_, err = tx.Exec(ctx, `DELETE FROM news_revisions WHERE news_id = $1 AND id IN (
		SELECT id FROM news_revisions WHERE news_id = $1 ORDER BY version DESC OFFSET $2)`, newsID, maxVersionsPerNews)
	return err
}

// newsManageGuard проверяет, что пользователь вправе править новость.
func (s *Server) newsManageGuard(c *Ctx, id int64) error {
	ctx := c.Context()
	var dept, author *int64
	if err := s.db.QueryRow(ctx, `SELECT department_id, author_id FROM news WHERE id = $1`, id).Scan(&dept, &author); err != nil {
		return err
	}
	sc, err := s.scopeOf(ctx, c.U)
	if err != nil {
		return err
	}
	if !sc.canManageNews(c.U, dept, author) {
		return errForbidden
	}
	return nil
}

func (s *Server) listNewsVersions(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.newsManageGuard(c, id); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT v.id, v.version, v.title, v.status, v.change_note, v.autosave, v.created_at, v.author_id,
			u.full_name AS author, (SELECT count(*) FROM news_revision_comments k WHERE k.version_id = v.id)::int AS comments
		FROM news_revisions v LEFT JOIN users u ON u.id = v.author_id WHERE v.news_id = $1 ORDER BY v.version DESC LIMIT 100`, id)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": rawJSON(b)})
}

func (s *Server) getNewsVersion(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	vid, err := c.ID("vid")
	if err != nil {
		return err
	}
	if err := s.newsManageGuard(c, id); err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT v.id, v.version, v.title, v.summary, v.body, v.cover, v.category_id, v.department_id,
			v.status, v.published_at, v.change_note, v.autosave, v.created_at, u.full_name AS author
		FROM news_revisions v LEFT JOIN users u ON u.id = v.author_id WHERE v.id = $1 AND v.news_id = $2`, vid, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

type autosaveIn struct {
	Title      string `json:"title"`
	Summary    string `json:"summary"`
	Body       string `json:"body"`
	Cover      string `json:"cover"`
	CategoryID *int   `json:"category_id"`
}

// autosaveNews — «сохранить черновик»: кладёт слепок в историю версий, не меняя опубликованную новость.
func (s *Server) autosaveNews(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in autosaveIn
	if err := c.Decode(&in); err != nil {
		return err
	}
	if err := s.newsManageGuard(c, id); err != nil {
		return err
	}
	if !s.rateOK(c.Context(), "autosave:"+i64s(c.U.ID), 30, time.Minute) {
		return &apiError{429, "Слишком часто"}
	}
	ctx := c.Context()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		if _, err := tx.Exec(ctx, `DELETE FROM news_revisions WHERE news_id = $1 AND autosave AND author_id = $2`, id, c.U.ID); err != nil {
			return err
		}
		_, err := tx.Exec(ctx, `INSERT INTO news_revisions (news_id, version, title, summary, body, cover, category_id, status,
				change_note, autosave, author_id)
			SELECT n.id, coalesce((SELECT max(version) FROM news_revisions WHERE news_id = n.id), 0) + 1, $2, $3, $4, $5, $6, n.status,
				'Автосохранение', true, $7 FROM news n WHERE n.id = $1`,
			id, strings.TrimSpace(in.Title), in.Summary, in.Body, in.Cover, in.CategoryID, c.U.ID)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

func (s *Server) listVersionComments(c *Ctx) error {
	vid, err := c.ID("vid")
	if err != nil {
		return err
	}
	nid, err := s.versionNews(c, vid)
	if err != nil {
		return err
	}
	if err := s.newsManageGuard(c, nid); err != nil {
		return err
	}
	b, err := s.arr(c.Context(), `SELECT k.id, k.body, k.created_at, k.author_id, u.full_name AS author, u.avatar AS author_avatar
		FROM news_revision_comments k LEFT JOIN users u ON u.id = k.author_id WHERE k.version_id = $1 ORDER BY k.id`, vid)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": rawJSON(b)})
}

func (s *Server) versionNews(c *Ctx, vid int64) (int64, error) {
	var nid int64
	err := s.db.QueryRow(c.Context(), `SELECT news_id FROM news_revisions WHERE id = $1`, vid).Scan(&nid)
	return nid, err
}

func (s *Server) addVersionComment(c *Ctx) error {
	vid, err := c.ID("vid")
	if err != nil {
		return err
	}
	var in struct {
		Body string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if n := len([]rune(in.Body)); n < 1 || n > 2000 {
		return badReq("Комментарий: от 1 до 2000 символов")
	}
	nid, err := s.versionNews(c, vid)
	if err != nil {
		return err
	}
	if err := s.newsManageGuard(c, nid); err != nil {
		return err
	}
	var id int64
	if err := s.db.QueryRow(c.Context(), `INSERT INTO news_revision_comments (version_id, author_id, body) VALUES ($1, $2, $3) RETURNING id`,
		vid, c.U.ID, in.Body).Scan(&id); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"id": id})
}

// ---------------------------------------------------------------- аналитика чтения

// trackRead: POST /api/news-track/{id}/read {depth: 0..100, seconds: n}. Значения — «максимум/приращение» на стороне сервера,
// поэтому повторные отправки (visibilitychange, pagehide) безопасны.
func (s *Server) trackRead(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Depth   int `json:"depth"`
		Seconds int `json:"seconds"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Depth = min(max(in.Depth, 0), 100)
	in.Seconds = min(max(in.Seconds, 0), 600) // за одну отправку — не больше 10 минут активного чтения
	if !s.rateOK(c.Context(), "nread:"+i64s(c.U.ID), 120, time.Minute) {
		return c.JSON(200, map[string]any{"ok": false})
	}
	_, err = s.db.Exec(c.Context(), `INSERT INTO news_read_stats (news_id, user_id, max_depth, seconds)
		SELECT n.id, $2, $3, $4 FROM news n WHERE n.id = $1
		ON CONFLICT (news_id, user_id) DO UPDATE SET max_depth = greatest(news_read_stats.max_depth, EXCLUDED.max_depth),
			seconds = news_read_stats.seconds + EXCLUDED.seconds, last_at = now(),
			opens = news_read_stats.opens + CASE WHEN EXCLUDED.seconds = 0 AND EXCLUDED.max_depth = 0 THEN 1 ELSE 0 END`,
		id, c.U.ID, in.Depth, in.Seconds)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// trackImpressions: POST /api/news-track/impressions {ids:[…], clicked?: id}
func (s *Server) trackImpressions(c *Ctx) error {
	var in struct {
		IDs     []int64 `json:"ids"`
		Clicked int64   `json:"clicked"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if len(in.IDs) > 50 {
		in.IDs = in.IDs[:50]
	}
	ctx := c.Context()
	if !s.rateOK(ctx, "nimp:"+i64s(c.U.ID), 60, time.Minute) {
		return c.JSON(200, map[string]any{"ok": false})
	}
	if len(in.IDs) > 0 {
		if _, err := s.db.Exec(ctx, `INSERT INTO news_feed_impressions (news_id, impressions)
			SELECT n.id, 1 FROM news n WHERE n.id = ANY($1)
			ON CONFLICT (news_id, day) DO UPDATE SET impressions = news_feed_impressions.impressions + 1`, in.IDs); err != nil {
			return err
		}
	}
	if in.Clicked > 0 {
		if _, err := s.db.Exec(ctx, `INSERT INTO news_feed_impressions (news_id, clicks)
			SELECT n.id, 1 FROM news n WHERE n.id = $1
			ON CONFLICT (news_id, day) DO UPDATE SET clicks = news_feed_impressions.clicks + 1`, in.Clicked); err != nil {
			return err
		}
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// trackCategory: POST /api/news-track/category {category_id} (0 — «Все»).
func (s *Server) trackCategory(c *Ctx) error {
	var in struct {
		CategoryID int `json:"category_id"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.CategoryID < 0 || !s.rateOK(c.Context(), "ncat:"+i64s(c.U.ID), 60, time.Minute) {
		return c.JSON(200, map[string]any{"ok": false})
	}
	if _, err := s.db.Exec(c.Context(), `INSERT INTO news_category_clicks (category_id, clicks) VALUES ($1, 1)
		ON CONFLICT (category_id, day) DO UPDATE SET clicks = news_category_clicks.clicks + 1`, in.CategoryID); err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// newsAnalytics: GET /api/news/{id}/analytics — сведения о публикации для редактора.
func (s *Server) newsAnalytics(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.newsManageGuard(c, id); err != nil {
		return err
	}
	b, err := s.one(c.Context(), `SELECT
		(SELECT views_count FROM news WHERE id = $1) AS views,
		(SELECT uniq_views FROM news WHERE id = $1) AS uniq,
		(SELECT coalesce(sum(impressions), 0) FROM news_feed_impressions WHERE news_id = $1)::int AS impressions,
		(SELECT coalesce(sum(clicks), 0) FROM news_feed_impressions WHERE news_id = $1)::int AS clicks,
		(SELECT count(*) FROM news_read_stats WHERE news_id = $1)::int AS readers,
		(SELECT coalesce(round(avg(max_depth)), 0) FROM news_read_stats WHERE news_id = $1)::int AS avg_depth,
		(SELECT coalesce(round(avg(seconds) FILTER (WHERE seconds > 0)), 0) FROM news_read_stats WHERE news_id = $1)::int AS avg_seconds,
		(SELECT count(*) FROM news_read_stats WHERE news_id = $1 AND max_depth >= 90)::int AS finished,
		(SELECT json_build_array(
			count(*) FILTER (WHERE max_depth < 25), count(*) FILTER (WHERE max_depth >= 25 AND max_depth < 50),
			count(*) FILTER (WHERE max_depth >= 50 AND max_depth < 75), count(*) FILTER (WHERE max_depth >= 75))
			FROM news_read_stats WHERE news_id = $1) AS depth_buckets`, id)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// categoryAnalytics: GET /api/news-track/categories — переходы по категориям за 30 дней.
func (s *Server) categoryAnalytics(c *Ctx) error {
	b, err := s.arr2(c.Context(), `SELECT k.category_id, coalesce(cat.name, 'Все') AS name, sum(k.clicks)::int AS clicks
		FROM news_category_clicks k LEFT JOIN categories cat ON cat.id = k.category_id
		WHERE k.day >= current_date - 30 GROUP BY k.category_id, cat.name ORDER BY clicks DESC`)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"items": rawJSON(b)})
}

func i64s(n int64) string { return strconv.FormatInt(n, 10) }
