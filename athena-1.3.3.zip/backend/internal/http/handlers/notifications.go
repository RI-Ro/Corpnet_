package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
)

type NotificationsHandler struct {
	pool *pgxpool.Pool
}

func NewNotificationsHandler(pool *pgxpool.Pool) *NotificationsHandler {
	return &NotificationsHandler{pool: pool}
}

// notificationItem — одна строка центра уведомлений.
//
// #7 — поле Text собирается НА СЕРВЕРЕ (service.NotificationText), а не на
// фронте по виду события: раньше фронт знал только kind и показывал безликое
// «Новое сообщение в обсуждении» без автора, текста и названия документа.
// Теперь текст один и тот же везде, где уведомление показывается.
type notificationItem struct {
	ID         int64   `json:"id"`
	Kind       string  `json:"kind"`
	Text       string  `json:"text"`
	DocumentID *int64  `json:"document_id,omitempty"`
	DocTitle   *string `json:"document_title,omitempty"`
	ActorName  string  `json:"actor_name,omitempty"`
	IsRead     bool    `json:"is_read"`
	// #2 — требует подтверждения (показывается блокирующей модалкой).
	RequiresAck bool   `json:"requires_ack"`
	SnoozedTill string `json:"snoozed_until,omitempty"`
	CreatedAt   string `json:"created_at"`
}

// listQuery — общая выборка уведомлений пользователя. extraWhere подставляется
// как дополнительное условие (фиксированные строки из кода, не пользовательский
// ввод).
const notificationsSelect = `
	SELECT n.id, n.kind, n.document_id, d.title,
	       coalesce(u.full_name, ''), CASE WHEN left(n.kind,10)='resolution' AND NOT EXISTS (SELECT 1 FROM resolutions r WHERE r.document_id=n.document_id AND r.id::text=n.payload->>'resolution_id') THEN '' WHEN n.kind IN ('execution_done','document_executed','execution_changed','execution_cancelled') THEN '' ELSE coalesce(n.detail, '') END, n.is_read, n.requires_ack,
	       coalesce(to_char(n.snoozed_until AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'), ''),
	       to_char(n.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
	FROM notifications n
	LEFT JOIN documents d ON d.id = n.document_id
	LEFT JOIN users u ON u.id = n.actor_id
	WHERE n.user_id = $1 AND (n.document_id IS NULL OR d.id IS NOT NULL)`

func scanNotifications(rows pgx.Rows) ([]notificationItem, error) {
	defer rows.Close()
	var items []notificationItem
	for rows.Next() {
		var it notificationItem
		var title *string
		var actor, detail string
		if err := rows.Scan(&it.ID, &it.Kind, &it.DocumentID, &title,
			&actor, &detail, &it.IsRead, &it.RequiresAck, &it.SnoozedTill, &it.CreatedAt); err != nil {
			return nil, err
		}
		it.DocTitle = title
		it.ActorName = actor
		docTitle := ""
		if title != nil {
			docTitle = *title
		}
		it.Text = service.NotificationText(it.Kind, actor, detail, docTitle)
		items = append(items, it)
	}
	return items, rows.Err()
}

// List GET /api/notifications?only_unread=false&limit=50 — центр уведомлений.
// Возвращает уведомления текущего пользователя (RLS notifications_select уже
// ограничивает выборку своими), новые сверху, с флагом is_read — так центр
// показывает и непрочитанные, и прочитанные (по требованию "с возможностью
// просмотра прочитанных").
func (h *NotificationsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	onlyUnread := c.Query("only_unread") == "true"
	limit := 50
	if v := c.Query("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 200 {
			limit = n
		}
	}

	var items []notificationItem
	var unreadCount int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM notifications n WHERE user_id=$1 AND is_read=false AND (document_id IS NULL OR EXISTS (SELECT 1 FROM documents d WHERE d.id=n.document_id))`, userID).Scan(&unreadCount); err != nil {
			return err
		}
		q := notificationsSelect
		if onlyUnread {
			q += ` AND n.is_read = false`
		}
		q += ` ORDER BY n.created_at DESC LIMIT $2`
		rows, err := tx.Query(c.Context(), q, userID, limit)
		if err != nil {
			return err
		}
		items, err = scanNotifications(rows)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить уведомления")
	}
	return c.JSON(fiber.Map{"items": items, "unread_count": unreadCount})
}

// Alarms GET /api/notifications/alarms — уведомления, требующие подтверждения
// (#2): непрочитанные, с requires_ack, срок «отложить» которых уже истёк.
// Именно их фронт показывает блокирующей модалкой со звуком.
//
// Отдельный эндпоинт, а не фильтр в List: модалка опрашивает его часто (и по
// каждому WS-событию), а выборка под частичный индекс idx_notifications_alarms
// заведомо узкая — полный список колокола для этого тянуть незачем.
// alarmStillActual — условие «работа по уведомлению ВСЁ ЕЩЁ не сделана».
//
// Зачем. Уведомление-будильник — это напоминание о работе, а не сама работа.
// Пользователь мог отложить напоминание, а потом пойти и выполнить дело: решить
// по согласованию, закрыть поручение. Уведомление при этом остаётся
// непрочитанным, и по истечении срока «отложить» окно всплывало снова — с
// требованием сделать то, что уже сделано. Именно на это и была жалоба.
//
// Поэтому будильник показывается, только если ПРЕДМЕТ напоминания по-прежнему
// требует внимания. Проверяется по виду события — для каждого есть свой
// признак «ещё не сделано»:
//
//	stage_pending — у пользователя есть АКТИВНЫЙ этап согласования/подписи
//	                по этому документу;
//	resolution    — есть резолюция, по которой этот пользователь исполнитель,
//	                и его часть не принята и не снята (, п. 3:
//	                поручения заменены резолюциями);
//	overdue       — срок документа действительно истёк, а документ не
//	                исполнен и не в архиве.
//
// Виды событий, не перечисленные здесь, остаются будильниками как раньше: для
// них «предмет» определить нельзя, и молча прятать их было бы хуже — это
// нарушило бы второе требование, «ничего не пропустить».
//
// Уведомление НЕ помечается прочитанным: в колоколе оно остаётся историей
// («вас просили, вы сделали»). Скрывается только блокирующее окно.
const alarmStillActual = `
	AND (
	    CASE n.kind
	      WHEN 'stage_pending' THEN EXISTS (
	            SELECT 1 FROM approval_stages s
	             WHERE s.document_id = n.document_id
	               AND s.status = 'pending' AND (n.payload->>'stage_id' IS NULL OR s.id::text=n.payload->>'stage_id')
	               AND s.approver_id = n.user_id)
	      WHEN 'resolution' THEN EXISTS (
	            SELECT 1 FROM resolution_executors re
	              JOIN resolutions r ON r.id = re.resolution_id
	             WHERE r.document_id = n.document_id
                 AND (n.payload->>'resolution_id' IS NULL OR r.id::text=n.payload->>'resolution_id')
	               AND re.user_id = n.user_id
	               AND re.status IN ('open','returned','in_progress')
	               AND r.status NOT IN ('done', 'cancelled'))
	      WHEN 'resolution_reported' THEN EXISTS (
	            -- Автору резолюции напоминаем, пока он не принял отчёт.
	            SELECT 1 FROM resolutions r
	             WHERE r.document_id = n.document_id
                 AND (n.payload->>'resolution_id' IS NULL OR r.id::text=n.payload->>'resolution_id')
	               AND r.author_id = n.user_id
	               AND r.status = 'on_report')
	      WHEN 'overdue' THEN EXISTS (
	            SELECT 1 FROM documents d
	             WHERE d.id = n.document_id
	               AND d.status NOT IN ('executed', 'archived')
	               AND coalesce(d.due_datetime, (d.due_date + time '23:59')::timestamptz) < now())
	      -- «в напоминания попадают документы, уже не
	      -- требующие внимания». Прежде здесь стояло ELSE TRUE: любой вид
	      -- события, для которого признак «ещё не сделано» не описан,
	      -- напоминал о себе ВЕЧНО, пока уведомление не прочитают. А виды
	      -- событий настраиваются конфигом (notifications.alarm_kinds), то
	      -- есть в будильники могли попасть document_sent и acquaintance — и
	      -- тогда блокирующее окно показывало входящие, с которыми давно
	      -- разобрались.
	      --
	      -- Описаны три оставшихся вида, у которых предмет напоминания
	      -- определить можно:
	      WHEN 'document_sent' THEN EXISTS (
	            SELECT 1 FROM document_recipients dr JOIN documents d ON d.id=dr.document_id
	             WHERE dr.document_id=n.document_id AND NOT dr.is_planned AND d.status IN ('sent','in_progress')
	               AND app_handles_recipient(dr.recipient_user_id,dr.recipient_department_id,n.user_id)
	               AND NOT EXISTS (SELECT 1 FROM document_incoming_instances i
	                 WHERE i.document_id=dr.document_id AND i.receiving_department_id=dr.recipient_department_id))
	      WHEN 'acquaintance' THEN NOT EXISTS (
	            -- Ознакомление требует внимания, пока человек документ не
	            -- открыл. Строка document_acquaintances означает «направлено
	            -- на ознакомление» (её создаёт тот, кто ознакамливает), а факт
	            -- прочтения — запись в document_views. Проверять первую было бы
	            -- неверно: она есть с самого начала.
	            SELECT 1 FROM document_views dv
	             WHERE dv.document_id = n.document_id
	               AND dv.viewer_id = n.user_id)
	      WHEN 'resolution_returned' THEN EXISTS (
	            -- Возвращённое на доработку требует внимания, пока исполнитель
	            -- не отчитался заново.
	            SELECT 1 FROM resolution_executors re
	              JOIN resolutions r ON r.id = re.resolution_id
	             WHERE r.document_id = n.document_id
                 AND (n.payload->>'resolution_id' IS NULL OR r.id::text=n.payload->>'resolution_id')
	               AND re.user_id = n.user_id
	               AND re.status = 'returned')
	      -- Для всех прочих видов предмет напоминания не определён, и ОНИ
	      -- БУДИЛЬНИКАМИ НЕ ЯВЛЯЮТСЯ: остаться в этой ветке событие может
	      -- только если его добавили в alarm_kinds конфигом, не описав здесь
	      -- признак актуальности. Прежнее ELSE TRUE означало «напоминать
	      -- вечно»; теперь — «не перекрывать экран». Событие при этом НЕ
	      -- теряется: оно остаётся в колоколе, в непрочитанных и в журнале.
	      ELSE FALSE
	    END
	)`

func (h *NotificationsHandler) Alarms(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var items []notificationItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// «бывает, один документ отображается несколько
		// раз». Так и было: будильник показывал КАЖДОЕ подходящее уведомление,
		// а их по одному документу легко несколько — две резолюции, резолюция
		// и нарушенный срок, повторно созданное stage_pending после
		// перезапуска маршрута. Человек закрывал окно и получал почти такое
		// же, с тем же документом.
		//
		// DISTINCT ON (document_id) оставляет по документу ОДНО напоминание —
		// самое свежее. Выбран именно документ, а не пара «документ + вид
		// события»: с точки зрения человека будильник означает «по этому
		// документу от тебя чего-то ждут», и двух окон про один документ он не
		// ждёт. Остальные уведомления никуда не исчезают — они в колоколе.
		//
		// Уведомления без документа (document_id IS NULL) под сворачивание не
		// попадают: coalesce(document_id, -id) даёт каждому своё значение,
		// иначе все системные напоминания слиплись бы в одно.
		rows, err := tx.Query(c.Context(), `
			SELECT * FROM (
			  SELECT DISTINCT ON (coalesce(n.document_id, -n.id)) *
			    FROM (`+notificationsSelect+`
			            AND n.requires_ack AND NOT n.is_read
			            AND (n.snoozed_until IS NULL OR n.snoozed_until <= now())`+alarmStillActual+`
			         ) AS n(id, kind, document_id, title, actor_name, detail,
			                is_read, requires_ack, snoozed_until, created_at)
			   ORDER BY coalesce(n.document_id, -n.id), n.created_at DESC
			) AS d
			ORDER BY d.created_at ASC
			LIMIT 20`, userID)
		if err != nil {
			return err
		}
		items, err = scanNotifications(rows)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить уведомления")
	}
	return c.JSON(fiber.Map{
		"items":          items,
		"snooze_minutes": service.SnoozeMinutes(),
		"repeat_seconds": service.AlarmRepeatSeconds(),
	})
}

// MarkRead POST /api/notifications/:id/read — отметить одно прочитанным.
func (h *NotificationsHandler) MarkRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// RLS notifications_update гарантирует, что пометить можно только своё.
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2`, id, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить прочитанным")
	}
	return c.SendStatus(fiber.StatusOK)
}

// MarkAllRead POST /api/notifications/read-all — отметить все прочитанными.
func (h *NotificationsHandler) MarkAllRead(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `UPDATE notifications SET is_read=true WHERE user_id=$1 AND is_read=false`, userID)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отметить все прочитанными")
	}
	return c.SendStatus(fiber.StatusOK)
}

// SnoozeAll POST /api/notifications/snooze-all {minutes: 5|15|30} — отложить
// ВСЕ показанные сейчас будильники одним действием.
//
// Зачем отдельный эндпоинт. Будильников у человека обычно несколько (несколько
// документов на согласовании, поручение, входящий). Если «отложить» действует
// на один, то после нажатия окно не закрывается, а показывает следующий — с
// похожим текстом. Снаружи это выглядит так, будто кнопка не работает: именно
// на это и была жалоба. Один запрос на все показанные — и окно закрывается с
// первого нажатия.
//
// Откладываются только те, что показаны сейчас (requires_ack, непрочитанные,
// срок отложенности истёк). Уже отложенные повторно не сдвигаются: иначе
// нажатие «5 минут» продлевало бы и то, что отложено на 30.
func (h *NotificationsHandler) SnoozeAll(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	var req struct {
		Minutes int `json:"minutes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный запрос")
	}
	if !service.SnoozeAllowed(req.Minutes) {
		return fiber.NewError(fiber.StatusUnprocessableEntity, "отложить можно только на 5, 15 или 30 минут")
	}

	var affected int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		ct, err := tx.Exec(c.Context(), `
			UPDATE notifications
			   SET snoozed_until = now() + make_interval(mins => $2)
			 WHERE user_id = $1
			   AND requires_ack AND NOT is_read
			   AND (snoozed_until IS NULL OR snoozed_until <= now())`, userID, req.Minutes)
		if err != nil {
			return err
		}
		affected = ct.RowsAffected()
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отложить уведомления")
	}
	return c.JSON(fiber.Map{"snoozed": affected})
}

// Snooze POST /api/notifications/:id/snooze {minutes: 5|15|30} — отложить
// уведомление-будильник (#2).
//
// Допустимые интервалы проверяются на сервере: «отложить навсегда» через
// произвольно большое значение быть не должно — уведомления этого типа
// требуют действия, а не откладывания на сутки.
func (h *NotificationsHandler) Snooze(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		Minutes int `json:"minutes"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный запрос")
	}
	if !service.SnoozeAllowed(req.Minutes) {
		return fiber.NewError(fiber.StatusUnprocessableEntity, "отложить можно только на 5, 15 или 30 минут")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `
			UPDATE notifications
			   SET snoozed_until = now() + make_interval(mins => $3)
			 WHERE id = $1 AND user_id = $2`, id, userID, req.Minutes)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось отложить уведомление")
	}
	return c.SendStatus(fiber.StatusOK)
}
