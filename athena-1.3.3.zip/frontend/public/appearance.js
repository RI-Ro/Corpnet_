(function () {
  var families = ["Manrope", "JetBrains Mono", "Liberation Serif", "Liberation Sans", "Liberation Mono", "DejaVu Sans", "DejaVu Serif", "DejaVu Sans Mono", "DejaVu Sans Condensed", "DejaVu Serif Condensed", "Noto Sans", "Noto Serif", "Noto Sans Display", "Noto Serif Display", "Noto Sans Mono", "Open Sans", "Open Sans Condensed"]
  var defaults = { elements: 100, text: 100, family: 'Manrope', bold: false, italic: false }
  function percent(value, min, max, fallback) {
    return typeof value === 'number' && isFinite(value) ? Math.max(min, Math.min(max, Math.round(value))) : fallback
  }
  function normalize(v) {
    v = v || {}
    return { elements: percent(v.elements,80,120,100), text: percent(v.text,50,150,100),
      family: families.indexOf(v.family) >= 0 ? v.family : defaults.family, bold: v.bold === true, italic: v.italic === true }
  }
  function read(user) {
    try { return JSON.parse(localStorage.getItem('athena_appearance:' + user)) || {} } catch (_) { return {} }
  }
  function apply(value) {
    var v = normalize(value), root = document.documentElement
    root.style.fontSize = (81 * v.elements / 100) + '%'
    root.style.setProperty('--ui-elements', v.elements / 100)
    root.style.setProperty('--ui-text', v.text / 100)
    root.style.setProperty('--font-body', '"' + v.family + '", sans-serif')
    root.style.setProperty('--font-display', '"' + v.family + '", sans-serif')
    root.dataset.uiBold = String(v.bold)
    root.dataset.uiItalic = String(v.italic)
  }
  window.athenaAppearance = { families: families, defaults: defaults, normalize: normalize, read: read, apply: apply }
  try { apply(read(localStorage.getItem('athena_login')).value) } catch (_) { apply(defaults) }
})()
