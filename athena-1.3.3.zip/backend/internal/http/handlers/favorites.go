package handlers

import (
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
)

// FavoritesHandler — избранное («звёздочка») у каждого пользователя.
//
// Список у каждого свой, и попасть туда может любой доступный документ —
// входящий, исходящий, архивный. Поэтому это связь «пользователь — документ»,
// а не поле документа.
//
// Права целиком на RLS (политики favorites_*): видеть и менять можно только
// своё, и только по доступному документу. Администратор сюда не допущен
// намеренно — чужое избранное это личная рабочая пометка.
type FavoritesHandler struct {
	pool *pgxpool.Pool
}

func NewFavoritesHandler(pool *pgxpool.Pool) *FavoritesHandler {
	return &FavoritesHandler{pool: pool}
}

// Add POST /api/documents/:id/favorite — добавить в избранное.
//
// Идемпотентно: повторное нажатие звёздочки не ошибка. ON CONFLICT вместо
// проверки «уже есть» — иначе два быстрых нажатия давали бы ошибку уникальности.
func (h *FavoritesHandler) Add(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(), `
			INSERT INTO document_favorites (user_id, document_id) VALUES ($1, $2)
			ON CONFLICT (user_id, document_id) DO NOTHING`, userID, id)
		return err
	})
	if txErr != nil {
		// Политика favorites_insert требует, чтобы документ был виден. Отказ
		// означает именно это, и сообщать «нет такого документа» правильнее,
		// чем «нет прав»: иначе по ответу можно было бы проверять
		// существование чужих документов.
		return fiber.NewError(fiber.StatusNotFound, "документ не найден")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Remove DELETE /api/documents/:id/favorite — убрать из избранного.
func (h *FavoritesHandler) Remove(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		_, err := tx.Exec(c.Context(),
			`DELETE FROM document_favorites WHERE user_id = $1 AND document_id = $2`, userID, id)
		return err
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось убрать из избранного")
	}
	return c.SendStatus(fiber.StatusOK)
}
