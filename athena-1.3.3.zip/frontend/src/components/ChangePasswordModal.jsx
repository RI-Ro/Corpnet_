import React, { useEffect, useMemo, useState } from 'react'
import { api } from '../api/client'

// Самостоятельная смена пароля.
//
// Требования (не менее 8 знаков, не менее 3 групп символов) показываются СРАЗУ,
// до ввода, а не выдаются отказом после отправки: человек должен знать правила
// заранее, иначе он угадывает. Текст требований приходит с сервера — там же,
// где выполняется настоящая проверка, поэтому подсказка и проверка не могут
// разойтись.
//
// Проверка в браузере — только подсказка. Решение принимает сервер: запрос на
// смену пароля можно отправить и мимо этой формы.

// Группы символов — те же четыре, что считает сервер (service.PasswordGroups).
// Буквы определяются по Unicode, а не по латинице: «Пароль123» — это три
// группы, и отвергать такой пароль было бы неверно.
function groupsOf(pw) {
  const found = []
  if (/\p{Ll}/u.test(pw)) found.push('строчные буквы')
  if (/\p{Lu}/u.test(pw)) found.push('заглавные буквы')
  if (/\p{Nd}/u.test(pw)) found.push('цифры')
  if (/[^\p{L}\p{Nd}]/u.test(pw)) found.push('знаки')
  return found
}

export default function ChangePasswordModal({ onClose }) {
  const [reqs, setReqs] = useState({ min_length: 8, min_groups: 3, text: '' })
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [repeat, setRepeat] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [done, setDone] = useState(false)

  useEffect(() => {
    api.getPasswordRequirements().then(setReqs).catch(() => {})
  }, [])

  const chars = useMemo(() => Array.from(next).length, [next])
  const groups = useMemo(() => groupsOf(next), [next])
  const longEnough = chars >= (reqs.min_length || 8)
  const enoughGroups = groups.length >= (reqs.min_groups || 3)
  const matches = next.length > 0 && next === repeat
  const canSubmit = current.length > 0 && longEnough && enoughGroups && matches && !busy

  async function submit(e) {
    e.preventDefault()
    if (!canSubmit) return
    setBusy(true)
    setError('')
    try {
      await api.changeOwnPassword(current, next)
      setDone(true)
    } catch (err) {
      // Сообщение сервера показываем как есть: оно объясняет, что именно не
      // так (неверный текущий пароль, слабый новый, совпадает с прежним).
      setError(err.message || 'Не удалось сменить пароль')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-surface rounded-lg shadow-2xl w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-3 border-b border-border">
          <h2 className="font-display text-base font-semibold">Смена пароля</h2>
        </div>

        {done ? (
          <div className="p-5">
            <div className="text-sm">Пароль изменён. В следующий раз входите с новым паролем.</div>
            <div className="mt-4 flex justify-end">
              <button onClick={onClose} className="btn btn-primary">Закрыть</button>
            </div>
          </div>
        ) : (
          <form onSubmit={submit} className="p-5 space-y-3">
            {/* Требования — до ввода, а не после отказа. */}
            <div className="text-xs text-text-secondary border border-border rounded-md px-3 py-2">
              {reqs.text || `Пароль должен быть не короче ${reqs.min_length || 8} знаков и содержать символы не менее чем ${reqs.min_groups || 3} групп: строчные буквы, заглавные буквы, цифры, знаки.`}
            </div>

            <div>
              <label className="block text-sm mb-1">Текущий пароль</label>
              <input
                type="password"
                value={current}
                onChange={(e) => setCurrent(e.target.value)}
                autoComplete="current-password"
                required
                className="field w-full"
              />
            </div>

            <div>
              <label className="block text-sm mb-1">Новый пароль</label>
              <input
                type="password"
                value={next}
                onChange={(e) => setNext(e.target.value)}
                autoComplete="new-password"
                required
                className="field w-full"
              />
              {/* Выполнение правил показывается по мере ввода — это и есть
                  обещанное «обязательно уведомление». */}
              {next.length > 0 && (
                <ul className="mt-1.5 space-y-0.5 text-[11px]">
                  <li className={longEnough ? 'text-success' : 'text-text-secondary'}>
                    {longEnough ? '✓' : '•'} не короче {reqs.min_length || 8} знаков — сейчас {chars}
                  </li>
                  <li className={enoughGroups ? 'text-success' : 'text-text-secondary'}>
                    {enoughGroups ? '✓' : '•'} не менее {reqs.min_groups || 3} групп символов — сейчас {groups.length}
                    {groups.length > 0 && ` (${groups.join(', ')})`}
                  </li>
                </ul>
              )}
            </div>

            <div>
              <label className="block text-sm mb-1">Новый пароль ещё раз</label>
              <input
                type="password"
                value={repeat}
                onChange={(e) => setRepeat(e.target.value)}
                autoComplete="new-password"
                required
                className="field w-full"
              />
              {repeat.length > 0 && !matches && (
                <div className="mt-1 text-[11px] text-danger">Пароли не совпадают</div>
              )}
            </div>

            {error && <div className="text-xs text-danger">{error}</div>}

            <div className="flex justify-end gap-2 pt-1">
              <button type="button" onClick={onClose} className="btn btn-secondary">Отмена</button>
              <button type="submit" disabled={!canSubmit} className="btn btn-primary disabled:opacity-50">
                Сменить пароль
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
