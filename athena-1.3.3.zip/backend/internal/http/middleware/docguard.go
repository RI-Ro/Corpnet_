package middleware

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
)

// DocumentGuard — единая проверка доступа ко всем маршрутам
// /api/documents/:id/… : документ обязан быть ВИДИМ пользователю (политика
// RLS documents_select: автор, участник маршрута, получатель, область
// видимости подразделений — с учётом замещения).
//
// Зачем отдельный слой. Под RLS находятся не все таблицы: получатели,
// связи, печати, ознакомления, этапы, файлы защищены только проверкой в
// обработчике. В нескольких обработчиках её не оказалось, и посторонний
// сотрудник по номеру документа читал список получателей и связи. Проверка
// «в каждом обработчике» ломается ровно так — забытым местом. Поэтому она
// вынесена сюда и выполняется ДО любого обработчика; обработчики дальше
// проверяют уже право на конкретное действие.
//
// Постороннему отвечаем 404, а не 403: по ответу нельзя узнать, существует
// ли документ с таким номером.
func DocumentGuard(pool *pgxpool.Pool) fiber.Handler {
	return func(c *fiber.Ctx) error {
		idStr := c.Params("id")
		id, err := strconv.ParseInt(idStr, 10, 64)
		if err != nil || id <= 0 {
			// /documents/search, /documents/category-counts и т. п.
			return c.Next()
		}
		userID, _ := c.Locals(CtxUserID).(int64)
		isAdmin, _ := c.Locals(CtxIsAdmin).(bool)
		var visible bool
		txErr := db.WithUserTx(c.Context(), pool, userID, isAdmin, func(tx pgx.Tx) error {
			return tx.QueryRow(c.Context(), `SELECT true FROM documents WHERE id = $1`, id).Scan(&visible)
		})
		if txErr != nil {
			if errors.Is(txErr, pgx.ErrNoRows) {
				return fiber.NewError(fiber.StatusNotFound, "документ не найден")
			}
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось проверить доступ к документу")
		}
		return c.Next()
	}
}
