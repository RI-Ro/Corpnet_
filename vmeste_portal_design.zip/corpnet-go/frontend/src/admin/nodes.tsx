import React, { useEffect, useState } from 'react';
import * as I from '../lib/icons';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { toast } from '../lib/store';
import { cx } from '../lib/util';
import { Badge, Btn, Field, Input, Loading, Modal, Textarea, useConfirm } from '../ui';

const KEY = 'adm:cluster';
const EMPTY = { code: '', name: '', region: '', public_url: '', internal_url: '', priority: 100, enabled: true, maintenance: false, note: '' };

function ago(iso?: string) {
  if (!iso || iso.startsWith('0001')) return '—';
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  return s < 60 ? `${s} с назад` : s < 3600 ? `${Math.round(s / 60)} мин назад` : `${Math.round(s / 3600)} ч назад`;
}

function statusOf(n: any): { kind: 'ok' | 'warn' | 'dng' | 'accent'; text: string } {
  if (!n.enabled) return { kind: 'accent', text: 'Выключен' };
  if (n.maintenance) return { kind: 'warn', text: 'Обслуживание' };
  const st = n.state;
  if (!st) return { kind: 'warn', text: 'Нет данных' };
  if (!st.ok) return { kind: 'dng', text: st.err || 'Недоступен' };
  return { kind: 'ok', text: 'В сети' };
}

export function NodesAdmin() {
  const q = useQuery<any>(KEY, () => api.get('/api/admin/cluster'), { stale: 0 });
  const [edit, setEdit] = useState<any | null>(null);
  const [sw, setSw] = useState<any | null>(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [set, setSet] = useState<any | null>(null);
  const [confirm, cnode] = useConfirm();
  useEffect(() => { const t = setInterval(() => invalidate(KEY), 5000); return () => clearInterval(t); }, []);
  if (q.data && !set) setSet({ ...q.data.settings });
  if (!q.data || !set) return <Loading />;
  const d = q.data;
  const nodes: any[] = d.nodes || [];
  const master = nodes.find((n) => n.is_master);

  async function save() {
    try {
      const body = { ...edit, priority: Number(edit.priority) || 100 };
      if (edit.id) await api.put('/api/admin/nodes/' + edit.id, body); else await api.post('/api/admin/nodes', body);
      setEdit(null); invalidate(KEY); toast({ title: 'Сохранено', kind: 'success' }, 2000);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function del(n: any) {
    if (!(await confirm(`Удалить узел «${n.name}»?`, { text: 'Узел исчезнет из реестра; данные на нём не затрагиваются.', ok: 'Удалить' }))) return;
    try { await api.del('/api/admin/nodes/' + n.id); invalidate(KEY); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function maint(n: any) {
    try {
      await api.put('/api/admin/nodes/' + n.id, { ...n, maintenance: !n.maintenance });
      invalidate(KEY);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function doSwitch() {
    setBusy(true);
    try {
      const r = await api.post('/api/admin/cluster/master', { code: sw.code, reason });
      toast({ title: `Мастер: ${sw.name}`, text: r.note || undefined, kind: r.note ? 'info' : 'success' } as any, 6000);
      setSw(null); setReason(''); invalidate(KEY);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } finally { setBusy(false); }
  }
  async function saveSettings() {
    try { await api.put('/api/admin/cluster/settings', { ...set, fail_after_sec: Number(set.fail_after_sec), max_lag_sec: Number(set.max_lag_sec) }); toast({ title: 'Настройки сохранены', kind: 'success' }, 2000); invalidate(KEY); }
    catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }

  return (
    <div className="stack">
      {cnode}
      <div className="card pad stack">
        <div className="row sp"><h3>Узлы портала</h3><Btn kind="pri" onClick={() => setEdit({ ...EMPTY })}><I.Plus size={14} /> Добавить узел</Btn></div>
        <div className="small muted">
          Один узел — мастер (принимает запись в PostgreSQL), остальные работают на чтение с репликой; изменения с них прозрачно уходят мастеру.
          Файлы синхронизируются между узлами средствами портала (нужен общий INTERNAL_TOKEN). Распределение пользователей по узлам — на стороне DNS.
          Вы находитесь на узле <b>{d.self}</b> (БД: {d.local_db.role === 'primary' ? 'основная' : d.local_db.role === 'replica' ? `реплика, отставание ${Math.round(d.local_db.lag_sec)} с` : 'нет связи'}).
        </div>
        {!d.sync.token_set && <div className="alert warn small">INTERNAL_TOKEN не задан: узлы не смогут проверять друг друга и синхронизировать файлы.</div>}
        {nodes.length === 0 && <div className="empty small">Реестр пуст — портал работает как одиночная установка. Добавьте первый узел (он станет мастером).</div>}
        {nodes.length > 0 && (
          <div className="nodesTbl">
            <div className="nodesRow head"><span>Узел</span><span>Состояние</span><span>Роль БД</span><span>Отставание</span><span>Отклик</span><span>Проверен</span><span /></div>
            {nodes.map((n) => {
              const s = statusOf(n);
              return (
                <div key={n.id} className={cx('nodesRow', n.self && 'self')}>
                  <span><b>{n.name}</b> {n.self && <Badge kind="accent">этот узел</Badge>} {n.is_master && <Badge kind="lime">мастер</Badge>}<br /><span className="small muted mono">{n.code} · {n.region || 'без региона'} · приоритет {n.priority}</span></span>
                  <span><Badge kind={s.kind}>{s.text}</Badge></span>
                  <span>{n.state?.db_role === 'primary' ? 'основная' : n.state?.db_role === 'replica' ? 'реплика' : '—'}</span>
                  <span className="mono">{n.state?.db_role === 'replica' ? `${Math.round(n.state.lag_sec)} с` : '—'}</span>
                  <span className="mono">{n.state?.ok && !n.self ? `${n.state.latency_ms} мс` : '—'}</span>
                  <span className="small muted">{ago(n.state?.checked_at)}</span>
                  <span className="row gap">
                    {!n.is_master && n.enabled && !n.maintenance && <Btn size="sm" onClick={() => setSw(n)}>Сделать мастером</Btn>}
                    {!n.is_master && <Btn size="sm" onClick={() => maint(n)}>{n.maintenance ? 'Вернуть в работу' : 'На обслуживание'}</Btn>}
                    <Btn size="sm" onClick={() => setEdit({ ...n })}>Изменить</Btn>
                    {!n.is_master && <Btn size="sm" kind="dng" onClick={() => del(n)}><I.Trash size={13} /></Btn>}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="card pad stack">
        <h3>Автоматическое переключение</h3>
        <label className="row gap"><input type="checkbox" checked={!!set.auto_failover} onChange={(e) => setSet({ ...set, auto_failover: e.target.checked })} /> Переключать мастера автоматически, если он недоступен</label>
        <div className="small muted">Решение принимает лучший кандидат (приоритет, затем меньшее отставание) и только при согласии большинства узлов (нужно не меньше трёх узлов). Узлы «на обслуживании» кандидатами не становятся.</div>
        <div className="grid2">
          <Field label="Мастер недоступен дольше, секунд"><Input type="number" min={10} value={set.fail_after_sec} onChange={(e) => setSet({ ...set, fail_after_sec: e.target.value })} /></Field>
          <Field label="Допустимое отставание реплики, секунд"><Input type="number" min={1} value={set.max_lag_sec} onChange={(e) => setSet({ ...set, max_lag_sec: e.target.value })} /></Field>
        </div>
        <div><Btn kind="pri" onClick={saveSettings}>Сохранить</Btn></div>
      </div>

      <div className="card pad stack">
        <h3>Журнал</h3>
        {(d.events || []).length === 0 ? <div className="small muted">Событий пока нет.</div> : (d.events as any[]).map((e) => (
          <div key={e.id} className="small row gap"><span className="muted mono">{new Date(e.at).toLocaleString('ru-RU')}</span><Badge kind={e.kind === 'node_down' ? 'dng' : e.kind === 'node_up' ? 'ok' : 'accent'}>{({ master_change: 'смена мастера', node_down: 'узел недоступен', node_up: 'узел вернулся', failover: 'автопереключение' } as any)[e.kind] || e.kind}</Badge><span><b>{e.node}</b> {e.details}</span></div>
        ))}
      </div>

      {edit && (
        <Modal title={edit.id ? 'Узел: ' + edit.name : 'Новый узел'} onClose={() => setEdit(null)}
          footer={<><Btn onClick={() => setEdit(null)}>Отмена</Btn><Btn kind="pri" onClick={save} disabled={!edit.code || !edit.name}>Сохранить</Btn></>}>
          <div className="stack">
            <div className="grid2">
              <Field label="Код (латиницей)" hint="Совпадает с NODE_CODE на самом узле"><Input value={edit.code} onChange={(e) => setEdit({ ...edit, code: e.target.value.toLowerCase() })} maxLength={40} /></Field>
              <Field label="Название"><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} maxLength={80} /></Field>
            </div>
            <div className="grid2">
              <Field label="Регион"><Input value={edit.region} onChange={(e) => setEdit({ ...edit, region: e.target.value })} placeholder="Москва, Новосибирск…" /></Field>
              <Field label="Приоритет мастера" hint="Меньше — раньше кандидат"><Input type="number" min={1} value={edit.priority} onChange={(e) => setEdit({ ...edit, priority: e.target.value })} /></Field>
            </div>
            <Field label="Адрес узла"><Input value={edit.public_url} onChange={(e) => setEdit({ ...edit, public_url: e.target.value })} placeholder="https://msk.portal.example" /></Field>
            <Field label="Адрес для связи узлов" hint="Необязательно: внутренний адрес, если отличается"><Input value={edit.internal_url} onChange={(e) => setEdit({ ...edit, internal_url: e.target.value })} placeholder="http://10.0.0.5:8080" /></Field>
            <label className="row gap"><input type="checkbox" checked={edit.enabled} onChange={(e) => setEdit({ ...edit, enabled: e.target.checked })} /> Узел включён</label>
            <Field label="Заметка"><Textarea rows={2} value={edit.note} onChange={(e) => setEdit({ ...edit, note: e.target.value })} /></Field>
          </div>
        </Modal>
      )}
      {sw && (
        <Modal title={`Сделать мастером: ${sw.name}`} size="sm" onClose={() => setSw(null)}
          footer={<><Btn onClick={() => setSw(null)}>Отмена</Btn><Btn kind="dngF" busy={busy} onClick={doSwitch}>Переключить</Btn></>}>
          <div className="stack">
            <p className="muted">Текущий мастер ({master?.name}) перестанет принимать запись, а на «{sw.name}» PostgreSQL будет переведён из реплики в основную БД. Остальные узлы нужно переподключить к новому мастеру (сценарий NODE_SWITCH_HOOK). На время переключения запись недоступна — это секунды.</p>
            <Field label="Причина (попадёт в журнал)"><Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Плановое обслуживание" /></Field>
          </div>
        </Modal>
      )}
    </div>
  );
}
