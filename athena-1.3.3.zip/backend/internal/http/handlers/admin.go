package handlers

import (
	"errors"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/service"
)

type AdminHandler struct {
	pool *pgxpool.Pool
	svc  *service.AdminService
}

func NewAdminHandler(pool *pgxpool.Pool, svc *service.AdminService) *AdminHandler {
	return &AdminHandler{pool: pool, svc: svc}
}

// ctx извлекает userID/isAdmin и проверяет права администратора.
func (h *AdminHandler) ctx(c *fiber.Ctx) (int64, bool, error) {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	if !isAdmin {
		return 0, false, fiber.NewError(fiber.StatusForbidden, "доступно только администратору")
	}
	return userID, isAdmin, nil
}

func mapAdminErr(err error) error {
	switch {
	case errors.Is(err, service.ErrDeptHasChildren), errors.Is(err, service.ErrDeptHasUsers), errors.Is(err, service.ErrCycle):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, service.ErrDomainUser), errors.Is(err, service.ErrBadLogin), errors.Is(err, service.ErrBadEmail):
		return fiber.NewError(fiber.StatusBadRequest, err.Error())
	case errors.Is(err, service.ErrLoginTaken), errors.Is(err, service.ErrPrefixTaken):
		return fiber.NewError(fiber.StatusConflict, err.Error())
	case errors.Is(err, pgx.ErrNoRows):
		return fiber.NewError(fiber.StatusNotFound, "не найдено")
	default:
		return fiber.NewError(fiber.StatusInternalServerError, "внутренняя ошибка")
	}
}

// ---------------- Departments ----------------

// ListDepartments GET /api/admin/departments — плоский список для построения дерева.
func (h *AdminHandler) ListDepartments(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	type dept struct {
		ID              int64  `json:"id"`
		ParentID        *int64 `json:"parent_id"`
		Name            string `json:"name"`
		NumberingPrefix string `json:"numbering_prefix"`
		City            string `json:"city"`
		IsActive        bool   `json:"is_active"`
		UserCount       int    `json:"user_count"`
	}
	var out []dept
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT d.id, d.parent_id, d.name, coalesce(d.numbering_prefix,''),
			       coalesce(d.city,''), d.is_active,
			       (SELECT count(*) FROM users u WHERE u.primary_department_id = d.id)
			FROM departments d
			ORDER BY d.parent_id NULLS FIRST, d.name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var d dept
			if err := rows.Scan(&d.ID, &d.ParentID, &d.Name, &d.NumberingPrefix, &d.City, &d.IsActive, &d.UserCount); err != nil {
				return err
			}
			out = append(out, d)
		}
		return rows.Err()
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.JSON(fiber.Map{"departments": out})
}

func (h *AdminHandler) CreateDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	var req struct {
		Name            string `json:"name"`
		NumberingPrefix string `json:"numbering_prefix"`
		City            string `json:"city"`
		ParentID        int64  `json:"parent_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	if req.Name == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите название подразделения")
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var e error
		id, e = h.svc.CreateDepartment(c.Context(), tx, req.Name, req.NumberingPrefix, req.City, req.ParentID)
		return e
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

func (h *AdminHandler) UpdateDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Name            string `json:"name"`
		NumberingPrefix string `json:"numbering_prefix"`
		City            string `json:"city"`
		IsActive        bool   `json:"is_active"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.UpdateDepartment(c.Context(), tx, id, req.Name, req.NumberingPrefix, req.City, req.IsActive)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// MoveDepartment PATCH /api/admin/departments/:id/parent — перенос (drag-drop).
func (h *AdminHandler) MoveDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		ParentID int64 `json:"parent_id"` // 0 => корень
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.MoveDepartment(c.Context(), tx, id, req.ParentID)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

func (h *AdminHandler) DeleteDepartment(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.DeleteDepartment(c.Context(), tx, id)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// ---------------- Users ----------------

// ListUsers GET /api/admin/users — все пользователи с ролями и подразделением.
func (h *AdminHandler) ListUsers(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	type usr struct {
		ID              int64    `json:"id"`
		Login           string   `json:"login"`
		DomainID        *int64   `json:"domain_id"`
		Domain          string   `json:"domain"`
		Email           string   `json:"email"`
		FullName        string   `json:"full_name"`
		Position        string   `json:"position"`
		Basis           string   `json:"basis"`
		DepartmentID    *int64   `json:"department_id"`
		NumberingDeptID *int64   `json:"numbering_department_id"`
		IsActive        bool     `json:"is_active"`
		Roles           []string `json:"roles"`
		Visible         []int64  `json:"visible_departments"`
		Acquaint        []int64  `json:"acquaint_departments"`
		Incoming        []int64  `json:"incoming_departments"`
		Redirect        []int64  `json:"redirect_departments"`
		// п. 4 — дополнительные подразделения для резолюций.
		Resolution []int64 `json:"resolution_departments"`
		Dashboard  []int64 `json:"dashboard_departments"`
		Duty       []int64 `json:"duty_departments"`
	}
	var out []usr
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, u.login, u.domain_id, coalesce((SELECT realm FROM auth_domains ad WHERE ad.id = u.domain_id),''), coalesce(u.email,''), u.full_name, coalesce(u.position,''), coalesce(u.basis,''), u.primary_department_id,
			       u.numbering_department_id, u.is_active,
			       coalesce(array_agg(DISTINCT ur.role::text) FILTER (WHERE ur.role IS NOT NULL), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_visible_departments  x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_acquaint_departments x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_incoming_departments x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_redirect_departments x WHERE x.user_id=u.id), '{}'),
			       coalesce((SELECT array_agg(department_id) FROM user_resolution_departments x WHERE x.user_id=u.id), '{}'),
 ARRAY(SELECT department_id FROM user_dashboard_departments x WHERE x.user_id=u.id),
 ARRAY(SELECT department_id FROM user_duty_departments x WHERE x.user_id=u.id)
			FROM users u
			LEFT JOIN user_roles ur ON ur.user_id = u.id
			WHERE u.duty_department_id IS NULL
			GROUP BY u.id
			ORDER BY u.full_name`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var u usr
			if err := rows.Scan(&u.ID, &u.Login, &u.DomainID, &u.Domain, &u.Email, &u.FullName, &u.Position, &u.Basis, &u.DepartmentID,
				&u.NumberingDeptID, &u.IsActive,
				&u.Roles, &u.Visible, &u.Acquaint, &u.Incoming, &u.Redirect,
				&u.Resolution, &u.Dashboard, &u.Duty); err != nil {
				return err
			}
			out = append(out, u)
		}
		return rows.Err()
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.JSON(fiber.Map{"users": out})
}

func (h *AdminHandler) CreateUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	var req struct {
		Login        string `json:"login"`
		Password     string `json:"password"`
		FullName     string `json:"full_name"`
		Position     string `json:"position"`
		Basis        string `json:"basis"`
		DepartmentID int64  `json:"department_id"`
		// DomainID > 0 — учётная запись домена: логин сохраняется как
		// имя@REALM, пароль не задаётся (вход через LDAP/Kerberos домена).
		DomainID int64 `json:"domain_id"`
		// Email — адрес для писем о новых входящих документах.
		Email string `json:"email"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	req.Login = strings.TrimSpace(req.Login)
	if req.Login == "" || req.FullName == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите логин и ФИО")
	}
	if req.DomainID == 0 {
		if strings.ContainsAny(req.Login, `@\`) {
			return fiber.NewError(fiber.StatusBadRequest, "логин локальной учётной записи не может содержать @ и \\ — для доменной выберите домен")
		}
		if err := service.ValidatePassword(req.Password); err != nil {
			return fiber.NewError(fiber.StatusUnprocessableEntity, err.Error())
		}
	}
	var id int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var e error
		id, e = h.svc.CreateUser(c.Context(), tx, req.Login, req.Password, req.FullName, req.Position, req.Basis, req.DepartmentID, req.DomainID)
		if e != nil {
			return e
		}
		return h.svc.SetEmail(c.Context(), tx, id, req.Email)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.Status(fiber.StatusCreated).JSON(fiber.Map{"id": id})
}

func (h *AdminHandler) UpdateUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Login           string `json:"login"`
		FullName        string `json:"full_name"`
		Position        string `json:"position"`
		Basis           string `json:"basis"`
		DepartmentID    int64  `json:"department_id"`
		NumberingDeptID int64  `json:"numbering_department_id"`
		IsActive        bool   `json:"is_active"`
		// Email: nil — не менять.
		Email *string `json:"email"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if err := h.svc.UpdateUser(c.Context(), tx, id, req.Login, req.FullName, req.Position, req.Basis,
			req.DepartmentID, req.NumberingDeptID, req.IsActive); err != nil {
			return err
		}
		if req.Email != nil {
			return h.svc.SetEmail(c.Context(), tx, id, *req.Email)
		}
		return nil
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// MoveUser PATCH /api/admin/users/:id/department — перенос (drag-drop).
func (h *AdminHandler) MoveUser(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		DepartmentID int64 `json:"department_id"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.MoveUser(c.Context(), tx, id, req.DepartmentID)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// SetUserDepartments PATCH /api/admin/users/:id/departments — заменяет наборы
// доп. подразделений (видимость исходящих / ознакомление / поручения).
func (h *AdminHandler) SetUserDepartments(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Visible    []int64 `json:"visible_departments"`
		Acquaint   []int64 `json:"acquaint_departments"`
		Incoming   []int64 `json:"incoming_departments"`
		Redirect   []int64 `json:"redirect_departments"`
		Resolution []int64 `json:"resolution_departments"`
		Dashboard  []int64 `json:"dashboard_departments"`
		Duty       []int64 `json:"duty_departments"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		sets := []struct {
			table string
			ids   []int64
		}{
			{"user_visible_departments", req.Visible}, {"user_acquaint_departments", req.Acquaint}, {"user_incoming_departments", req.Incoming},
			{"user_redirect_departments", req.Redirect}, {"user_resolution_departments", req.Resolution}, {"user_dashboard_departments", req.Dashboard}, {"user_duty_departments", req.Duty},
		}
		for _, set := range sets {
			if set.ids != nil {
				if err := h.svc.SetUserDepartmentSet(c.Context(), tx, set.table, id, set.ids); err != nil {
					return err
				}
			}
		}
		return nil
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

func (h *AdminHandler) SetUserPassword(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		Password string `json:"password"`
	}
	if err := c.BodyParser(&req); err != nil || req.Password == "" {
		return fiber.NewError(fiber.StatusBadRequest, "укажите пароль")
	}
	if err := service.ValidatePassword(req.Password); err != nil {
		return fiber.NewError(fiber.StatusUnprocessableEntity, err.Error())
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.SetPassword(c.Context(), tx, id, req.Password)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	return c.SendStatus(fiber.StatusOK)
}

// SetUserRoles PATCH /api/admin/users/:id/roles — заменить роли пользователя
// в подразделении (department_id=0 => глобальные, напр. admin).
func (h *AdminHandler) SetUserRoles(c *fiber.Ctx) error {
	userID, isAdmin, err := h.ctx(c)
	if err != nil {
		return err
	}
	id, _ := strconv.ParseInt(c.Params("id"), 10, 64)
	var req struct {
		DepartmentID int64    `json:"department_id"`
		Roles        []string `json:"roles"`
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		return h.svc.SetRoles(c.Context(), tx, id, req.DepartmentID, req.Roles)
	})
	if txErr != nil {
		return mapAdminErr(txErr)
	}
	// Роли изменились — сбрасываем кэш актуальных прав пользователя.
	middleware.InvalidateUser(id)
	return c.SendStatus(fiber.StatusOK)
}
