import { useState } from 'react';
import '../pages/tz/tz.css';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { toast, setState } from '../lib/store';
import { DESIGNS } from '../lib/appearance';
import { THEMES } from '../lib/themes';
import { FONT_LIST } from '../lib/fontlist';
import { BGS } from '../lib/bg';
import { PhotoPicker } from '../layout/AppearanceExtra';
import { ImageUpload, Badge, Btn, Field, Input, Loading, Modal, Select, Switch, Tabs, Textarea, Avatar, UserPicker, type UserLite } from '../ui';
import { plural } from '../lib/util';
import * as I from '../lib/icons';
import { useAudiences } from '../pages/tz/common';
import { AudienceForm } from '../pages/tz/targeting';

/** Универсальный редактор справочника: список + форма в окне. Сервер приводит значения к типам колонок сам (crud в tz_crud.go). */
type F = { key: string; label: string; type?: 'text' | 'area' | 'number' | 'bool' | 'select' | 'date' | 'json' | 'lines' | 'ids'; options?: [string, string][]; def?: any; hint?: string; wide?: boolean };
interface CatCfg { path: string; title: string; fields: F[]; cols: { key: string; label: string; fmt?: (v: any, r: any) => any }[]; query?: string; defaults?: any; addLabel?: string }

function Cat({ cfg }: { cfg: CatCfg }) {
  const key = 'adm:' + cfg.path + (cfg.query || '');
  const q = useQuery<any[]>(key, () => api.get(`/api/${cfg.path}${cfg.query ? '?' + cfg.query : ''}`), { stale: 0 });
  const [ed, setEd] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const aud = useAudiences();
  const open = (r?: any) => setEd(r ? { ...r } : Object.fromEntries(cfg.fields.map((f) => [f.key, cfg.defaults?.[f.key] ?? f.def ?? (f.type === 'bool' ? false : f.type === 'lines' || f.type === 'ids' ? [] : f.type === 'json' ? {} : '')])));
  async function save() {
    setBusy(true);
    try {
      const body: any = { ...(cfg.defaults || {}) };
      for (const f of cfg.fields) {
        let v = ed[f.key];
        if (f.type === 'number') v = v === '' || v == null ? (f.def ?? 0) : +v;
        if (f.type === 'json' && typeof v === 'string') v = JSON.parse(v || '{}');
        if (f.type === 'ids' && typeof v === 'string') v = v.split(/[,\s]+/).filter(Boolean).map(Number);
        if ((f.type === 'date' || f.key === 'audience_id') && v === '') v = null;
        if (f.key === 'audience_id' && v != null) v = +v;
        body[f.key] = v;
      }
      if (ed.id) await api.put(`/api/${cfg.path}/${ed.id}`, body); else await api.post(`/api/${cfg.path}`, body);
      invalidate('adm:'); setEd(null); toast({ title: 'Сохранено', kind: 'success' }, 2000);
    } catch (e) { toast({ title: e instanceof SyntaxError ? 'Некорректный JSON' : errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  async function del(r: any) { if (!confirm('Удалить запись?')) return; try { await api.del(`/api/${cfg.path}/${r.id}`); invalidate('adm:'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  const input = (f: F) => {
    const v = ed[f.key];
    const set = (x: any) => setEd({ ...ed, [f.key]: x });
    if (f.key === 'audience_id') return <Select value={v ?? ''} onChange={(e) => set(e.target.value)}><option value="">Все</option>{(aud.data || []).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</Select>;
    switch (f.type) {
      case 'area': return <Textarea rows={3} value={v ?? ''} onChange={(e) => set(e.target.value)} />;
      case 'number': return <Input type="number" value={v ?? ''} onChange={(e) => set(e.target.value)} />;
      case 'date': return <Input type="date" value={v ? String(v).slice(0, 10) : ''} onChange={(e) => set(e.target.value)} />;
      case 'bool': return <Switch checked={!!v} onChange={set} />;
      case 'select': return <Select value={v ?? ''} onChange={(e) => set(e.target.value)}>{f.options!.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</Select>;
      case 'json': return <Textarea rows={4} style={{ fontFamily: 'var(--mono)' }} value={typeof v === 'string' ? v : JSON.stringify(v ?? {}, null, 2)} onChange={(e) => set(e.target.value)} />;
      case 'lines': return <Textarea rows={3} value={(v || []).join('\n')} onChange={(e) => set(e.target.value.split('\n').map((z: string) => z.trim()).filter(Boolean))} />;
      case 'ids': return <Input value={Array.isArray(v) ? v.join(', ') : v ?? ''} onChange={(e) => set(e.target.value)} placeholder="ID сотрудников через запятую" />;
      default: return <Input value={v ?? ''} onChange={(e) => set(e.target.value)} />;
    }
  };
  return (
    <div className="card pad stack">
      <div className="row"><h3 className="sp">{cfg.title}</h3><button className="btn pri sm" onClick={() => open()}><I.Plus size={15} /> {cfg.addLabel || 'Добавить'}</button></div>
      {!q.data ? <Loading /> : (
        <div style={{ overflowX: 'auto' }}><table className="tbl"><thead><tr>{cfg.cols.map((c) => <th key={c.key}>{c.label}</th>)}<th /></tr></thead>
          <tbody>{q.data.map((r) => <tr key={r.id}>{cfg.cols.map((c) => <td key={c.key}>{c.fmt ? c.fmt(r[c.key], r) : String(r[c.key] ?? '')}</td>)}
            <td style={{ whiteSpace: 'nowrap', textAlign: 'right' }}><button className="btn ghost sm" onClick={() => open(r)} aria-label="Изменить"><I.Edit size={15} /></button><button className="btn ghost sm" onClick={() => del(r)} aria-label="Удалить"><I.Trash size={15} /></button></td></tr>)}
            {q.data.length === 0 && <tr><td colSpan={cfg.cols.length + 1} className="muted small">Записей нет</td></tr>}</tbody></table></div>
      )}
      {ed && <Modal title={ed.id ? 'Изменение' : 'Новая запись'} onClose={() => setEd(null)} footer={<><button className="btn" onClick={() => setEd(null)}>Отмена</button><Btn kind="pri" busy={busy} onClick={save}>Сохранить</Btn></>}>
        <div className="formGrid">{cfg.fields.map((f) => <Field key={f.key} label={f.label} hint={f.hint} className={f.wide || f.type === 'area' || f.type === 'json' || f.type === 'lines' ? 'full' : ''}>{input(f)}</Field>)}</div></Modal>}
    </div>
  );
}

const yn = (v: any) => (v ? <Badge kind="ok">да</Badge> : <Badge>нет</Badge>);
const EVENTS: [string, string][] = [['course_complete', 'Завершение курса'], ['test_pass', 'Успешный тест'], ['must_read', 'Ознакомление с обязательным'], ['profile_fill', 'Заполненный профиль'], ['comment', 'Комментарий'], ['idea', 'Идея'], ['thanks_received', 'Получена благодарность'], ['thanks_sent', 'Отправлена благодарность'], ['login_streak', 'Серия входов (каждые 5 дней)'], ['onboarding_done', 'Адаптация завершена'], ['onboarding_step', 'Шаг адаптации'], ['intro', 'Рассказ «Знакомьтесь»'], ['poll_answer', 'Ответ в опросе'], ['greeting', 'Поздравление коллеги']];

// ---------------------------------------------------------------- аудитории
export function AudiencesAdmin() {
  const q = useAudiences();
  const [edit, setEdit] = useState<any>(null);
  async function del(x: any) {
    if (!confirm(`Удалить аудиторию «${x.name}»? Публикации с этой аудиторией станут видны всем.`)) return;
    try { await api.del('/api/audiences/' + x.id); invalidate('audiences'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const sum = (r: any) => [r.all && 'все сотрудники', r.departments?.length && `подразделений: ${r.departments.length}${r.subtree ? ' (с вложенными)' : ''}`, r.users?.length && `сотрудников: ${r.users.length}`, r.job_titles?.length && 'должности: ' + r.job_titles.join(', '), r.newbies && 'новички'].filter(Boolean).join(' · ');
  return (
    <div className="stack">
      <div className="row"><h3 className="sp">Аудитории</h3><Btn kind="pri" onClick={() => setEdit({})}>Создать аудиторию</Btn></div>
      <div className="small muted">Аудитория — готовый список адресатов для публикаций, опросов, адаптации и наград. Выбирайте подразделения и людей — без правил и JSON.</div>
      {!q.data ? <Loading /> : !q.data.length ? <div className="card pad muted">Аудиторий пока нет</div> : (
        <div className="stackS">{q.data.map((x) => (
          <div key={x.id} className="card pad row">
            <div className="sp"><b>{x.name}</b><div className="small muted">{sum(x.rules || {}) || 'Состав не задан'} · {plural(x.size, ['человек', 'человека', 'человек'])}</div>{x.description && <div className="tiny muted">{x.description}</div>}</div>
            <Btn size="sm" onClick={() => setEdit(x)}>Изменить</Btn><Btn size="sm" kind="dng" onClick={() => del(x)}>Удалить</Btn>
          </div>))}</div>
      )}
      {edit && <AudienceForm item={edit.id ? edit : undefined} onClose={() => setEdit(null)} />}
    </div>
  );
}

// ---------------------------------------------------------------- геймификация
function GfConfig() {
  const q = useQuery<any>('adm:gf:me', () => api.get('/api/gf/me'), { stale: 0 });
  const [c, setC] = useState<any>(null);
  if (q.data && !c) setC({ ...q.data.config });
  if (!c) return <Loading />;
  const set = (k: string, v: any) => setC({ ...c, [k]: v });
  async function save() { try { await api.put('/api/gf/config', c); invalidate('gf'); toast({ title: 'Сохранено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  return (
    <div className="card pad stack"><h3>Настройки геймификации</h3>
      <div className="formGrid">
        <Field label="Название баллов"><Input value={c.currency_name} onChange={(e) => set('currency_name', e.target.value)} /></Field>
        <Field label="Значок"><Input value={c.currency_icon} maxLength={3} onChange={(e) => set('currency_icon', e.target.value)} /></Field>
        <Field label="Стиль"><Select value={c.style} onChange={(e) => set('style', e.target.value)}><option value="strict">Строгий (деловой)</option><option value="playful">Игровой (с анимацией)</option></Select></Field>
        <Field label="Благодарностей в сутки"><Input type="number" min={0} value={c.thanks_per_day} onChange={(e) => set('thanks_per_day', +e.target.value)} /></Field>
      </div>
      <Switch checked={c.enabled} onChange={(v) => set('enabled', v)} label="Геймификация включена" />
      <Switch checked={c.leaderboard} onChange={(v) => set('leaderboard', v)} label="Показывать рейтинги" />
      <Switch checked={c.streak_enabled} onChange={(v) => set('streak_enabled', v)} label="Серии дней" />
      <div><Btn kind="pri" onClick={save}>Сохранить</Btn></div>
    </div>
  );
}

function GfStats() {
  const q = useQuery<any>('adm:gf:stats', () => api.get('/api/gf/stats'), { stale: 0 });
  const d = q.data;
  const [g, setG] = useState({ user_id: 0, points: 0, xp: 0, comment: '' });
  async function grant() { try { await api.post('/api/gf/grant', g); invalidate('adm:'); toast({ title: 'Начислено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  if (!d) return <Loading />;
  return (
    <div className="stack">
      <div className="tzStats"><div className="tzStat"><span className="small muted">Начислено</span><b>{d.earned}</b></div><div className="tzStat"><span className="small muted">Потрачено</span><b>{d.spent}</b></div><div className="tzStat"><span className="small muted">Активны за 30 дней</span><b>{d.active_30d} / {d.users}</b></div></div>
      <div className="tzGrid"><div className="card pad stackS"><h3>За что начисляют (30 дней)</h3>{d.by_event.map((e: any) => <div key={e.event} className="row small"><span className="sp">{EVENTS.find((x) => x[0] === e.event)?.[1] || e.event}</span><b>{e.points}</b></div>)}</div>
        <div className="card pad stackS"><h3>Популярные награды</h3>{d.popular.length === 0 && <div className="small muted">Заказов пока нет</div>}{d.popular.map((p: any) => <div key={p.title} className="row small"><span className="sp">{p.title}</span><b>{p.orders}</b></div>)}</div></div>
      <div className="card pad stack"><h3>Ручное начисление</h3><div className="formGrid">
        <Field label="ID сотрудника"><Input type="number" value={g.user_id || ''} onChange={(e) => setG({ ...g, user_id: +e.target.value })} /></Field>
        <Field label="Баллы (можно отрицательные)"><Input type="number" value={g.points} onChange={(e) => setG({ ...g, points: +e.target.value })} /></Field>
        <Field label="Причина (попадёт в журнал)" className="full"><Input value={g.comment} onChange={(e) => setG({ ...g, comment: e.target.value })} /></Field></div>
        <div><Btn kind="pri" disabled={!g.user_id || !g.comment.trim()} onClick={grant}>Начислить</Btn></div></div>
    </div>
  );
}

export function GamificationAdmin() {
  const [t, setT] = useState<'cfg' | 'rules' | 'levels' | 'badges' | 'rewards' | 'stats'>('cfg');
  return (
    <div className="stack">
      <Tabs value={t} onChange={(v) => setT(v as any)} items={[{ id: 'cfg', label: 'Общее' }, { id: 'rules', label: 'Правила' }, { id: 'levels', label: 'Уровни' }, { id: 'badges', label: 'Достижения' }, { id: 'rewards', label: 'Награды' }, { id: 'stats', label: 'Отчёты' }]} />
      {t === 'cfg' && <GfConfig />}
      {t === 'stats' && <GfStats />}
      {t === 'rules' && <Cat cfg={{ path: 'gf/rules', title: 'Правила начисления', addLabel: 'Правило',
        cols: [{ key: 'title', label: 'Правило' }, { key: 'event', label: 'Событие', fmt: (v) => EVENTS.find((x) => x[0] === v)?.[1] || v }, { key: 'points', label: 'Баллы' }, { key: 'xp', label: 'Опыт' }, { key: 'day_limit', label: 'В сутки' }, { key: 'active', label: 'Активно', fmt: yn }],
        fields: [{ key: 'title', label: 'Название' }, { key: 'event', label: 'Событие', type: 'select', options: EVENTS, def: 'comment' }, { key: 'points', label: 'Баллы', type: 'number' }, { key: 'xp', label: 'Опыт (XP)', type: 'number' }, { key: 'day_limit', label: 'Максимум в сутки (0 — без лимита)', type: 'number' }, { key: 'total_limit', label: 'Максимум за всё время (0 — без лимита)', type: 'number' }, { key: 'audience_id', label: 'Аудитория' }, { key: 'starts_on', label: 'Действует с', type: 'date' }, { key: 'ends_on', label: 'Действует по', type: 'date' }, { key: 'active', label: 'Активно', type: 'bool', def: true }] }} />}
      {t === 'levels' && <Cat cfg={{ path: 'gf/levels', title: 'Уровни', cols: [{ key: 'xp_from', label: 'С опыта' }, { key: 'title', label: 'Название' }, { key: 'icon', label: 'Иконка' }, { key: 'color', label: 'Цвет', fmt: (v) => <span style={{ background: v, padding: '2px 14px', borderRadius: 8 }} /> }],
        fields: [{ key: 'xp_from', label: 'Опыта для уровня', type: 'number' }, { key: 'title', label: 'Название' }, { key: 'icon', label: 'Иконка (seedling, cap, star, heart, book, zap, users, bulb, shield, crown)' }, { key: 'color', label: 'Цвет (#hex)' }] }} />}
      {t === 'badges' && <Cat cfg={{ path: 'gf/badges', title: 'Достижения', cols: [{ key: 'title', label: 'Название' }, { key: 'tier', label: 'Ранг' }, { key: 'kind', label: 'Выдача' }, { key: 'description', label: 'Условие' }, { key: 'active', label: 'Активно', fmt: yn }],
        fields: [{ key: 'title', label: 'Название' }, { key: 'description', label: 'Описание', type: 'area' }, { key: 'icon', label: 'Иконка' }, { key: 'color', label: 'Цвет' }, { key: 'shape', label: 'Форма', type: 'select', options: [['circle', 'Круг'], ['shield', 'Щит'], ['hex', 'Шестиугольник'], ['star', 'Звезда']] }, { key: 'tier', label: 'Ранг', type: 'select', options: [['bronze', 'Бронза'], ['silver', 'Серебро'], ['gold', 'Золото']] }, { key: 'kind', label: 'Выдача', type: 'select', options: [['auto', 'Автоматически'], ['manual', 'Вручную']] }, { key: 'cond_event', label: 'Событие для счёта', type: 'select', options: [['', '—'], ...EVENTS] }, { key: 'cond_count', label: 'Сколько раз', type: 'number', def: 1 }, { key: 'cond_xp', label: 'Или набрать XP', type: 'number' }, { key: 'cond_streak', label: 'Или серия дней', type: 'number' }, { key: 'secret', label: 'Скрытое («сюрприз»)', type: 'bool' }, { key: 'active', label: 'Активно', type: 'bool', def: true }] }} />}
      {t === 'rewards' && <Cat cfg={{ path: 'gf/rewards-admin', title: 'Награды', cols: [{ key: 'title', label: 'Награда' }, { key: 'price', label: 'Цена' }, { key: 'stock', label: 'Остаток', fmt: (v) => v ?? '∞' }, { key: 'active', label: 'Активна', fmt: yn }],
        fields: [{ key: 'title', label: 'Название' }, { key: 'description', label: 'Описание', type: 'area' }, { key: 'kind', label: 'Тип', type: 'select', options: [['merch', 'Мерч'], ['dayoff', 'Выходной'], ['charity', 'Благотворительность'], ['privilege', 'Привилегия'], ['other', 'Другое']] }, { key: 'price', label: 'Цена в баллах', type: 'number' }, { key: 'per_user_limit', label: 'На человека (0 — без лимита)', type: 'number' }, { key: 'audience_id', label: 'Аудитория' }, { key: 'approval', label: 'Требует выдачи администратором', type: 'bool', def: true }, { key: 'active', label: 'Активна', type: 'bool', def: true }] }} />}
    </div>
  );
}

// ---------------------------------------------------------------- адаптация
function Items({ tid }: { tid: number }) {
  return <Cat cfg={{ path: 'onboarding/items', query: 'template_id=' + tid, title: 'Шаги чек-листа', defaults: { template_id: tid }, addLabel: 'Шаг',
    cols: [{ key: 'sort', label: '№' }, { key: 'section', label: 'Раздел' }, { key: 'title', label: 'Шаг' }, { key: 'assignee', label: 'Кто', fmt: (v) => ({ employee: 'Сотрудник', manager: 'Руководитель', mentor: 'Наставник', hr: 'HR' } as any)[v] }, { key: 'due_day', label: 'Срок, день' }],
    fields: [{ key: 'sort', label: 'Порядок', type: 'number' }, { key: 'section', label: 'Раздел' }, { key: 'title', label: 'Шаг' }, { key: 'description', label: 'Описание', type: 'area' }, { key: 'link', label: 'Ссылка (/learning, /people …)' }, { key: 'assignee', label: 'Ответственный', type: 'select', options: [['employee', 'Сотрудник'], ['manager', 'Руководитель'], ['mentor', 'Наставник'], ['hr', 'HR']] }, { key: 'due_day', label: 'Срок: день от начала', type: 'number', def: 7 }, { key: 'required', label: 'Обязательный', type: 'bool', def: true }, { key: 'auto_event', label: 'Автоотметка', type: 'select', options: [['', 'Нет'], ['profile_fill', 'Заполнен профиль'], ['intro', 'Написан рассказ «Знакомьтесь»']] }] }} />;
}
export function OnboardingAdmin() {
  const t = useQuery<any[]>('adm:onboarding/templates', () => api.get('/api/onboarding/templates'), { stale: 0 });
  const [sel, setSel] = useState(0);
  const [as, setAs] = useState({ user_id: 0, template_id: 0, mentor_id: 0 });
  const [asUser, setAsUser] = useState<UserLite[]>([]);
  const [asMentor, setAsMentor] = useState<UserLite[]>([]);
  async function assign() { try { await api.post('/api/onboarding/assign', { user_id: as.user_id, template_id: as.template_id, mentor_id: as.mentor_id || null }); toast({ title: 'План назначен', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  const cur = sel || t.data?.[0]?.id || 0;
  return (
    <div className="stack">
      <Cat cfg={{ path: 'onboarding/templates', title: 'Шаблоны адаптации', addLabel: 'Шаблон',
        cols: [{ key: 'name', label: 'Название' }, { key: 'duration_days', label: 'Дней' }, { key: 'auto_assign', label: 'Авто', fmt: yn }, { key: 'active', label: 'Активен', fmt: yn }],
        fields: [{ key: 'name', label: 'Название' }, { key: 'description', label: 'Описание', type: 'area' }, { key: 'audience_id', label: 'Кому назначается автоматически' }, { key: 'duration_days', label: 'Длительность, дней', type: 'number', def: 90 }, { key: 'auto_assign', label: 'Назначать автоматически по дате приёма', type: 'bool', def: true }, { key: 'active', label: 'Активен', type: 'bool', def: true }] }} />
      {t.data && t.data.length > 0 && <><div className="row"><Select style={{ maxWidth: 360 }} value={cur} onChange={(e) => setSel(+e.target.value)}>{t.data.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</Select></div><Items key={cur} tid={cur} /></>}
      <div className="card pad stack"><h3>Назначить вручную</h3><div className="formGrid">
        <Field label="Сотрудник"><UserPicker single value={asUser} onChange={(v) => { setAsUser(v); setAs({ ...as, user_id: v[0]?.id || 0 }); }} placeholder="Найти сотрудника…" /></Field>
        <Field label="Шаблон"><Select value={as.template_id} onChange={(e) => setAs({ ...as, template_id: +e.target.value })}><option value={0}>Выберите…</option>{(t.data || []).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</Select></Field>
        <Field label="Наставник"><UserPicker single value={asMentor} onChange={(v) => { setAsMentor(v); setAs({ ...as, mentor_id: v[0]?.id || 0 }); }} placeholder="Найти наставника…" /></Field></div>
        <div><Btn kind="pri" disabled={!as.user_id || !as.template_id} onClick={assign}>Назначить</Btn></div></div>
    </div>
  );
}

// ---------------------------------------------------------------- поля профиля, темы обращений, «Спросите директора», HR-данные
export function ProfileFieldsAdmin() {
  return <Cat cfg={{ path: 'profile-fields-admin', title: 'Дополнительные поля профиля (конструктор)', addLabel: 'Поле',
    cols: [{ key: 'sort', label: '№' }, { key: 'label', label: 'Название' }, { key: 'kind', label: 'Тип' }, { key: 'visibility', label: 'Кто видит' }, { key: 'in_list', label: 'В справочнике', fmt: yn }, { key: 'active', label: 'Активно', fmt: yn }],
    fields: [{ key: 'key', label: 'Ключ (латиница)', hint: 'Задаётся один раз' }, { key: 'label', label: 'Название' }, { key: 'kind', label: 'Тип', type: 'select', options: [['text', 'Строка'], ['longtext', 'Текст'], ['number', 'Число'], ['date', 'Дата'], ['select', 'Список'], ['multiselect', 'Мультисписок'], ['url', 'Ссылка'], ['phone', 'Телефон'], ['checkbox', 'Флажок']] }, { key: 'options', label: 'Варианты (JSON-массив для списков)', type: 'json', def: [] }, { key: 'help', label: 'Подсказка' }, { key: 'visibility', label: 'Кто видит', type: 'select', options: [['all', 'Все'], ['managers', 'Руководители и HR'], ['hr', 'Только HR'], ['self', 'Только сам сотрудник']] }, { key: 'editable_by', label: 'Кто редактирует', type: 'select', options: [['self', 'Сам сотрудник'], ['hr', 'Только HR']] }, { key: 'sort', label: 'Порядок', type: 'number' }, { key: 'in_list', label: 'Колонка в справочнике', type: 'bool' }, { key: 'filterable', label: 'Фильтр в справочнике', type: 'bool' }, { key: 'required', label: 'Обязательное', type: 'bool' }, { key: 'active', label: 'Активно', type: 'bool', def: true }] }} />;
}

export function FeedbackAdmin() {
  const q = useQuery<any>('adm:qa:cfg', () => api.get('/api/qa'), { stale: 0 });
  const [c, setC] = useState<any>(null);
  if (q.data && !c) setC({ ...q.data.config, responder_ids: [] });
  async function save() { try { await api.put('/api/qa/config', { ...c, responder_ids: String(c.responders ?? '').split(/[,\s]+/).filter(Boolean).map(Number) }); toast({ title: 'Сохранено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  return (
    <div className="stack">
      {c && <div className="card pad stack"><h3>«Спросите директора»</h3>
        <Field label="Заголовок раздела"><Input value={c.title} onChange={(e) => setC({ ...c, title: e.target.value })} /></Field>
        <Field label="ID отвечающих (директор, помощник)"><Input value={c.responders ?? ''} placeholder="1, 5" onChange={(e) => setC({ ...c, responders: e.target.value })} /></Field>
        <Switch checked={c.enabled} onChange={(v) => setC({ ...c, enabled: v })} label="Раздел включён" /><Switch checked={c.moderation} onChange={(v) => setC({ ...c, moderation: v })} label="Предварительная модерация вопросов" /><Switch checked={c.allow_anonymous} onChange={(v) => setC({ ...c, allow_anonymous: v })} label="Разрешить анонимные вопросы" />
        <div><Btn kind="pri" onClick={save}>Сохранить</Btn></div></div>}
      <Cat cfg={{ path: 'feedback-topics', title: 'Темы обращений', addLabel: 'Тема',
        cols: [{ key: 'title', label: 'Тема' }, { key: 'sla_hours', label: 'SLA, ч' }, { key: 'handler_ids', label: 'Обработчики', fmt: (v) => (v || []).join(', ') }, { key: 'active', label: 'Активна', fmt: yn }],
        fields: [{ key: 'title', label: 'Название' }, { key: 'description', label: 'Описание', type: 'area' }, { key: 'handler_ids', label: 'ID обработчиков', type: 'ids' }, { key: 'sla_hours', label: 'Срок реакции, часов', type: 'number', def: 72 }, { key: 'sort', label: 'Порядок', type: 'number' }, { key: 'active', label: 'Активна', type: 'bool', def: true }] }} />
    </div>
  );
}

export function HRDataAdmin() {
  const [qs, setQs] = useState('');
  const q = useQuery<any>('adm:hr:' + qs, () => api.get('/api/users?per=30&q=' + encodeURIComponent(qs)), { stale: 0 });
  const [ed, setEd] = useState<any>(null);
  const list: any[] = q.data?.items || q.data || [];
  async function save() { try { await api.put(`/api/users/${ed.id}/hr`, { hire_date: ed.hire_date || null, mentor_id: ed.mentor_id ? +ed.mentor_id : null, can_author: !!ed.can_author, hr_admin: !!ed.hr_admin, survey_manager: !!ed.survey_manager }); invalidate('adm:'); setEd(null); toast({ title: 'Сохранено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  return (
    <div className="card pad stack"><h3>Кадровые данные: дата приёма, наставник, права «Автор» и HR</h3>
      <Input placeholder="Поиск сотрудника…" value={qs} onChange={(e) => setQs(e.target.value)} />
      {!q.data ? <Loading /> : <div className="stackS">{list.map((u) => <div key={u.id} className="row"><Avatar name={u.name} src={u.avatar} size={32} /><span className="sp small"><b>{u.name}</b> <span className="muted">· {u.job_title} · ID {u.id}</span></span><span className="tiny muted">{u.hire_date ? 'с ' + u.hire_date : ''}</span><button className="btn sm" onClick={() => setEd({ id: u.id, name: u.name, hire_date: u.hire_date || '', mentor_id: u.mentor_id || '', can_author: !!u.can_author, hr_admin: !!u.hr_admin })}>Изменить</button></div>)}</div>}
      {ed && <Modal title={ed.name} onClose={() => setEd(null)} footer={<><button className="btn" onClick={() => setEd(null)}>Отмена</button><Btn kind="pri" onClick={save}>Сохранить</Btn></>}><div className="stack">
        <Field label="Дата приёма на работу"><Input type="date" value={ed.hire_date ? String(ed.hire_date).slice(0, 10) : ''} onChange={(e) => setEd({ ...ed, hire_date: e.target.value })} /></Field>
        <Field label="Наставник"><UserPicker single value={ed.mentor_id ? [{ id: +ed.mentor_id, name: ed.mentor_name || 'Сотрудник №' + ed.mentor_id }] : []} onChange={(v) => setEd({ ...ed, mentor_id: v[0]?.id || '', mentor_name: v[0]?.name || '' })} placeholder="Найти наставника…" /></Field>
        <Switch checked={ed.can_author} onChange={(v) => setEd({ ...ed, can_author: v })} label="Автор: готовит публикации (публикует редактор)" />
        <Switch checked={ed.hr_admin} onChange={(v) => setEd({ ...ed, hr_admin: v })} label="HR-администратор (аудитории, геймификация, адаптация)" />
        <Switch checked={!!ed.survey_manager} onChange={(v) => setEd({ ...ed, survey_manager: v })} label="Проводящий опросы: создаёт опросы и управляет только своими" /></div></Modal>}
    </div>
  );
}

// ---------------------------------------------------------------- email-рассылки
export function MailAdmin() {
  const st = useQuery<any>('adm:mail:settings', () => api.get('/api/mail/settings'), { stale: 0 });
  const list = useQuery<any[]>('adm:mail:list', () => api.get('/api/mail/campaigns'), { stale: 0 });
  const aud = useAudiences();
  const [s, setS] = useState<any>(null);
  const [c, setC] = useState({ subject: '', body: '', audience_id: '' as any, scheduled_at: '' });
  const [busy, setBusy] = useState(false);
  if (st.data && !s) setS({ ...st.data, password: '' });
  async function save() { try { await api.put('/api/mail/settings', { ...s, port: +s.port, per_minute: +s.per_minute, password: s.password || null }); invalidate('adm:'); toast({ title: 'Сохранено', kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function test() { try { await api.post('/api/mail/test'); toast({ title: 'Тестовое письмо отправлено вам', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  async function send() {
    setBusy(true);
    try { const r = await api.post<{ total: number }>('/api/mail/campaigns', { subject: c.subject, body: c.body, audience_id: c.audience_id ? +c.audience_id : null, scheduled_at: c.scheduled_at ? new Date(c.scheduled_at).toISOString() : null }); toast({ title: `Рассылка поставлена в очередь: ${r.total} писем`, kind: 'success' }); setC({ ...c, subject: '', body: '' }); invalidate('adm:'); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="stack">
      {s && <div className="card pad stack"><h3>Исходящая почта (SMTP)</h3><div className="formGrid">
        <Field label="Сервер"><Input value={s.host} onChange={(e) => setS({ ...s, host: e.target.value })} /></Field>
        <Field label="Порт"><Input type="number" value={s.port} onChange={(e) => setS({ ...s, port: e.target.value })} /></Field>
        <Field label="Защита"><Select value={s.security} onChange={(e) => setS({ ...s, security: e.target.value })}><option value="starttls">STARTTLS</option><option value="tls">TLS (SMTPS)</option><option value="none">Без шифрования</option></Select></Field>
        <Field label="Пользователь"><Input value={s.username} onChange={(e) => setS({ ...s, username: e.target.value })} /></Field>
        <Field label="Пароль" hint={s.has_password ? 'Задан — оставьте пустым, чтобы не менять' : ''}><Input type="password" autoComplete="new-password" value={s.password} onChange={(e) => setS({ ...s, password: e.target.value })} /></Field>
        <Field label="Адрес отправителя"><Input value={s.from_addr} onChange={(e) => setS({ ...s, from_addr: e.target.value })} /></Field>
        <Field label="Имя отправителя"><Input value={s.from_name} onChange={(e) => setS({ ...s, from_name: e.target.value })} /></Field>
        <Field label="Писем в минуту"><Input type="number" value={s.per_minute} onChange={(e) => setS({ ...s, per_minute: e.target.value })} /></Field></div>
        <Switch checked={s.enabled} onChange={(v) => setS({ ...s, enabled: v })} label="Отправка почты включена" />
        <div className="row"><Btn kind="pri" onClick={save}>Сохранить</Btn><button className="btn" onClick={test}>Отправить тестовое письмо мне</button></div></div>}
      <div className="card pad stack"><h3>Новая рассылка</h3>
        <Field label="Тема"><Input value={c.subject} onChange={(e) => setC({ ...c, subject: e.target.value })} /></Field>
        <Field label="Текст" hint="Переменные: {{name}} — полное имя, {{first_name}} — имя"><Textarea rows={6} value={c.body} onChange={(e) => setC({ ...c, body: e.target.value })} /></Field>
        <div className="formGrid"><Field label="Кому"><Select value={c.audience_id} onChange={(e) => setC({ ...c, audience_id: e.target.value })}><option value="">Всем сотрудникам</option>{(aud.data || []).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</Select></Field>
          <Field label="Отправить не раньше (необязательно)"><Input type="datetime-local" value={c.scheduled_at} onChange={(e) => setC({ ...c, scheduled_at: e.target.value })} /></Field></div>
        <div><Btn kind="pri" busy={busy} disabled={!c.subject.trim() || !c.body.trim()} onClick={send}><I.Send size={16} /> Отправить</Btn></div></div>
      <div className="card pad stackS"><h3>История рассылок</h3>{(list.data || []).map((m) => <div key={m.id} className="row small"><span className="sp clip"><b>{m.subject}</b> <span className="muted">· {m.audience || 'все'}</span></span><span className="muted">{m.sent}/{m.total}{m.failed ? `, ошибок ${m.failed}` : ''}</span><Badge kind={m.status === 'sent' ? 'ok' : m.status === 'failed' ? 'dng' : 'warn'}>{({ queued: 'В очереди', sending: 'Отправляется', sent: 'Отправлено', failed: 'Ошибка', draft: 'Черновик' } as any)[m.status]}</Badge></div>)}{list.data?.length === 0 && <div className="small muted">Рассылок ещё не было.</div>}</div>
    </div>
  );
}

// ---------------------------------------------------------------- модули портала
export function ModulesAdmin() {
  const q = useQuery<any[]>('adm:modules', () => api.get('/api/modules'), { stale: 0 });
  async function set(m: any, on: boolean) {
    try { await api.put(`/api/admin/modules/${m.key}`, { enabled: on }); invalidate('adm:modules'); toast({ title: `«${m.title}»: ${on ? 'включён' : 'отключён'}`, kind: 'success' }, 2000); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  if (!q.data) return <Loading />;
  return (
    <div className="stack">
      <div className="card pad stackS"><h3>Модули портала</h3>
        <div className="small muted">Отключённый модуль исчезает из меню у всех сотрудников, а его API закрывается (администратор сохраняет доступ). Изменения действуют в течение нескольких секунд; чтобы меню обновилось, сотрудникам достаточно перезагрузить страницу.</div>
        {q.data.map((m) => (
          <div key={m.key} className="row" style={{ padding: '6px 0', borderTop: '1px solid var(--line)' }}>
            <div className="sp"><b>{m.title}</b><div className="small muted">{m.descr}</div></div>
            <Badge kind={m.enabled ? 'ok' : 'dng'}>{m.enabled ? 'Включён' : 'Отключён'}</Badge>
            <Switch checked={m.enabled} onChange={(v) => set(m, v)} label="" />
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- оформление для всех
/** Название и логотип сайта + умолчания оформления. Умолчания действуют только на те настройки, которые пользователь не менял сам. */
export function UiDefaultsAdmin() {
  const q = useQuery<any>('adm:uidef', () => api.get('/api/ui-defaults'), { stale: 0 });
  const site = useQuery<any>('adm:site', () => api.get('/api/site'), { stale: 0 });
  const [f, setF] = useState<any>(null);
  const [st, setSt] = useState<any>(null);
  if (q.data && !f) setF({ design: 'glass', theme: '', ui: 100, fs: 100, font: '', bg: 'none', bgPhoto: '', bgDim: 55, sound: true, ...q.data });
  if (site.data && !st) setSt({ name: 'Вместе', logo: '', ...site.data });
  if (!f || !st) return <Loading />;
  const set = (p: any) => setF({ ...f, ...p });
  async function save() {
    try {
      const body = { ...f }; if (!body.theme) delete body.theme;
      await api.put('/api/ui-defaults', body);
      toast({ title: 'Оформление по умолчанию сохранено. Сотрудники увидят его после перезагрузки страницы.', kind: 'success' }, 3500);
    } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  async function saveSite() {
    try { await api.put('/api/admin/site', st); setState({ site: st }); document.title = document.title.replace(/ — .*$/, '') + ' — ' + st.name; toast({ title: 'Название и логотип сохранены', kind: 'success' }, 2500); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  return (
    <div className="stack">
      <div className="card pad stack"><h3>Название и логотип</h3>
        <div className="small muted">Показываются в левом верхнем углу, на экране входа и в заголовке вкладки.</div>
        <Field label="Название сайта"><Input value={st.name} maxLength={60} onChange={(e) => setSt({ ...st, name: e.target.value })} /></Field>
        <ImageUpload label="Логотип" value={st.logo} onChange={(v) => setSt({ ...st, logo: v })} />
        <div><Btn kind="pri" onClick={saveSite} disabled={!st.name.trim()}>Сохранить</Btn></div>
      </div>
      <div className="card pad stack"><h3>Оформление по умолчанию</h3>
        <div className="small muted">Применяется ко всем сотрудникам, кроме тех настроек, которые человек уже выбрал сам (его личный выбор не перезаписывается). Кнопка «Сбросить» в настройках сотрудника возвращает его к этим значениям.</div>
        <div className="formGrid">
          <Field label="Дизайн"><Select value={f.design} onChange={(e) => set({ design: e.target.value })}>{DESIGNS.map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}</Select></Field>
          <Field label="Цветовая палитра"><Select value={f.theme} onChange={(e) => set({ theme: e.target.value })}><option value="">Рекомендуемая для дизайна</option>{THEMES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}</Select></Field>
          <Field label="Шрифт"><Select value={f.font} onChange={(e) => set({ font: e.target.value })}><option value="">Как в дизайне</option>{FONT_LIST.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select></Field>
          <Field label="Масштаб элементов, %"><Input type="number" min={50} max={150} step={5} value={f.ui} onChange={(e) => set({ ui: +e.target.value })} /></Field>
          <Field label="Размер шрифта, %"><Input type="number" min={50} max={150} step={5} value={f.fs} onChange={(e) => set({ fs: +e.target.value })} /></Field>
        </div>
        <div className="small bold">Фон</div>
        <div className="apBgGrid">
          {BGS.map((b) => <button key={b.id} type="button" className={'apBg' + (f.bg === b.id ? ' on' : '')} style={b.css ? { backgroundImage: b.css, backgroundSize: b.size === 'cover' ? 'cover' : b.size } : undefined} onClick={() => set({ bg: b.id })}>{b.label}</button>)}
          <button type="button" className={'apBg' + (f.bg === 'photo' ? ' on' : '')} style={f.bgPhoto ? { backgroundImage: `url("${f.bgPhoto}")`, backgroundSize: 'cover' } : undefined} onClick={() => f.bgPhoto && set({ bg: 'photo' })}>Фото</button>
        </div>
        <label className="row small" style={{ gap: 8 }}>Однотонный фон: <input type="color" value={/^#[0-9a-f]{6}$/i.test(f.bg) ? f.bg : '#3b82f6'} onChange={(e) => set({ bg: e.target.value })} /></label>
        <div className="small bold">Фотография для фона (в том числе по внешней ссылке)</div>
        <PhotoPicker value={f.bgPhoto} onChange={(u) => set({ bgPhoto: u, bg: u ? 'photo' : f.bg === 'photo' ? 'none' : f.bg })} />
        {f.bg === 'photo' && <Field label={`Затемнение: ${f.bgDim}%`}><input type="range" min={0} max={90} step={5} value={f.bgDim} onChange={(e) => set({ bgDim: +e.target.value })} /></Field>}
        <Switch checked={f.sound !== false} onChange={(v) => set({ sound: v })} label="Звуковые уведомления включены" />
        <div><Btn kind="pri" onClick={save}>Сохранить</Btn></div>
      </div>
    </div>
  );
}
