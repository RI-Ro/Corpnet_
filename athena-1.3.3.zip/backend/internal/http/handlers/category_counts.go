package handlers

import (
	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/repository"
)

// countedCategories — категории, для которых в боковом меню показывается
// счётчик.
//
// счётчик нужен только там, где число требует ДЕЙСТВИЯ —
// «на контроле», «на согласование», «на подписи», «ожидают регистрации»,
// «на регистрацию». В остальных разделах («все документы», «входящие»,
// «исходящие», «исполнено», архив, журналы) число ни к чему не призывает:
// оно только растёт и перестаёт восприниматься, обесценивая те пять
// счётчиков, на которые действительно надо реагировать.
//
// Список согласован со CATEGORIES во frontend/src/components/Layout.jsx:
// лишний счётчик здесь был бы посчитан в БД и выброшен на клиенте, то есть
// это ещё и экономия запроса, который опрашивается раз в минуту каждым
// пользователем.
var countedCategories = []repository.Category{
	repository.CategoryAwaiting,
	repository.CategoryOnApproval,
	repository.CategoryOnSigning,
	repository.CategoryControl,
	repository.CategoryPrintUnreg,
	// «Резолюции Вам»: число здесь прямо призывает к действию — это
	// поручения, по которым человек ещё не отчитался.
	repository.CategoryMyResolutions,
}

// CategoryCounts GET /api/documents/category-counts — количество документов в
// каждой категории бокового меню (#41).
//
// Фронт опрашивает этот эндпоинт периодически и дополнительно по приходу
// WS-уведомления, чтобы числа менялись сами, а не только при клике на раздел.
// Поэтому запрос сделан дешёвым: все категории считаются ОДНИМ обращением к
// БД, условия берутся из того же построителя, что и у самих списков
// (repository.categoryCondition) — иначе счётчик и список расходились бы.
//
// RLS действует как обычно: пользователь видит количество только тех
// документов, которые ему доступны.
func (h *DocumentsHandler) CategoryCounts(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	counts := map[string]int64{}
	var pendingRegistration int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var deptID int64
		if err := tx.QueryRow(c.Context(),
			`SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); err != nil {
			return err
		}
		res, err := h.repo.CategoryCounts(c.Context(), tx, countedCategories, userID, deptID)
		if err != nil {
			return err
		}
		for cat, n := range res {
			counts[string(cat)] = n
		}

		pendingRegistration = res[repository.CategoryAwaiting]
		return nil
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось посчитать документы по категориям")
	}
	return c.JSON(fiber.Map{"counts": counts, "pending_registration": pendingRegistration})
}
