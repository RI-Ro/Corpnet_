package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"errors"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/gofiber/contrib/websocket"
	"github.com/gofiber/fiber/v2"
	"github.com/valyala/fasthttp"

	"corpnet/internal/server"
)

// Модуль предназначен для HTTP-слоя на Fiber (fasthttp) с prefork.
//
// Prefork: мастер (fiber.IsChild() == false) только порождает и сторожит рабочие процессы (по числу PREFORK, auto — ядра);
// каждый рабочий — полноценный экземпляр приложения со своим пулом БД, слушающий общий порт через SO_REUSEPORT.
// События между рабочими идут через Redis Pub/Sub или PostgreSQL (hub), сессии и блокировки — в общем KV/БД,
// фоновые циклы работают в одном процессе, выбранном выборами лидера (server.Run).
//
// Обработчики приложения — стандартные net/http; мост bridge превращает запрос fasthttp в *http.Request и обратно,
// не буферизуя большие ответы (видео, файлы, SSE идут потоком). WebSocket обслуживается Fiber напрямую.

const bufferLimit = 256 << 10 // ответы до 256 КБ уходят одним куском с Content-Length, больше — потоком

type bridgeWriter struct {
	hdr     http.Header
	status  int
	wrote   bool
	buf     bytes.Buffer
	stream  bool
	pw      *io.PipeWriter
	pr      *io.PipeReader
	started chan struct{}
	once    sync.Once
}

func newBridgeWriter() *bridgeWriter {
	return &bridgeWriter{hdr: http.Header{}, started: make(chan struct{})}
}

func (w *bridgeWriter) Header() http.Header { return w.hdr }
func (w *bridgeWriter) WriteHeader(code int) {
	if !w.wrote {
		w.wrote, w.status = true, code
	}
}
func (w *bridgeWriter) startStream() {
	w.once.Do(func() {
		w.pr, w.pw = io.Pipe()
		w.stream = true
		close(w.started)
		if w.buf.Len() > 0 {
			w.pw.Write(w.buf.Bytes()) // блокируется до чтения fasthttp: мост уже вышел из ожидания
			w.buf.Reset()
		}
	})
}
func (w *bridgeWriter) Write(p []byte) (int, error) {
	if !w.wrote {
		w.WriteHeader(200)
	}
	if w.stream {
		return w.pw.Write(p)
	}
	w.buf.Write(p)
	if w.buf.Len() > bufferLimit {
		w.startStream()
	}
	return len(p), nil
}
func (w *bridgeWriter) Flush() {
	if !w.wrote {
		w.WriteHeader(200)
	}
	w.startStream()
}
func (w *bridgeWriter) finish() {
	if w.stream {
		w.pw.Close()
	}
}

// bridge — fiber.Handler, исполняющий net/http обработчик.
func bridge(h http.Handler) fiber.Handler {
	return func(c *fiber.Ctx) error {
		fc := c.Context()
		u, err := url.ParseRequestURI(string(fc.RequestURI()))
		if err != nil {
			return c.SendStatus(fiber.StatusBadRequest)
		}
		ctx, cancel := context.WithCancel(context.Background())
		r := &http.Request{
			Method: string(fc.Method()), URL: u, RequestURI: string(fc.RequestURI()),
			Proto: "HTTP/1.1", ProtoMajor: 1, ProtoMinor: 1,
			Header: make(http.Header, 16), Host: string(fc.Host()), RemoteAddr: fc.RemoteAddr().String(),
		}
		fc.Request.Header.VisitAll(func(k, v []byte) { r.Header.Add(string(k), string(v)) })
		r.ContentLength = int64(fc.Request.Header.ContentLength())
		if fc.IsBodyStream() {
			r.Body = io.NopCloser(fc.RequestBodyStream())
		} else {
			r.Body = io.NopCloser(bytes.NewReader(fc.Request.Body()))
		}
		if fc.IsTLS() {
			r.TLS = &tls.ConnectionState{}
		}
		r = r.WithContext(ctx)
		w := newBridgeWriter()
		done := make(chan struct{})
		go func() {
			defer func() {
				if rec := recover(); rec != nil {
					slog.Error("panic в обработчике", "path", r.URL.Path, "panic", rec)
					if !w.wrote {
						w.status, w.wrote = 500, true
					}
				}
				w.finish()
				close(done)
			}()
			h.ServeHTTP(w, r)
		}()
		select {
		case <-w.started: // потоковый ответ
			applyHeaders(fc, w)
			cl := -1
			if v := w.hdr.Get("Content-Length"); v != "" {
				if n, err := strconv.Atoi(v); err == nil {
					cl = n
				}
			}
			fc.Response.SetBodyStream(&cancelReader{PipeReader: w.pr, cancel: cancel}, cl)
		case <-done:
			cancel()
			applyHeaders(fc, w)
			if r.Method != http.MethodHead {
				fc.Response.SetBodyRaw(append([]byte(nil), w.buf.Bytes()...))
			}
		}
		return nil
	}
}

type cancelReader struct {
	*io.PipeReader
	cancel func()
}

func (c *cancelReader) Close() error { c.cancel(); return c.PipeReader.Close() }

func applyHeaders(fc *fasthttp.RequestCtx, w *bridgeWriter) {
	st := w.status
	if st == 0 {
		st = 200
	}
	fc.Response.SetStatusCode(st)
	for k, vs := range w.hdr {
		if strings.EqualFold(k, "Content-Length") && w.stream {
			continue // длину выставляет SetBodyStream
		}
		for i, v := range vs {
			if i == 0 && !strings.EqualFold(k, "Set-Cookie") {
				fc.Response.Header.Set(k, v)
			} else {
				fc.Response.Header.Add(k, v)
			}
		}
	}
}

// newApp собирает приложение Fiber: WebSocket напрямую, всё остальное — через мост к net/http обработчику приложения.
func newApp(cfg server.Config, prefork bool, srv *server.Server) *fiber.App {
	app := fiber.New(fiber.Config{
		Prefork:                      prefork,
		DisableStartupMessage:        true,
		AppName:                      "Вместе",
		ServerHeader:                 "",
		StreamRequestBody:            true,
		BodyLimit:                    int(cfg.MaxUploadMB+8) << 20,
		ReadBufferSize:               16 << 10,
		WriteBufferSize:              16 << 10,
		ReadTimeout:                  15 * time.Minute, // предельное время приёма запроса, включая загрузки
		IdleTimeout:                  120 * time.Second,
		Concurrency:                  256 * 1024,
		DisablePreParseMultipartForm: true,
		ErrorHandler: func(c *fiber.Ctx, err error) error {
			code := fiber.StatusInternalServerError
			var fe *fiber.Error
			if errors.As(err, &fe) {
				code = fe.Code
			}
			return c.Status(code).JSON(fiber.Map{"error": http.StatusText(code)})
		},
	})
	if srv == nil {
		return app
	}
	app.Use("/api/ws", func(c *fiber.Ctx) error {
		if !websocket.IsWebSocketUpgrade(c) {
			return fiber.ErrUpgradeRequired
		}
		r := &http.Request{Header: http.Header{}, Host: string(c.Context().Host())}
		c.Context().Request.Header.VisitAll(func(k, v []byte) { r.Header.Add(string(k), string(v)) })
		u, code := srv.WSAuthorize(r)
		if code != 0 {
			return c.SendStatus(code)
		}
		c.Locals("user", u)
		return c.Next()
	})
	app.Get("/api/ws", websocket.New(func(conn *websocket.Conn) {
		if u, ok := conn.Locals("user").(*server.User); ok {
			srv.ServeWSConn(conn, u)
		}
	}, websocket.Config{ReadBufferSize: 1024, WriteBufferSize: 4096}))
	app.All("/*", bridge(srv.Handler()))
	return app
}

// listenApp запускает Fiber (TLS — по настройкам) и возвращает при остановке.
func listenApp(app *fiber.App, cfg server.Config) error {
	if cfg.TLSCert != "" {
		return app.ListenTLS(cfg.Addr, cfg.TLSCert, cfg.TLSKey)
	}
	return app.Listen(cfg.Addr)
}

// runMaster — мастер prefork: порождает рабочих (число — runtime.GOMAXPROCS), следит за ними, пересылает SIGHUP (переоткрытие журналов).
func runMaster(ctx context.Context, cfg server.Config, log *slog.Logger) error {
	n := cfg.Prefork
	if n < 1 {
		n = 1
	}
	runtime.GOMAXPROCS(n) // Fiber запускает столько рабочих, сколько GOMAXPROCS; сами рабочие получают по одному P
	app := newApp(cfg, true, nil)
	hup := make(chan os.Signal, 1)
	signal.Notify(hup, syscall.SIGHUP)
	go func() {
		for range hup {
			forwardSignal(syscall.SIGHUP)
		}
	}()
	go func() { // SIGTERM/SIGINT мастеру: передать рабочим, дождаться их корректного завершения
		<-ctx.Done()
		forwardSignal(syscall.SIGTERM)
		for i := 0; i < 40 && countChildren() > 0; i++ {
			time.Sleep(500 * time.Millisecond)
		}
		os.Exit(0)
	}()
	if cfg.RedirectAddr != "" && cfg.TLSCert != "" { // http → https; рабочие заняты основным портом
		if ln, err := net.Listen("tcp", cfg.RedirectAddr); err == nil {
			go http.Serve(ln, redirectHandler(cfg.Addr))
		} else {
			log.Warn("HTTP_REDIRECT_ADDR", "err", err)
		}
	}
	log.Info("prefork: мастер запущен", "addr", cfg.Addr, "workers", n, "pid", os.Getpid())
	return listenApp(app, cfg)
}

func countChildren() int {
	n := 0
	eachChild(func(int) { n++ })
	return n
}

// forwardSignal посылает сигнал дочерним процессам мастера (Linux: /proc).
func forwardSignal(sig syscall.Signal) { eachChild(func(pid int) { syscall.Kill(pid, sig) }) }

func eachChild(fn func(pid int)) {
	me := os.Getpid()
	ents, _ := os.ReadDir("/proc")
	for _, e := range ents {
		pid, err := strconv.Atoi(e.Name())
		if err != nil {
			continue
		}
		b, err := os.ReadFile("/proc/" + e.Name() + "/stat")
		if err != nil {
			continue
		}
		s := string(b)
		if i := strings.LastIndexByte(s, ')'); i > 0 {
			f := strings.Fields(s[i+1:])
			if len(f) > 1 && f[1] == strconv.Itoa(me) {
				fn(pid)
			}
		}
	}
}

func redirectHandler(httpsAddr string) http.Handler {
	_, port, _ := net.SplitHostPort(httpsAddr)
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/healthz" {
			w.WriteHeader(200)
			_, _ = w.Write([]byte("ok"))
			return
		}
		host := r.Host
		if h, _, err := net.SplitHostPort(host); err == nil {
			host = h
		}
		if strings.Contains(host, ":") && !strings.HasPrefix(host, "[") {
			host = "[" + host + "]"
		}
		if port != "" && port != "443" {
			host += ":" + port
		}
		http.Redirect(w, r, "https://"+host+r.URL.RequestURI(), http.StatusPermanentRedirect)
	})
}

func logListen(log *slog.Logger, cfg server.Config) {
	scheme := "http"
	if cfg.TLSCert != "" {
		scheme = "https"
	}
	log.Info("listening", "addr", cfg.Addr, "scheme", scheme, "instance", cfg.InstanceID, "pid", os.Getpid(), "prefork", cfg.Prefork >= 1)
}
