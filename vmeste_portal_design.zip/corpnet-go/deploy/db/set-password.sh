#!/usr/bin/env bash
# Смена пароля учётной записи.
#   DATABASE_URL=postgres://... ./set-password.sh <логин или email>
# Пароль запрашивается скрытно (или берётся из переменной NEW_PASSWORD). Хэш bcrypt считает PostgreSQL (pgcrypto),
# пароль передаётся через окружение процесса psql (нужен psql 15+), а не через аргументы, ни в историю shell. Все открытые сессии пользователя завершаются.
set -euo pipefail
: "${DATABASE_URL:?укажите DATABASE_URL}"
WHO="${1:?использование: ./set-password.sh <логин или email>}"
PASS="${NEW_PASSWORD:-}"
if [ -z "$PASS" ]; then
  read -r -s -p "Новый пароль для $WHO: " PASS; echo
  read -r -s -p "Повторите пароль: " P2; echo
  [ "$PASS" = "$P2" ] || { echo "пароли не совпадают" >&2; exit 1; }
fi
[ "${#PASS}" -ge 8 ] || { echo "пароль короче 8 символов" >&2; exit 1; }
CP_PASS="$PASS" psql "$DATABASE_URL" -X -q -v ON_ERROR_STOP=1 -v who="$WHO" <<'SQL'
\getenv pw CP_PASS
CREATE EXTENSION IF NOT EXISTS pgcrypto;
BEGIN;
WITH u AS (
  UPDATE users SET password_hash = crypt(:'pw', gen_salt('bf', 10))
  WHERE login = :'who' OR lower(email) = lower(:'who')
  RETURNING id
), s AS (DELETE FROM sessions WHERE user_id IN (SELECT id FROM u))
SELECT count(*) AS updated FROM u \gset
\if :updated
  COMMIT;
  \echo пароль изменён (пользователей: :updated)
\else
  ROLLBACK;
  \echo пользователь не найден
\endif
SQL
echo "Если сессии хранятся в Redis (SESSION_STORE не pg), прежний вход действует до истечения срока — при необходимости очистите ключи sess:* в Redis."
