package service

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)

var ErrStageNotPending = errors.New("stage is not in pending status")
var ErrForbiddenApprover = errors.New("user is not the approver for this stage")

type ApprovalService struct {
	access *AccessService
}

func NewApprovalService(access *AccessService) *ApprovalService {
	return &ApprovalService{access: access}
}

// StageInput описывает этап при создании маршрута; DependsOnIdx — индексы
// (в пределах этого же запроса на создание) этапов, от которых зависит
// активация данного этапа. Это и даёт "гибкую очерёдность": можно
// выразить последовательные, параллельные и смешанные маршруты одной моделью.
type StageInput struct {
	StageType    string
	ApproverID   int64
	DisplayOrder int
	// StepNo — номер шага согласования (см. RouteInput).
	StepNo       int
	DependsOnIdx []int
}

// validateAddedApprover проверяет сотрудника, которого согласующий добавляет в
// маршрут «на ходу» (перед собой или после себя). Требования те же, что к
// маршруту при создании документа: действующая учётная запись, роль
// согласующего нужного типа, не автор документа и не участник маршрута с
// незавершённым этапом. Без этой проверки в маршрут можно было добавить
// кого угодно — в том числе самого автора, который согласовал бы свой же
// документ.
func (s *ApprovalService) validateAddedApprover(ctx context.Context, tx pgx.Tx, documentID, newApproverID int64, stageType string) error {
	if stageType != "hierarchy" && stageType != "cross_dept" {
		stageType = "hierarchy"
	}
	var authorID int64
	if err := tx.QueryRow(ctx, `SELECT author_id FROM documents WHERE id=$1`, documentID).Scan(&authorID); err != nil {
		return fmt.Errorf("lookup document: %w", err)
	}
	if newApproverID == authorID {
		return ErrSelfApproval
	}
	roleOK, _, err := s.LoadRoleCheckers(ctx, tx, []int64{newApproverID})
	if err != nil {
		return err
	}
	if !roleOK(newApproverID, stageType) {
		return ErrApproverWrongRole
	}
	var dup bool
	if err := tx.QueryRow(ctx, `
		SELECT EXISTS (SELECT 1 FROM approval_stages
		                WHERE document_id=$1 AND approver_id=$2 AND status IN ('pending','waiting_deps'))`,
		documentID, newApproverID).Scan(&dup); err != nil {
		return err
	}
	if dup {
		return ErrDuplicateApprover
	}
	return nil
}

// CreateRoute создаёт этапы согласования и их зависимости одной транзакцией,
// затем активирует (переводит в pending) все этапы без зависимостей.
// AddApproverAfter вставляет ДОПОЛНИТЕЛЬНОГО согласующего в цепочку сразу
// ПОСЛЕ уже пройденного этапа afterStageID (реализует «донаправление»:
// согласующий одобряет и направляет на доп. согласование новому пользователю).
// В DAG: новый этап зависит от afterStageID (только что approved → активен);
// все этапы, что зависели от afterStageID (следующий согласующий/подпись),
// теперь зависят и от нового — то есть новый согласующий встаёт в очередь
// ПЕРЕД ними. Возвращает id нового этапа.
func (s *ApprovalService) AddApproverAfter(ctx context.Context, tx pgx.Tx, documentID, afterStageID, newApproverID int64, stageType string) (int64, error) {
	if stageType != "hierarchy" && stageType != "cross_dept" {
		stageType = "hierarchy"
	}
	var baseOrder int
	if err := tx.QueryRow(ctx, `SELECT display_order FROM approval_stages WHERE id=$1`, afterStageID).Scan(&baseOrder); err != nil {
		return 0, fmt.Errorf("lookup base stage: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET display_order = display_order + 1
		WHERE document_id=$1 AND display_order > $2`, documentID, baseOrder); err != nil {
		return 0, fmt.Errorf("shift orders: %w", err)
	}
	var newID int64
	if err := tx.QueryRow(ctx, `
		INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, status)
		VALUES ($1, $2::stage_type, $3, $4, 'waiting_deps')
		RETURNING id`, documentID, stageType, newApproverID, baseOrder+1).Scan(&newID); err != nil {
		return 0, fmt.Errorf("insert added stage: %w", err)
	}
	// Этапы, ранее зависевшие от afterStageID, перецепляем на новый этап...
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stage_dependencies SET depends_on_stage_id = $1
		WHERE depends_on_stage_id = $2 AND stage_id <> $1`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("repoint deps: %w", err)
	}
	// ...а новый этап зависит от afterStageID.
	if _, err := tx.Exec(ctx, `
		INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
		VALUES ($1, $2) ON CONFLICT DO NOTHING`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("insert new dep: %w", err)
	}
	if err := s.RenumberSteps(ctx, tx, documentID); err != nil {
		return 0, err
	}
	if _, err := s.activateStage(ctx, tx, documentID, newID); err != nil {
		return 0, err
	}
	return newID, nil
}

// AddApproverBefore вставляет согласующего ПЕРЕД указанным (ещё не пройденным)
// этапом beforeStageID, НЕ проставляя отметку о согласовании текущего
// пользователя (#4 — «направить на согласование перед мной»). Новый этап
// занимает место beforeStage в DAG: перенимает его зависимости, а beforeStage
// начинает зависеть от нового и уходит в ожидание. Возвращает id нового этапа.
func (s *ApprovalService) AddApproverBefore(ctx context.Context, tx pgx.Tx, documentID, beforeStageID, newApproverID int64, stageType string) (int64, error) {
	if stageType != "hierarchy" && stageType != "cross_dept" {
		stageType = "hierarchy"
	}
	var baseOrder int
	if err := tx.QueryRow(ctx, `SELECT display_order FROM approval_stages WHERE id=$1 AND document_id=$2`, beforeStageID, documentID).Scan(&baseOrder); err != nil {
		return 0, fmt.Errorf("lookup before stage: %w", err)
	}
	// Сдвигаем порядок начиная с beforeStage, чтобы вставить новый на его место.
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET display_order = display_order + 1
		WHERE document_id=$1 AND display_order >= $2`, documentID, baseOrder); err != nil {
		return 0, fmt.Errorf("shift orders: %w", err)
	}
	var newID int64
	if err := tx.QueryRow(ctx, `
		INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, status)
		VALUES ($1, $2::stage_type, $3, $4, 'waiting_deps')
		RETURNING id`, documentID, stageType, newApproverID, baseOrder).Scan(&newID); err != nil {
		return 0, fmt.Errorf("insert stage: %w", err)
	}
	// Новый этап перенимает зависимости beforeStage.
	if _, err := tx.Exec(ctx, `
		INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
		SELECT $1, depends_on_stage_id FROM approval_stage_dependencies WHERE stage_id=$2
		ON CONFLICT DO NOTHING`, newID, beforeStageID); err != nil {
		return 0, fmt.Errorf("copy deps: %w", err)
	}
	// beforeStage теперь зависит ТОЛЬКО от нового этапа и уходит в ожидание.
	if _, err := tx.Exec(ctx, `DELETE FROM approval_stage_dependencies WHERE stage_id=$1`, beforeStageID); err != nil {
		return 0, fmt.Errorf("clear before deps: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id) VALUES ($1, $2)`, beforeStageID, newID); err != nil {
		return 0, fmt.Errorf("add dep to new: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET status='waiting_deps', decided_at=NULL WHERE id=$1`, beforeStageID); err != nil {
		return 0, fmt.Errorf("reset before stage: %w", err)
	}
	if err := s.RenumberSteps(ctx, tx, documentID); err != nil {
		return 0, err
	}
	if _, err := s.activateStage(ctx, tx, documentID, newID); err != nil {
		return 0, err
	}
	return newID, nil
}

// SendToApproverBefore — «направить на согласование перед мной» (#4): текущий
// согласующий stageID НЕ ставит отметку о согласовании, а добавляет согласующего
// перед своим этапом. Возвращает id нового согласующего (для уведомления).
func (s *ApprovalService) SendToApproverBefore(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID, newApproverID int64, stageType string) (int64, error) {
	var approverID int64
	var status string
	if err := tx.QueryRow(ctx, `SELECT approver_id, status FROM approval_stages WHERE id=$1 AND document_id=$2 FOR UPDATE`,
		stageID, documentID).Scan(&approverID, &status); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, ErrForbiddenApprover
		}
		return 0, fmt.Errorf("lookup stage: %w", err)
	}
	if actingUserID != approverID {
		return 0, ErrForbiddenApprover
	}
	if status != "pending" {
		return 0, ErrStageNotPending
	}
	if newApproverID == actingUserID || newApproverID == approverID {
		return 0, ErrSelfApproval
	}
	if err := s.validateAddedApprover(ctx, tx, documentID, newApproverID, stageType); err != nil {
		return 0, err
	}
	newID, err := s.AddApproverBefore(ctx, tx, documentID, stageID, newApproverID, stageType)
	if err != nil {
		return 0, err
	}
	var newName string
	_ = tx.QueryRow(ctx, `SELECT full_name FROM users WHERE id=$1`, newApproverID).Scan(&newName)
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'approver_added', $3)`,
		documentID, actingUserID,
		fmt.Sprintf("направлено на согласование перед собой: %s (без отметки о согласовании)", newName)); err != nil {
		return 0, fmt.Errorf("insert history: %w", err)
	}
	return newID, nil
}

// ForwardSigner — подписант перенаправляет документ на подпись ДРУГОМУ
// подписанту (#1). Текущий подписант при этом НЕ подписывает, а его действие
// фиксируется как СОГЛАСОВАНИЕ: его signing-этап помечается approved (без выдачи
// исходящего номера), а следом создаётся новый signing-этап для нового
// подписанта. Аналогично «доп. согласованию», но для этапа подписи. Возвращает
// id нового подписанта (для уведомления).
func (s *ApprovalService) ForwardSigner(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID, newSignerID int64, comment string) (int64, error) {
	var approverID int64
	var status, stageType string
	if err := tx.QueryRow(ctx, `SELECT approver_id, status, stage_type FROM approval_stages WHERE id=$1 AND document_id=$2 FOR UPDATE`,
		stageID, documentID).Scan(&approverID, &status, &stageType); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, ErrForbiddenApprover
		}
		return 0, fmt.Errorf("lookup stage: %w", err)
	}
	if actingUserID != approverID {
		return 0, ErrForbiddenApprover
	}
	if status != "pending" {
		return 0, ErrStageNotPending
	}
	if stageType != "signing" {
		return 0, fmt.Errorf("этап не является подписью")
	}
	if newSignerID == actingUserID {
		return 0, ErrSelfApproval
	}
	// Проверяем, что новый подписант имеет право подписи.
	_, signerOK, err := s.LoadRoleCheckers(ctx, tx, []int64{newSignerID})
	if err != nil {
		return 0, err
	}
	if !signerOK(newSignerID) {
		return 0, ErrSignerWrongRole
	}
	// Текущий этап подписи → approved как СОГЛАСОВАНИЕ (без Sign/номера).
	// В комментарий этапа пишем понятную формулировку для маршрута (#4).
	stageComment := "Документ согласован и передан на подпись другому подписанту"
	if comment != "" {
		stageComment = comment + " · документ согласован и передан на подпись другому подписанту"
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET status='approved', decided_at=now(), comment=$2 WHERE id=$1`,
		stageID, stageComment); err != nil {
		return 0, fmt.Errorf("approve current signing stage: %w", err)
	}
	// Новый signing-этап сразу после текущего (использует ту же перецепку DAG).
	newID, err := s.addStageAfter(ctx, tx, documentID, stageID, newSignerID, "signing")
	if err != nil {
		return 0, err
	}
	var newName string
	_ = tx.QueryRow(ctx, `SELECT full_name FROM users WHERE id=$1`, newSignerID).Scan(&newName)
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'stage_approved', $3),
		       ($1, $2, 'approver_added', $4)`,
		documentID, actingUserID,
		func() string {
			if comment != "" {
				return comment
			}
			return "согласовано, направлено на подпись"
		}(),
		fmt.Sprintf("направлено на подпись другому подписанту: %s", newName)); err != nil {
		return 0, fmt.Errorf("insert history: %w", err)
	}
	return newID, nil
}

// addStageAfter — общая вставка этапа сразу ПОСЛЕ afterStageID (для доп.
// согласования и переадресации подписи). stageType: hierarchy|cross_dept|signing.
func (s *ApprovalService) addStageAfter(ctx context.Context, tx pgx.Tx, documentID, afterStageID, newApproverID int64, stageType string) (int64, error) {
	var baseOrder int
	if err := tx.QueryRow(ctx, `SELECT display_order FROM approval_stages WHERE id=$1`, afterStageID).Scan(&baseOrder); err != nil {
		return 0, fmt.Errorf("lookup base stage: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET display_order = display_order + 1
		WHERE document_id=$1 AND display_order > $2`, documentID, baseOrder); err != nil {
		return 0, fmt.Errorf("shift orders: %w", err)
	}
	var newID int64
	if err := tx.QueryRow(ctx, `
		INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, status)
		VALUES ($1, $2::stage_type, $3, $4, 'waiting_deps')
		RETURNING id`, documentID, stageType, newApproverID, baseOrder+1).Scan(&newID); err != nil {
		return 0, fmt.Errorf("insert added stage: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stage_dependencies SET depends_on_stage_id = $1
		WHERE depends_on_stage_id = $2 AND stage_id <> $1`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("repoint deps: %w", err)
	}
	if _, err := tx.Exec(ctx, `
		INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
		VALUES ($1, $2) ON CONFLICT DO NOTHING`, newID, afterStageID); err != nil {
		return 0, fmt.Errorf("insert new dep: %w", err)
	}
	if err := s.RenumberSteps(ctx, tx, documentID); err != nil {
		return 0, err
	}
	if _, err := s.activateStage(ctx, tx, documentID, newID); err != nil {
		return 0, err
	}
	return newID, nil
}

// ApproveAndAddApprover — «согласовать и направить на доп. согласование».
// Согласующий stageID одобряет свой этап И вставляет нового согласующего
// newApproverID сразу после себя (см. AddApproverAfter). В историю пишется
// факт донаправления. Возвращает id нового согласующего (для уведомления).
func (s *ApprovalService) ApproveAndAddApprover(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID, newApproverID int64, stageType, comment string) (int64, error) {
	var approverID int64
	var status string
	if err := tx.QueryRow(ctx, `SELECT approver_id, status FROM approval_stages WHERE id=$1 AND document_id=$2 FOR UPDATE`,
		stageID, documentID).Scan(&approverID, &status); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return 0, ErrForbiddenApprover
		}
		return 0, fmt.Errorf("lookup stage: %w", err)
	}
	if actingUserID != approverID {
		return 0, ErrForbiddenApprover
	}
	if status != "pending" {
		return 0, ErrStageNotPending
	}
	if newApproverID == actingUserID || newApproverID == approverID {
		return 0, ErrSelfApproval
	}
	if err := s.validateAddedApprover(ctx, tx, documentID, newApproverID, stageType); err != nil {
		return 0, err
	}
	// Одобряем текущий этап (без авто-активации нижестоящих — их «перехватит»
	// новый этап внутри AddApproverAfter).
	if _, err := tx.Exec(ctx, `
		UPDATE approval_stages SET status='approved', decided_at=now(), comment=$2 WHERE id=$1`,
		stageID, comment); err != nil {
		return 0, fmt.Errorf("approve stage: %w", err)
	}
	newID, err := s.AddApproverAfter(ctx, tx, documentID, stageID, newApproverID, stageType)
	if err != nil {
		return 0, err
	}
	// История: и факт согласования, и факт донаправления (с ФИО нового).
	var newName string
	_ = tx.QueryRow(ctx, `SELECT full_name FROM users WHERE id=$1`, newApproverID).Scan(&newName)
	if _, err := tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, 'stage_approved', $3),
		       ($1, $2, 'approver_added', $4)`,
		documentID, actingUserID, comment,
		fmt.Sprintf("направлено на дополнительное согласование: %s", newName)); err != nil {
		return 0, fmt.Errorf("insert history: %w", err)
	}
	_ = newID
	return newApproverID, nil
}

// Возвращает ID согласующих, чьи этапы активировались сразу — им нужно
// отправить push-уведомление после коммита (см. Decide).
func (s *ApprovalService) CreateRoute(ctx context.Context, tx pgx.Tx, documentID int64, stages []StageInput) ([]int64, error) {
	ids := make([]int64, len(stages))
	for i, st := range stages {
		var id int64
		err := tx.QueryRow(ctx, `
			INSERT INTO approval_stages (document_id, stage_type, approver_id, display_order, step_no, status)
			VALUES ($1, $2::stage_type, $3, $4, $5, 'waiting_deps')
			RETURNING id`, documentID, st.StageType, st.ApproverID, st.DisplayOrder, max(st.StepNo, 1)).Scan(&id)
		if err != nil {
			return nil, fmt.Errorf("insert stage %d: %w", i, err)
		}
		ids[i] = id
	}

	for i, st := range stages {
		for _, depIdx := range st.DependsOnIdx {
			_, err := tx.Exec(ctx, `
				INSERT INTO approval_stage_dependencies (stage_id, depends_on_stage_id)
				VALUES ($1, $2)`, ids[i], ids[depIdx])
			if err != nil {
				return nil, fmt.Errorf("insert dependency for stage %d: %w", i, err)
			}
		}
	}

	var notified []int64
	for i, st := range stages {
		if len(st.DependsOnIdx) == 0 {
			approver, err := s.activateStage(ctx, tx, documentID, ids[i])
			if err != nil {
				return nil, err
			}
			notified = append(notified, approver)
		}
	}
	return notified, nil
}

func (s *ApprovalService) activateStage(ctx context.Context, tx pgx.Tx, documentID, stageID int64) (int64, error) {
	var approverID int64
	err := tx.QueryRow(ctx, `
		UPDATE approval_stages SET status = 'pending'
		WHERE id = $1
		RETURNING approver_id`, stageID).Scan(&approverID)
	if err != nil {
		return 0, fmt.Errorf("activate stage %d: %w", stageID, err)
	}
	if err := s.access.GrantStageApproverAccess(ctx, tx, documentID, approverID); err != nil {
		return 0, err
	}
	// #7 — здесь актор намеренно НЕ указывается: этап активируется системой
	// (предыдущий согласующий закрыл свой этап, сработал DAG), и текст
	// «Требуется ваше решение по документу «…»» точнее любого ФИО.
	// #2 — это главный будильник: без решения согласующего маршрут стоит.
	_, err = tx.Exec(ctx, `
		INSERT INTO notifications (user_id, document_id, kind, payload, requires_ack)
		VALUES ($1, $2, 'stage_pending', jsonb_build_object('stage_id',$4::bigint), $3)`,
		approverID, documentID, RequiresAck("stage_pending"), stageID)
	if err != nil {
		return 0, err
	}
	return approverID, nil
}

// Decide фиксирует решение согласующего (approve/reject) и, при
// подтверждении, активирует все этапы, для которых этот этап был
// последней недостающей зависимостью (топологическое "продвижение" DAG).
// Возвращает stage_type решённого этапа, идентификатор НАЗНАЧЕННОГО на этап
// согласующего (onBehalfOf — он же actingUserID, когда человек действует от
// себя, и замещаемый, когда решение принял заместитель) и ID пользователей,
// чьи этапы только что активировались — вызывающий код (handler) рассылает им
// push-уведомление через WebSocket ПОСЛЕ коммита транзакции (Hub не
// участвует в транзакции БД намеренно, чтобы не держать соединение
// открытым на время сетевой отправки).
//
// onBehalfOf возвращается наружу, потому что подпись (SigningService.Sign)
// обязана записать в себя факт замещения с указанием замещаемого, а кто это —
// известно только здесь, из этапа (п. 19).
func (s *ApprovalService) Decide(ctx context.Context, tx pgx.Tx, documentID, stageID, actingUserID int64, approve bool, comment string) (string, int64, []int64, error) {
	var approverID int64
	var status, stageType string
	// FOR UPDATE: два одновременных решения по одному этапу (двойной щелчок,
	// заместитель и замещаемый разом) выстраиваются в очередь, и второе
	// увидит уже обработанный этап, а не «pending».
	err := tx.QueryRow(ctx, `SELECT approver_id, status, stage_type FROM approval_stages WHERE id = $1 AND document_id = $2 FOR UPDATE`,
		stageID, documentID).Scan(&approverID, &status, &stageType)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return "", 0, nil, ErrForbiddenApprover
		}
		return "", 0, nil, fmt.Errorf("lookup stage: %w", err)
	}
	// Решение принимает только назначенный на этап согласующий/подписант.
	if actingUserID != approverID {
		return "", 0, nil, ErrForbiddenApprover
	}
	if status != "pending" {
		return "", 0, nil, ErrStageNotPending
	}

	newStatus := "approved"
	if !approve {
		newStatus = "rejected"
	}
	_, err = tx.Exec(ctx, `
		UPDATE approval_stages SET status = $1, decided_at = now(), comment = $2 WHERE id = $3`,
		newStatus, comment, stageID)
	if err != nil {
		return "", 0, nil, fmt.Errorf("update stage: %w", err)
	}
	// Если решение принято заместителем, в истории остаётся подробная пометка:
	// ЗА КОГО ИМЕННО и на какой период оформлено замещение (п. 19). Пометка
	// добавляется к комментарию, а не заменяет его: сам комментарий
	// согласующего нужен не меньше. Берётся ActorNoteFor, а не ActorNote: в
	// записи должен быть назван тот, чей этап решён, а не все замещаемые.
	_, err = tx.Exec(ctx, `
		INSERT INTO document_history (document_id, actor_id, event_type, comment)
		VALUES ($1, $2, $3, $4)`, documentID, actingUserID,
		map[bool]string{true: "stage_approved", false: "stage_rejected"}[approve],
		(comment))
	if err != nil {
		return "", 0, nil, fmt.Errorf("insert history: %w", err)
	}

	if !approve {
		return stageType, approverID, nil, nil
	}

	// Находим все этапы, зависящие от этого, у которых ВСЕ зависимости approved.
	rows, err := tx.Query(ctx, `
		SELECT s.id
		FROM approval_stage_dependencies d
		JOIN approval_stages s ON s.id = d.stage_id
		WHERE d.depends_on_stage_id = $1
		  AND s.status = 'waiting_deps'
		  AND NOT EXISTS (
		      SELECT 1 FROM approval_stage_dependencies d2
		      JOIN approval_stages s2 ON s2.id = d2.depends_on_stage_id
		      WHERE d2.stage_id = s.id AND s2.status <> 'approved'
		  )`, stageID)
	if err != nil {
		return "", 0, nil, fmt.Errorf("find ready stages: %w", err)
	}
	var readyIDs []int64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			rows.Close()
			return "", 0, nil, err
		}
		readyIDs = append(readyIDs, id)
	}
	rows.Close()

	var notified []int64
	for _, id := range readyIDs {
		approver, err := s.activateStage(ctx, tx, documentID, id)
		if err != nil {
			return "", 0, nil, err
		}
		notified = append(notified, approver)
	}
	return stageType, approverID, notified, nil
}

// AllApproved проверяет, что все этапы документа в статусе approved
// (используется перед переводом документа on_signing -> signed и т.д.)
func (s *ApprovalService) AllApproved(ctx context.Context, tx pgx.Tx, documentID int64) (bool, error) {
	var pendingCount int
	err := tx.QueryRow(ctx, `
		SELECT count(*) FROM approval_stages
		WHERE document_id = $1 AND status <> 'approved'`, documentID).Scan(&pendingCount)
	if err != nil {
		return false, err
	}
	return pendingCount == 0, nil
}

// RenumberSteps пересчитывает номера шагов (step_no) и порядок показа этапов
// документа по графу зависимостей. Вызывается после любого изменения
// маршрута «на ходу»: направление на согласование перед собой или после
// себя, передача подписи, замена подписантов.
func (s *ApprovalService) RenumberSteps(ctx context.Context, tx pgx.Tx, documentID int64) error {
	rows, err := tx.Query(ctx, `
		SELECT st.id, coalesce(array_agg(d.depends_on_stage_id) FILTER (WHERE d.depends_on_stage_id IS NOT NULL), '{}')
		  FROM approval_stages st
		  LEFT JOIN approval_stage_dependencies d ON d.stage_id = st.id
		 WHERE st.document_id = $1
		 GROUP BY st.id ORDER BY st.display_order, st.id`, documentID)
	if err != nil {
		return fmt.Errorf("load stages for renumber: %w", err)
	}
	var ids []int64
	deps := map[int64][]int64{}
	for rows.Next() {
		var id int64
		var d []int64
		if err := rows.Scan(&id, &d); err != nil {
			rows.Close()
			return err
		}
		ids = append(ids, id)
		deps[id] = d
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}
	steps := ComputeSteps(ids, deps)
	for pos, id := range ids {
		// Порядок показа: по шагу, внутри шага — прежний взаимный порядок.
		if _, err := tx.Exec(ctx, `UPDATE approval_stages SET step_no = $2, display_order = $3 WHERE id = $1`,
			id, steps[id], steps[id]*1000+pos); err != nil {
			return fmt.Errorf("renumber stage %d: %w", id, err)
		}
	}
	return nil
}
