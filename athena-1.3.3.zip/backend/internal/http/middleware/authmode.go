package middleware

import (
	"net"
	"strconv"

	"github.com/gofiber/fiber/v2"
)

// Режимы входа. Одно приложение слушает два порта: на одном вход по паролю
// (локальные учётные записи и LDAP), на другом — по Kerberos. Режим запроса
// определяется по порту, на который он ПРИШЁЛ (локальный адрес соединения),
// а не по заголовкам — их клиент может подставить любые.
const (
	AuthModePassword = "password"
	AuthModeKerberos = "kerberos"
)

var kerberosPort int

// ConfigureAuthPorts запоминает порт входа по Kerberos (0 — выключен).
func ConfigureAuthPorts(kerberosAddr string) {
	kerberosPort = 0
	if kerberosAddr == "" {
		return
	}
	if _, p, err := net.SplitHostPort(kerberosAddr); err == nil {
		kerberosPort, _ = strconv.Atoi(p)
	}
}

// AuthMode — режим входа для этого запроса.
func AuthMode(c *fiber.Ctx) string {
	if kerberosPort != 0 {
		if a, ok := c.Context().LocalAddr().(*net.TCPAddr); ok && a.Port == kerberosPort {
			return AuthModeKerberos
		}
	}
	return AuthModePassword
}
