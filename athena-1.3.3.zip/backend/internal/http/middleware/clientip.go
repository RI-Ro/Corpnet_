package middleware

import (
	"net"
	"strings"
	"sync/atomic"

	"github.com/gofiber/fiber/v2"
)

// ФАКТИЧЕСКИЙ АДРЕС КЛИЕНТА за NAT и обратными прокси (63-ФЗ, журнал аудита).
//
// Адрес прямого соединения (c.IP()) за прокси или в docker-сети — адрес
// шлюза/контейнера, один на всех. Реальный адрес приходит в заголовках
// X-Forwarded-For / X-Real-IP / Forwarded, но им можно верить, ТОЛЬКО если
// соединение пришло от доверенного прокси: иначе любой клиент подставит
// произвольный адрес. Поэтому:
//
//  1. если соединение пришло НЕ от доверенной сети — возвращаем адрес
//     соединения, заголовки игнорируем;
//  2. иначе берём цепочку из заголовка и идём справа налево, пропуская
//     доверенные прокси; первый «чужой» адрес и есть клиент;
//  3. если вся цепочка доверенная — берём самый левый адрес.
//
// Настройка: http.trusted_proxies и http.client_ip_header в config.yaml.

type clientIPConfig struct {
	nets   []*net.IPNet
	header string
}

var clientIPCfg atomic.Value // *clientIPConfig

var defaultTrusted = []string{
	// Только loopback: приложение само принимает соединения клиентов (nginx
	// не используется), поэтому заголовкам X-Forwarded-For от произвольных
	// адресов внутренней сети верить нельзя — иначе любой пользователь
	// подставит в журнал аудита чужой адрес. Если перед приложением стоит
	// балансировщик, его адрес указывают в http.trusted_proxies.
	"127.0.0.0/8", "::1/128",
}

func init() { ConfigureClientIP(nil, "") }

// ConfigureClientIP задаёт доверенные прокси (CIDR или одиночные адреса) и
// основной заголовок. Пустой список — частные сети по умолчанию.
func ConfigureClientIP(trusted []string, header string) {
	if len(trusted) == 0 {
		trusted = defaultTrusted
	}
	cfg := &clientIPConfig{header: strings.TrimSpace(header)}
	for _, t := range trusted {
		t = strings.TrimSpace(t)
		if t == "" {
			continue
		}
		if !strings.Contains(t, "/") {
			if ip := net.ParseIP(t); ip != nil {
				if ip.To4() != nil {
					t += "/32"
				} else {
					t += "/128"
				}
			}
		}
		if _, n, err := net.ParseCIDR(t); err == nil {
			cfg.nets = append(cfg.nets, n)
		}
	}
	clientIPCfg.Store(cfg)
}

func (cfg *clientIPConfig) trusted(ip string) bool {
	p := net.ParseIP(ip)
	if p == nil {
		return false
	}
	for _, n := range cfg.nets {
		if n.Contains(p) {
			return true
		}
	}
	return false
}

// forwardedFor извлекает адреса из заголовка Forwarded (RFC 7239): for=...
func forwardedFor(h string) []string {
	var out []string
	for _, el := range strings.Split(h, ",") {
		for _, part := range strings.Split(el, ";") {
			part = strings.TrimSpace(part)
			if len(part) > 4 && strings.EqualFold(part[:4], "for=") {
				v := strings.Trim(part[4:], `"`)
				v = strings.TrimPrefix(strings.TrimSuffix(v, "]"), "[")
				out = append(out, v)
			}
		}
	}
	return out
}

func splitList(h string) []string {
	var out []string
	for _, p := range strings.Split(h, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}

// chainFromHeaders — цепочка адресов от клиента к ближайшему прокси.
func chainFromHeaders(c *fiber.Ctx, header string) []string {
	if header != "" {
		v := c.Get(header)
		if strings.EqualFold(header, "Forwarded") {
			return forwardedFor(v)
		}
		return splitList(v)
	}
	if v := c.Get("X-Forwarded-For"); v != "" {
		return splitList(v)
	}
	if v := c.Get("Forwarded"); v != "" {
		if l := forwardedFor(v); len(l) > 0 {
			return l
		}
	}
	if v := strings.TrimSpace(c.Get("X-Real-IP")); v != "" {
		return []string{v}
	}
	if v := strings.TrimSpace(c.Get("X-Client-IP")); v != "" {
		return []string{v}
	}
	return nil
}

// ClientIP определяет ФАКТИЧЕСКИЙ IP клиента (см. описание выше). Перенесено
// из handlers (v51, п. 9): определение нужно и подписи, и журналу аудита,
// и расхождения между ними быть не должно.
func ClientIP(c *fiber.Ctx) string {
	cfg, _ := clientIPCfg.Load().(*clientIPConfig)
	peer := PeerIP(c)
	if cfg == nil || !cfg.trusted(peer) {
		return peer
	}
	chain := chainFromHeaders(c, cfg.header)
	if len(chain) == 0 {
		return peer
	}
	for i := len(chain) - 1; i >= 0; i-- {
		ip := normalizeIP(chain[i])
		if !cfg.trusted(ip) {
			return ip
		}
	}
	return normalizeIP(chain[0])
}

// normalizeIP срезает порт (если есть); при неуспехе возвращает исходную
// строку (лучше зафиксировать «как есть», чем потерять).
func normalizeIP(s string) string {
	if host, _, err := net.SplitHostPort(s); err == nil {
		s = host
	}
	return s
}

// PeerIP — адрес, с которого ПРИШЛО СОЕДИНЕНИЕ, без учёта заголовков.
// Подделать его клиент не может, поэтому в журнале он хранится РЯДОМ с
// фактическим адресом, а не вместо него.
func PeerIP(c *fiber.Ctx) string {
	return normalizeIP(c.IP())
}

// ForwardedChain — заголовок X-Forwarded-For (а при его отсутствии Forwarded)
// целиком, как пришёл. По цепочке видно весь путь запроса.
func ForwardedChain(c *fiber.Ctx) string {
	if v := strings.TrimSpace(c.Get("X-Forwarded-For")); v != "" {
		return v
	}
	return strings.TrimSpace(c.Get("Forwarded"))
}
