package middleware

import (
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/gofiber/fiber/v2"
)

func newCSRFApp() *fiber.App {
	app := fiber.New()
	app.Use(SameOrigin([]string{"http://localhost:5173"}))
	app.Use(CSRF())
	app.All("/x", func(c *fiber.Ctx) error { return c.SendString("ok") })
	app.Get("/login", func(c *fiber.Ctx) error {
		return SetSessionCookies(c, "tok", time.Now().Add(time.Hour), true)
	})
	return app
}

func TestCSRF(t *testing.T) {
	app := newCSRFApp()
	cases := []struct {
		name, method, cookie, header, origin string
		want                                 int
	}{
		{"чтение без заголовка", "GET", "", "", "", 200},
		{"изменение без cookie", "POST", "", "", "", 403},
		{"изменение без заголовка", "POST", "athena_csrf=abc", "", "", 403},
		{"чужое значение", "POST", "athena_csrf=abc", "abd", "", 403},
		{"совпадает", "POST", "athena_csrf=abc", "abc", "", 200},
		{"совпадает, свой сайт другой порт", "PUT", "athena_csrf=abc", "abc", "https://example.org:8444", 200},
		{"совпадает, но чужой сайт", "DELETE", "athena_csrf=abc", "abc", "https://evil.example", 403},
		{"разрешённый источник разработки", "PATCH", "athena_csrf=abc", "abc", "http://localhost:5173", 200},
	}
	for _, tc := range cases {
		req := httptest.NewRequest(tc.method, "/x", nil)
		req.Host = "example.org:8443"
		if tc.cookie != "" {
			req.Header.Set("Cookie", tc.cookie)
		}
		if tc.header != "" {
			req.Header.Set(CSRFHeader, tc.header)
		}
		if tc.origin != "" {
			req.Header.Set("Origin", tc.origin)
		}
		resp, err := app.Test(req)
		if err != nil {
			t.Fatal(err)
		}
		if resp.StatusCode != tc.want {
			t.Errorf("%s: код %d, ожидался %d", tc.name, resp.StatusCode, tc.want)
		}
	}
}

func TestSessionCookieFlags(t *testing.T) {
	app := newCSRFApp()
	req := httptest.NewRequest("GET", "/login", nil)
	req.Host = "example.org"
	resp, err := app.Test(req)
	if err != nil {
		t.Fatal(err)
	}
	var sess, csrf string
	for _, h := range resp.Header.Values("Set-Cookie") {
		switch {
		case strings.HasPrefix(h, SessionCookie+"="):
			sess = strings.ToLower(h)
		case strings.HasPrefix(h, CSRFCookie+"="):
			csrf = strings.ToLower(h)
		}
	}
	if !strings.Contains(sess, "httponly") || !strings.Contains(sess, "samesite=strict") || !strings.Contains(sess, "path=/") {
		t.Errorf("cookie сеанса без нужных флагов: %q", sess)
	}
	if csrf == "" || strings.Contains(csrf, "httponly") {
		t.Errorf("CSRF-cookie должна быть доступна интерфейсу: %q", csrf)
	}
}
