-- Выполняется владельцем схемы, в транзакции вызывающего файла.
CREATE TABLE user_dashboard_departments (
    user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id,department_id)
);
CREATE TABLE user_duty_departments (
    user_id bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    department_id bigint NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id,department_id)
);
CREATE INDEX duty_department_members ON user_duty_departments(department_id,user_id);

-- Адрес очереди совместим с существующими адресными книгами, плановыми
-- рассылками и группами. Ограничение БД запрещает вход под этим адресом.
ALTER TABLE users ADD COLUMN duty_department_id bigint UNIQUE REFERENCES departments(id),
    ADD CONSTRAINT duty_address_no_login CHECK (duty_department_id IS NULL OR
      (NOT is_active AND domain_id IS NULL AND primary_department_id IS NOT DISTINCT FROM duty_department_id));
CREATE FUNCTION create_duty_address() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE address_id bigint;
BEGIN
  INSERT INTO users(login,password_hash,full_name,primary_department_id,duty_department_id,is_active)
    VALUES ('duty-' || gen_random_uuid(), '!', 'Дежурный', NEW.id, NEW.id, false) RETURNING id INTO address_id;
  INSERT INTO user_roles(user_id,department_id,role) VALUES(address_id,NEW.id,'clerk');
  RETURN NEW;
END $$;
CREATE TRIGGER department_duty_address AFTER INSERT ON departments FOR EACH ROW EXECUTE FUNCTION create_duty_address();
WITH addresses AS (
 INSERT INTO users(login,password_hash,full_name,primary_department_id,duty_department_id,is_active)
 SELECT 'duty-' || gen_random_uuid(), '!', 'Дежурный', id,id,false FROM departments
 RETURNING id,duty_department_id)
INSERT INTO user_roles(user_id,department_id,role) SELECT id,duty_department_id,'clerk' FROM addresses;

CREATE FUNCTION app_handles_recipient(address_id bigint, dept bigint, operator_id bigint)
RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT address_id=operator_id OR EXISTS (
   SELECT 1 FROM users a JOIN user_duty_departments m ON m.department_id=a.duty_department_id
    JOIN users u ON u.id=m.user_id AND u.is_active
    WHERE a.id=address_id AND a.duty_department_id=dept AND m.user_id=operator_id)
$$;
CREATE FUNCTION delivery_members(address_id bigint) RETURNS SETOF bigint LANGUAGE sql STABLE AS $$
 SELECT u.id FROM users u WHERE u.id=address_id AND u.is_active AND u.duty_department_id IS NULL
 UNION ALL
 SELECT m.user_id FROM users a JOIN user_duty_departments m ON m.department_id=a.duty_department_id
 JOIN users u ON u.id=m.user_id AND u.is_active WHERE a.id=address_id
$$;

CREATE OR REPLACE FUNCTION public.app_can_see_document(p_id bigint, p_author bigint, p_author_dept bigint, p_outgoing text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
    SELECT p_author = app_user_id()
        OR EXISTS (SELECT 1 FROM document_access da
                    WHERE da.document_id = p_id AND da.user_id = app_user_id())
        OR (p_outgoing IS NOT NULL AND EXISTS (
                SELECT 1 FROM user_roles ur
                  JOIN department_closure dc ON dc.ancestor_id = ur.department_id
                 WHERE ur.user_id = app_user_id() AND ur.role = 'chief'
                   AND dc.descendant_id = p_author_dept))
        OR (p_outgoing IS NOT NULL AND EXISTS (
                SELECT 1 FROM user_visible_departments uvd
                 WHERE uvd.user_id = app_user_id() AND uvd.department_id = p_author_dept))
        OR EXISTS (SELECT 1 FROM document_incoming_instances dii
                     JOIN user_incoming_departments uid ON uid.department_id = dii.receiving_department_id
                    WHERE dii.document_id = p_id AND uid.user_id = app_user_id())
        OR EXISTS (SELECT 1 FROM document_recipients dr
                    WHERE dr.document_id=p_id AND NOT dr.is_planned
                      AND app_handles_recipient(dr.recipient_user_id,dr.recipient_department_id,app_user_id()))
        OR EXISTS (SELECT 1 FROM document_incoming_instances i
                    WHERE i.document_id=p_id AND chief_scope_has(app_user_id(),i.receiving_department_id))
        OR app_is_system()
$$;

ALTER TABLE document_history ADD COLUMN resolution_id bigint REFERENCES resolutions(id) ON DELETE CASCADE,
 ADD COLUMN execution_department_id bigint REFERENCES departments(id);
-- Старые события связываются только по однозначным признакам.
UPDATE document_history h SET resolution_id=r.id FROM resolutions r
 WHERE h.document_id=r.document_id AND left(h.event_type,11)='resolution_'
 AND (h.event_type<>'resolution_issued' AND substring(h.comment FROM '^(?:резолюция|отчёт по резолюции) #([0-9]+)')=r.id::text
 OR h.event_type='resolution_issued' AND h.actor_id=r.author_id AND h.created_at=r.created_at
 AND (SELECT count(*) FROM resolutions x WHERE x.document_id=r.document_id AND x.author_id=r.author_id AND x.created_at=r.created_at)=1);
CREATE FUNCTION app_execution_visible(doc bigint, dept bigint) RETURNS boolean LANGUAGE sql STABLE AS $$
 SELECT dept IS NOT NULL AND (
   dept IN (SELECT app_resolution_departments())
   OR EXISTS (SELECT 1 FROM document_recipients r WHERE r.document_id=doc AND NOT r.is_planned
     AND r.recipient_department_id=dept AND app_handles_recipient(r.recipient_user_id,dept,app_user_id()))
   OR EXISTS (SELECT 1 FROM user_roles WHERE user_id=app_user_id() AND department_id=dept AND role='execution_marker')
   OR EXISTS (SELECT 1 FROM document_acquaintances a JOIN users u ON u.id=a.user_id
      WHERE a.document_id=doc AND a.user_id=app_user_id() AND u.primary_department_id=dept)
   OR EXISTS (SELECT 1 FROM resolutions r JOIN resolution_executors e ON e.resolution_id=r.id
      WHERE r.document_id=doc AND r.department_id=dept AND e.user_id=app_user_id() AND e.status<>'cancelled'))
$$;
ALTER TABLE document_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_history FORCE ROW LEVEL SECURITY;
CREATE POLICY history_read ON document_history FOR SELECT USING (
 app_is_system() OR (EXISTS (SELECT 1 FROM documents d WHERE d.id=document_history.document_id)
 AND CASE
 WHEN left(event_type,11)='resolution_' THEN EXISTS (SELECT 1 FROM resolutions r WHERE r.id=document_history.resolution_id AND r.document_id=document_history.document_id)
 WHEN left(event_type,10)='execution_' THEN actor_id=app_user_id() OR app_execution_visible(document_id,execution_department_id)
 WHEN left(event_type,10)='assignment' OR event_type='chat_attachment_downloaded' THEN actor_id=app_user_id()
 ELSE true END));
CREATE POLICY history_append ON document_history FOR INSERT WITH CHECK(true);
-- Изменение отметки у адресата не должно повторно проверять прежние кадровые назначения.
DROP TRIGGER trg_check_recipient_role ON document_recipients;
CREATE TRIGGER trg_check_recipient_role BEFORE INSERT OR UPDATE OF recipient_user_id,recipient_department_id
 ON document_recipients FOR EACH ROW EXECUTE FUNCTION check_recipient_role();
UPDATE document_recipients r SET completed_at=i.executed_at,completion_note=i.execution_note
 FROM document_incoming_instances i WHERE r.document_id=i.document_id AND r.recipient_department_id=i.receiving_department_id
 AND NOT r.is_planned AND (r.completed_at,r.completion_note) IS DISTINCT FROM (i.executed_at,i.execution_note);
INSERT INTO schema_version(version,applied_at,note) VALUES (2,now(),'История, дежурные и области сводной панели');
