package authdom

import (
	"context"
	"errors"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/jcmturner/gokrb5/v8/keytab"
	"github.com/jcmturner/gokrb5/v8/messages"
	"github.com/jcmturner/gokrb5/v8/service"
	"github.com/jcmturner/gokrb5/v8/spnego"
)

// ErrKerberosRejected — билет не подтверждён ни одним keytab.
var ErrKerberosRejected = errors.New("билет Kerberos не подтверждён")

// ParseKeytab проверяет загруженный keytab и возвращает краткое описание его
// записей (принципалы и номера версий ключей) — без самих ключей.
func ParseKeytab(b []byte) (string, error) {
	kt := keytab.New()
	if err := kt.Unmarshal(b); err != nil {
		return "", fmt.Errorf("файл не является keytab: %w", err)
	}
	if len(kt.Entries) == 0 {
		return "", errors.New("keytab пуст")
	}
	seen := map[string]bool{}
	var out []string
	for _, e := range kt.Entries {
		s := fmt.Sprintf("%s@%s (kvno %d, etype %d)", strings.Join(e.Principal.Components, "/"), e.Principal.Realm, e.KVNO, e.Key.KeyType)
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	sort.Strings(out)
	return strings.Join(out, "; "), nil
}

// apReqFromToken достаёт KRB_AP_REQ из содержимого заголовка
// «Authorization: Negotiate …» (SPNEGO NegTokenInit либо «голый» токен KRB5).
func apReqFromToken(token []byte) (*messages.APReq, error) {
	mech := token
	var st spnego.SPNEGOToken
	if err := st.Unmarshal(token); err == nil {
		switch {
		case st.Init:
			mech = st.NegTokenInit.MechTokenBytes
		case st.Resp:
			mech = st.NegTokenResp.ResponseToken
		}
	}
	var kt spnego.KRB5Token
	if err := kt.Unmarshal(mech); err != nil {
		return nil, fmt.Errorf("токен не является билетом Kerberos: %w", err)
	}
	if !kt.IsAPReq() {
		return nil, errors.New("токен не содержит KRB_AP_REQ")
	}
	return &kt.APReq, nil
}

// VerifyKerberos проверяет билет клиента по keytab активных доменов с
// включённым Kerberos. Возвращает имя пользователя и его область (realm) —
// именно КЛИЕНТСКУЮ область из билета: при доверии между доменами служба
// может быть в DOMAIN1, а пользователь — из DOMAIN2.
//
// Повторное предъявление того же билета отклоняется (кэш повторов gokrb5),
// расхождение часов допускается в пределах 5 минут.
func (s *Store) VerifyKerberos(ctx context.Context, token []byte) (user, realm string, err error) {
	apReq, err := apReqFromToken(token)
	if err != nil {
		return "", "", err
	}
	all, err := s.All(ctx)
	if err != nil {
		return "", "", err
	}
	// Сначала домен, чья область совпадает с областью службы в билете.
	var cands []Domain
	for _, d := range all {
		if d.IsActive && d.KerberosEnabled && d.HasKeytab {
			cands = append(cands, d)
		}
	}
	sort.SliceStable(cands, func(i, j int) bool {
		return strings.EqualFold(cands[i].Realm, apReq.Ticket.Realm) && !strings.EqualFold(cands[j].Realm, apReq.Ticket.Realm)
	})
	if len(cands) == 0 {
		return "", "", errors.New("нет ни одного домена с включённым Kerberos и загруженным keytab")
	}
	var lastErr error
	for _, d := range cands {
		raw, err := s.KeytabBytes(d)
		if err != nil {
			lastErr = err
			continue
		}
		user, realm, err := verifyAPReq(apReq, raw, d.KerberosSPN)
		if err != nil {
			lastErr = err
			continue
		}
		return user, realm, nil
	}
	if lastErr != nil {
		return "", "", fmt.Errorf("%w: %v", ErrKerberosRejected, lastErr)
	}
	return "", "", ErrKerberosRejected
}

// verifyAPReq проверяет KRB_AP_REQ одним keytab: расшифровывает билет ключом
// службы, сверяет аутентификатор, срок действия, расхождение часов и повтор.
func verifyAPReq(apReq *messages.APReq, keytabBytes []byte, spn string) (user, realm string, err error) {
	kt := keytab.New()
	if err := kt.Unmarshal(keytabBytes); err != nil {
		return "", "", err
	}
	opts := []func(*service.Settings){service.DecodePAC(false), service.MaxClockSkew(5 * time.Minute)}
	if spn != "" {
		opts = append(opts, service.KeytabPrincipal(spn))
	}
	// Копия: VerifyAPREQ расшифровывает билет на месте.
	req := *apReq
	ok, creds, err := service.VerifyAPREQ(&req, service.NewSettings(kt, opts...))
	if err != nil {
		return "", "", err
	}
	if !ok || creds == nil {
		return "", "", ErrKerberosRejected
	}
	return creds.UserName(), NormalizeRealm(creds.Domain()), nil
}
