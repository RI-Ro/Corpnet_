#!/usr/bin/env bash
# Сводная проверка двух площадок: репликация PostgreSQL, здоровье приложений и отставание синхронизации файлов.
#   PRIMARY_DSN='postgres://postgres@10.10.0.10/postgres' REPLICA_DSN='postgres://postgres@10.20.0.10/postgres' \
#   SITE_A=https://portal-msk.corp.local SITE_B=https://portal-spb.corp.local INTERNAL_TOKEN=... ./check-two-sites.sh
# Код возврата 0 — всё хорошо, 1 — есть замечания (удобно для мониторинга).
set -uo pipefail
RC=0; ok() { printf '  [ ok ] %s\n' "$*"; }; bad() { printf '  [FAIL] %s\n' "$*"; RC=1; }
Q() { psql "$1" -X -tA -c "$2" 2>/dev/null; }

echo "== PostgreSQL"
if [ -n "${PRIMARY_DSN:-}" ]; then
  Q "$PRIMARY_DSN" "SELECT NOT pg_is_in_recovery()" | grep -q t && ok "основная БД принимает запись" || bad "основная БД недоступна или это реплика"
  rows=$(Q "$PRIMARY_DSN" "SELECT application_name||' '||state||' отставание: '||coalesce(replay_lag::text,'—')||' ('||pg_wal_lsn_diff(sent_lsn,replay_lsn)||' байт)' FROM pg_stat_replication")
  [ -n "$rows" ] && printf '%s\n' "$rows" | while read -r l; do ok "$l"; done || bad "нет подключённых реплик"
  Q "$PRIMARY_DSN" "SELECT slot_name||' активен='||active FROM pg_replication_slots" | while read -r l; do ok "слот $l"; done
fi
if [ -n "${REPLICA_DSN:-}" ]; then
  Q "$REPLICA_DSN" "SELECT pg_is_in_recovery()" | grep -q t && ok "реплика в режиме standby" || bad "реплика не в режиме standby"
  st=$(Q "$REPLICA_DSN" "SELECT status FROM pg_stat_wal_receiver")
  [ "$st" = streaming ] && ok "WAL-приёмник реплики: streaming" || bad "WAL-приёмник реплики: '${st:-не запущен}' (связь с основной БД потеряна?)"
  # на «тихой» БД время последней транзакции стареет само по себе, поэтому судим по накопленному, но не применённому WAL
  backlog=$(Q "$REPLICA_DSN" "SELECT coalesce(pg_wal_lsn_diff(pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn()),0)::bigint")
  [ "${backlog:-999999999}" -le 16777216 ] && ok "не применено WAL: ${backlog} байт" || bad "не применено WAL: ${backlog} байт (порог 16 МБ) — реплика не успевает"
fi

echo "== Приложения"
for s in "A:${SITE_A:-}" "B:${SITE_B:-}"; do
  name=${s%%:*}; url=${s#*:}; [ -n "$url" ] || continue
  out=$(curl -fsS -m 5 "$url/healthz" 2>&1) && ok "площадка $name: $out" || bad "площадка $name: /healthz не отвечает ($url)"
done

echo "== Синхронизация файлов (изменённые за последний час)"
if [ -n "${SITE_A:-}" ] && [ -n "${SITE_B:-}" ] && [ -n "${INTERNAL_TOKEN:-}" ]; then
  since=$(( ($(date +%s) - 3600) * 1000000000 ))
  for kind in prv pub; do
    na=$(curl -fsS -m 20 -H "X-Internal-Token: $INTERNAL_TOKEN" "$SITE_A/internal/manifest/$kind?after=$since&limit=5000" | grep -o '"n":' | wc -l)
    nb=$(curl -fsS -m 20 -H "X-Internal-Token: $INTERNAL_TOKEN" "$SITE_B/internal/manifest/$kind?after=$since&limit=5000" | grep -o '"n":' | wc -l)
    [ "$na" -eq "$nb" ] && ok "$kind: на обеих площадках по $na файлов" || bad "$kind: A=$na, B=$nb (разница догоняется синхронизацией; если не уходит — смотрите журнал «filesync»)"
  done
else
  echo "  (пропущено: задайте SITE_A, SITE_B и INTERNAL_TOKEN)"
fi
exit $RC
