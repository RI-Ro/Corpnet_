import React, { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '../api/client'
import { playEventSound, primeAudio } from '../lib/sound'
import { fmtDateTime } from '../utils/format'
import { isLeader, emitBus, onBus } from '../lib/tabSync'

// УВЕДОМЛЕНИЯ-БУДИЛЬНИКИ.
//
// Что было не так и что изменилось.
//
// 1. «Отложить» не закрывало окно. Кнопка откладывала ОДНО уведомление, а
//    будильников у человека обычно несколько (документ на согласовании,
//    поручение, входящий). После нажатия окно оставалось и показывало
//    следующий — с похожим текстом. Снаружи это ровно «кнопка не работает».
//    Теперь окно показывает ВСЕ будильники сразу, а «отложить» применяется ко
//    всем показанным одним запросом (/notifications/snooze-all) — окно
//    закрывается с первого нажатия.
//
// 2. Лишние будильники. Причина была на сервере: при направлении документа
//    адресное уведомление получали адресаты, и ТО ЖЕ событие рассылалось всем,
//    у кого есть доступ к документу. Контролёр, согласующие и ознакомленные
//    получали блокирующее окно «Вам направлен документ», хотя им его не
//    направляли. Исправлено разделением видов события (document_sent —
//    адресатам, document_sent_info — остальным, и он не будильник).
//
// 3. Кнопки. По требованию пользователю оставлены ТОЛЬКО «отложить» на
//    5/15/30 минут (интервалы приходят с сервера, задаются в конфиге).
//    «Открыть документ» и «Прочитать» убраны: будильник сообщает, что
//    требуется действие, а само действие делается в документе — и отмечать
//    прочтение, не посмотрев документ, смысла не имеет. Уведомления остаются
//    в колоколе, где эти действия и есть.
//
// 4. Изображение — колокольчик. Нарисован здесь inline-SVG, а не взят из
//    набора Icon: в наборе иконка интерфейсная (18px, тонкий контур), а тут
//    нужен крупный узнаваемый образ. Колокольчик слегка наклонён — «звонит».

// Период повторного сигнала по умолчанию (сервер может прислать свой).
const DEFAULT_REPEAT_MS = 20000

// BellImage — крупный колокольчик. aria-hidden: смысл несёт заголовок окна,
// а не картинка, и читать её вслух незачем.
function BellImage() {
  return (
    <svg
      viewBox="0 0 64 64"
      width="56"
      height="56"
      aria-hidden="true"
      className="shrink-0"
      style={{ transform: 'rotate(-12deg)' }}
    >
      {/* Корпус */}
      <path
        d="M32 8c-1.9 0-3.4 1.5-3.4 3.4v1.8C20.9 14.8 15 21.6 15 29.8v8.4l-3.4 5.1c-.9 1.3.1 3.1 1.7 3.1h37.4c1.6 0 2.6-1.8 1.7-3.1L49 38.2v-8.4c0-8.2-5.9-15-13.6-16.6v-1.8C35.4 9.5 33.9 8 32 8z"
        fill="currentColor"
      />
      {/* Язычок */}
      <path d="M25.5 50h13a6.5 6.5 0 01-13 0z" fill="currentColor" />
      {/* Звуковые волны — показывают, что колокольчик звонит */}
      <path
        d="M54 20c3.2 3.4 5 7.9 5 12.6M10 20c-3.2 3.4-5 7.9-5 12.6"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
        opacity="0.5"
      />
    </svg>
  )
}


// Подпись кнопки отсрочки. Интервалы приходят с сервера в МИНУТАХ, и для
// суток это 1440 — надпись «через 1440 мин» человек вынужден пересчитывать в
// уме. Часы и сутки подписываются своими словами.
function snoozeLabel(minutes) {
  if (minutes % 1440 === 0) {
    const d = minutes / 1440
    return d === 1 ? 'через сутки' : `через ${d} сут.`
  }
  if (minutes % 60 === 0) {
    const h = minutes / 60
    return h === 1 ? 'через час' : `через ${h} ч`
  }
  return `через ${minutes} мин`
}
export default function AlarmNotifications() {
  const [items, setItems] = useState([])
  const [snoozeOptions, setSnoozeOptions] = useState([5, 15, 30, 1440])
  const [repeatMs, setRepeatMs] = useState(DEFAULT_REPEAT_MS)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  // id, по которым сигнал уже звучал: иначе один и тот же будильник пищал бы
  // на каждом опросе.
  const soundedRef = useRef(new Set())

  // ПОЧЕМУ «ОТЛОЖИТЬ» НЕ ЗАКРЫВАЛО ОКНО.
  //
  // Окно опрашивает сервер по таймеру и по приходу уведомления. Запрос
  // занимает десятки миллисекунд, а нажатие «отложить» происходит в любой
  // момент — в том числе когда опрос уже в пути. Тогда порядок такой:
  //
  //   1. load() уходит на сервер и возвращает ещё НЕ отложенный список;
  //   2. пользователь нажимает «через 5 мин», сервер откладывает, setItems([]);
  //   3. приходит ответ из п.1 и вызывает setItems(старый список).
  //
  // Окно открывается снова — с тем же текстом, как будто кнопка не работает.
  // Воспроизводимость зависит от задержки сети, поэтому «иногда».
  //
  // Лечится порядковым номером запроса: ответ применяется только если он
  // самый свежий. Любое действие (отложить) номер увеличивает, и все ответы,
  // ушедшие до него, игнорируются.
  const reqSeqRef = useRef(0)

  const load = useCallback(async () => {
    const seq = ++reqSeqRef.current
    try {
      const res = await api.getAlarmNotifications()
      // Ответ устарел: за время запроса пользователь успел отложить или
      // ушёл следующий опрос. Применять его нельзя.
      if (seq !== reqSeqRef.current) return
      const list = res.items || []
      if (Array.isArray(res.snooze_minutes) && res.snooze_minutes.length > 0) {
        setSnoozeOptions(prev => JSON.stringify(prev) === JSON.stringify(res.snooze_minutes) ? prev : res.snooze_minutes)
      }
      if (res.repeat_seconds > 0) setRepeatMs(res.repeat_seconds * 1000)
      setItems(prev => JSON.stringify(prev) === JSON.stringify(list) ? prev : list)
      // Сигнал — только для тех, по которым он ещё не звучал. Отложенное,
      // вернувшееся по истечении срока, звучит снова: иначе вернувшееся
      // уведомление было бы тихим и его легко пропустить.
      const shown = new Set(list.map((it) => it.id))
      soundedRef.current.forEach((id) => {
        if (!shown.has(id)) soundedRef.current.delete(id)
      })
      const fresh = list.find((it) => !soundedRef.current.has(it.id))
      if (fresh) {
        list.forEach((it) => soundedRef.current.add(it.id))
        // Звук играет только вкладка-лидер: при нескольких вкладках сигнал
        // не должен звучать несколько раз.
        if (isLeader()) playEventSound(fresh.kind || 'notification', { alarm: true })
      }
    } catch (_) {
      /* сеть/сессия — окно не показываем, колокол перечитает сам */
    }
  }, [])

  useEffect(() => {
    primeAudio()
    load()
  }, [load])

  // Периодический опрос нужен не для «живости» (её даёт WebSocket в колоколе),
  // а чтобы будильник ВЕРНУЛСЯ, когда истечёт время «отложить»: события при
  // этом не происходит и присылать его некому.
  useEffect(() => {
    const t = setInterval(load, 60000)
    return () => clearInterval(t)
  }, [load])

  // Повторный сигнал, пока окно открыто.
  useEffect(() => {
    if (items.length === 0 || repeatMs <= 0) return undefined
    const t = setInterval(() => {
      if (isLeader()) playEventSound(items[0].kind || 'notification', { alarm: true })
    }, repeatMs)
    return () => clearInterval(t)
  }, [items, repeatMs])

  // Отложили в другой вкладке — закрываем окно и здесь.
  useEffect(() => onBus('alarm_snoozed', () => {
    reqSeqRef.current += 1
    setItems([])
    soundedRef.current.clear()
  }), [])

  // Новое уведомление по WebSocket — перечитываем сразу.
  useEffect(() => {
    window.addEventListener('athena:notification', load)
    window.addEventListener('athena:changed', load)
    return () => { window.removeEventListener('athena:notification', load); window.removeEventListener('athena:changed', load) }
  }, [load])

  if (items.length === 0) return null

  // Отложить ВСЕ показанные. Если запрос не удался, окно остаётся открытым и
  // причина показывается текстом: молчаливый отказ и был главной претензией.
  async function snoozeAll(minutes) {
    if (busy) return
    setBusy(true)
    setError('')
    try {
      await api.snoozeAllNotifications(minutes)
      // Номер увеличиваем ДО setItems: все ответы load(), ушедшие раньше,
      // станут устаревшими и не откроют окно заново (см. reqSeqRef).
      reqSeqRef.current += 1
      // Локально убираем всё показанное: ждать следующего опроса незачем.
      setItems([])
      emitBus('alarm_snoozed', {})
      // Отложенное должно прозвучать, когда вернётся.
      soundedRef.current.clear()
    } catch (e) {
      setError(e.message || 'Не удалось отложить. Попробуйте ещё раз.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4">
      <div
        className="w-full max-w-xl bg-surface rounded-lg shadow-2xl overflow-hidden"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="alarm-title"
      >
        <div className="flex items-start gap-4 px-5 pt-5 pb-4">
          <span className="text-warning mt-0.5">
            <BellImage />
          </span>
          <div className="min-w-0">
            <div id="alarm-title" className="font-display text-lg font-semibold">
              {items.length === 1 ? 'Требует вашего внимания' : `Требуют вашего внимания: ${items.length}`}
            </div>
            <div className="text-xs text-text-secondary mt-1">
              Эти уведомления требуют действия. Отложите, если сейчас заняты, — окно вернётся.
            </div>
          </div>
        </div>

        {/* Список всех будильников: человек видит сразу всё, что его ждёт, и не
            закрывает их по одному. Прокрутка — чтобы при десятке уведомлений
            кнопки не уехали за край экрана. */}
        <ul className="px-5 max-h-72 overflow-auto divide-y divide-border border-y border-border">
          {items.map((it) => (
            <li key={it.id} className="py-2.5">
              <div className="text-sm leading-relaxed">{it.text}</div>
              <div className="text-[11px] text-text-secondary mt-1 nums">
                {fmtDateTime(it.created_at)}
              </div>
            </li>
          ))}
        </ul>

        {error && (
          <div className="px-5 pt-3 text-xs text-danger">{error}</div>
        )}

        <div className="px-5 py-4 flex flex-wrap items-center gap-2">
          <span className="text-sm text-text-secondary mr-1">Напомнить позже:</span>
          {snoozeOptions.map((m) => (
            <button
              key={m}
              onClick={() => snoozeAll(m)}
              disabled={busy}
              className="btn btn-secondary disabled:opacity-50"
            >
              {snoozeLabel(m)}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
