package server

import (
	"context"
	"crypto/rand"
	"encoding/base32"
	"strings"

	"github.com/jackc/pgx/v5"
)

// Модуль предназначен для разделов «Спросите директора» и «Куда жаловаться» (раздел 16 ТЗ).
// Для анонимных обращений связь с автором не сохраняется вообще; отслеживание — по одноразовому коду.

func (s *Server) isResponder(c *Ctx) bool {
	if c.U.IsAdmin() {
		return true
	}
	var ok bool
	s.db.QueryRow(c.Context(), `SELECT $1 = ANY(responder_ids) FROM qa_config WHERE id = 1`, c.U.ID).Scan(&ok)
	return ok
}

// qaList — GET /api/qa: опубликованные вопросы + мои + (для отвечающих) очередь модерации.
func (s *Server) qaList(c *Ctx) error {
	ctx := c.Context()
	cfg, err := s.one(ctx, `SELECT enabled, title, moderation, allow_anonymous FROM qa_config WHERE id = 1`)
	if err != nil {
		return err
	}
	resp := s.isResponder(c)
	items, err := s.arr(ctx, `SELECT q.id, q.topic, q.question, q.status, q.answer, q.answered_at, q.votes, q.created_at,
			CASE WHEN q.anonymous THEN NULL ELSE q.author_id END AS author_id, CASE WHEN q.anonymous THEN NULL ELSE u.full_name END AS author,
			(q.author_id = $1) AS mine, EXISTS (SELECT 1 FROM qa_votes v WHERE v.question_id = q.id AND v.user_id = $1) AS voted,
			ab.full_name AS answered_by
		FROM qa_questions q LEFT JOIN users u ON u.id = q.author_id LEFT JOIN users ab ON ab.id = q.answered_by
		WHERE q.status IN ('approved','answered') OR q.author_id = $1 OR $2::boolean
		ORDER BY (q.status = 'answered') DESC, q.votes DESC, q.id DESC LIMIT 200`, c.U.ID, resp)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"config": cfg, "items": items, "responder": resp})
}

func (s *Server) qaAsk(c *Ctx) error {
	var in struct {
		Topic     string `json:"topic"`
		Question  string `json:"question"`
		Anonymous bool   `json:"anonymous"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Question = strings.TrimSpace(in.Question)
	if n := len([]rune(in.Question)); n < 10 || n > 1500 {
		return badReq("Сформулируйте вопрос (10–1500 символов)")
	}
	ctx := c.Context()
	var moder, anon bool
	s.db.QueryRow(ctx, `SELECT moderation, allow_anonymous FROM qa_config WHERE id = 1`).Scan(&moder, &anon)
	if in.Anonymous && !anon {
		return badReq("Анонимные вопросы отключены")
	}
	var recent int
	s.db.QueryRow(ctx, `SELECT count(*) FROM qa_questions WHERE author_id = $1 AND created_at > now() - interval '1 day'`, c.U.ID).Scan(&recent)
	if recent >= 5 {
		return &apiError{429, "Не более 5 вопросов в сутки"}
	}
	st := "approved"
	if moder {
		st = "new"
	}
	var id int64
	if err := s.db.QueryRow(ctx, `INSERT INTO qa_questions (author_id, anonymous, topic, question, status) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
		c.U.ID, in.Anonymous, strings.TrimSpace(in.Topic), in.Question, st).Scan(&id); err != nil {
		return err
	}
	if moder {
		var ids []int64
		s.db.QueryRow(ctx, `SELECT responder_ids FROM qa_config WHERE id = 1`).Scan(&ids)
		s.notify(ctx, ids, "qa", "Новый вопрос руководителю", in.Question, "/ask")
	}
	return c.JSON(200, map[string]any{"id": id, "status": st})
}

func (s *Server) qaVote(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	ctx := c.Context()
	err = s.tx(ctx, func(tx pgx.Tx) error {
		tag, err := tx.Exec(ctx, `INSERT INTO qa_votes (question_id, user_id) SELECT id, $2 FROM qa_questions WHERE id = $1 AND status IN ('approved','answered') ON CONFLICT DO NOTHING`, id, c.U.ID)
		if err != nil {
			return err
		}
		if tag.RowsAffected() == 0 { // повторный голос снимает прежний
			if _, err := tx.Exec(ctx, `DELETE FROM qa_votes WHERE question_id = $1 AND user_id = $2`, id, c.U.ID); err != nil {
				return err
			}
		}
		_, err = tx.Exec(ctx, `UPDATE qa_questions SET votes = (SELECT count(*) FROM qa_votes WHERE question_id = $1) WHERE id = $1`, id)
		return err
	})
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// qaDecide — модерация и ответ (POST /api/qa/{id}/decide {status, answer, reason}).
func (s *Server) qaDecide(c *Ctx) error {
	if !s.isResponder(c) {
		return errForbidden
	}
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Status string `json:"status"`
		Answer string `json:"answer"`
		Reason string `json:"reason"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if in.Status != "approved" && in.Status != "answered" && in.Status != "rejected" {
		return badReq("Недопустимый статус")
	}
	if in.Status == "answered" && strings.TrimSpace(in.Answer) == "" {
		return badReq("Напишите ответ")
	}
	ctx := c.Context()
	var author *int64
	var q string
	err = s.db.QueryRow(ctx, `UPDATE qa_questions SET status = $2, answer = CASE WHEN $2 = 'answered' THEN $3 ELSE answer END, reject_reason = $4,
		answered_by = CASE WHEN $2 = 'answered' THEN $5::bigint ELSE answered_by END, answered_at = CASE WHEN $2 = 'answered' THEN now() ELSE answered_at END
		WHERE id = $1 RETURNING author_id, question`, id, in.Status, strings.TrimSpace(in.Answer), in.Reason, c.U.ID).Scan(&author, &q)
	if err != nil {
		return errNotFound
	}
	if author != nil && in.Status != "approved" {
		t := map[string]string{"answered": "Руководитель ответил на ваш вопрос", "rejected": "Вопрос не опубликован"}[in.Status]
		s.notify(ctx, []int64{*author}, "qa", t, q, "/ask")
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// ---------------------------------------------------------------- Куда жаловаться

func newCode() string {
	b := make([]byte, 6)
	rand.Read(b)
	return "FB-" + strings.ToUpper(base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(b))[:8]
}

func (s *Server) fbTopics(c *Ctx) error {
	b, err := s.arr(c.Context(), `SELECT id, title, description, modes, sla_hours FROM fb_topics WHERE active ORDER BY sort, id`)
	if err != nil {
		return err
	}
	return c.Raw(200, b)
}

// fbCreate — POST /api/feedback {topic_id, mode, subject, body}: возвращает код отслеживания.
func (s *Server) fbCreate(c *Ctx) error {
	var in struct {
		TopicID int    `json:"topic_id"`
		Mode    string `json:"mode"`
		Subject string `json:"subject"`
		Body    string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Subject, in.Body = strings.TrimSpace(in.Subject), strings.TrimSpace(in.Body)
	if in.Subject == "" || len([]rune(in.Body)) < 10 {
		return badReq("Заполните тему и описание")
	}
	ctx := c.Context()
	var modes []string
	var handlers []int64
	var title string
	if err := s.db.QueryRow(ctx, `SELECT modes, handler_ids, title FROM fb_topics WHERE id = $1 AND active`, in.TopicID).Scan(&modes, &handlers, &title); err != nil {
		return badReq("Тема не найдена")
	}
	if !contains(modes, in.Mode) {
		return badReq("Этот способ обращения для темы недоступен")
	}
	var author any
	if in.Mode != "anonymous" {
		author = c.U.ID
	}
	code := newCode()
	var id int64
	if err := s.db.QueryRow(ctx, `INSERT INTO fb_reports (code, topic_id, mode, author_id, subject, body) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
		code, in.TopicID, in.Mode, author, in.Subject, in.Body).Scan(&id); err != nil {
		return err
	}
	s.notify(ctx, handlers, "feedback", "Новое обращение: "+title, in.Subject, "/feedback")
	return c.JSON(200, map[string]any{"code": code, "id": id})
}

func (s *Server) canHandleFB(c *Ctx, topicID int) bool {
	if c.U.IsAdmin() || c.U.HR {
		return true
	}
	var ok bool
	s.db.QueryRow(c.Context(), `SELECT $1 = ANY(handler_ids) FROM fb_topics WHERE id = $2`, c.U.ID, topicID).Scan(&ok)
	return ok
}

// fbMine — мои обращения (кроме анонимных: у них нет связи с автором) и очередь обработчика.
func (s *Server) fbMine(c *Ctx) error {
	ctx := c.Context()
	mine, err := s.arr(ctx, `SELECT r.id, r.code, r.subject, r.status, r.mode, r.created_at, r.updated_at, t.title AS topic FROM fb_reports r JOIN fb_topics t ON t.id = r.topic_id
		WHERE r.author_id = $1 ORDER BY r.id DESC LIMIT 100`, c.U.ID)
	if err != nil {
		return err
	}
	inbox, err := s.arr(ctx, `SELECT r.id, r.code, r.subject, r.status, r.mode, r.created_at, r.updated_at, t.title AS topic, t.sla_hours,
			(r.status IN ('new','in_work','need_info') AND r.created_at + make_interval(hours => t.sla_hours) < now()) AS overdue,
			CASE WHEN r.mode = 'named' OR $2::boolean THEN u.full_name END AS author
		FROM fb_reports r JOIN fb_topics t ON t.id = r.topic_id LEFT JOIN users u ON u.id = r.author_id
		WHERE $2::boolean OR $1 = ANY(t.handler_ids) ORDER BY (r.status IN ('resolved','rejected')), r.created_at DESC LIMIT 300`, c.U.ID, c.U.IsAdmin() || c.U.HR)
	if err != nil {
		return err
	}
	return c.JSON(200, map[string]any{"mine": mine, "inbox": inbox})
}

// fbThread — переписка: по id для автора/обработчика (GET /api/feedback/{id}) или по коду (GET /api/feedback/track?code=).
func (s *Server) fbThread(c *Ctx) error {
	ctx := c.Context()
	var id int64
	var topic int
	var author *int64
	var mode string
	if code := strings.TrimSpace(c.Q("code")); code != "" {
		if err := s.db.QueryRow(ctx, `SELECT id, topic_id, author_id, mode FROM fb_reports WHERE code = $1`, strings.ToUpper(code)).Scan(&id, &topic, &author, &mode); err != nil {
			return errNotFound
		}
	} else {
		var err error
		if id, err = c.ID("id"); err != nil {
			return err
		}
		if err := s.db.QueryRow(ctx, `SELECT topic_id, author_id, mode FROM fb_reports WHERE id = $1`, id).Scan(&topic, &author, &mode); err != nil {
			return errNotFound
		}
		if !(author != nil && *author == c.U.ID) && !s.canHandleFB(c, topic) {
			return errForbidden
		}
	}
	handler := s.canHandleFB(c, topic)
	rep, err := s.one(ctx, `SELECT r.id, r.code, r.subject, r.body, r.status, r.result, r.mode, r.created_at, r.updated_at, t.title AS topic,
		CASE WHEN $2::boolean AND (r.mode = 'named' OR $3::boolean) THEN u.full_name END AS author
		FROM fb_reports r JOIN fb_topics t ON t.id = r.topic_id LEFT JOIN users u ON u.id = r.author_id WHERE r.id = $1`, id, handler, c.U.IsAdmin() || c.U.HR)
	if err != nil {
		return err
	}
	msgs, err := s.arr(ctx, `SELECT side, body, created_at FROM fb_messages WHERE report_id = $1 ORDER BY id`, id)
	if err != nil {
		return err
	}
	editable := author != nil && *author == c.U.ID && s.fbEditable(ctx, id)
	return c.JSON(200, map[string]any{"report": rep, "messages": msgs, "handler": handler, "editable": editable})
}

// fbMessage — сообщение в обращение (POST /api/feedback/message {id|code, body}); автор по коду отвечает без входа в учётку обращения.
func (s *Server) fbMessage(c *Ctx) error {
	var in struct {
		ID   int64  `json:"id"`
		Code string `json:"code"`
		Body string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Body = strings.TrimSpace(in.Body)
	if in.Body == "" || len(in.Body) > 4000 {
		return badReq("Введите сообщение")
	}
	ctx := c.Context()
	var topic int
	var author *int64
	var subject string
	q, arg := `SELECT id, topic_id, author_id, subject FROM fb_reports WHERE id = $1`, any(in.ID)
	if in.Code != "" {
		q, arg = `SELECT id, topic_id, author_id, subject FROM fb_reports WHERE code = $1`, strings.ToUpper(strings.TrimSpace(in.Code))
	}
	if err := s.db.QueryRow(ctx, q, arg).Scan(&in.ID, &topic, &author, &subject); err != nil {
		return errNotFound
	}
	handler := s.canHandleFB(c, topic)
	side := "author"
	if handler && !(author != nil && *author == c.U.ID) && in.Code == "" {
		side = "handler"
	} else if in.Code == "" && !(author != nil && *author == c.U.ID) {
		return errForbidden
	}
	var uid any
	if side == "handler" {
		uid = c.U.ID
	}
	if _, err := s.db.Exec(ctx, `INSERT INTO fb_messages (report_id, side, user_id, body) VALUES ($1,$2,$3,$4)`, in.ID, side, uid, in.Body); err != nil {
		return err
	}
	s.db.Exec(ctx, `UPDATE fb_reports SET updated_at = now(), status = CASE WHEN $2 = 'author' AND status = 'need_info' THEN 'in_work' ELSE status END WHERE id = $1`, in.ID, side)
	if side == "handler" && author != nil {
		s.notify(ctx, []int64{*author}, "feedback", "Ответ по обращению", subject, "/feedback")
	} else if side == "author" {
		var hs []int64
		s.db.QueryRow(ctx, `SELECT handler_ids FROM fb_topics WHERE id = $1`, topic).Scan(&hs)
		s.notify(ctx, hs, "feedback", "Новое сообщение в обращении", subject, "/feedback")
	}
	return c.JSON(200, map[string]any{"ok": true})
}

// fbStatus — смена статуса обработчиком (POST /api/feedback/{id}/status {status, result}).
func (s *Server) fbStatus(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Status string `json:"status"`
		Result string `json:"result"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	if !contains([]string{"new", "in_work", "need_info", "resolved", "rejected"}, in.Status) {
		return badReq("Недопустимый статус")
	}
	var topic int
	var author *int64
	var subject string
	if err := s.db.QueryRow(c.Context(), `SELECT topic_id, author_id, subject FROM fb_reports WHERE id = $1`, id).Scan(&topic, &author, &subject); err != nil {
		return errNotFound
	}
	if !s.canHandleFB(c, topic) {
		return errForbidden
	}
	s.db.Exec(c.Context(), `UPDATE fb_reports SET status = $2, result = $3, assigned_to = $4, updated_at = now(),
		closed_at = CASE WHEN $2 IN ('resolved','rejected') THEN now() ELSE NULL END WHERE id = $1`, id, in.Status, in.Result, c.U.ID)
	if author != nil {
		s.notify(c.Context(), []int64{*author}, "feedback", "Статус обращения изменён", subject, "/feedback")
	}
	s.audit(c, "feedback.status", "fb_report", id, map[string]any{"status": in.Status})
	return c.JSON(200, map[string]any{"ok": true})
}

// fbEditable: обращение можно менять и удалять, пока его никто не взял в работу и не ответил.
func (s *Server) fbEditable(ctx context.Context, id int64) bool {
	var ok bool
	err := s.db.QueryRow(ctx, `SELECT r.status = 'new' AND r.assigned_to IS NULL AND NOT EXISTS (SELECT 1 FROM fb_messages m WHERE m.report_id = r.id AND m.side = 'handler')
		FROM fb_reports r WHERE r.id = $1`, id).Scan(&ok)
	return err == nil && ok
}

func (s *Server) fbOwn(c *Ctx, id int64) error {
	var author *int64
	if err := s.db.QueryRow(c.Context(), `SELECT author_id FROM fb_reports WHERE id = $1`, id).Scan(&author); err != nil {
		return errNotFound
	}
	if author == nil || *author != c.U.ID {
		return errForbidden
	}
	if !s.fbEditable(c.Context(), id) {
		return badReq("Обращение уже взято в работу — менять и удалять его нельзя")
	}
	return nil
}

// fbEdit: PUT /api/feedback/{id} {subject, body, mode} — автор правит необработанное обращение.
func (s *Server) fbEdit(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	var in struct {
		Subject string `json:"subject"`
		Body    string `json:"body"`
	}
	if err := c.Decode(&in); err != nil {
		return err
	}
	in.Subject, in.Body = strings.TrimSpace(in.Subject), strings.TrimSpace(in.Body)
	if in.Subject == "" || len([]rune(in.Body)) < 10 {
		return badReq("Заполните тему и описание (не короче 10 символов)")
	}
	if err := s.fbOwn(c, id); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `UPDATE fb_reports SET subject = $2, body = $3, updated_at = now() WHERE id = $1`, id, in.Subject, in.Body); err != nil {
		return err
	}
	return c.OK()
}

// fbDelete: DELETE /api/feedback/{id} — автор удаляет необработанное обращение.
func (s *Server) fbDelete(c *Ctx) error {
	id, err := c.ID("id")
	if err != nil {
		return err
	}
	if err := s.fbOwn(c, id); err != nil {
		return err
	}
	if _, err := s.db.Exec(c.Context(), `DELETE FROM fb_reports WHERE id = $1`, id); err != nil {
		return err
	}
	s.audit(c, "feedback.delete", "fb_report", id, nil)
	return c.OK()
}
