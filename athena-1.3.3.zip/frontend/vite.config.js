import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import legacy from '@vitejs/plugin-legacy'
import path from 'node:path'
import fs from 'node:fs'
import zlib from 'node:zlib'

// Предсжатие brotli (q11) и gzip (9) рядом с файлами сборки. Бэкенд выбирает
// вариант по Accept-Encoding и не тратит CPU на сжатие при каждом запросе.
function precompress() {
  const EXT = /\.(js|mjs|css|html|svg|json|map|txt|woff|ttf)$/
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) =>
      e.isDirectory() ? walk(path.join(dir, e.name)) : [path.join(dir, e.name)])
  return {
    name: 'precompress',
    apply: 'build',
    closeBundle() {
      const out = path.resolve(import.meta.dirname, 'dist')
      if (!fs.existsSync(out)) return
      for (const f of walk(out)) {
        if (!EXT.test(f)) continue
        const buf = fs.readFileSync(f)
        if (buf.length < 1024) continue
        const br = zlib.brotliCompressSync(buf, {
          params: {
            [zlib.constants.BROTLI_PARAM_QUALITY]: 11,
            [zlib.constants.BROTLI_PARAM_SIZE_HINT]: buf.length,
          },
        })
        const gz = zlib.gzipSync(buf, { level: 9 })
        if (br.length < buf.length) fs.writeFileSync(f + '.br', br)
        if (gz.length < buf.length) fs.writeFileSync(f + '.gz', gz)
      }
    },
  }
}

// Воркер pdf.js под старые браузеры.
//
// Готовый pdf.worker.mjs содержит приватные методы классов (#x) — Firefox
// понимает их только с версии 90, и в Firefox ESR 78 документ не открывался.
// Сборка воркера через «?worker» не годится: Vite убирает экспорты точки
// входа, а pdf.js, когда модульный воркер недоступен (Firefox до 114),
// импортирует этот же файл в основном потоке и берёт из него экспорт
// WorkerMessageHandler. Поэтому файл просто понижается esbuild'ом до целевых
// браузеров с сохранением экспортов и кладётся в сборку как отдельный файл.
function pdfWorkerLegacy() {
  let isBuild = false
  const VID = 'virtual:pdf-worker-url'
  return {
    name: 'pdf-worker-legacy',
    configResolved(c) { isBuild = c.command === 'build' },
    resolveId(id) { return id === VID ? '\0' + VID : undefined },
    async load(id) {
      if (id !== '\0' + VID) return undefined
      const src = path.resolve(import.meta.dirname, 'node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs')
      if (!isBuild) return `export default ${JSON.stringify('/@fs' + src)}`
      const { transform } = await import('esbuild')
      const out = await transform(fs.readFileSync(src, 'utf8'), {
        target: ['es2020', 'firefox78', 'chrome87', 'edge88', 'safari14'],
        format: 'esm', minify: true, legalComments: 'none',
      })
      const ref = this.emitFile({ type: 'asset', name: 'pdf.worker.mjs', source: out.code })
      return `export default import.meta.ROLLUP_FILE_URL_${ref}`
    },
  }
}

// Dev-прокси: все /api и /ws идут на бэкенд через тот же origin (localhost:5173),
// поэтому браузер вообще не делает cross-origin запросов и CORS не участвует —
// самый надёжный способ убрать CORS-проблемы в разработке.
//
// Чтобы это работало, фронтенд должен обращаться к ОТНОСИТЕЛЬНЫМ путям
// (/api/...), а не к http://localhost:8080. Это включается, если НЕ задавать
// VITE_API_URL (см. client.js: API_URL по умолчанию пустой -> относительные URL).
// Поддерживаемые браузеры. Нижняя граница — Firefox ESR 78: на рабочих
// местах Debian 10–13 стоят firefox-esr от 78 (давно не обновлявшийся
// Debian 10) до 140 (Debian 13). Синтаксис понижается esbuild'ом под эти
// версии, а недостающие встроенные функции (Array.prototype.at, structuredClone,
// Object.hasOwn и т. п.) добавляет core-js — только те, что реально
// используются в коде (modernPolyfills). Отдельная «legacy»-сборка без ES-модулей
// не нужна: модули есть во всех этих версиях.
const TARGETS = ['firefox >= 78', 'chrome >= 87', 'edge >= 88', 'safari >= 14']

export default defineConfig({
  plugins: [
    react(),
    pdfWorkerLegacy(),
    legacy({ modernTargets: TARGETS, modernPolyfills: true, renderLegacyChunks: false }),
    precompress(),
  ],
  build: {
    target: ['es2020', 'firefox78', 'chrome87', 'edge88', 'safari14'],
    cssCodeSplit: true,
    sourcemap: false,
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      output: {
        // Крупные библиотеки — в свои чанки: они редко меняются и годами
        // лежат в кэше браузера, а код приложения обновляется малым чанком.
        manualChunks(id) {
          if (!id.includes('node_modules')) return undefined
          if (/node_modules\/(react|react-dom|scheduler|react-router|react-router-dom|@remix-run)\//.test(id)) return 'vendor-react'
          if (/node_modules\/(motion|framer-motion|motion-dom|motion-utils)\//.test(id)) return 'vendor-motion'
          if (/node_modules\/pdfjs-dist\//.test(id)) return 'vendor-pdf'
          if (/node_modules\/animejs\//.test(id)) return 'vendor-anime'
          return undefined
        },
      },
    },
  },
  // Алиас @ -> src нужен для компонентов Kokonut UI и Bklit UI (они
  // подключаются как «@/lib/utils» и т. п. — так устроен shadcn-реестр).
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'src') } },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:8080',
        changeOrigin: true,
      },
      '/ws': {
        target: process.env.VITE_PROXY_TARGET || 'http://localhost:8080',
        changeOrigin: true,
        ws: true, // проксируем и WebSocket (чат, уведомления)
      },
    },
  },
})
