package handlers

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/xuri/excelize/v2"

	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/search"
)

// RegistryHandler — журналы/реестры документов: официальные табличные перечни
// со всеми реквизитами (исходящий/входящие номера с датами, рассылка с ФИО,
// должностью и подразделением, согласующие с датами, краткое содержание),
// пригодные для печати и выгрузки в Excel.
type RegistryHandler struct {
	pool *pgxpool.Pool
}

func NewRegistryHandler(pool *pgxpool.Pool) *RegistryHandler {
	return &RegistryHandler{pool: pool}
}

// Вложенные реквизиты (приходят из json_agg подзапросов).
type incomingInst struct {
	Number       string `json:"number"`
	Department   string `json:"department"`
	RegisteredAt string `json:"registered_at"`
}
type recipientRow struct {
	FIO        string `json:"fio"`
	Position   string `json:"position"`
	Department string `json:"department"`
}
type approverRow struct {
	FIO       string `json:"fio"`
	Position  string `json:"position"`
	DecidedAt string `json:"decided_at"`
	Status    string `json:"status"`
}

// registryRow — строка реестра со всеми реквизитами.
type registryRow struct {
	ID              int64          `json:"id"`
	OutgoingNumber  *string        `json:"outgoing_number,omitempty"`
	SignedAt        *string        `json:"signed_at,omitempty"` // дата-время подписи (к исх. номеру)
	IncomingNumbers []incomingInst `json:"incoming_numbers"`    // все вх. номера с подразделением и датой регистрации
	Title           string         `json:"title"`
	Status          string         `json:"status"`
	Urgency         string         `json:"urgency"`
	AuthorName      string         `json:"author_name"` // ФИО (должность)
	SignerName      *string        `json:"signer_name,omitempty"`
	Recipients      []recipientRow `json:"recipients"` // рассылка
	Approvers       []approverRow  `json:"approvers"`  // согласующие с датами
	CreatedAt       string         `json:"created_at"` // дата-время создания
	DueDate         *string        `json:"due_date,omitempty"`
	DueDatetime     *string        `json:"due_datetime,omitempty"`    // срок с временем
	Prints          []printRow     `json:"prints"`                    // распечатанные копии + учёт в журнале
	PrintCount      int            `json:"print_count"`               // #8 — всего выдач на печать (скачиваний)
	PrintRegCount   int            `json:"print_reg_count"`           // #8 — из них зарегистрировано в бумажном журнале
	PrintUsers      int            `json:"print_users"`               // #8 — сколько разных пользователей печатали
	LastPrintedAt   *string        `json:"last_printed_at,omitempty"` // #8 — последняя выдача на печать
	// #17 — переписка и вложения: в журнале и его выгрузке видно, есть ли по
	// документу обсуждение и приложенные файлы, без открытия карточки.
	// Особая отметка — первая колонка журнала.
	SpecialMarkName  string `json:"special_mark_name"`
	SpecialMarkColor string `json:"special_mark_color"`
	MessageCount     int    `json:"message_count"`
	FileCount        int    `json:"file_count"`
}

// registryLimit — сколько строк журнала отдаётся за один запрос. Журнал
// читают глазами и выгружают в Excel, поэтому постраничная навигация здесь не
// нужна, но предел необходим: без него один запрос мог бы вытащить всю базу.
// Отдаётся клиенту вместе с total_count (#9), чтобы было видно, когда журнал
// показан не полностью.
const registryLimit = 100

// printRow — сведения о распечатанной копии для журнала.
type printRow struct {
	FIO        string  `json:"fio"`
	Instance   int     `json:"instance"`
	Copy       int     `json:"copy"`
	PrintedAt  string  `json:"printed_at"`
	RegJournal *string `json:"reg_journal,omitempty"`
	RegNumber  *string `json:"reg_number,omitempty"`
	RegAt      *string `json:"reg_at,omitempty"`
}

// fioPos форматирует "ФИО (должность)".
const fioPosSQL = `%s.full_name || CASE WHEN coalesce(%s.position,'')<>'' THEN ' (' || %s.position || ')' ELSE '' END`

// registryScope — подразделения журналов исходящих и входящих (см. rows).
func registryScope(c *fiber.Ctx, tx pgx.Tx, userID int64) (out, in []int64, err error) {
	q := func(extra string) ([]int64, error) {
		var ids []int64
		err := tx.QueryRow(c.Context(), `
			SELECT coalesce(array_agg(DISTINCT x), '{}') FROM (
			  SELECT primary_department_id AS x FROM users WHERE id = $1 AND primary_department_id IS NOT NULL
			  UNION
			  SELECT dc.descendant_id FROM user_roles ur
			    JOIN department_closure dc ON dc.ancestor_id = coalesce(ur.department_id,
			         (SELECT primary_department_id FROM users WHERE id = $1))
			   WHERE ur.user_id = $1 AND ur.role = 'chief'
			  UNION
			  SELECT urd.department_id FROM user_resolution_departments urd WHERE urd.user_id = $1
			  UNION `+extra+`
			) s`, userID).Scan(&ids)
		return ids, err
	}
	if out, err = q(`SELECT department_id FROM user_visible_departments WHERE user_id = $1`); err != nil {
		return nil, nil, err
	}
	in, err = q(`SELECT department_id FROM user_incoming_departments WHERE user_id = $1 UNION SELECT department_id FROM user_duty_departments WHERE user_id=$1`)
	return out, in, err
}

// rows строит и выполняет запрос журнала по типу kind. year (или "") — фильтр
// по году (по дате создания; для архива — по дате помещения в архив).
// rows возвращает строки журнала и ОБЩЕЕ количество подходящих документов.
//
// #9 — журнал отдаётся порцией (LIMIT registryLimit), и без общего числа
// нельзя было понять, видишь ты весь журнал или его начало. Поэтому рядом со
// списком считается count(*) по тому же условию.
func (h *RegistryHandler) rows(c *fiber.Ctx, kind string, userID int64, export bool) ([]registryRow, int64, error) {
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	year := c.Query("year")
	if kind == "archive" && c.Params("year") != "" {
		year = c.Params("year")
	}

	offset, err := strconv.Atoi(c.Query("offset", "0"))
	if err != nil || offset < 0 {
		return nil, 0, fiber.NewError(400, "неверное смещение страницы")
	}
	pageSQL := " LIMIT " + strconv.Itoa(registryLimit) + " OFFSET " + strconv.Itoa(offset)
	if export {
		pageSQL = ""
	}
	out := []registryRow{}
	var total int64
	err = db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Подразделение пользователя (для фильтра входящих «для подразделения»).
		var deptID int64
		if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
			return e
		}

		var where string
		var args []any
		// ВХОДЯЩИЕ И ИСХОДЯЩИЕ РАЗДЕЛЯЮТСЯ ПО ПРОИСХОЖДЕНИЮ ДОКУМЕНТА.
		//
		// Раньше «исходящие» значили просто «документ получил исходящий номер»,
		// без всякой привязки к подразделению. Из-за этого в исходящие попадали
		// ВСЕ подписанные документы системы, в том числе пришедшие из других
		// подразделений, — а они же одновременно показывались во входящих. То
		// же самое было у распечатанных.
		//
		// Правильное деление делопроизводства такое:
		//   исходящие — документы, СОЗДАННЫЕ в подразделении пользователя и
		//               получившие исходящий номер;
		//   входящие  — документы, ПРИШЕДШИЕ в подразделение пользователя,
		//               то есть созданные в другом подразделении.
		// Условие «подразделение автора не равно моему» и есть то, что убирает
		// пересечение: один и тот же документ не может быть одновременно и
		// нашим исходящим, и нашим входящим.
		//
		// Если подразделение у пользователя не задано (встречается у
		// администратора), делить не по чему. Тогда журналы работают как
		// прежде — иначе человек увидел бы пустой экран и решил, что раздел
		// сломан.
		// ОБЛАСТЬ ЖУРНАЛА — подразделения, чьё делопроизводство человек ведёт
		// или контролирует: своё; подчинённые (роль «может ставить резолюции»
		// в подразделении или выше); назначенная администратором видимость
		// исходящих (для журнала исходящих) и входящих (для журнала входящих).
		// Раньше журнал строился только по своему подразделению, и
		// руководитель, документы которого создаются в подчинённых отделах,
		// видел пустые журналы. Что именно показать, всё равно решают
		// правила доступа базы (RLS): область лишь задаёт, какие журналы.
		outDepts, inDepts, err := registryScope(c, tx, userID)
		if err != nil {
			return err
		}
		outgoingOwn := `d.outgoing_number IS NOT NULL AND d.author_department_id = ANY($1::bigint[])`
		incomingOwn := `EXISTS (SELECT 1 FROM document_recipients r
		                        WHERE r.document_id = d.id AND r.is_planned = false
		                          AND r.recipient_department_id = ANY($1::bigint[])
		                          AND r.recipient_department_id <> d.author_department_id)`
		incomingOwn = "(" + incomingOwn + ` OR EXISTS (SELECT 1 FROM document_incoming_instances i WHERE i.document_id=d.id AND i.receiving_department_id=ANY($1::bigint[]) AND i.receiving_department_id IS DISTINCT FROM d.author_department_id))`
		if deptID == 0 && isAdmin {
			outgoingOwn = `d.outgoing_number IS NOT NULL AND cardinality($1::bigint[]) >= 0`
			incomingOwn = `cardinality($1::bigint[]) >= 0 AND EXISTS (SELECT 1 FROM document_recipients r
			                                  WHERE r.document_id = d.id AND r.is_planned = false)`
		}
		const printed = `EXISTS (SELECT 1 FROM document_prints p WHERE p.document_id = d.id)`

		switch kind {
		case "outgoing":
			where = outgoingOwn
			args = append(args, outDepts)
		case "incoming":
			where = incomingOwn
			args = append(args, inDepts)
		case "printed_outgoing":
			// #8 — Распечатанные ИСХОДЯЩИЕ: наши исходящие, по которым была
			// хотя бы одна выдача на печать.
			where = outgoingOwn + " AND " + printed
			args = append(args, outDepts)
		case "printed_incoming":
			// #8 — Распечатанные ВХОДЯЩИЕ: пришедшие к нам документы, по
			// которым была выдача на печать.
			where = incomingOwn + " AND " + printed
			args = append(args, inDepts)
		case "control":
			// На контроле — ВСЕ документы на контроле.
			where = "d.on_control = true"
		case "all":
			where = "TRUE"
		case "archive":
			where = "d.status='archived'"
		default:
			return fiber.NewError(400, "неизвестный вид журнала")
		}

		// Фильтр по году (по дате создания).
		if year != "" {
			args = append(args, year)
			dateColumn := "d.created_at"
			if kind == "archive" {
				dateColumn = "coalesce(d.archived_at,d.executed_at,d.created_at)"
			}
			where = fmt.Sprintf("(%s) AND EXTRACT(YEAR FROM %s)::text = $%d", where, dateColumn, len(args))
		}

		// #6 — фильтр по категории документа.
		if cat := c.Query("category_id"); cat != "" {
			args = append(args, cat)
			where = fmt.Sprintf("(%s) AND d.category_id = $%d", where, len(args))
		}

		// #26 — фильтр по особой отметке. Требование: отметка участвует во
		// ВСЕХ фильтрах, журнал — не исключение.
		if sm := c.Query("special_mark_id"); sm != "" {
			args = append(args, sm)
			where = fmt.Sprintf("(%s) AND d.special_mark_id = $%d", where, len(args))
		}

		// #3/#27 — Поиск по журналу: наименование, содержание, исходящий
		// номер, ФИО автора, входящие номера. Учитывает выбранный раздел
		// (kind) и год (условия выше сохраняются).
		//
		// ВАЖНО: через fold_ru(), а не ILIKE. ILIKE приводит регистр
		// средствами ОС по ctype базы, и в локали C для кириллицы не делает
		// НИЧЕГО — проверено на живой БД:
		//
		//   title ILIKE '%проведении%' → найдено (регистр совпал)
		//   title ILIKE '%ПРОВЕДЕНИИ%' → НЕ найдено
		//   title ILIKE '%Проведении%' → НЕ найдено
		//
		// То есть поиск по журналу находил документ только при точном
		// совпадении регистра. Везде остальном система уже перешла на
		// fold_ru (миграция 0015), журнал остался единственным местом с
		// ILIKE. Номера сравниваются через normalize_doc_number — тогда
		// находится и «231/2026», и «исх 1 2 231 2026».
		if qs := strings.TrimSpace(c.Query("q")); qs != "" {
			args = append(args, "%"+search.FoldRU(qs)+"%")
			p := len(args)
			normalized := search.NormalizeDocNumber(qs)
			var numberPattern *string
			if normalized != "" {
				pattern := "%" + normalized + "%"
				numberPattern = &pattern
			}
			args = append(args, numberPattern)
			pn := len(args)
			where = fmt.Sprintf(`(%s) AND (
				fold_ru(d.title) LIKE $%d
				OR fold_ru(au.full_name) LIKE $%d
				OR normalize_doc_number(coalesce(d.outgoing_number,'')) LIKE $%d
				OR EXISTS (SELECT 1 FROM document_incoming_instances ii
				           WHERE ii.document_id = d.id
				             AND normalize_doc_number(ii.incoming_number) LIKE $%d)
			)`, where, p, p, pn, pn)
		}

		if err := tx.QueryRow(c.Context(), "SELECT count(*) FROM documents d JOIN users au ON au.id=d.author_id WHERE "+where, args...).Scan(&total); err != nil {
			return err
		}
		q := fmt.Sprintf(`
			SELECT d.id, d.outgoing_number,
			       to_char(sig.signed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS signed_at,
			       d.title,
			       d.status::text, d.urgency::text,
			       `+fmt.Sprintf(fioPosSQL, "au", "au", "au")+` AS author_name,
			       (SELECT `+fmt.Sprintf(fioPosSQL, "su", "su", "su")+`
			        FROM document_signatures ds JOIN users su ON su.id = ds.signer_id
			        WHERE ds.document_id = d.id ORDER BY ds.signed_at DESC LIMIT 1) AS signer_name,
			       to_char(d.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS created_at,
			       to_char(d.due_date, 'YYYY-MM-DD') AS due_date,
			       to_char(d.due_datetime AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS due_datetime,
			       coalesce((SELECT json_agg(json_build_object(
			             'number', i.incoming_number,
			             'department', coalesce(dep.name,''),
			             'registered_at', to_char(coalesce(i.first_viewed_at, i.created_at) AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
			           ORDER BY i.id)
			         FROM document_incoming_instances i
			         LEFT JOIN departments dep ON dep.id = i.receiving_department_id
			         WHERE i.document_id = d.id), '[]') AS incoming_numbers,
			       coalesce((SELECT json_agg(json_build_object(
			             'fio', ru.full_name, 'position', coalesce(ru.position,''),
			             'department', coalesce(rdep.name,'')) ORDER BY ru.full_name)
			         FROM document_recipients r
			         JOIN users ru ON ru.id = r.recipient_user_id
			         LEFT JOIN departments rdep ON rdep.id = r.recipient_department_id
			         WHERE r.document_id = d.id), '[]') AS recipients,
			       coalesce((SELECT json_agg(json_build_object(
			             'fio', apu.full_name, 'position', coalesce(apu.position,''),
			             'decided_at', to_char(aps.decided_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			             'status', aps.status::text) ORDER BY aps.display_order)
			         FROM approval_stages aps
			         JOIN users apu ON apu.id = aps.approver_id
			         WHERE aps.document_id = d.id AND aps.stage_type <> 'signing'), '[]') AS approvers,
			       coalesce((SELECT json_agg(json_build_object(
			             'fio', pu.full_name, 'instance', p.instance_number, 'copy', p.copy_number,
			             'printed_at', to_char(p.printed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			             'reg_journal', p.reg_journal, 'reg_number', p.reg_number,
			             'reg_at', to_char(p.reg_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'))
			           ORDER BY p.printed_at)
			         FROM document_prints p JOIN users pu ON pu.id = p.user_id
			         WHERE p.document_id = d.id), '[]') AS prints,
			       coalesce(sm.name, ''), coalesce(sm.color, ''),
			       -- #17 — комментарии и вложения одним LATERAL
			       coalesce(ch.msg_count, 0),
			       coalesce(ch.file_count, 0)
			FROM documents d
			JOIN users au ON au.id = d.author_id
			LEFT JOIN special_marks sm ON sm.id = d.special_mark_id
			LEFT JOIN LATERAL (
			    SELECT signed_at FROM document_signatures
			    WHERE document_id = d.id ORDER BY signed_at DESC LIMIT 1) sig ON true
			LEFT JOIN LATERAL (
			    SELECT count(*) AS msg_count,
			           coalesce(sum((SELECT count(*) FROM chat_attachments a WHERE a.message_id = m.id)), 0) AS file_count
			    FROM chat_messages m
			    WHERE m.document_id = d.id AND m.deleted_at IS NULL) ch ON true
			WHERE %s
			ORDER BY d.created_at DESC, d.id DESC
			`+pageSQL, where)

		rows, err := tx.Query(c.Context(), q, args...)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r registryRow
			var incJSON, recJSON, apprJSON, printJSON []byte
			if err := rows.Scan(&r.ID, &r.OutgoingNumber, &r.SignedAt, &r.Title,
				&r.Status, &r.Urgency, &r.AuthorName, &r.SignerName, &r.CreatedAt, &r.DueDate, &r.DueDatetime,
				&incJSON, &recJSON, &apprJSON, &printJSON,
				&r.SpecialMarkName, &r.SpecialMarkColor,
				&r.MessageCount, &r.FileCount); err != nil {
				return err
			}
			_ = json.Unmarshal(incJSON, &r.IncomingNumbers)
			_ = json.Unmarshal(recJSON, &r.Recipients)
			_ = json.Unmarshal(apprJSON, &r.Approvers)
			_ = json.Unmarshal(printJSON, &r.Prints)
			fillPrintStats(&r)
			out = append(out, r)
		}
		return rows.Err()
	})
	return out, total, err
}

// List GET /api/registry/:kind — журнал в JSON (для таблицы на фронте).
func (h *RegistryHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	kind := c.Params("kind")
	rows, total, err := h.rows(c, kind, userID, false)
	if err != nil {
		if fe, ok := err.(*fiber.Error); ok {
			return fe
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сформировать журнал")
	}
	// #9 — total_count: сколько всего документов подходит под журнал, limit —
	// сколько строк максимум отдаётся за раз.
	return c.JSON(fiber.Map{"items": rows, "kind": kind, "total_count": total, "limit": registryLimit})
}

// Export GET /api/registry/:kind/export — журнал в Excel (.xlsx) со всеми
// реквизитами. Служебные коды enum заменяются человекочитаемыми подписями.
func (h *RegistryHandler) Export(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	kind := c.Params("kind")
	rows, _, err := h.rows(c, kind, userID, true)
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выгрузить журнал")
	}

	f := excelize.NewFile()
	sheet := "Реестр"
	f.SetSheetName("Sheet1", sheet)

	headers := []string{
		"Особая отметка", "№ исх.", "Дата подписи", "№ вх. (подразделение, дата регистрации)",
		// #31 — столбец «Срочность» убран: поле исключено из системы.
		"Заголовок", "Статус",
		"Автор", "Подписант", "Согласующие (дата/время)",
		"Рассылка (ФИО, должность, подразделение)", "Создан", "Срок",
		// #8 — сведения о печати (полезны в первую очередь для вкладок
		// «Распечатанные входящие/исходящие», но выгружаются всегда).
		"Скачиваний на печать", "Зарегистрировано в журнале", "Печатали (чел.)",
		"Последняя печать", "Печать: детали",
		// #17 — переписка и вложения
		"Комментариев", "Вложений",
	}
	for i, hdr := range headers {
		cell, _ := excelize.CoordinatesToCellName(i+1, 1)
		f.SetCellValue(sheet, cell, hdr)
	}
	for r, row := range rows {
		vals := []string{
			row.SpecialMarkName,
			deref(row.OutgoingNumber), fmtTime(row.SignedAt), joinIncoming(row.IncomingNumbers),
			row.Title, statusLabelRU(row.Status),
			row.AuthorName, deref(row.SignerName), joinApprovers(row.Approvers),
			joinRecipients(row.Recipients), fmtTime(&row.CreatedAt), deref(row.DueDate),
			strconv.Itoa(row.PrintCount), strconv.Itoa(row.PrintRegCount), strconv.Itoa(row.PrintUsers),
			fmtTime(row.LastPrintedAt), joinPrints(row.Prints),
			strconv.Itoa(row.MessageCount), strconv.Itoa(row.FileCount),
		}
		for col, v := range vals {
			cell, _ := excelize.CoordinatesToCellName(col+1, r+2)
			f.SetCellValue(sheet, cell, v)
		}
	}

	c.Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Set("Content-Disposition", fmt.Sprintf(`attachment; filename="registry_%s_%s.xlsx"`, kind, time.Now().Format("2006-01-02")))

	buf, err := f.WriteToBuffer()
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось сформировать XLSX")
	}
	return c.Send(buf.Bytes())
}

func deref(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}

// fmtTime переводит ISO-строку в дату-время dd.mm.yyyy HH:MM для выгрузки.
func fmtTime(s *string) string {
	if s == nil || *s == "" {
		return ""
	}
	t, err := time.Parse(time.RFC3339, *s)
	if err != nil {
		return *s
	}
	return t.Format("02.01.2006 15:04")
}

func joinIncoming(items []incomingInst) string {
	parts := make([]string, 0, len(items))
	for _, i := range items {
		s := i.Number
		if i.Department != "" {
			s += " (" + i.Department
			if i.RegisteredAt != "" {
				if t, err := time.Parse(time.RFC3339, i.RegisteredAt); err == nil {
					s += ", " + t.Format("02.01.2006 15:04")
				}
			}
			s += ")"
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

func joinRecipients(items []recipientRow) string {
	parts := make([]string, 0, len(items))
	for _, r := range items {
		s := r.FIO
		if r.Position != "" {
			s += ", " + r.Position
		}
		if r.Department != "" {
			s += ", " + r.Department
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

func joinApprovers(items []approverRow) string {
	parts := make([]string, 0, len(items))
	for _, a := range items {
		s := a.FIO
		if a.Position != "" {
			s += " (" + a.Position + ")"
		}
		if a.DecidedAt != "" {
			if t, err := time.Parse(time.RFC3339, a.DecidedAt); err == nil {
				s += " — " + t.Format("02.01.2006 15:04")
			}
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "\n")
}

// ArchiveYears GET /api/registry/archive/years — годы с архивными документами.
func (h *RegistryHandler) ArchiveYears(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	type yearRow struct {
		Year  int   `json:"year"`
		Count int64 `json:"count"`
	}
	var items []yearRow
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT EXTRACT(YEAR FROM coalesce(archived_at, executed_at, created_at))::int AS y, count(*)
			FROM documents
			WHERE status = 'archived'
			GROUP BY y ORDER BY y DESC`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var r yearRow
			if err := rows.Scan(&r.Year, &r.Count); err != nil {
				return err
			}
			items = append(items, r)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить годы архива")
	}
	return c.JSON(fiber.Map{"items": items})
}

// ArchiveByYear GET /api/registry/archive/:year — архивные документы за год,
// со всеми реквизитами (переиспользует обогащённый rows-запрос с фильтром).
func (h *RegistryHandler) ArchiveByYear(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	rows, total, err := h.rows(c, "archive", userID, false)
	if err != nil {
		return err
	}
	return c.JSON(fiber.Map{"items": rows, "total_count": total, "limit": registryLimit, "year": c.Params("year")})
}

// statusLabelRU переводит коды enum статуса в подписи для выгрузок.
func statusLabelRU(s string) string {
	m := map[string]string{
		"draft": "Черновик", "on_approval_hierarchy": "Согласование (иерархия)",
		"on_approval_cross_dept": "Согласование (межвед.)", "on_signing": "На подписи",
		"signed": "Подписан", "sent": "Направлен", "in_progress": "В работе",
		"executed": "Исполнен", "archived": "В архиве", "rejected": "Отклонён",
	}
	if v, ok := m[s]; ok {
		return v
	}
	return s
}

// urgencyLabelRU переводит коды срочности в подписи для выгрузок и истории
// изменений карточки (, п. 6 — «все значения выдавать не как Id, а
// значения»). Рядом со statusLabelRU намеренно: это один и тот же вид работы —
// перевод значений перечисления в человеческие слова, и держать их в разных
// файлах значит однажды перевести одно и забыть другое.
func urgencyLabelRU(s string) string {
	switch s {
	case "normal":
		return "Обычная"
	case "urgent":
		return "Срочно"
	case "out_of_turn":
		return "Вне очереди"
	}
	return s
}

// fillPrintStats считает агрегаты по выдачам на печать для строки журнала (#8):
// сколько всего скачиваний, сколько из них зарегистрировано в бумажном журнале,
// сколько разных пользователей печатали и когда была последняя выдача.
func fillPrintStats(r *registryRow) {
	r.PrintCount = len(r.Prints)
	users := make(map[string]struct{}, len(r.Prints))
	var last string
	for _, p := range r.Prints {
		if p.RegAt != nil && *p.RegAt != "" {
			r.PrintRegCount++
		}
		users[p.FIO] = struct{}{}
		if p.PrintedAt > last {
			last = p.PrintedAt
		}
	}
	r.PrintUsers = len(users)
	if last != "" {
		r.LastPrintedAt = &last
	}
}

// joinPrints — текстовое представление выдач на печать для Excel (#8).
func joinPrints(items []printRow) string {
	parts := make([]string, 0, len(items))
	for _, p := range items {
		s := fmt.Sprintf("Экз. №%d · Копия №%d · %s · %s", p.Instance, p.Copy, p.FIO, fmtTime(&p.PrintedAt))
		if p.RegAt != nil && *p.RegAt != "" {
			s += fmt.Sprintf(" · журнал «%s» №%s от %s", deref(p.RegJournal), deref(p.RegNumber), fmtTime(p.RegAt))
		} else {
			s += " · не зарегистрирован"
		}
		parts = append(parts, s)
	}
	return strings.Join(parts, "; ")
}
