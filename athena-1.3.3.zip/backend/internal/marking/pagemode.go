package marking

import "sync/atomic"

// Режим страниц маркировки: "first" — только первая страница, "all" — каждая.
// Хранится в system_settings (marking.page_mode), в памяти — для быстрого
// доступа из рендера и из GetMarking.
var pageMode atomic.Value

func init() { pageMode.Store("first") }

// PageMode возвращает текущий режим: "first" или "all".
func PageMode() string {
	if v, ok := pageMode.Load().(string); ok && v == "all" {
		return "all"
	}
	return "first"
}

// SetPageMode задаёт режим; любое значение, кроме "all", означает "first".
func SetPageMode(m string) {
	if m == "all" {
		pageMode.Store("all")
		return
	}
	pageMode.Store("first")
}

// watermarkPages — список страниц для pdfcpu: nil означает все страницы.
func watermarkPages() []string {
	if PageMode() == "all" {
		return nil
	}
	return []string{"1"}
}
