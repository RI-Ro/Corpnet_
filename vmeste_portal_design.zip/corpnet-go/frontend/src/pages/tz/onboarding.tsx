import { useState } from 'react';
import './tz.css';
import { api } from '../../lib/api';
import { useQuery, invalidate } from '../../lib/query';
import { toast, useStore } from '../../lib/store';
import { Avatar, Badge, Btn, Empty, Loading, Tabs, Textarea } from '../../ui';
import { Link, useTitle, useSearchParams } from '../../lib/router';
import { cx, fmtShort as fmtDate } from '../../lib/util';
import * as I from '../../lib/icons';
import { errMsg } from './common';

const WHO: Record<string, string> = { employee: 'Вы', manager: 'Руководитель', mentor: 'Наставник', hr: 'HR' };

function Plan({ plan, items, mine, canEditFor }: { plan: any; items: any[]; mine: boolean; canEditFor: boolean }) {
  const me = useStore((s) => s.me)!;
  const pct = plan.total ? Math.round((plan.done * 100) / plan.total) : 0;
  const sections = [...new Set(items.map((i) => i.section))];
  async function toggle(it: any) {
    try { const r = await api.post<{ finished: boolean }>(`/api/onboarding/items/${it.id}/done`, { plan_id: plan.id, undo: it.done }); invalidate('ob'); invalidate('home'); invalidate('gf'); if (r.finished) toast({ title: '🎉 Адаптация завершена!', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
  }
  const can = (_it: any) => me.role === 'admin' || me.hr_admin || mine || canEditFor;
  return (
    <div className="stack">
      <div className="card tzHero">
        <div className="tzRing" style={{ ['--p' as any]: pct, width: 84, height: 84 }}><b style={{ width: 66, height: 66, fontSize: 18 }}>{pct}%</b></div>
        <div className="stackS"><h2>{plan.template}</h2>
          <div className="small muted">День {plan.day} из {plan.duration_days} · выполнено {plan.done} из {plan.total}{plan.overdue ? ` · просрочено: ${plan.overdue}` : ''}</div>
          {plan.mentor_name && <div className="row small"><Avatar name={plan.mentor_name} src={plan.mentor_avatar} size={26} /> Наставник: <Link to={`/people/${plan.mentor_id}`}><b>{plan.mentor_name}</b></Link></div>}</div>
      </div>
      {sections.map((sec) => (
        <div key={sec} className="stackS"><h3>{sec || 'Шаги'}</h3>
          {items.filter((i) => i.section === sec).map((it) => (
            <div key={it.id} className={cx('tzStep', it.done && 'done', it.overdue && 'late')}>
              <button className={cx('tzCheck', it.done && 'on')} disabled={!can(it)} onClick={() => toggle(it)} aria-label={(it.done ? 'Снять отметку: ' : 'Отметить выполненным: ') + it.title}>{it.done && <I.Check size={16} />}</button>
              <div><b className={cx('small', it.done && 'strike')}>{it.link ? <Link to={it.link}>{it.title}</Link> : it.title}</b>{it.description && <div className="small muted">{it.description}</div>}
                <div className="tiny muted">Ответственный: {WHO[it.assignee]} · срок {fmtDate(it.due)}{!it.required ? ' · по желанию' : ''}</div></div>
              {it.overdue ? <Badge kind="dng">Просрочено</Badge> : it.done ? <Badge kind="ok">Готово</Badge> : null}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function Intros() {
  const me = useStore((s) => s.me)!;
  const q = useQuery<any[]>('ob:intros', () => api.get('/api/onboarding/intros'));
  const [body, setBody] = useState('');
  const mine = (q.data || []).some((i) => i.user_id === me.id);
  async function save() { try { await api.put('/api/onboarding/intro', { body }); setBody(''); invalidate('ob'); invalidate('gf'); toast({ title: 'Спасибо, коллеги увидят ваш рассказ', kind: 'success' }); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); } }
  return (
    <div className="stack">
      {!mine && <div className="card pad stack"><h3>Расскажите о себе</h3><Textarea rows={4} maxLength={2000} placeholder="Чем занимались раньше, что любите, чем можете быть полезны коллегам…" value={body} onChange={(e) => setBody(e.target.value)} /><div><Btn kind="pri" disabled={body.trim().length < 5} onClick={save}>Опубликовать</Btn></div></div>}
      <div className="tzGrid">{(q.data || []).map((i) => (
        <div key={i.user_id} className="card tzW"><div className="row"><Avatar name={i.name} src={i.avatar} size={44} /><div className="sp"><Link to={`/people/${i.user_id}`}><b>{i.name}</b></Link><div className="tiny muted">{[i.job_title, i.department].filter(Boolean).join(' · ')}</div></div></div><div className="small" style={{ whiteSpace: 'pre-wrap' }}>{i.body}</div></div>
      ))}</div>
    </div>
  );
}

function Team() {
  const q = useQuery<any[]>('ob:team', () => api.get('/api/onboarding/team'));
  if (!q.data) return <Loading />;
  if (!q.data.length) return <Empty icon={I.Users} title="Подопечных нет">Здесь появятся новички, у которых вы наставник или руководитель.</Empty>;
  return <div className="stackS">{q.data.map((p) => { const pct = p.total ? Math.round((p.done * 100) / p.total) : 0; return (
    <Link key={p.id} to={`/onboarding?user=${p.user_id}`} className="card pad row" style={{ color: 'inherit' }}><Avatar name={p.name} src={p.avatar} size={40} /><div className="sp"><b className="small">{p.name}</b><div className="tiny muted">{p.job_title} · день {p.day}</div><div className="tzBar" style={{ marginTop: 6 }}><i style={{ width: pct + '%' }} /></div></div>{p.overdue > 0 && <Badge kind="dng">Просрочено {p.overdue}</Badge>}<b>{pct}%</b></Link>); })}</div>;
}

export function OnboardingPage() {
  useTitle('Адаптация');
  const [sp] = useSearchParams();
  const user = sp.get('user');
  const [tab, setTab] = useState<'me' | 'team' | 'intros'>(sp.get('tab') === 'intros' ? 'intros' : user ? 'me' : 'me');
  const q = useQuery<any>('ob:me:' + (user || ''), () => api.get('/api/onboarding/me' + (user ? '?user=' + user : '')), { stale: 10000 });
  const d = q.data;
  return (
    <div className="stack">
      <div className="pageH"><h1>Адаптация</h1></div>
      <Tabs value={tab} onChange={(v) => setTab(v as any)} items={[{ id: 'me', label: user ? 'План сотрудника' : 'Мой план' }, { id: 'team', label: 'Мои подопечные' }, { id: 'intros', label: 'Знакомьтесь' }]} />
      {tab === 'me' && (!d ? <Loading /> : d.plans.length === 0 ? <div className="card"><Empty icon={I.GradCap} title="План адаптации не назначен">Он появится автоматически, когда HR укажет дату вашего выхода на работу.</Empty></div> :
        d.plans.map((p: any) => <Plan key={p.id} plan={p} items={d.items.filter((i: any) => i.plan_id === p.id)} mine={!user} canEditFor={!!user} />))}
      {tab === 'team' && <Team />}
      {tab === 'intros' && <Intros />}
    </div>
  );
}
