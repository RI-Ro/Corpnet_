import React, { useEffect, useRef } from 'react'
import { animate } from 'motion/react'
import { prefersReducedMotion } from './presets'

// AnimatedNumber — число, которое «докатывается» до нового значения.
// Пишет прямо в DOM-узел, минуя React-рендер на каждом кадре, поэтому не
// нагружает страницы с десятками счётчиков. Первое значение показывается
// сразу, анимируются только изменения (и первое появление с нуля, если
// from="zero").
export default function AnimatedNumber({
  value,
  format = (n) => String(Math.round(n)),
  duration = 0.7,
  from,
  className,
  style,
}) {
  const ref = useRef(null)
  const prev = useRef(from === 'zero' ? 0 : value)

  useEffect(() => {
    const node = ref.current
    const target = Number(value)
    if (!node || !Number.isFinite(target)) return undefined
    if (prefersReducedMotion() || prev.current === target) {
      node.textContent = format(target)
      prev.current = target
      return undefined
    }
    const controls = animate(prev.current, target, {
      duration,
      ease: [0.23, 1, 0.32, 1],
      onUpdate: (v) => {
        node.textContent = format(v)
      },
    })
    prev.current = target
    return () => controls.stop()
    // format намеренно не в зависимостях: его обычно создают в рендере.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, duration])

  const initial = Number.isFinite(Number(value)) ? format(from === 'zero' ? 0 : Number(value)) : String(value)
  return (
    <span ref={ref} className={className} style={style}>
      {initial}
    </span>
  )
}
