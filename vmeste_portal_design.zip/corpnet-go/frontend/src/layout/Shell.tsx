import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { animate } from 'motion';
import { movePill } from '../lib/fx';
import * as I from '../lib/icons';
import { Link, navigate, useLocation } from '../lib/router';
import { useStore, setState, getState, toast, isEditor, isAdmin, canWrite } from '../lib/store';
import { api, errMsg } from '../lib/api';
import { useQuery, invalidate } from '../lib/query';
import { realtime, useRealtime } from '../lib/ws';
import { cx, fmtDate, useDebounced, thumb, plural } from '../lib/util';
import { Avatar, Img, Loading, usePopover, Toasts } from '../ui';
import { Banners } from '../ui/Banners';
import { stripMd } from '../lib/markdown';
import { usePersist } from '../lib/persist';
import { useAppearance, setAppearance } from '../lib/appearance';
import { buildMenu, MENU } from '../lib/menu';
import { playSound } from '../lib/sound';
import { trackPageview, trackSearchClick, resetPageview } from '../lib/analytics';
import { NotifRow, useNotifications, type NotifFilter } from '../pages/notifications';
import { wikiLink } from '../pages/wiki/lib';
import { ReqIcon } from '../pages/requests/icons';
import { FileHitRow, type FileHit } from '../ui/FileHit';
import { usePdfPreview } from '../ui/PdfViewer';
import * as X from '../lib/social-icons';
import './shell.css';

const HeaderProgress = React.lazy(() => import('../pages/tz/home').then((m) => ({ default: m.HeaderProgress })));
const RailQuickLinks = React.lazy(() => import('../pages/tz/home').then((m) => ({ default: m.RailQuickLinks })));
const RailAsk = React.lazy(() => import('../pages/tz/home').then((m) => ({ default: m.RailAsk })));

function GlobalSearch() {
  const pdf = usePdfPreview();
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const dq = useDebounced(q.trim(), 250);
  const ref = useRef<HTMLDivElement>(null);
  const { data, error, loading, refetch } = useQuery<any>(dq.length >= 2 ? 'search:' + dq : null, () => api.get('/api/search?q=' + encodeURIComponent(dq)), { stale: 60000 });
  useEffect(() => {
    const d = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    addEventListener('mousedown', d);
    return () => removeEventListener('mousedown', d);
  }, []);
  const searchInput = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const focus = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.code === 'KeyK' && !document.querySelector('[aria-modal="true"]')) {
        event.preventDefault();
        searchInput.current?.focus();
        searchInput.current?.select();
      }
    };
    window.addEventListener('keydown', focus);
    return () => window.removeEventListener('keydown', focus);
  }, []);
  const go = (to: string) => { setOpen(false); setQ(''); navigate(to); };
  const A = ({ to, children }: { to: string; children: React.ReactNode }) => <a href={to} onClick={(e) => { e.preventDefault(); trackSearchClick(dq, 'global', to.replace(/^\//, '').replace(/\?.*$/, '')); go(to); }}>{children}</a>;
  const g = (k: string): any[] => (dq.length >= 2 && data?.[k]) || [];
  const none = data && ['news', 'users', 'departments', 'files', 'file_content', 'groups', 'ideas', 'wiki'].every((k) => !g(k).length);
  const typing = q.trim().length >= 2 && q.trim() !== dq;
  return (
    <div className="searchBox" ref={ref}>
      <I.Search size={18} />
      <input
        ref={searchInput}
        aria-keyshortcuts="Control+k Meta+k"
        value={q}
        placeholder="Поиск новостей, людей, файлов, идей…"
        aria-label="Поиск"
        onFocus={() => setOpen(true)}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }}
        onKeyDown={(e) => { if (e.key === 'Enter' && q.trim().length >= 2) go('/search?q=' + encodeURIComponent(q.trim())); if (e.key === 'Escape') setOpen(false); }}
      />
      {open && q.trim().length > 0 && (
        <div className="sugg">
          {q.trim().length < 2 && <div className="muted small" style={{ padding: 14 }}>Введите минимум 2 символа</div>}
          {q.trim().length >= 2 && (loading || typing) && <Loading />}
          {q.trim().length >= 2 && error && !typing && !loading && <div className="searchFailure" role="status">Поиск временно недоступен <button className="btn sm" onClick={refetch}>Повторить</button></div>}
          {q.trim().length >= 2 && !error && !typing && none && <div className="muted" style={{ padding: 16 }}>Ничего не найдено</div>}
          {!typing && g('news').length > 0 && <div className="sh">Новости</div>}
          {!typing && g('news').map((n: any) => <A key={'n' + n.id} to={`/news/${n.id}`}><Img className="thumbS" style={{ width: 40, height: 40 }} src={thumb(n.cover)} /><span className="clamp2 small">{n.title}</span></A>)}
          {!typing && g('users').length > 0 && <div className="sh">Сотрудники</div>}
          {!typing && g('users').map((u: any) => <A key={'u' + u.id} to={`/people/${u.id}`}><Avatar name={u.name} src={u.avatar} size={34} /><span style={{ minWidth: 0 }}><div className="small bold clip">{u.name}</div><div className="tiny muted clip">{[u.job_title, u.department].filter(Boolean).join(' · ')}</div></span></A>)}
          {!typing && g('departments').length > 0 && <div className="sh">Подразделения</div>}
          {!typing && g('departments').map((d: any) => <A key={'d' + d.id} to={`/departments/${d.id}`}><I.Building size={18} /><span className="small">{d.name}</span></A>)}
          {!typing && g('groups').length > 0 && <div className="sh">Группы</div>}
          {!typing && g('groups').map((x: any) => <A key={'g' + x.id} to={`/groups/${x.id}`}><I.Users size={18} /><span className="small">{x.name}</span></A>)}
          {!typing && g('ideas').length > 0 && <div className="sh">Идеи</div>}
          {!typing && g('ideas').map((x: any) => <A key={'i' + x.id} to={`/ideas/${x.id}`}><I.Lightbulb size={18} /><span className="small clamp2">{x.title}</span></A>)}
          {!typing && g('wiki').length > 0 && <div className="sh">Базы знаний</div>}
          {!typing && g('wiki').map((w: any) => <A key={'w' + w.id} to={wikiLink(w)}><span style={{ fontSize: 18, width: 24, textAlign: 'center' }}>{w.space_icon || '📘'}</span><span style={{ minWidth: 0 }}><div className="small bold clip">{w.title}</div><div className="tiny muted clip">{w.space_title}</div></span></A>)}
          {!typing && g('files').length > 0 && <div className="sh">Файлы</div>}
          {!typing && g('files').map((f: any) => <A key={'f' + f.id} to={`/${f.kind}?folder=${f.folder_id}`}><I.File size={18} /><span className="small clip">{f.name} <span className="muted">· {f.folder}</span></span></A>)}
          {!typing && g('file_content').length > 0 && <div className="sh">В содержимом файлов</div>}
          {!typing && g('file_content').map((h: FileHit) => <FileHitRow key={'c' + h.id} h={h} q={dq} compact pdf={pdf} onNavigate={() => { setOpen(false); setQ(''); }} />)}
          {data && !typing && !none && q.trim().length >= 2 && <a href={'/search?q=' + encodeURIComponent(q.trim())} onClick={(e) => { e.preventDefault(); go('/search?q=' + encodeURIComponent(q.trim())); }} style={{ borderTop: '1px solid var(--line)', color: 'var(--accent)', fontWeight: 600 }}>Все результаты →</a>}
        </div>
      )}
      {pdf.node}
    </div>
  );
}

function Notifications() {
  const { open, setOpen, ref } = usePopover();
  const unread = useStore((s) => s.unreadNotifications);
  const [tab, setTab] = usePersist<NotifFilter>('notif.tab', 'unread');
  const L = useNotifications(tab, 8);
  // useNotifications подписан на realtime 'refresh' и обновляет счётчик, даже когда окно закрыто
  const close = () => setOpen(false);
  const bell = useRef<HTMLSpanElement>(null);
  const prev = useRef(unread);
  useEffect(() => { // новое уведомление → колокольчик «звенит» (motion)
    if (unread > prev.current && bell.current && !matchMedia('(prefers-reduced-motion: reduce)').matches)
      animate(bell.current, { transform: ['rotate(0deg)', 'rotate(-16deg)', 'rotate(13deg)', 'rotate(-9deg)', 'rotate(5deg)', 'rotate(0deg)'] }, { duration: 0.7 });
    prev.current = unread;
  }, [unread]);
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="iconBtn" aria-label={unread > 0 ? `Уведомления, непрочитанных: ${unread}` : 'Уведомления'} aria-expanded={open} onClick={() => setOpen(!open)}>
        <span ref={bell} style={{ display: 'grid', transformOrigin: '50% 10%' }}><I.Bell size={21} /></span>
        {unread > 0 && <span className="dot">{unread > 99 ? '99+' : unread}</span>}
      </button>
      {open && (
        <div className="pop">
          <div className="ph">
            <span className="sp">Уведомления</span>
            {tab === 'unread' && unread > 0 && <button className="btn ghost sm" onClick={L.markAll}><I.CheckCheck size={15} /> Прочитать все</button>}
          </div>
          <div className="popTabs">
            <button className={cx(tab === 'unread' && 'on')} onClick={() => setTab('unread')}>Непрочитанные{unread > 0 ? ` · ${unread}` : ''}</button>
            <button className={cx(tab === 'read' && 'on')} onClick={() => setTab('read')}>Прочитанные</button>
          </div>
          <div className="pb">
            {L.loading && !L.items.length ? <Loading /> : L.items.length === 0 ? (
              <div className="empty"><I.Bell size={32} />{tab === 'unread' ? 'Новых уведомлений нет' : 'Прочитанных нет'}</div>
            ) : L.items.map((n) => <NotifRow key={n.id} n={n} onOpen={() => L.open(n, close)} onRead={() => L.markRead([n.id])} />)}
          </div>
          <Link to="/notifications" className="popFoot" onClick={close}>
            {L.hasMore ? 'Показать все уведомления →' : 'Все уведомления →'}
          </Link>
        </div>
      )}
    </div>
  );
}

function ProfileMenu() {
  const me = useStore((s) => s.me)!;
  const { open, setOpen, ref } = usePopover();
  async function logout() {
    try { await api.post('/api/auth/logout'); } catch (error) { toast({ title: errMsg(error), kind: 'error' }); return; }
    try { sessionStorage.setItem('krb_off', '1'); } catch {} // после выхода не входить автоматически по Kerberos (login.tsx)
    realtime.stop();
    location.href = '/login';
  }
  return (
    <div style={{ position: 'relative' }} ref={ref}>
      <button className="profBtn" onClick={() => setOpen(!open)} aria-label="Профиль">
        <Avatar name={me.name} src={me.avatar} size={38} />
        <span className="pt"><div className="pn">{me.first_name}</div><div className="pr">{me.job_title || (me.role === 'admin' ? 'Администратор' : me.role === 'editor' ? 'Редактор' : '')}</div></span>
      </button>
      {open && (
        <div className="menu" onClick={() => setOpen(false)}>
          <Link to={`/people/${me.id}`}><I.UserCheck size={18} /> Мой профиль</Link>
          <Link to="/settings"><I.Settings size={18} /> Настройки</Link>
          {isEditor(me) && <><hr /><Link to="/admin"><I.Dashboard size={18} /> {isAdmin(me) ? 'Администрирование' : 'Управление новостями'}</Link></>}
          <hr />
          <button onClick={logout}><I.Logout size={18} /> Выйти</button>
        </div>
      )}
    </div>
  );
}

function RightRail({ featured }: { featured: boolean }) {
  const imp = useQuery<any>('rail:important', () => api.get('/api/news?important=1&per=4'), { stale: 60000 });
  const ev = useQuery<any[]>('rail:events', () => api.get('/api/events/upcoming'), { stale: 60000 });
  const leadIds = new Set(featured ? imp.data?.items?.slice(0, 3).map((n: { id: number }) => n.id) : []);
  const impList: any[] = [...(imp.data?.items || []), ...(imp.data?.pinned || [])].filter((n, i, a) => !leadIds.has(n.id) && a.findIndex((x) => x.id === n.id) === i).sort((x, y) => (y.published_at || '').localeCompare(x.published_at || '')).slice(0, 4);
  const birthdays = (ev.data || []).filter((e) => e.id < 0);
  const events = (ev.data || []).filter((e) => e.id > 0).slice(0, 6);
  const dm = (iso: string) => { const d = new Date(iso); return [d.getDate(), d.toLocaleDateString('ru', { month: 'short' }).replace('.', '')]; };
  return (
    <aside className="rail">
      <Banners />
      {impList.length > 0 && (
        <div className="card railC">
          <h4><I.Zap size={17} style={{ color: 'var(--warn)' }} /> Важное</h4>
          {impList.map((n: any) => (
            <Link key={n.id} to={`/news/${n.id}`} className="it">
              <Img className="thumbS" src={thumb(n.cover)} />
              <div style={{ minWidth: 0 }}><div className="small bold clamp2">{n.title}</div><div className="tiny faint">{fmtDate(n.published_at)}</div></div>
            </Link>
          ))}
        </div>
      )}
      <div className="card railC">
        <h4><I.Calendar size={17} style={{ color: 'var(--accent)' }} /> Ближайшие 5 дней</h4>
        {ev.data && events.length === 0 && <div className="small muted" style={{ padding: '0 18px 16px' }}>Нет запланированных событий</div>}
        {events.map((e) => { const [d, m] = dm(e.starts_at); return (
          <Link key={e.id + e.starts_at} to={`/calendar?event=${e.id}`} className="it">
            <div className="dateBox"><b>{d}</b><span>{m}</span></div>
            <div style={{ minWidth: 0 }}><div className="small bold clamp2">{e.title}</div><div className="tiny faint">{e.all_day ? 'Весь день' : new Date(e.starts_at).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' })}{e.location ? ' · ' + e.location : ''}</div></div>
          </Link>
        ); })}
      </div>
      {birthdays.length > 0 && (
        <div className="card railC">
          <h4><I.Cake size={17} style={{ color: 'var(--danger)' }} /> Дни рождения</h4>
          {birthdays.slice(0, 6).map((e) => { const [d, m] = dm(e.starts_at); const nm = String(e.title).replace('День рождения: ', ''); const Tag: any = e.user_id ? Link : 'div'; return (
            <Tag key={e.id} {...(e.user_id ? { to: `/people/${e.user_id}` } : {})} className="it">
              <div className="dateBox" style={{ background: 'var(--danger-soft)', color: 'var(--danger)' }}><b>{d}</b><span>{m}</span></div>
              <div style={{ minWidth: 0 }}>
                <div className="small bold">{nm}</div>
                <div className="tiny faint clip">{[e.age ? plural(e.age, ['год', 'года', 'лет']) : '', e.description].filter(Boolean).join(' · ')}</div>
              </div>
            </Tag>
          ); })}
        </div>
      )}
      <React.Suspense fallback={null}><RailQuickLinks /><RailAsk /></React.Suspense>
    </aside>
  );
}

export function Shell({ children, rail, wide }: { children: React.ReactNode; rail?: boolean; wide?: boolean }) {
  const { path, search } = useLocation();
  const company = useStore((s) => s.company);
  const unreadChats = useStore((s) => s.unreadChats);
  const wsOnline = useStore((s) => s.wsOnline);
  const me = useStore((s) => s.me)!;
  const [menu, setMenu] = useState(false);
  // меню можно скрыть (запоминается): на экранах шире 960 px оно тогда выезжает по кнопке, освобождая место под содержимое
  const ap = useAppearance();
  const sideOff = ap.sideOff;
  const modulesOff = useStore((s) => s.modulesOff);
  const site = useStore((s) => s.site);
  const blocked = !isAdmin(me) && MENU.some((m) => m.module && modulesOff.includes(m.module) && m.to !== '/' && (path === m.to || path.startsWith(m.to + '/')));
  const menu2 = buildMenu(me, modulesOff, ap.menuOrder, ap.menuHidden);
  const setSideOff = (v: boolean) => setAppearance({ sideOff: v });
  useEffect(() => setMenu(false), [path, search]);
  useEffect(() => {
    if (!menu) return;
    const close = (e: KeyboardEvent) => { if (e.key === 'Escape') { setMenu(false); document.querySelector<HTMLButtonElement>('.menuBtn')?.focus(); } };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [menu]);
  const navRef = useRef<HTMLElement>(null);
  useLayoutEffect(() => { movePill(navRef.current); }, [path, wide, me.role]);
  useEffect(() => { const f = () => movePill(navRef.current); addEventListener('resize', f); document.fonts?.ready.then(f); return () => removeEventListener('resize', f); }, []);
  useEffect(() => { trackPageview(path); }, [path]); // аналитика посещений разделов
  useEffect(() => resetPageview, []);

  // --- global realtime wiring (works identically whichever instance serves the socket)
  const chats = useQuery<any[]>('chats', () => api.get('/api/chats'), { stale: 20000 });
  useEffect(() => { if (chats.data) setState({ unreadChats: chats.data.reduce((a, c) => a + (c.unread || 0), 0) }); }, [chats.data]);
  useRealtime('presence', (d) => setState((s) => { const n = new Set(s.online); d.online ? n.add(d.user_id) : n.delete(d.user_id); return { online: n }; }));
  useRealtime('message', (d) => {
    invalidate('chats');
    const m = d.message;
    if (m.user_id !== me.id && !(location.pathname === '/messages' && new URLSearchParams(location.search).get('chat') === String(d.chat_id) && document.visibilityState === 'visible')) {
      toast({ title: m.author, body: m.body ? stripMd(m.body) : '📎 Вложение', link: `/messages?chat=${d.chat_id}`, kind: 'message' });
      playSound('message');
    }
  });
  const reqCnt = useQuery<{ inbox: number; rework: number }>('req:counts', () => api.get('/api/requests/counts'), { stale: 30000 });
  useRealtime('req', () => invalidate('req:'));
  useRealtime('chat', () => invalidate('chats'));
  useRealtime('read', (d) => d.user_id === me.id && invalidate('chats'));
  useRealtime('message.update', () => invalidate('chats'));
  useRealtime('news.new', (d) => {
    invalidate('news'); invalidate('rail:');
    if (d.title && d.author_id !== me.id) { toast({ title: d.important ? '⚡ Важная новость' : 'Новая публикация', body: d.title, link: `/news/${d.id}`, kind: 'news' }); playSound('news'); }
  });
  useRealtime('notif', (d) => { if (d?.kind !== 'message') playSound('notify'); });
  useRealtime('reconnected', () => { invalidate(() => true); api.get('/api/presence').then((r) => setState({ online: new Set<number>(r.online) })).catch(() => {}); });
  useEffect(() => { api.get('/api/presence').then((r) => setState({ online: new Set<number>(r.online) })).catch(() => {}); }, []);

  return (
    <>
      <a className="skipContent" href="#portal-content">К содержимому</a>
      <header className="hdr">
        <div className="hdrIn">
          <button className="iconBtn menuBtn" onClick={() => setMenu(true)} aria-label="Меню" aria-expanded={menu}><I.Menu size={22} /></button>
          <button className="iconBtn sideToggle" onClick={() => setSideOff(!sideOff)} aria-label={sideOff ? 'Показать меню' : 'Свернуть меню'} aria-expanded={!sideOff} title={sideOff ? 'Показать меню' : 'Свернуть меню'}><I.Menu size={22} /></button>
          <Link to="/" className="logo" aria-label={site.name || 'На главную'}>
            {site.logo ? <img className="logoImg" src={thumb(site.logo)} alt="" /> : <span className="logoMark"><I.Newspaper size={20} /></span>}
            <span className="lt">{site.name}</span>
          </Link>
          <GlobalSearch />
          <Link to="/search" className="iconBtn mobileSearch" aria-label="Поиск по порталу"><I.Search size={20} /></Link>
          
          {!wsOnline && <span className="badge warn hide-m" title="Переподключение…"><span className="wsDot off" /> Переподключение</span>}
          {!modulesOff.includes('messenger') && <Link to="/messages" className="iconBtn" aria-label="Сообщения">
            <I.Message size={21} />
            {unreadChats > 0 && <span className="dot">{unreadChats > 99 ? '99+' : unreadChats}</span>}
          </Link>}
          <Notifications />
          {!modulesOff.includes('rewards') && <React.Suspense fallback={null}><HeaderProgress /></React.Suspense>}
          <ProfileMenu />
        </div>
      </header>
      <div className={cx('layout', rail && 'rail', wide && 'wide', sideOff && 'noside')}>
        {/* подложка — внутри .layout, в одном контексте наложения с выезжающим меню: иначе она перекрывала бы его кнопки */}
        <div className={cx('scrim', menu && 'open')} onClick={() => setMenu(false)} />
        {!wide && (
          <aside className={cx('side', menu && 'open')}>
            <SideResize />
            <div className="sideHead">
              <span className="tiny">Меню</span>
              <button className="iconBtn hideSide" onClick={() => setSideOff(true)} aria-label="Свернуть меню" title="Свернуть меню"><I.ChevronLeft size={20} /></button>
            </div>
            <nav className="nav" aria-label="Основная навигация" ref={navRef}>
              <span className="navPill" aria-hidden="true" />
              {menu2.map((g, gi) => (
                <React.Fragment key={g.group}>
                  {gi > 0 && <div className="navH">{g.label}</div>}
                  {g.items.map((n) => <NavLink key={n.id} n={n} path={path} cnt={n.badge === 'chats' ? unreadChats : n.badge === 'req' ? (reqCnt.data?.inbox || 0) + (reqCnt.data?.rework || 0) : 0} />)}
                </React.Fragment>
              ))}
            </nav>
            <Link className="navA appearanceLink" to="/settings"><I.Settings size={18} /> Внешний вид</Link>
            <div className="sideFoot">© {new Date().getFullYear()} {site.name}</div>
          </aside>
        )}
        <main id="portal-content" tabIndex={-1} style={{ minWidth: 0 }}>{blocked ? <div className="card pad"><h2>Раздел отключён</h2><p className="muted">Администратор временно отключил этот раздел портала.</p></div> : children}</main>
        {rail && <RightRail featured={path === '/' && !search} />}
      </div>
      <Toasts />
    </>
  );
}

/** Ручка на границе меню: перетаскивание меняет ширину (200–420 px), двойной клик сбрасывает. */
function SideResize() {
  const down = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    const side = (e.currentTarget.parentElement as HTMLElement);
    const left = side.getBoundingClientRect().left;
    const z = parseFloat(getComputedStyle(document.documentElement).zoom || '1') || 1;
    document.body.classList.add('sideResizing');
    const move = (ev: PointerEvent) => setAppearance({ sideW: Math.round((ev.clientX / z) - left / z) });
    const up = () => { document.body.classList.remove('sideResizing'); removeEventListener('pointermove', move); removeEventListener('pointerup', up); };
    addEventListener('pointermove', move); addEventListener('pointerup', up);
  };
  return <div className="sideResize" role="separator" aria-orientation="vertical" aria-label="Ширина меню" onPointerDown={down} onDoubleClick={() => setAppearance({ sideW: 0 })} />;
}

function NavLink({ n, path, cnt }: { n: { to: string; label: string; icon: any; match?: (p: string) => boolean }; path: string; cnt?: number }) {
  const on = n.match ? n.match(path) : n.to === '/' ? path === '/' : path === n.to || path.startsWith(n.to + '/');
  const Ic = n.icon;
  return (
    <Link to={n.to} className={cx('navA', on && 'on')} aria-current={on ? 'page' : undefined}>
      <Ic size={19} />{n.label}{cnt ? <span className="cnt">{cnt}</span> : null}
    </Link>
  );
}
