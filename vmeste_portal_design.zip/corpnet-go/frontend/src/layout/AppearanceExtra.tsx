import { useState } from 'react';
import { useRef, useState as useS } from 'react';
import { BGS } from '../lib/bg';
import { api, errMsg } from '../lib/api';
import { toast } from '../lib/store';
import { setAppearance, useAppearance } from '../lib/appearance';
import { availableItems, GROUPS, orderWithin } from '../lib/menu';
import { playSound } from '../lib/sound';
import { useStore } from '../lib/store';
import * as I from '../lib/icons';
import { cx } from '../lib/util';

/** Загрузка фото фона: файл в портал (с уменьшением на сервере) или ссылка. */
export function PhotoPicker({ value, onChange }: { value: string; onChange: (url: string) => void }) {
  const inp = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useS(false);
  async function pick(f?: File) {
    if (!f) return;
    setBusy(true);
    try { const r = await api.upload<{ url: string; view?: string }>('/api/uploads/public', f); onChange(r.view || r.url); } catch (e) { toast({ title: errMsg(e), kind: 'error' }); }
    setBusy(false);
  }
  return (
    <div className="row" style={{ flexWrap: 'wrap', gap: 8 }}>
      <button type="button" className="btn sm" disabled={busy} onClick={() => inp.current?.click()}><I.Upload size={15} /> {busy ? 'Загрузка…' : 'Загрузить фото'}</button>
      <input className="inp" style={{ minHeight: 32, padding: '4px 10px', fontSize: 13, flex: 1, minWidth: 200 }} placeholder="или ссылка на изображение (https://… или /путь)" value={value.startsWith('/media/') ? '' : value} onChange={(e) => onChange(e.target.value.trim())} aria-label="Ссылка на фото" />
      {value && <button type="button" className="btn ghost sm" onClick={() => onChange('')}>Убрать</button>}
      <input ref={inp} type="file" accept="image/*" hidden onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} />
    </div>
  );
}

/** Фон страницы: пресеты, свой цвет и своё фото (с регулируемой вуалью для читаемости). */
export function BackgroundSettings() {
  const a = useAppearance();
  const color = /^#[0-9a-f]{6}$/i.test(a.bg) ? a.bg : '#3b82f6';
  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="small bold">Фон страницы</div>
      <div className="apBgGrid" role="radiogroup" aria-label="Фон страницы">
        {BGS.map((b) => <button key={b.id} role="radio" aria-checked={a.bg === b.id} className={cx('apBg', a.bg === b.id && 'on')} style={b.css ? { backgroundImage: b.css, backgroundSize: b.size === 'cover' ? 'cover' : b.size } : undefined} onClick={() => setAppearance({ bg: b.id })}>{b.label}</button>)}
        <button role="radio" aria-checked={a.bg === 'photo'} className={cx('apBg', a.bg === 'photo' && 'on')} style={a.bgPhoto ? { backgroundImage: `url("${a.bgPhoto}")`, backgroundSize: 'cover' } : undefined} onClick={() => a.bgPhoto && setAppearance({ bg: 'photo' })} title={a.bgPhoto ? '' : 'Сначала загрузите фото'}>Моё фото</button>
      </div>
      <label className="row small" style={{ gap: 8 }}>Свой цвет: <input type="color" value={color} onChange={(e) => setAppearance({ bg: e.target.value })} aria-label="Свой цвет фона" /></label>
      <div className="small bold">Своё фото для фона</div>
      <PhotoPicker value={a.bgPhoto} onChange={(u) => setAppearance({ bgPhoto: u, bg: u ? 'photo' : a.bg === 'photo' ? 'none' : a.bg })} />
      {a.bg === 'photo' && <div className="apRow"><label htmlFor="ap-dim">Затемнение (читаемость текста)</label><input id="ap-dim" type="range" min={0} max={90} step={5} value={a.bgDim} onChange={(e) => setAppearance({ bgDim: +e.target.value })} /><b className="small">{a.bgDim}%</b></div>}
    </div>
  );
}

/** Звуковые уведомления: общий выключатель, громкость, типы событий, проверка. */
export function SoundSettings() {
  const a = useAppearance();
  const s = a.sound;
  const set = (p: any) => setAppearance({ sound: { ...s, ...p } });
  const kinds: [keyof typeof s.kinds, string][] = [['message', 'Новые сообщения'], ['news', 'Новости'], ['notify', 'Уведомления']];
  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="small bold">Звуковые уведомления</div>
      <label className="row small" style={{ gap: 6 }}><input type="checkbox" checked={s.on} onChange={(e) => set({ on: e.target.checked })} /> Включить звуки</label>
      <div className="apRow"><label htmlFor="ap-vol">Громкость</label><input id="ap-vol" type="range" min={0} max={100} step={5} value={s.vol} disabled={!s.on} onChange={(e) => set({ vol: +e.target.value })} /><b className="small">{s.vol}%</b></div>
      <div className="row" style={{ flexWrap: 'wrap', gap: 16 }}>
        {kinds.map(([k, l]) => <span key={k} className="row small" style={{ gap: 6 }}>
          <label className="row" style={{ gap: 6 }}><input type="checkbox" disabled={!s.on} checked={s.kinds[k]} onChange={(e) => set({ kinds: { ...s.kinds, [k]: e.target.checked } })} /> {l}</label>
          <button className="btn ghost sm" onClick={() => playSound(k, true)} aria-label={'Проверить звук: ' + l}>▶</button>
        </span>)}
      </div>
    </div>
  );
}

/** Меню: какие пункты показывать и в каком порядке (перетаскивание или стрелки). Закреплённые пункты скрыть нельзя. */
export function MenuSettings() {
  const a = useAppearance();
  const me = useStore((s) => s.me)!;
  const off = useStore((s) => s.modulesOff);
  const [drag, setDrag] = useState<string | null>(null);
  const [over, setOver] = useState<string | null>(null);
  const items = availableItems(me, off);
  const toggle = (id: string) => setAppearance({ menuHidden: a.menuHidden.includes(id) ? a.menuHidden.filter((x) => x !== id) : [...a.menuHidden, id] });
  // сохраняем плоский порядок: группы идут одна за другой, внутри — текущий порядок
  const flat = (g: string, list: string[]) => {
    const rest = GROUPS.filter((x) => x.id !== g).flatMap((x) => orderWithin(items.filter((m) => m.group === x.id), a.menuOrder).map((m) => m.id));
    setAppearance({ menuOrder: [...rest, ...list] });
  };
  const move = (g: string, ids: string[], from: string, to: string) => {
    const l = ids.filter((x) => x !== from);
    l.splice(Math.max(0, l.indexOf(to) + (ids.indexOf(from) < ids.indexOf(to) ? 1 : 0)), 0, from);
    flat(g, l);
  };
  const step = (g: string, ids: string[], id: string, d: number) => {
    const i = ids.indexOf(id), j = i + d;
    if (j < 0 || j >= ids.length) return;
    const l = [...ids]; [l[i], l[j]] = [l[j], l[i]]; flat(g, l);
  };
  return (
    <div className="stack" style={{ gap: 10 }}>
      <div className="row"><div className="small bold sp">Пункты меню и их порядок</div>
        <button className="btn ghost sm" onClick={() => setAppearance({ menuOrder: [], menuHidden: [] })}>Сбросить меню</button></div>
      <div className="tiny muted">Перетащите пункт или используйте стрелки; снимите галочку, чтобы скрыть пункт. Пункты, отключённые администратором, здесь не показываются.</div>
      {GROUPS.map((g) => {
        const list = orderWithin(items.filter((m) => m.group === g.id), a.menuOrder);
        if (!list.length) return null;
        const ids = list.map((m) => m.id);
        return (
          <div key={g.id} className="apMenuGroup"><div className="tiny muted" style={{ textTransform: 'uppercase', letterSpacing: '.08em' }}>{g.label}</div>
            {list.map((m) => { const Ic = m.icon; const hidden = !m.locked && a.menuHidden.includes(m.id); return (
              <div key={m.id} className={cx('apMenuRow', drag === m.id && 'drag', over === m.id && 'over', hidden && 'off')} draggable
                onDragStart={() => setDrag(m.id)} onDragEnd={() => { setDrag(null); setOver(null); }}
                onDragOver={(e) => { e.preventDefault(); setOver(m.id); }}
                onDrop={(e) => { e.preventDefault(); if (drag && drag !== m.id) move(g.id, ids, drag, m.id); setDrag(null); setOver(null); }}>
                <span className="grip" aria-hidden="true">⋮⋮</span>
                <input type="checkbox" checked={!hidden} disabled={m.locked} onChange={() => toggle(m.id)} aria-label={'Показывать: ' + m.label} />
                <Ic size={16} /><span className="t sp">{m.label}</span>
                <button className="btn ghost sm" onClick={() => step(g.id, ids, m.id, -1)} aria-label="Выше" disabled={ids[0] === m.id}><I.ChevronUp size={14} /></button>
                <button className="btn ghost sm" onClick={() => step(g.id, ids, m.id, 1)} aria-label="Ниже" disabled={ids[ids.length - 1] === m.id}><I.ChevronDown size={14} /></button>
              </div>); })}
          </div>
        );
      })}
    </div>
  );
}
