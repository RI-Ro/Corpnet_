package handlers

import (
	"errors"
	"log"
	"strconv"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"athena/backend/internal/config"
	"athena/backend/internal/db"
	"athena/backend/internal/http/middleware"
	"athena/backend/internal/marking"
	"athena/backend/internal/repository"
	"athena/backend/internal/service"
	"athena/backend/internal/ws"
)

type DocumentsHandler struct {
	pool        *pgxpool.Pool
	repo        *repository.DocumentsRepo
	incoming    *service.IncomingService
	markingData *service.MarkingDataService
	markingCfg  config.MarkingConfig
	pageSize    int
	pageMax     int
	hub         *ws.Hub
}

// SetHub подключает WS-хаб для уведомлений и живого обновления.
func (h *DocumentsHandler) SetHub(hub *ws.Hub) { h.hub = hub }

func NewDocumentsHandler(pool *pgxpool.Pool, repo *repository.DocumentsRepo, incoming *service.IncomingService, markingData *service.MarkingDataService, markingCfg config.MarkingConfig, pageSize, pageMax int) *DocumentsHandler {
	return &DocumentsHandler{pool: pool, repo: repo, incoming: incoming, markingData: markingData, markingCfg: markingCfg, pageSize: pageSize, pageMax: pageMax}
}

// List GET /api/documents?category=on_approval&page=2&department_id=4
func (h *DocumentsHandler) List(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	category := repository.Category(c.Query("category", "all"))
	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}
	deptID, _ := strconv.ParseInt(c.Query("department_id", "0"), 10, 64)

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Если подразделение не задано явно — берём основное подразделение
		// пользователя. Иначе категория «Исходящие» (фильтр по
		// author_department_id) оказывалась пустой (deptID=0 не совпадает ни
		// с одним документом) — из-за этого у автора не отображались исходящие.
		if deptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID); e != nil {
				return e
			}
		}
		year, _ := strconv.Atoi(c.Query("year"))
		res, err := h.repo.List(c.Context(), tx, category, userID, deptID, page, pageSize, year)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить документы")
	}
	return c.JSON(result)
}

// GetMarking GET /api/documents/:id/marking — вычисленные штампы для overlay
// на фронте (текст с подставленными плейсхолдерами, позиция, цвет, размер,
// рамка). Поле baked=true, если бэкенд уже вжигает штампы в PDF (тогда фронт
// overlay не рисует). Данные считаются по той же логике, что и вжигание.
func (h *DocumentsHandler) GetMarking(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var placeholders marking.Placeholders
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверяем, что документ виден текущему пользователю (RLS) — иначе
		// не отдаём его реквизиты маркировки.
		var one int
		if err := tx.QueryRow(c.Context(), `SELECT 1 FROM documents WHERE id=$1`, id).Scan(&one); err != nil {
			return err
		}
		ph, err := h.markingData.Collect(c.Context(), tx, id)
		if err != nil {
			return err
		}
		var deptID int64
		_ = tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&deptID)
		if err := h.markingData.CollectIncoming(c.Context(), tx, id, deptID, userID, ph); err != nil {
			return err
		}
		if err := h.markingData.CollectOwner(c.Context(), tx, id, userID, ph); err != nil {
			return err
		}
		placeholders = ph
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось вычислить маркировку")
	}

	specs := marking.ComputeSpecs(h.markingCfg, placeholders)
	stamps := make([]fiber.Map, 0, len(specs))
	for _, s := range specs {
		stamps = append(stamps, fiber.Map{
			"text":         s.Text,
			"position":     s.Position, // tl/tr/bl/br/c
			"offset_x":     s.OffsetX,
			"offset_y":     s.OffsetY,
			"font_size":    s.FontSize,
			"color":        s.ColorHex,
			"border":       s.Border,
			"border_color": s.BorderColorHex,
			"fill":         s.FillColorHex,
			// Факсимиле/печать как data-URL — для двухколоночного штампа
			// (слева изображение, справа текст).
			"image": marking.ImageDataURL(s.ImageFile),
		})
	}
	return c.JSON(fiber.Map{"stamps": stamps, "baked": marking.IsBaking(h.markingCfg), "page_mode": marking.PageMode()})
}

// Get GET /api/documents/:id
func (h *DocumentsHandler) Get(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var doc any
	var marking *service.IncomingMarking
	var myCopy *int

	// 1) ЧТЕНИЕ документа — единственный источник 404. Если документ не виден
	// (не существует или скрыт RLS) — 404. Иначе документ ОБЯЗАН открыться.
	readErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		d, err := h.repo.GetByID(c.Context(), tx, id)
		if err != nil {
			return err
		}
		doc = d
		return nil
	})
	if readErr != nil {
		if errors.Is(readErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить документ")
	}

	// 2) ПОБОЧНЫЕ ЭФФЕКТЫ (регистрация просмотра, входящего экземпляра, выдача
	// номера экземпляра) — BEST-EFFORT в ОТДЕЛЬНОЙ транзакции. Их сбой НЕ должен
	// мешать открытию документа (иначе первый заход мог падать 404/500, а
	// повторный открывался — как в отчётах). Ошибку логируем и продолжаем.
	sideErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		m, err := h.incoming.RegisterView(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		marking = m
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_views (document_id, viewer_id)
			SELECT $1, $2
			WHERE NOT EXISTS (
				SELECT 1 FROM document_views
				WHERE document_id = $1 AND viewer_id = $2
				  AND viewed_at > now() - interval '10 seconds'
			)`, id, userID); err != nil {
			return err
		}
		var copyReason *string
		_ = tx.QueryRow(c.Context(), `
			SELECT access_reason FROM document_access
			WHERE document_id=$1 AND user_id=$2
			ORDER BY granted_at LIMIT 1`, id, userID).Scan(&copyReason)
		reason := "view"
		if copyReason != nil && *copyReason != "" {
			reason = *copyReason
		}
		// Выдача номера экземпляра — ОДНОЙ общей функцией, той же, что
		// использует регистрация входящего. Раньше здесь был свой INSERT, а
		// там свой счёт по числу подразделений, и номера расходились: метка
		// на документе говорила «Экз. № 2», когда экземпляр был четвёртым.
		n, err := service.EnsureCopyNumber(c.Context(), tx, id, userID, reason)
		if err != nil {
			return err
		}
		myCopy = &n
		return nil
	})
	if sideErr != nil {
		// Не фатально — документ уже прочитан и будет отдан. Логируем для аудита.
		marking = nil
		myCopy = nil
		log.Printf("document %d view side-effects failed for user %d: %v", id, userID, sideErr)
	}
	return c.JSON(fiber.Map{"document": doc, "incoming_marking": marking, "registration_error": sideErr != nil, "my_copy_number": myCopy})
}

// Copies GET /api/documents/:id/copies — реестр экземпляров документа: у кого
// какой номер экземпляра (Экз. №), за что выдан и когда. Виден всем, у кого
// есть доступ к документу (RLS на document_copies нет, но выборка идёт только
// после проверки доступа к самому документу через GetByID под RLS).
func (h *DocumentsHandler) Copies(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	// #13 — Вкладка «Просмотры» удалена, её данные перенесены сюда: у каждого
	// экземпляра показываются первый и последний просмотр и их количество.
	// Два отдельных списка одних и тех же людей (кому выдан экземпляр / кто
	// открывал) заставляли сопоставлять их глазами; экземпляр выдаётся как раз
	// по факту получения документа, поэтому просмотр — его свойство.
	type copyItem struct {
		CopyNumber  int    `json:"copy_number"`
		UserID      int64  `json:"user_id"`
		FullName    string `json:"full_name"`
		Reason      string `json:"reason"`
		AssignedAt  string `json:"assigned_at"`
		FirstViewAt string `json:"first_view_at,omitempty"`
		LastViewAt  string `json:"last_view_at,omitempty"`
		ViewCount   int    `json:"view_count"`
	}
	var items []copyItem
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Проверка доступа к документу (иначе RLS вернёт ErrNoRows → 404).
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		// Агрегат просмотров считается подзапросом по владельцу экземпляра.
		// LEFT JOIN LATERAL, а не коррелированные подзапросы в SELECT: иначе
		// document_views сканировался бы трижды на каждую строку.
		rows, err := tx.Query(c.Context(), `
			SELECT c.copy_number, c.user_id,
			       u.full_name || CASE WHEN coalesce(u.position,'')<>'' THEN ' (' || u.position || ')' ELSE '' END,
			       c.reason, to_char(c.assigned_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce(to_char(v.first_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'), ''),
			       coalesce(to_char(v.last_at  AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'), ''),
			       coalesce(v.cnt, 0)
			FROM document_copies c
			JOIN users u ON u.id = c.user_id
			LEFT JOIN LATERAL (
			    SELECT min(dv.viewed_at) AS first_at, max(dv.viewed_at) AS last_at, count(*) AS cnt
			    FROM document_views dv
			    WHERE dv.document_id = c.document_id AND dv.viewer_id = c.user_id
			) v ON TRUE
			WHERE c.document_id = $1
			ORDER BY c.copy_number`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var it copyItem
			if err := rows.Scan(&it.CopyNumber, &it.UserID, &it.FullName, &it.Reason, &it.AssignedAt,
				&it.FirstViewAt, &it.LastViewAt, &it.ViewCount); err != nil {
				return err
			}
			items = append(items, it)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить экземпляры")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Search GET /api/documents/search?q=...&page=1&page_size=20
func (h *DocumentsHandler) Search(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)

	page, _ := strconv.Atoi(c.Query("page", "1"))
	if page < 1 {
		page = 1
	}
	pageSize := h.pageSize
	if ps := c.Query("page_size"); ps != "" {
		if n, err := strconv.Atoi(ps); err == nil && n > 0 && n <= h.pageMax {
			pageSize = n
		}
	}

	filter := repository.SearchFilter{
		Category:       c.Query("category"),
		UserID:         userID,
		Query:          c.Query("q"),
		DueFrom:        c.Query("due_from"),
		DueTo:          c.Query("due_to"),
		CreatedFrom:    c.Query("created_from"),
		CreatedTo:      c.Query("created_to"),
		SignedFrom:     c.Query("signed_from"),
		SignedTo:       c.Query("signed_to"),
		Number:         c.Query("number"),
		IncomingNumber: c.Query("incoming_number"),
		OnControl:      c.Query("on_control"),
		// #4 — поиск по содержимому PDF.
		Content: c.Query("content"),
		// #20 — одна строка на название/содержание/исх. номер/вх. номер.
		AnyText: c.Query("any"),
	}
	parseID := func(name string) int64 {
		if v := c.Query(name); v != "" {
			id, _ := strconv.ParseInt(v, 10, 64)
			return id
		}
		return 0
	}
	filter.AuthorID = parseID("author_id")
	filter.CategoryID = parseID("category_id")
	filter.SignerID = parseID("signer_id")
	filter.ControllerID = parseID("controller_id")
	filter.ApproverID = parseID("approver_id")
	filter.RecipientID = parseID("recipient_id")
	filter.DepartmentID = parseID("department_id")
	// #26 — особая отметка; #28 — «любое участие» пользователя в документе.
	filter.SpecialMarkID = parseID("special_mark_id")
	filter.AnyParticipantID = parseID("participant_id")
	if v := c.Query("status"); v != "" {
		filter.Statuses = splitCSV(v)
	}

	// Категория задаёт контекст поиска — если она есть, пустой набор фильтров
	// допустим (просто применяется ограничение категории).
	catScoped := filter.Category != "" && filter.Category != "all"
	empty := !catScoped && filter.Query == "" && filter.AuthorID == 0 && filter.SignerID == 0 &&
		filter.CategoryID == 0 &&
		filter.ControllerID == 0 && filter.ApproverID == 0 && filter.RecipientID == 0 &&
		filter.DepartmentID == 0 && len(filter.Statuses) == 0 &&
		filter.OnControl == "" && filter.DueFrom == "" && filter.DueTo == "" &&
		filter.CreatedFrom == "" && filter.CreatedTo == "" &&
		filter.SignedFrom == "" && filter.SignedTo == "" &&
		filter.Number == "" && filter.IncomingNumber == "" &&
		filter.Content == "" && filter.SpecialMarkID == 0 && filter.AnyParticipantID == 0 &&
		filter.AnyText == ""
	if empty {
		return fiber.NewError(fiber.StatusBadRequest, "укажите хотя бы один фильтр")
	}

	var result any
	err := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Для категории «Исходящие» нужно подразделение пользователя.
		if filter.Category == string(repository.CategoryOutgoing) && filter.DeptID == 0 {
			if e := tx.QueryRow(c.Context(), `SELECT coalesce(primary_department_id,0) FROM users WHERE id=$1`, userID).Scan(&filter.DeptID); e != nil {
				return e
			}
		}
		res, err := h.repo.Search(c.Context(), tx, filter, page, pageSize)
		if err != nil {
			return err
		}
		result = res
		return nil
	})
	if err != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось выполнить поиск документов")
	}
	return c.JSON(result)
}

func splitCSV(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		p := strings.TrimSpace(part)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// GetStages GET /api/documents/:id/stages
func (h *DocumentsHandler) GetStages(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	var stages any
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Явно проверяем видимость документа по RLS перед выдачей маршрута —
		// approval_stages не защищена собственной RLS-политикой (см. комментарий
		// в repository.ListStages), поэтому проверка здесь обязательна.
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		s, err := h.repo.ListStages(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		stages = s
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить этапы согласования")
	}
	return c.JSON(fiber.Map{"items": stages})
}

// GetFile GET /api/documents/:id/file — отдаёт PDF только для просмотра
// (inline), без возможности скачивания через отдельный "download"-эндпоинт.
func (h *DocumentsHandler) GetFile(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}

	// HTTP-кэш с ETag. Тело PDF не меняется, пока не заменён файл, поэтому
	// браузер при обновлении страницы спрашивает «не изменился ли файл?»
	// (If-None-Match) и получает 304 без передачи тела. Права при этом
	// проверяются на КАЖДЫЙ запрос (запрос к БД под RLS выполняется всегда), так
	// что отозванный доступ кэшем не обходится. Экранная маркировка — overlay на
	// фронте, в файл не вжигается, поэтому ETag зависит только от содержимого.
	var sha string
	var content []byte
	etagMatched := false
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// JOIN на documents — фильтр RLS: файл невидимого документа не отдаётся.
		if err := tx.QueryRow(c.Context(), `
			SELECT coalesce(f.sha256, '') FROM document_files f
			JOIN documents d ON d.id = f.document_id
			WHERE f.document_id = $1`, id).Scan(&sha); err != nil {
			return err
		}
		if sha != "" && etagHeaderMatches(c.Get("If-None-Match"), sha) {
			etagMatched = true
			return nil
		}
		return tx.QueryRow(c.Context(), `SELECT f.content FROM document_files f WHERE f.document_id = $1`, id).Scan(&content)
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "file not found")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить файл документа")
	}

	c.Set("Content-Type", "application/pdf")
	c.Set("Content-Disposition", "inline")
	c.Set("X-Content-Type-Options", "nosniff")
	// private — не в общих кэшах; no-cache — каждый раз с проверкой ETag.
	c.Set("Cache-Control", "private, no-cache")
	c.Set("Content-Security-Policy", "frame-ancestors 'self'")
	if sha != "" {
		c.Set("ETag", `"`+sha+`"`)
	}
	if etagMatched {
		return c.SendStatus(fiber.StatusNotModified)
	}
	return c.Send(content)
}

// etagHeaderMatches — совпадает ли ETag с заголовком If-None-Match (список
// значений, слабые валидаторы W/ допускаются).
func etagHeaderMatches(header, sha string) bool {
	for _, part := range strings.Split(header, ",") {
		p := strings.TrimSpace(part)
		p = strings.TrimPrefix(p, "W/")
		if p == `"`+sha+`"` || p == "*" {
			return true
		}
	}
	return false
}

// History GET /api/documents/:id/history — журнал событий документа
// (вкладка "История документа").
func (h *DocumentsHandler) History(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type event struct {
		EventType  string  `json:"event_type"`
		ActorName  *string `json:"actor_name,omitempty"`
		FromStatus *string `json:"from_status,omitempty"`
		ToStatus   *string `json:"to_status,omitempty"`
		Comment    *string `json:"comment,omitempty"`
		CreatedAt  string  `json:"created_at"`
	}
	var items []event
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		// Журнал событий + сообщения обсуждения (с именами вложений): в истории
		// должно быть всё, что происходит с документом.
		rows, err := tx.Query(c.Context(), `
			SELECT t.event_type, t.actor, t.from_status, t.to_status, t.comment,
			       to_char(t.created_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
			  FROM (
			    SELECT h.event_type, u.full_name AS actor, h.from_status::text AS from_status,
			           h.to_status::text AS to_status, h.comment AS comment, h.created_at
			      FROM document_history h
			      LEFT JOIN users u ON u.id = h.actor_id
			     WHERE h.document_id = $1
			    UNION ALL
			    SELECT 'chat_message'::text, u.full_name, NULL::text, NULL::text,
			           trim(coalesce(m.text,'') || coalesce((
			             SELECT ' [файлы: ' || string_agg(a.file_name, ', ') || ']'
			               FROM chat_attachments a WHERE a.message_id = m.id), '')),
			           m.created_at
			      FROM chat_messages m
			      LEFT JOIN users u ON u.id = m.author_id
			     WHERE m.document_id = $1 AND m.deleted_at IS NULL
			  ) t
			 ORDER BY t.created_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var e event
			if err := rows.Scan(&e.EventType, &e.ActorName, &e.FromStatus, &e.ToStatus, &e.Comment, &e.CreatedAt); err != nil {
				return err
			}
			items = append(items, e)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить историю")
	}
	return c.JSON(fiber.Map{"items": items})
}

// #13 — Обработчик Views (GET /api/documents/:id/views) УДАЛЁН вместе с
// вкладкой «Просмотры»: первый/последний просмотр и их количество теперь
// отдаются в составе экземпляров (см. Copies выше). Номер экземпляра
// присваивается ровно при первом просмотре, поэтому ни один просматривавший
// при объединении не теряется.

// SetControl POST /api/documents/:id/control — поставить/снять документ с
// контроля и назначить контролёров. Тело:
// { "on_control": true, "controller_ids": [4,7] }  (или старое "controller_id": 4).
// #4 — контролёров может быть несколько. Все они сохраняются в
// document_controllers; documents.controller_id = первый (для дашборда/реестра).
func (h *DocumentsHandler) SetControl(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var req struct {
		OnControl     bool    `json:"on_control"`
		ControllerID  int64   `json:"controller_id"`  // обратная совместимость
		ControllerIDs []int64 `json:"controller_ids"` // #4
	}
	if err := c.BodyParser(&req); err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверное тело запроса")
	}
	// Собираем итоговый набор контролёров (дедуп, без нулей).
	seen := map[int64]bool{}
	var ctlIDs []int64
	for _, cid := range append(req.ControllerIDs, req.ControllerID) {
		if cid != 0 && !seen[cid] {
			seen[cid] = true
			ctlIDs = append(ctlIDs, cid)
		}
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		// Контролёром можно назначить любого пользователя с ролью controller
		// или default_controller — БЕЗ ограничения по иерархии подразделений
		// (контроль может вести кто угодно из наделённых правом).
		if !isAdmin {
			for _, cid := range ctlIDs {
				var okCtl bool
				if err := tx.QueryRow(c.Context(), `
					SELECT EXISTS(
					  SELECT 1 FROM users u
					  JOIN user_roles ur ON ur.user_id = u.id AND ur.role::text IN ('controller','default_controller')
					  WHERE u.id = $1 AND u.is_active = true
					)`, cid).Scan(&okCtl); err != nil {
					return err
				}
				if !okCtl {
					return errControllerRole
				}
			}
		}
		// Основной контролёр (первый) — в documents.controller_id.
		var primary *int64
		if req.OnControl && len(ctlIDs) > 0 {
			primary = &ctlIDs[0]
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE documents SET on_control=$1, controller_id=$2 WHERE id=$3`,
			req.OnControl, primary, id); err != nil {
			return err
		}
		// Полный набор контролёров — в document_controllers (перезаписываем).
		if _, err := tx.Exec(c.Context(), `DELETE FROM document_controllers WHERE document_id=$1`, id); err != nil {
			return err
		}
		// Снятые с контроля теряют доступ «как контролёр».
		keep := ctlIDs
		if !req.OnControl {
			keep = []int64{}
		}
		if _, err := tx.Exec(c.Context(), `
			DELETE FROM document_access
			 WHERE document_id=$1 AND access_reason='controller' AND NOT (user_id = ANY($2::bigint[]))`, id, keep); err != nil {
			return err
		}
		// Контролёр видит документ и получает уведомление только после
		// подписания: до этого документ — промежуточный вариант. Для ещё не
		// подписанного документа контролёры запоминаются, доступ им выдаст
		// подписание (SigningService.Sign).
		var signed bool
		if err := tx.QueryRow(c.Context(),
			`SELECT outgoing_number IS NOT NULL FROM documents WHERE id=$1`, id).Scan(&signed); err != nil {
			return err
		}
		// История: постановка/снятие с контроля.
		evt := "removed_from_control"
		if req.OnControl {
			evt = "put_on_control"
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type)
			VALUES ($1, $2, $3)`, id, userID, evt); err != nil {
			return err
		}
		if req.OnControl {
			for _, cid := range ctlIDs {
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_controllers (document_id, user_id)
					VALUES ($1, $2) ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				if !signed {
					continue
				}
				if _, err := tx.Exec(c.Context(), `
					INSERT INTO document_access (document_id, user_id, access_reason)
					VALUES ($1, $2, 'controller') ON CONFLICT DO NOTHING`, id, cid); err != nil {
					return err
				}
				// #7 — актор нужен для единого текста уведомления.
				_, _ = tx.Exec(c.Context(), `
					INSERT INTO notifications (user_id, document_id, kind, payload, actor_id, requires_ack)
					VALUES ($1, $2, 'control_assigned', '{}', $3, $4)`,
					cid, id, userID, service.RequiresAck("control_assigned"))
			}
		}
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, errControllerRole) {
			return fiber.NewError(fiber.StatusUnprocessableEntity, "контролёром может быть только пользователь с ролью «контролёр» или «контролёр по умолчанию»")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось изменить контроль")
	}
	return c.SendStatus(fiber.StatusOK)
}

// Controllers GET /api/documents/:id/controllers — список контролёров документа
// (для префилла формы редактирования и отображения в карточке). Доступ через
// RLS: сначала проверяем доступ к документу.
func (h *DocumentsHandler) Controllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type ctl struct {
		UserID         int64  `json:"user_id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.id IN (
			   SELECT user_id FROM document_controllers WHERE document_id=$1
			   UNION
			   SELECT controller_id FROM documents WHERE id=$1 AND controller_id IS NOT NULL
			)
			ORDER BY u.full_name`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.UserID, &x.FullName, &x.Position, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров")
	}
	return c.JSON(fiber.Map{"items": items})
}

// DefaultControllers GET /api/default-controllers — активные пользователи с
// ролью default_controller. Форма создания использует их для ПРЕДВЫБОРА
// контролёров (галочка «на контроле» предустановлена, но автор может изменить
// или снять — контролёр добавляется только с санкции автора).
func (h *DocumentsHandler) DefaultControllers(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	type ctl struct {
		ID             int64  `json:"id"`
		FullName       string `json:"full_name"`
		Position       string `json:"position"`
		DepartmentID   int64  `json:"department_id"`
		DepartmentName string `json:"department_name"`
		City           string `json:"city"`
	}
	var items []ctl
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		rows, err := tx.Query(c.Context(), `
			SELECT DISTINCT u.id, coalesce(u.full_name,''), coalesce(u.position,''),
			       coalesce(u.primary_department_id,0), coalesce(d.name,''), coalesce(d.city,'')
			FROM users u
			JOIN user_roles ur ON ur.user_id = u.id AND ur.role::text = 'default_controller'
			LEFT JOIN departments d ON d.id = u.primary_department_id
			WHERE u.is_active = true
			ORDER BY 2`)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var x ctl
			if err := rows.Scan(&x.ID, &x.FullName, &x.Position, &x.DepartmentID, &x.DepartmentName, &x.City); err != nil {
				return err
			}
			items = append(items, x)
		}
		return rows.Err()
	})
	if txErr != nil {
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить контролёров по умолчанию")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Signatures GET /api/documents/:id/signatures — данные о факте(ах) подписания
// для аудита (63-ФЗ): ФИО/должность/логин подписанта, тип и время подписи,
// отпечаток подписи, хэш содержимого документа, фактический IP и user-agent.
// Доступ через RLS (сначала проверяем доступ к документу).
func (h *DocumentsHandler) Signatures(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	type sig struct {
		SignerFIO      string `json:"signer_fio"`
		SignerPosition string `json:"signer_position"`
		SignatureType  string `json:"signature_type"`
		SignedAt       string `json:"signed_at"`
		SignatureHash  string `json:"signature_hash"`
		DocumentHash   string `json:"document_hash"`
		//, п. 6 — пометка «выполнено заместителем за …, замещение
		// с … по …», если подпись поставлена в период замещения. Пустая строка
		// у обычной подписи, и тогда интерфейс её не показывает.
		ActorNote string `json:"actor_note,omitempty"`
		// Проверка подписи, выполняется при каждом запросе:
		//   Valid      — HMAC подписанной строки на серверном секрете сошёлся;
		//   KeyMatch   — подпись выполнена действующим секретом (false — секрет
		//                меняли, проверить эту подпись текущим ключом нельзя);
		//   FileIntact — файл документа сейчас тот же, что был подписан.
		Valid      bool   `json:"valid"`
		KeyMatch   bool   `json:"key_match"`
		FileIntact bool   `json:"file_intact"`
		Verdict    string `json:"verdict"`
	}
	var items []sig
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if _, err := h.repo.GetByID(c.Context(), tx, id); err != nil {
			return err
		}
		rows, err := tx.Query(c.Context(), `
			SELECT coalesce(signer_fio,''), coalesce(signer_position,''),
			       signature_type,
			       to_char(signed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
			       coalesce(signature_hash,''), coalesce(document_hash,''),
			       coalesce(actor_note,''), coalesce(signed_payload,''), coalesce(key_id,''),
			       coalesce((SELECT f.sha256 FROM document_files f WHERE f.document_id = document_signatures.document_id), '')
			FROM document_signatures WHERE document_id=$1 ORDER BY signed_at`, id)
		if err != nil {
			return err
		}
		defer rows.Close()
		for rows.Next() {
			var s sig
			var payload, keyID, fileHash string
			if err := rows.Scan(&s.SignerFIO, &s.SignerPosition, &s.SignatureType,
				&s.SignedAt, &s.SignatureHash, &s.DocumentHash, &s.ActorNote,
				&payload, &keyID, &fileHash); err != nil {
				return err
			}
			if signatureVerifier != nil {
				s.Valid, s.KeyMatch = signatureVerifier(payload, s.SignatureHash, keyID)
			}
			s.FileIntact = fileHash != "" && fileHash == s.DocumentHash
			switch {
			case !s.KeyMatch:
				s.Verdict = "подпись выполнена другим ключом — проверка текущим ключом невозможна"
			case !s.Valid:
				s.Verdict = "ПОДПИСЬ НЕДЕЙСТВИТЕЛЬНА: запись о подписи изменена"
			case !s.FileIntact:
				s.Verdict = "ПОДПИСЬ НЕ СООТВЕТСТВУЕТ ФАЙЛУ: файл документа изменён после подписания"
			default:
				s.Verdict = "подпись верна, документ не изменён"
			}
			items = append(items, s)
		}
		return rows.Err()
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось получить данные о подписи")
	}
	return c.JSON(fiber.Map{"items": items})
}

// Archive POST /api/documents/:id/archive — направить документ в архив.
// #8 — Право: автор или подписант (или admin). Разрешено ТОЛЬКО для
// ИСПОЛНЕННОГО документа (status='executed'). Фиксируется в истории.
func (h *DocumentsHandler) Archive(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	var interested []int64
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		if !isAdmin {
			ok, err := service.IsAuthorOrSigner(c.Context(), tx, id, userID)
			if err != nil {
				return err
			}
			if !ok {
				return errArchiveForbidden
			}
		}
		var status string
		if err := tx.QueryRow(c.Context(), `SELECT status FROM documents WHERE id=$1`, id).Scan(&status); err != nil {
			return err
		}
		if status == "archived" {
			return errAlreadyArchived
		}
		if status != "executed" {
			return errNotExecuted
		}
		if _, err := tx.Exec(c.Context(),
			`UPDATE documents SET status='archived', archived_at=now() WHERE id=$1`, id); err != nil {
			return err
		}
		if _, err := tx.Exec(c.Context(), `
			INSERT INTO document_history (document_id, actor_id, event_type, from_status, to_status, comment)
			VALUES ($1, $2, 'archived', 'executed'::doc_status, 'archived', 'направлен в архив')`, id, userID); err != nil {
			return err
		}
		ids, err := service.NotifyDocumentEventDetail(c.Context(), tx, id, "document_archived", userID, "", `{}`)
		if err != nil {
			return err
		}
		interested = ids
		return nil
	})
	if txErr != nil {
		switch {
		case errors.Is(txErr, errArchiveForbidden):
			return fiber.NewError(fiber.StatusForbidden, "направить в архив может только автор или подписант")
		case errors.Is(txErr, errNotExecuted):
			return fiber.NewError(fiber.StatusUnprocessableEntity, "в архив можно направить только исполненный документ")
		case errors.Is(txErr, errAlreadyArchived):
			return fiber.NewError(fiber.StatusConflict, "документ уже в архиве")
		case errors.Is(txErr, pgx.ErrNoRows):
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		default:
			return fiber.NewError(fiber.StatusInternalServerError, "не удалось направить документ в архив")
		}
	}
	if h.hub != nil && len(interested) > 0 {
		h.hub.NotifyUsers(interested, id, "document_archived")
	}
	return c.SendStatus(fiber.StatusOK)
}

// MyRoles GET /api/documents/:id/my-roles — в каких качествах текущий
// пользователь участвует в документе. Фронт по этому ответу показывает/скрывает
// вкладки (не участник согласования не видит вкладку маршрута и т.д.).
func (h *DocumentsHandler) MyRoles(c *fiber.Ctx) error {
	userID := c.Locals(middleware.CtxUserID).(int64)
	isAdmin := c.Locals(middleware.CtxIsAdmin).(bool)
	id, err := strconv.ParseInt(c.Params("id"), 10, 64)
	if err != nil {
		return fiber.NewError(fiber.StatusBadRequest, "неверный идентификатор")
	}
	res := fiber.Map{
		"is_author":     false,
		"is_approver":   false,
		"is_signer":     false,
		"is_controller": false,
		"is_recipient":  false,
		"is_printer":    false,
		"is_admin":      isAdmin,
		// п. 8 — доступен ли отчёт по документу (автор, подписант, контролёр,
		// администратор и их заместители).
		"can_report": isAdmin,
		//, п. 7 — право поставить отметку об исполнении.
		// Отдельный флаг, а не is_recipient: отметку ставит и тот, кого
		// дежурный ознакомил, если ему выдана роль execution_marker в этом
		// подразделении. Без отдельного флага вкладка «Исполнение» такому
		// человеку не показывалась бы, хотя сервер его отметку принимает.
		"can_mark_execution": false,
	}
	txErr := db.WithUserTx(c.Context(), h.pool, userID, isAdmin, func(tx pgx.Tx) error {
		var authorID int64
		var controllerID *int64
		if err := tx.QueryRow(c.Context(),
			`SELECT author_id, controller_id FROM documents WHERE id=$1`, id).Scan(&authorID, &controllerID); err != nil {
			return err
		}
		res["is_author"] = authorID == userID
		// #4 — контролёров может быть несколько (document_controllers);
		// controller_id хранит основного. Проверяем оба источника.
		isCtl := controllerID != nil && *controllerID == userID
		if !isCtl {
			var cnt int
			if err := tx.QueryRow(c.Context(),
				`SELECT count(*) FROM document_controllers WHERE document_id=$1 AND user_id=$2`, id, userID).Scan(&cnt); err != nil {
				return err
			}
			isCtl = cnt > 0
		}
		res["is_controller"] = isCtl

		//, п. 8 — «отчёт о документе показывать автору и
		// подписанту». Право считается ТОЙ ЖЕ функцией, которой оно потом
		// проверяется при построении отчёта (canSeeDocReport): иначе кнопка и
		// само право разошлись бы, и человек получал бы отказ по кнопке,
		// которую ему показали. Там же учтено замещение (п. 19).
		canRep, err := canSeeDocReport(c, tx, id, userID, isAdmin)
		if err != nil {
			return err
		}
		res["can_report"] = canRep

		// Согласующий или подписант — по этапам маршрута.
		var approverCnt, signerCnt int
		if err := tx.QueryRow(c.Context(), `
			SELECT
			  count(*) FILTER (WHERE stage_type IN ('hierarchy','cross_dept')),
			  count(*) FILTER (WHERE stage_type = 'signing')
			FROM approval_stages WHERE document_id=$1 AND approver_id=$2`, id, userID).
			Scan(&approverCnt, &signerCnt); err != nil {
			return err
		}
		res["is_approver"] = approverCnt > 0
		res["is_signer"] = signerCnt > 0

		// Получатель рассылки.
		var recipCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM document_recipients WHERE document_id=$1 AND NOT is_planned AND app_handles_recipient(recipient_user_id,recipient_department_id,$2)`, id, userID).
			Scan(&recipCnt); err != nil {
			return err
		}
		res["is_recipient"] = recipCnt > 0

		execution, err := service.NewExecutionService().Status(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		res["can_mark_execution"] = execution.CanMark

		// Роль печати — глобально по user_roles (в любом подразделении).
		var printerCnt int
		if err := tx.QueryRow(c.Context(),
			`SELECT count(*) FROM user_roles WHERE user_id=$1 AND role='printer'`, userID).
			Scan(&printerCnt); err != nil {
			return err
		}
		res["is_printer"] = printerCnt > 0 || isAdmin

		// #6/#7 — Права на ОЗНАКОМЛЕНИЕ и ПОРУЧЕНИЯ не зависят от статуса
		// получателя: доступны, если у пользователя есть подразделения
		// ознакомления/поручений (или он руководитель — для ознакомления).
		// Вкладки показываются по этим флагам, даже если пользователь просто
		// ознакомлен с документом.
		// Право ознакамливать даёт РОЛЬ «может ознакамливать». Раньше здесь
		// проверялось наличие строк в user_acquaint_departments или роли
		// руководителя/дежурного — и это расходилось с тем, кого на самом
		// деле показывал подбор кандидатов.
		canAcq, err := service.HasAcquaintRole(c.Context(), tx, userID)
		if err != nil {
			return err
		}
		res["can_acquaint"] = canAcq || isAdmin
		// Право НАЛОЖИТЬ РЕЗОЛЮЦИЮ считается тем же условием, что и в самом
		// обработчике резолюций (service.CanIssueResolution): роль
		// «может ставить резолюции» И документ в его области полномочий
		//. Если бы здесь была своя, упрощённая
		// проверка, человек либо видел бы вкладку и получал отказ, либо не
		// видел её, имея право.
		canRes, err := service.CanIssueResolution(c.Context(), tx, id, userID)
		if err != nil {
			return err
		}
		res["can_assign"] = canRes || isAdmin
		// Исполнитель резолюции по этому документу должен видеть вкладку
		// «Резолюции», даже если сам накладывать их не вправе.
		var isAssignee bool
		if err := tx.QueryRow(c.Context(), `
			SELECT EXISTS(SELECT 1 FROM resolution_executors re
			               JOIN resolutions r ON r.id = re.resolution_id
			              WHERE r.document_id = $1 AND re.user_id = $2)`,
			id, userID).Scan(&isAssignee); err != nil {
			return err
		}
		res["is_assignee"] = isAssignee
		// #7 — дежурный/получатель может ДОНАПРАВИТЬ документ, если он получатель
		// этого документа и ему назначены подразделения донаправления.
		var canRedirect bool
		if err := tx.QueryRow(c.Context(), `
			SELECT EXISTS(SELECT 1 FROM document_recipients WHERE document_id=$1 AND app_handles_recipient(recipient_user_id,recipient_department_id,$2) AND is_planned=false)
			   AND EXISTS(SELECT 1 FROM user_redirect_departments WHERE user_id=$2)`, id, userID).Scan(&canRedirect); err != nil {
			return err
		}
		res["can_redirect"] = canRedirect
		return nil
	})
	if txErr != nil {
		if errors.Is(txErr, pgx.ErrNoRows) {
			return fiber.NewError(fiber.StatusNotFound, "документ не найден")
		}
		return fiber.NewError(fiber.StatusInternalServerError, "не удалось загрузить роли")
	}
	return c.JSON(res)
}

// signatureVerifier проверяет простую электронную подпись (HMAC на серверном
// секрете). Устанавливается при сборке маршрутов.
var signatureVerifier func(payload, signature, keyID string) (valid, keyMatch bool)

// SetSignatureVerifier задаёт функцию проверки подписи.
func SetSignatureVerifier(f func(payload, signature, keyID string) (valid, keyMatch bool)) {
	signatureVerifier = f
}
