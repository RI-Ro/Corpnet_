package metrics

import (
	"sort"
	"sync"
	"time"
)

// ============================================================================
// СТАТИСТИКА ЗАПРОСОВ ДЛЯ АДМИН-ДАШБОРДА.
//
// Требование: отслеживать долгие запросы и показывать среднее время ответа.
//
// Почему отдельно от Prometheus-метрик, которые уже собираются рядом:
// Prometheus отвечает на вопрос «как система ведёт себя во времени» и требует
// поднятого Prometheus с Grafana. Админ-дашборд отвечает на вопрос «что
// происходит сейчас» и обязан работать сам по себе, без внешнего стека, —
// иначе на установке без мониторинга страница будет пустой.
//
// Хранение в памяти процесса и осознанные следствия:
//   * при нескольких экземплярах приложения каждый считает свои запросы —
//     поэтому в ответе отдаётся признак, что числа по одному процессу;
//   * после перезапуска статистика обнуляется; это нормально для вопроса
//     «что происходит сейчас» и честно показывается через uptime.
//
// Память ограничена по построению: по маршруту хранятся агрегаты
// (фиксированный размер), а долгие запросы — в кольцевом буфере на
// slowCapacity записей. Расти неограниченно нечему.
// ============================================================================

// slowCapacity — сколько самых свежих долгих запросов хранить.
const slowCapacity = 50

// SlowThreshold — с какой длительности запрос считается долгим.
// Значение по умолчанию; переопределяется из конфига через SetSlowThreshold.
var slowThreshold = struct {
	mu sync.RWMutex
	d  time.Duration
}{d: 1500 * time.Millisecond}

// SetSlowThreshold задаёт порог «долгого» запроса (monitoring.slow_request_ms).
func SetSlowThreshold(d time.Duration) {
	if d <= 0 {
		return
	}
	slowThreshold.mu.Lock()
	slowThreshold.d = d
	slowThreshold.mu.Unlock()
}

// SlowThresholdValue — текущий порог (для отображения в интерфейсе).
func SlowThresholdValue() time.Duration {
	slowThreshold.mu.RLock()
	defer slowThreshold.mu.RUnlock()
	return slowThreshold.d
}

// routeStat — агрегаты по одному маршруту.
type routeStat struct {
	Count      int64
	TotalNanos int64
	MaxNanos   int64
	Errors4xx  int64
	Errors5xx  int64
	SlowCount  int64
}

// SlowRequest — одна запись о долгом запросе.
type SlowRequest struct {
	At         string `json:"at"`
	Method     string `json:"method"`
	Route      string `json:"route"`
	Status     int    `json:"status"`
	DurationMs int64  `json:"duration_ms"`
}

// RouteSummary — сводка по маршруту для интерфейса.
type RouteSummary struct {
	Route     string  `json:"route"`
	Count     int64   `json:"count"`
	AvgMs     float64 `json:"avg_ms"`
	MaxMs     int64   `json:"max_ms"`
	SlowCount int64   `json:"slow_count"`
	Errors4xx int64   `json:"errors_4xx"`
	Errors5xx int64   `json:"errors_5xx"`
	SharePct  float64 `json:"share_pct"`
	TotalMs   int64   `json:"total_ms"`
}

// Stats — то, что отдаётся админ-дашборду.
type Stats struct {
	Requests      int64          `json:"requests"`
	AvgMs         float64        `json:"avg_ms"`
	MaxMs         int64          `json:"max_ms"`
	Errors4xx     int64          `json:"errors_4xx"`
	Errors5xx     int64          `json:"errors_5xx"`
	SlowCount     int64          `json:"slow_count"`
	SlowThreshold int64          `json:"slow_threshold_ms"`
	ByRoute       []RouteSummary `json:"by_route"`
	Slowest       []SlowRequest  `json:"slowest"`
	SingleProcess bool           `json:"single_process"`
}

var reqStats = struct {
	mu        sync.RWMutex
	routes    map[string]*routeStat
	slow      [slowCapacity]SlowRequest
	slowNext  int
	slowTotal int64
}{routes: make(map[string]*routeStat)}

// RecordRequest учитывает завершённый запрос. Вызывается из Middleware.
func RecordRequest(method, route string, status int, d time.Duration) {
	thr := SlowThresholdValue()

	reqStats.mu.Lock()
	defer reqStats.mu.Unlock()

	st := reqStats.routes[route]
	if st == nil {
		st = &routeStat{}
		reqStats.routes[route] = st
	}
	st.Count++
	st.TotalNanos += int64(d)
	if int64(d) > st.MaxNanos {
		st.MaxNanos = int64(d)
	}
	switch {
	case status >= 500:
		st.Errors5xx++
	case status >= 400:
		st.Errors4xx++
	}

	if d >= thr {
		st.SlowCount++
		reqStats.slowTotal++
		// Кольцевой буфер: самые свежие долгие запросы вытесняют старые.
		// Именно свежие и нужны — разбираются «почему сейчас медленно».
		reqStats.slow[reqStats.slowNext] = SlowRequest{
			At:         time.Now().UTC().Format("2006-01-02T15:04:05Z"),
			Method:     method,
			Route:      route,
			Status:     status,
			DurationMs: d.Milliseconds(),
		}
		reqStats.slowNext = (reqStats.slowNext + 1) % slowCapacity
	}
}

// Snapshot собирает статистику. Маршруты сортируются по суммарному времени, а
// не по количеству: узкое место — это то, на что система тратит время в
// сумме, а не то, что просто часто вызывается.
func Snapshot(topRoutes int) Stats {
	reqStats.mu.RLock()
	defer reqStats.mu.RUnlock()

	var out Stats
	out.SlowThreshold = SlowThresholdValue().Milliseconds()
	out.SingleProcess = true

	var totalNanos int64
	for route, st := range reqStats.routes {
		out.Requests += st.Count
		totalNanos += st.TotalNanos
		out.Errors4xx += st.Errors4xx
		out.Errors5xx += st.Errors5xx
		out.SlowCount += st.SlowCount
		if st.MaxNanos/1e6 > out.MaxMs {
			out.MaxMs = st.MaxNanos / 1e6
		}
		avg := 0.0
		if st.Count > 0 {
			avg = float64(st.TotalNanos) / float64(st.Count) / 1e6
		}
		out.ByRoute = append(out.ByRoute, RouteSummary{
			Route:     route,
			Count:     st.Count,
			AvgMs:     round1(avg),
			MaxMs:     st.MaxNanos / 1e6,
			SlowCount: st.SlowCount,
			Errors4xx: st.Errors4xx,
			Errors5xx: st.Errors5xx,
			TotalMs:   st.TotalNanos / 1e6,
		})
	}
	if out.Requests > 0 {
		out.AvgMs = round1(float64(totalNanos) / float64(out.Requests) / 1e6)
	}
	for i := range out.ByRoute {
		if totalNanos > 0 {
			out.ByRoute[i].SharePct = round1(float64(out.ByRoute[i].TotalMs) * 1e6 * 100 / float64(totalNanos))
		}
	}
	sort.Slice(out.ByRoute, func(i, j int) bool { return out.ByRoute[i].TotalMs > out.ByRoute[j].TotalMs })
	if topRoutes > 0 && len(out.ByRoute) > topRoutes {
		out.ByRoute = out.ByRoute[:topRoutes]
	}

	// Долгие запросы — от самых свежих к старым.
	n := int(reqStats.slowTotal)
	if n > slowCapacity {
		n = slowCapacity
	}
	for i := 0; i < n; i++ {
		idx := (reqStats.slowNext - 1 - i + slowCapacity*2) % slowCapacity
		out.Slowest = append(out.Slowest, reqStats.slow[idx])
	}
	return out
}

func round1(v float64) float64 {
	return float64(int64(v*10+0.5)) / 10
}
